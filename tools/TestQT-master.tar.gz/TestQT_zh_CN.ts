<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>AddBaslerCameraPage</name>
    <message>
        <location filename="plugins/camera/basler/addbaslercamerapage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/addbaslercamerapage.ui" line="28"/>
        <source>Device Version</source>
        <translation>设备版本</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/addbaslercamerapage.ui" line="42"/>
        <source>Model Name</source>
        <translation>型号</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/addbaslercamerapage.ui" line="68"/>
        <source>Device</source>
        <translation>设备</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/addbaslercamerapage.ui" line="75"/>
        <source>Vendor Name</source>
        <translation>厂商</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/addbaslercamerapage.ui" line="118"/>
        <source>Device ID</source>
        <translation>设备ID</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/addbaslercamerapage.ui" line="125"/>
        <source>Full Name</source>
        <translation>全名</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/addbaslercamerapage.ui" line="132"/>
        <source>User Defined Name</source>
        <translation>用户定义名称</translation>
    </message>
</context>
<context>
    <name>AddCameraDialog</name>
    <message>
        <location filename="src/ui/dialog/device/addcameradialog.ui" line="14"/>
        <location filename="src/ui/dialog/device/addcameradialog.ui" line="123"/>
        <source>Add Camera</source>
        <translation>添加相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addcameradialog.ui" line="37"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addcameradialog.ui" line="59"/>
        <source>Camera Type</source>
        <translation>相机类型</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addcameradialog.cpp" line="56"/>
        <location filename="src/ui/dialog/device/addcameradialog.cpp" line="135"/>
        <source>&lt;font color=&apos;green&apos;&gt;Camera is opened&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;相机已打开&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addcameradialog.cpp" line="110"/>
        <source>&lt;font color=&apos;red&apos;&gt;Camera error %1&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;相机发生错误%1&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addcameradialog.cpp" line="152"/>
        <source>&lt;font color=&apos;red&apos;&gt;Camera name empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;相机名字不能为空&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addcameradialog.cpp" line="176"/>
        <source>&lt;font color=&apos;red&apos;&gt;Camera is invalid&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;相机无效&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>AddCharConfirmDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/addcharconfirmdialog.ui" line="14"/>
        <source>Confirm Add Characters</source>
        <translation>添加字符样本确认</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/addcharconfirmdialog.ui" line="25"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/qss_icons/images/warning-24.png&quot;/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;Warning&lt;/span&gt;&lt;br/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;1.Please check if character segment results are correct;&lt;/span&gt;&lt;br/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;2.Please check if character labels are correct;&lt;/span&gt;&lt;br/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;3.Don&apos;t add wrong characters, it will corrupt existing font file.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <oldsource>&lt;img src=&quot;:/qss_icons/images/warning-24.png&quot;/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;Waring:&lt;/span&gt;&lt;br/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;1.Please check character segment results carefully;&lt;/span&gt;&lt;br/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;2.Don&apos;t add wrong characters, it will corrupt existing font file.&lt;/span&gt;&lt;/body&gt;&lt;/html&gt;</oldsource>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;img src=&quot;:/qss_icons/images/warning-24.png&quot;/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;警告&lt;/span&gt;&lt;br/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;1.请仔细检查字符分割是否正确;&lt;/span&gt;&lt;br/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;2.请仔细检查字符标注是否正确;&lt;/span&gt;&lt;br/&gt;&lt;span style=&quot; font-weight:700;&quot;&gt;3.不要把错误字符加到字体文件.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>AddDahengCameraPage</name>
    <message>
        <location filename="plugins/camera/daheng/adddahengcamerapage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/adddahengcamerapage.ui" line="28"/>
        <source>Device Version</source>
        <translation>设备版本</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/adddahengcamerapage.ui" line="42"/>
        <source>Model Name</source>
        <translation>型号</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/adddahengcamerapage.ui" line="68"/>
        <source>Device</source>
        <translation>设备</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/adddahengcamerapage.ui" line="75"/>
        <source>Vendor Name</source>
        <translation>厂商</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/adddahengcamerapage.ui" line="118"/>
        <source>Device ID</source>
        <translation>设备ID</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/adddahengcamerapage.ui" line="125"/>
        <source>Full Name</source>
        <translation>全名</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/adddahengcamerapage.ui" line="132"/>
        <source>User Defined Name</source>
        <translation>用户定义名称</translation>
    </message>
</context>
<context>
    <name>AddFileCameraPage</name>
    <message>
        <location filename="plugins/camera/imagefile/addfilecamerapage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefile/addfilecamerapage.ui" line="40"/>
        <source>File Path</source>
        <translation>文件路径</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefile/addfilecamerapage.ui" line="59"/>
        <source>Load</source>
        <translation>加载</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefile/addfilecamerapage.cpp" line="19"/>
        <source>Images(*.png *.jpg *.tiff *.tif *.bmp *.dib)</source>
        <translation>图像(*.png *.jpg *.tiff *.tif *.bmp *.dib)</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefile/addfilecamerapage.cpp" line="20"/>
        <source>Open Image File</source>
        <translation>打开图像文件</translation>
    </message>
</context>
<context>
    <name>AddFolderCameraPage</name>
    <message>
        <location filename="plugins/camera/imagefolder/addfoldercamerapage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefolder/addfoldercamerapage.ui" line="40"/>
        <source>Folder Path</source>
        <translation>文件夹路径</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefolder/addfoldercamerapage.ui" line="59"/>
        <source>Load</source>
        <translation>加载</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefolder/addfoldercamerapage.cpp" line="18"/>
        <source>Open Image Folder</source>
        <translation>打开图像文件夹</translation>
    </message>
</context>
<context>
    <name>AddHKGenTLCameraPage</name>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="35"/>
        <source>UserDefinedName</source>
        <translation>用户定义名称</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="54"/>
        <source>Interface</source>
        <translation>接口</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="73"/>
        <source>DeviceID</source>
        <translation>设备ID</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="98"/>
        <source>Device</source>
        <translation>设备</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="112"/>
        <source>TLType</source>
        <translation>类型</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="133"/>
        <source>ModelName</source>
        <translation>型号</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="140"/>
        <source>DisplayName</source>
        <translation>显示名称</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="147"/>
        <source>InterfaceID</source>
        <translation>接口ID</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="161"/>
        <source>SerialNumber</source>
        <translation>系列号</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="175"/>
        <source>VendorName</source>
        <translation>厂商</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/addhkgentlcamerapage.ui" line="182"/>
        <source>DeviceVersion</source>
        <translation>设备版本</translation>
    </message>
</context>
<context>
    <name>AddImageDialog</name>
    <message>
        <location filename="src/ui/dialog/addimagedialog.ui" line="14"/>
        <source>Add Image</source>
        <translation>添加图像</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.ui" line="29"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.ui" line="39"/>
        <source>Source</source>
        <translation>图像源</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.ui" line="61"/>
        <source>Load</source>
        <translation>加载</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.ui" line="107"/>
        <source>Ok</source>
        <translation>确认</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.ui" line="129"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.cpp" line="19"/>
        <source>Images(*.png *.jpg *.tiff *.tif *.bmp *.dib)</source>
        <translation>图像(*.png *.jpg *.tiff *.tif *.bmp *.dib)</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.cpp" line="20"/>
        <source>Load Image File</source>
        <translation>加载图像文件</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.cpp" line="42"/>
        <source>&lt;font color=&apos;red&apos;&gt;Source empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;图像源为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.cpp" line="46"/>
        <source>&lt;font color=&apos;red&apos;&gt;Name empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;名字为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.cpp" line="50"/>
        <source>&lt;font color=&apos;red&apos;&gt;Not an existing file error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;文件不存在错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/addimagedialog.cpp" line="54"/>
        <source>&lt;font color=&apos;red&apos;&gt;Not an file error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;文件无效错误&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>AddLightSourceDialog</name>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="14"/>
        <source>Add Light Source</source>
        <translation>添加光源控制器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="22"/>
        <source>Model</source>
        <translation>型号</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="29"/>
        <source>Num Channels</source>
        <translation>通道数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="36"/>
        <source>Communication Type</source>
        <translation>通信类型</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="57"/>
        <source>Wordop</source>
        <translation>沃德普</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="65"/>
        <source>Vendor</source>
        <translation>厂商</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="76"/>
        <source>Serial Port</source>
        <translation>串口</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="88"/>
        <source>PD4 Family</source>
        <translation>PD4系列</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="93"/>
        <source>PBT4 Family</source>
        <translation>PBT4系列</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="98"/>
        <source>PSC3 Family</source>
        <translation>PSC3系列</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="106"/>
        <source>Communication Device</source>
        <translation>通信设备</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="116"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="184"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addlightsourcedialog.ui" line="206"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>AddNetClientDialog</name>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.ui" line="31"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.ui" line="38"/>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.ui" line="48"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.ui" line="55"/>
        <source>Connect Wait(ms)</source>
        <translation>连接超时(ms)</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.ui" line="111"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.ui" line="127"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.cpp" line="20"/>
        <source>&lt;font color=&apos;red&apos;&gt;Name empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;名字为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.cpp" line="26"/>
        <source>&lt;font color=&apos;red&apos;&gt;Address empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;地址为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.cpp" line="32"/>
        <source>&lt;font color=&apos;red&apos;&gt;Port empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;端口为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.cpp" line="38"/>
        <source>&lt;font color=&apos;red&apos;&gt;Address invalid error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;无效地址错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.cpp" line="46"/>
        <source>&lt;font color=&apos;red&apos;&gt;Port invalid error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;无效端口错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.cpp" line="52"/>
        <source>&lt;font color=&apos;red&apos;&gt;Port out of range error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;端口号超出范围错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetclientdialog.cpp" line="59"/>
        <source>&lt;font color=&apos;red&apos;&gt;Connect wait invalid error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;连接等待时间无效错误&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>AddNetworkDialog</name>
    <message>
        <location filename="src/ui/dialog/device/addnetworkdialog.ui" line="14"/>
        <source>Add Network</source>
        <translation>添加网络</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetworkdialog.ui" line="25"/>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetworkdialog.ui" line="35"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetworkdialog.ui" line="42"/>
        <source>IP Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetworkdialog.ui" line="104"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetworkdialog.ui" line="126"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetworkdialog.cpp" line="40"/>
        <source>&lt;font color=&apos;red&apos;&gt;Name empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;名字为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addnetworkdialog.cpp" line="48"/>
        <source>&lt;font color=&apos;red&apos;&gt;Invalid port error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;无效端口错误&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>AddOCRFontDialog</name>
    <message>
        <source>Add OCR Font</source>
        <translation type="vanished">添加新OCR字体</translation>
    </message>
    <message>
        <source>Camera</source>
        <translation type="vanished">相机</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="vanished">触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <source>Polarity</source>
        <translation type="vanished">极性</translation>
    </message>
    <message>
        <source>Add Sample</source>
        <translation type="vanished">添加样本</translation>
    </message>
    <message>
        <source>Font Name</source>
        <translation type="vanished">字体名字</translation>
    </message>
    <message>
        <source>Dark On Light</source>
        <translation type="vanished">暗字符</translation>
    </message>
    <message>
        <source>Light On Dark</source>
        <translation type="vanished">亮字符</translation>
    </message>
    <message>
        <source>Both</source>
        <translation type="vanished">两者都有</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">方位角</translation>
    </message>
    <message>
        <source>Segment</source>
        <translation type="vanished">分割</translation>
    </message>
    <message>
        <source>Train</source>
        <translation type="vanished">训练</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">名字</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="vanished">值</translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="vanished">选择</translation>
    </message>
    <message>
        <source>Feature</source>
        <translation type="vanished">特征</translation>
    </message>
    <message>
        <source>Rectify</source>
        <translation type="vanished">矫正</translation>
    </message>
    <message>
        <source>Sample</source>
        <translation type="vanished">样本</translation>
    </message>
    <message>
        <source>Save Sample</source>
        <translation type="vanished">保存样本</translation>
    </message>
    <message>
        <source>Edit Sample</source>
        <oldsource>Pack Sample</oldsource>
        <translation type="vanished">编辑样本</translation>
    </message>
    <message>
        <source>Char Size(w/h)</source>
        <oldsource>Char Box Size(w/h)</oldsource>
        <translation type="vanished">字符尺寸(宽/高)</translation>
    </message>
    <message>
        <source>Segment Algorithm</source>
        <translation type="vanished">分割算法</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">搜索</translation>
    </message>
    <message>
        <source>Min Confidence</source>
        <translation type="vanished">最小得分</translation>
    </message>
    <message>
        <source>Positioning</source>
        <translation type="vanished">定位</translation>
    </message>
    <message>
        <source>OCR</source>
        <translation type="vanished">光学字符识别</translation>
    </message>
    <message>
        <source>Char Box</source>
        <translation type="vanished">字符框</translation>
    </message>
    <message>
        <source>Hide Char Box</source>
        <translation type="vanished">隐藏字符框</translation>
    </message>
    <message>
        <source>Sample Char Box</source>
        <translation type="vanished">显示字符样本框</translation>
    </message>
    <message>
        <source>Search Char Box</source>
        <translation type="vanished">显示字符搜索框</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="vanished">创建</translation>
    </message>
    <message>
        <source>Fixed</source>
        <translation type="vanished">固定</translation>
    </message>
    <message>
        <source>Load Font</source>
        <translation type="vanished">加载字体</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="vanished">输出</translation>
    </message>
    <message>
        <source>Y Resolution(μm)</source>
        <translation type="vanished">竖直方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>X Resolution(μm)</source>
        <translation type="vanished">水平方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Font file not exists&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;字体文件不存在&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Font name empty error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;字体名字为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;No samples in %1&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;%1里面没有样本&lt;/font&gt;</translation>
    </message>
    <message>
        <source>Char segemnt error</source>
        <translation type="vanished">字符分割错误</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Font name invalid error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;字体名字无效错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Empty char box error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;字符框为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Invalid char name error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;字符名字无效错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Traing final error: %1&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;green&apos;&gt;最终训练误差: %1&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Traing samples failed with error message: %1&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;样本训练失败: %1&lt;/font&gt;</translation>
    </message>
    <message>
        <source>Change Parameter %1</source>
        <translation type="vanished">修改%1</translation>
    </message>
    <message>
        <source>Error</source>
        <translation type="vanished">错误</translation>
    </message>
    <message>
        <source>Invalid parameters value %1</source>
        <translation type="vanished">参数值%1无效</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation type="vanished">丢弃修改</translation>
    </message>
    <message>
        <source>Parameter changed. Are you sure you want to discard changes?</source>
        <translation type="vanished">你确定要丢弃参数修改吗?</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Saved %1 of total %2 sample(s)&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;green&apos;&gt;保存总共%2个样本中的%1个&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Saved %1 of total %2 sample(s)&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;保存总共%2个样本中的%1个&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>AddProjectDialog</name>
    <message>
        <location filename="src/ui/dialog/project/addprojectdialog.ui" line="20"/>
        <source>Add Project</source>
        <translation>添加项目</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/addprojectdialog.ui" line="43"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/addprojectdialog.ui" line="78"/>
        <source>Project Path</source>
        <translation>项目路径</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/addprojectdialog.ui" line="119"/>
        <source>Only accept character, number and underline and not start with number.</source>
        <translation>只接受字母数字和下划线并且不能以数字开头。</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/addprojectdialog.ui" line="126"/>
        <source>Project Name</source>
        <translation>项目名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/addprojectdialog.cpp" line="36"/>
        <source>Open Project File</source>
        <translation>打开项目文件</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/addprojectdialog.cpp" line="36"/>
        <source>Laser X Project Files (*.db *.lxp)</source>
        <translation>项目文件(*.db *.lxp)</translation>
    </message>
</context>
<context>
    <name>AddSerialPortDialog</name>
    <message>
        <location filename="src/ui/dialog/device/addserialportdialog.ui" line="14"/>
        <source>Add Serial Port</source>
        <translation>添加串口</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addserialportdialog.ui" line="28"/>
        <source>PortName</source>
        <translation>端口名</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addserialportdialog.ui" line="33"/>
        <source>SystemLocation</source>
        <translation>系统位置</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addserialportdialog.ui" line="38"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addserialportdialog.ui" line="51"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/addserialportdialog.ui" line="61"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>AddUserDialog</name>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="20"/>
        <source>Add User</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="35"/>
        <source>Group</source>
        <translation>群组</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="77"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="94"/>
        <source>Operator</source>
        <translation>操作员</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="99"/>
        <source>Engineer</source>
        <translation>工程师</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="107"/>
        <source>User Name</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="121"/>
        <source>Confirm Password</source>
        <translation>密码确认</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="164"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.ui" line="171"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.cpp" line="26"/>
        <source>Name empty error</source>
        <translation>名字空错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.cpp" line="30"/>
        <source>Password empty error</source>
        <translation>密码空错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.cpp" line="34"/>
        <source>Confirm password empty error</source>
        <translation>确认密码空错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.cpp" line="38"/>
        <source>Confirm password error</source>
        <translation>确认密码错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.cpp" line="45"/>
        <source>User exist error</source>
        <translation>用户已经存在错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.cpp" line="54"/>
        <source>Add user success</source>
        <translation>成功添加用户</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/adduserdialog.cpp" line="58"/>
        <source>Add user error</source>
        <translation>添加用户错误</translation>
    </message>
</context>
<context>
    <name>AddVideoCameraPage</name>
    <message>
        <location filename="plugins/camera/videofile/addvideocamerapage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/videofile/addvideocamerapage.ui" line="43"/>
        <source>Video Path</source>
        <translation>视频文件路径</translation>
    </message>
    <message>
        <location filename="plugins/camera/videofile/addvideocamerapage.ui" line="62"/>
        <source>Load</source>
        <translation>加载</translation>
    </message>
    <message>
        <location filename="plugins/camera/videofile/addvideocamerapage.cpp" line="18"/>
        <source>Videos(*.mp4 *.avi)</source>
        <translation>视频文件(*.mp4 *.avi)</translation>
    </message>
    <message>
        <location filename="plugins/camera/videofile/addvideocamerapage.cpp" line="19"/>
        <source>Open Video File</source>
        <translation>打开视频文件</translation>
    </message>
</context>
<context>
    <name>BarTester00</name>
    <message>
        <location filename="src/resources/ui/BarTester00.ui" line="14"/>
        <source>Frame</source>
        <translation>边框</translation>
    </message>
    <message>
        <location filename="src/resources/ui/BarTester00.ui" line="95"/>
        <source>Live Control</source>
        <translation>相机实时显示控制</translation>
    </message>
    <message>
        <location filename="src/resources/ui/BarTester00.ui" line="125"/>
        <source>CamLeft</source>
        <oldsource>Cam2</oldsource>
        <translation>左相机</translation>
    </message>
    <message>
        <location filename="src/resources/ui/BarTester00.ui" line="138"/>
        <source>CamBot</source>
        <oldsource>Cam3</oldsource>
        <translation>下相机</translation>
    </message>
    <message>
        <location filename="src/resources/ui/BarTester00.ui" line="158"/>
        <source>CamTop</source>
        <translation>上相机</translation>
    </message>
    <message>
        <location filename="src/resources/ui/BarTester00.ui" line="171"/>
        <source>CamRight</source>
        <translation>右相机</translation>
    </message>
    <message>
        <source>Cam1</source>
        <translation type="vanished">相机1</translation>
    </message>
    <message>
        <source>Cam4</source>
        <translation type="vanished">相机4</translation>
    </message>
    <message>
        <location filename="src/resources/ui/BarTester00.ui" line="145"/>
        <source>Stop All Live</source>
        <translation>停止所有</translation>
    </message>
</context>
<context>
    <name>BlobFinder</name>
    <message>
        <source>Threshold</source>
        <translation type="vanished">阈值</translation>
    </message>
    <message>
        <source>Area</source>
        <translation type="vanished">面积</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="vanished">宽度</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="vanished">高度</translation>
    </message>
    <message>
        <source>Max Diameter</source>
        <translation type="vanished">最长直径</translation>
    </message>
    <message>
        <source>Rectangularity</source>
        <translation type="vanished">矩形度</translation>
    </message>
    <message>
        <source>Circularity</source>
        <translation type="vanished">圆度</translation>
    </message>
    <message>
        <source>Outer Radius</source>
        <translation type="vanished">外接圆半径</translation>
    </message>
    <message>
        <source>Inner Radius</source>
        <translation type="vanished">内接圆半径</translation>
    </message>
    <message>
        <source>Anisometry</source>
        <translation type="vanished">偏心率</translation>
    </message>
    <message>
        <source>Area Holes</source>
        <translation type="vanished">孔面积</translation>
    </message>
    <message>
        <source>Holes Num</source>
        <translation type="vanished">孔数</translation>
    </message>
    <message>
        <source>Center Y</source>
        <translation type="vanished">中心Y</translation>
    </message>
    <message>
        <source>Center X</source>
        <translation type="vanished">中心X</translation>
    </message>
    <message>
        <source>Compactness</source>
        <translation type="vanished">紧凑度</translation>
    </message>
    <message>
        <source>Contour Length</source>
        <translation type="vanished">轮廓长度</translation>
    </message>
    <message>
        <source>Convexity</source>
        <translation type="vanished">凸度</translation>
    </message>
    <message>
        <source>Major Radius</source>
        <translation type="vanished">同等椭圆长半轴</translation>
    </message>
    <message>
        <source>Minor Radius</source>
        <translation type="vanished">同等椭圆短半轴</translation>
    </message>
    <message>
        <source>Ellipse Angle</source>
        <oldsource>Ellipse Orientation</oldsource>
        <translation type="vanished">同等椭圆角</translation>
    </message>
    <message>
        <source>Bulkiness</source>
        <translation type="vanished">膨松度</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="vanished">方位角</translation>
    </message>
    <message>
        <source>Euler Number</source>
        <translation type="vanished">欧拉数</translation>
    </message>
    <message>
        <source>Rect Angle</source>
        <translation type="vanished">最小矩形角度</translation>
    </message>
    <message>
        <source>Half Length</source>
        <translation type="vanished">最小矩形半长</translation>
    </message>
    <message>
        <source>Half Width</source>
        <translation type="vanished">最小矩形半宽</translation>
    </message>
    <message>
        <source>Mean Gray</source>
        <translation type="vanished">平均灰度</translation>
    </message>
    <message>
        <source>M11 Invariant Moments</source>
        <translation type="vanished">M11不变矩</translation>
    </message>
    <message>
        <source>Noise Radius</source>
        <translation type="vanished">噪声半径</translation>
    </message>
    <message>
        <source>Background Mask Size</source>
        <translation type="vanished">背景遮罩尺寸</translation>
    </message>
    <message>
        <source>Contrast</source>
        <translation type="vanished">对比度</translation>
    </message>
    <message>
        <source>Struct Factor</source>
        <translation type="vanished">结构系数</translation>
    </message>
    <message>
        <source>Unknown</source>
        <translation type="vanished">未知</translation>
    </message>
</context>
<context>
    <name>BlobFinderDialog</name>
    <message>
        <source>Blob Finder</source>
        <translation type="vanished">区域分割</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="36"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="37"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="38"/>
        <source>Blob Search</source>
        <translation>Blob搜索</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">搜索</translation>
    </message>
    <message>
        <source>Shape</source>
        <translation type="vanished">形状</translation>
    </message>
    <message>
        <source>Number of Objects</source>
        <translation type="vanished">目标数</translation>
    </message>
    <message>
        <source>Rectangle</source>
        <translation type="vanished">矩形</translation>
    </message>
    <message>
        <source>Circle</source>
        <translation type="vanished">圆</translation>
    </message>
    <message>
        <source>Ellipse</source>
        <translation type="vanished">椭圆</translation>
    </message>
    <message>
        <source>Free Shape</source>
        <translation type="vanished">自由形状</translation>
    </message>
    <message>
        <source>Algorithm</source>
        <translation type="vanished">算法</translation>
    </message>
    <message>
        <source>Features</source>
        <translation type="vanished">特征</translation>
    </message>
    <message>
        <source>Feature</source>
        <translation type="vanished">特征</translation>
    </message>
    <message>
        <source>Min</source>
        <translation type="vanished">最小值</translation>
    </message>
    <message>
        <source>Max</source>
        <translation type="vanished">最大值</translation>
    </message>
    <message>
        <source>Threshold</source>
        <translation type="vanished">阈值</translation>
    </message>
    <message>
        <source>128</source>
        <translation type="vanished">128</translation>
    </message>
    <message>
        <source>255</source>
        <translation type="vanished">255</translation>
    </message>
    <message>
        <source>Area</source>
        <translation type="vanished">面积</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="vanished">1</translation>
    </message>
    <message>
        <source>100</source>
        <translation type="vanished">100</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="39"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <source>Y Resolution(μm)</source>
        <translation type="vanished">竖直方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="obsolete">发送结果使用</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>X Resolution(μm)</source>
        <translation type="vanished">水平方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>New Value</source>
        <translation type="vanished">新值</translation>
    </message>
    <message>
        <source>Add Feature</source>
        <translation type="vanished">添加特征</translation>
    </message>
    <message>
        <source>Delete Feature</source>
        <translation type="vanished">删除特征</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation type="vanished">丢弃修改</translation>
    </message>
    <message>
        <source>Parameter changed. Are you sure you want to discard changes?</source>
        <translation type="vanished">你确定要丢弃参数修改吗?</translation>
    </message>
</context>
<context>
    <name>BlobSearcher</name>
    <message>
        <source>Threshold</source>
        <translation type="obsolete">阈值</translation>
    </message>
    <message>
        <source>Area</source>
        <translation type="obsolete">面积</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="obsolete">宽度</translation>
    </message>
    <message>
        <source>Height</source>
        <translation type="obsolete">高度</translation>
    </message>
    <message>
        <source>Max Diameter</source>
        <translation type="obsolete">最长直径</translation>
    </message>
    <message>
        <source>Rectangularity</source>
        <translation type="obsolete">矩形度</translation>
    </message>
    <message>
        <source>Circularity</source>
        <translation type="obsolete">圆度</translation>
    </message>
    <message>
        <source>Outer Radius</source>
        <translation type="obsolete">外接圆半径</translation>
    </message>
    <message>
        <source>Inner Radius</source>
        <translation type="obsolete">内接圆半径</translation>
    </message>
    <message>
        <source>Anisometry</source>
        <translation type="obsolete">偏心率</translation>
    </message>
    <message>
        <source>Area Holes</source>
        <translation type="obsolete">孔面积</translation>
    </message>
    <message>
        <source>Holes Num</source>
        <translation type="obsolete">孔数</translation>
    </message>
    <message>
        <source>Center Y</source>
        <translation type="obsolete">中心Y</translation>
    </message>
    <message>
        <source>Center X</source>
        <translation type="obsolete">中心X</translation>
    </message>
    <message>
        <source>Compactness</source>
        <translation type="obsolete">紧凑度</translation>
    </message>
    <message>
        <source>Contour Length</source>
        <translation type="obsolete">轮廓长度</translation>
    </message>
    <message>
        <source>Convexity</source>
        <translation type="obsolete">凸度</translation>
    </message>
    <message>
        <source>Major Radius</source>
        <translation type="obsolete">同等椭圆长半轴</translation>
    </message>
    <message>
        <source>Minor Radius</source>
        <translation type="obsolete">同等椭圆短半轴</translation>
    </message>
    <message>
        <source>Ellipse Angle</source>
        <translation type="obsolete">同等椭圆角</translation>
    </message>
    <message>
        <source>Bulkiness</source>
        <translation type="obsolete">膨松度</translation>
    </message>
    <message>
        <source>Orientation</source>
        <translation type="obsolete">方位角</translation>
    </message>
    <message>
        <source>Euler Number</source>
        <translation type="obsolete">欧拉数</translation>
    </message>
    <message>
        <source>Rect Angle</source>
        <translation type="obsolete">最小矩形角度</translation>
    </message>
    <message>
        <source>Half Length</source>
        <translation type="obsolete">最小矩形半长</translation>
    </message>
    <message>
        <source>Mean Gray</source>
        <translation type="obsolete">平均灰度</translation>
    </message>
</context>
<context>
    <name>BlobSearcherPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="57"/>
        <source>Algorithm</source>
        <translation>算法</translation>
    </message>
    <message>
        <source>Number of Objects</source>
        <translation type="vanished">目标数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="50"/>
        <source>Shape</source>
        <translation>形状</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="43"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="20"/>
        <source>Hide ROI</source>
        <translation>隐藏ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="64"/>
        <source>ROI</source>
        <translation>ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="78"/>
        <source>Rectangle</source>
        <translation>矩形</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="87"/>
        <source>Circle</source>
        <translation>圆</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="96"/>
        <source>Ellipse</source>
        <translation>椭圆</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="105"/>
        <source>Free Shape</source>
        <translation>自由形状</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="121"/>
        <source>Options</source>
        <translation>选项</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="155"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="160"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="169"/>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.cpp" line="230"/>
        <source>Features</source>
        <translation>特征</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="209"/>
        <source>Feature</source>
        <translation>特征</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="214"/>
        <source>Min</source>
        <translation>最小值</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="219"/>
        <source>Max</source>
        <translation>最大值</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="231"/>
        <source>Show Search ROI</source>
        <translation>显示搜索ROI</translation>
    </message>
    <message>
        <source>Threshold</source>
        <translation type="vanished">阈值</translation>
    </message>
    <message>
        <source>128</source>
        <translation type="vanished">128</translation>
    </message>
    <message>
        <source>255</source>
        <translation type="vanished">255</translation>
    </message>
    <message>
        <source>Area</source>
        <translation type="vanished">面积</translation>
    </message>
    <message>
        <source>1</source>
        <translation type="vanished">1</translation>
    </message>
    <message>
        <source>100</source>
        <translation type="vanished">100</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.ui" line="30"/>
        <source>Parameter</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.cpp" line="94"/>
        <source>New Value</source>
        <translation>新值</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.cpp" line="124"/>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.cpp" line="230"/>
        <source>Add Feature</source>
        <translation>添加特征</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.cpp" line="127"/>
        <source>Delete Feature</source>
        <translation>删除特征</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.cpp" line="148"/>
        <source>Add Option</source>
        <translation>添加选项</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/blobsearcherpage.cpp" line="151"/>
        <source>Delete Option</source>
        <translation>删除选项</translation>
    </message>
</context>
<context>
    <name>CameraDialog</name>
    <message>
        <location filename="src/ui/dialog/device/cameradialog.ui" line="14"/>
        <source>Camera Manager</source>
        <translation>相机管理</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/cameradialog.ui" line="74"/>
        <location filename="src/ui/dialog/device/cameradialog.ui" line="96"/>
        <source>T</source>
        <translation>T</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/cameradialog.ui" line="85"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/cameradialog.cpp" line="106"/>
        <source>Confirm Delete Camera</source>
        <translation>删除相机确认</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/cameradialog.cpp" line="107"/>
        <source>Are you sure you want to delete camera %1</source>
        <translation>你确定要删除相机%1</translation>
    </message>
</context>
<context>
    <name>CameraForm</name>
    <message>
        <location filename="src/ui/dialog/device/cameraform.ui" line="20"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/cameraform.ui" line="84"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/cameraform.ui" line="264"/>
        <source>Ready</source>
        <translation>就绪</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/cameraform.cpp" line="187"/>
        <source>&lt;font color=&apos;red&apos;&gt;Camera error %1&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;相机发生错误%1&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/cameraform.cpp" line="199"/>
        <source>&lt;font color=&apos;green&apos;&gt;%1 changed to %2&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;%1变为%2&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>CameraPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.ui" line="22"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.ui" line="35"/>
        <source>Light Source</source>
        <translation>光源</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.ui" line="55"/>
        <source>Controller</source>
        <translation>控制器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.ui" line="60"/>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="145"/>
        <source>Channel</source>
        <translation>通道</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.ui" line="65"/>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="152"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.ui" line="70"/>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="159"/>
        <source>Brightness</source>
        <translation>亮度</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="145"/>
        <source>Set Light Source Channel</source>
        <translation>设置光源通道</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="152"/>
        <source>Set Light Source Status</source>
        <translation>设置光源状态</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="159"/>
        <source>Set Light Source Brightness</source>
        <translation>设置光源亮度</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="176"/>
        <source>Add Light Source</source>
        <translation>添加光源控制器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="177"/>
        <source>Light Sources</source>
        <translation>光源</translation>
    </message>
</context>
<context>
    <name>CanvasScene</name>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="47"/>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="49"/>
        <source>Reverse</source>
        <translation>反向</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="50"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="52"/>
        <source>Move Back</source>
        <translation>向后移</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="53"/>
        <source>Move Front</source>
        <translation>向前移</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="55"/>
        <source>Change Width</source>
        <translation>修改宽度</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="56"/>
        <source>Change Height</source>
        <translation>修改高度</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="128"/>
        <source>New Name</source>
        <translation>新名字</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="143"/>
        <source>Change Char</source>
        <translation>修改字符</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="241"/>
        <source>New Width</source>
        <translation>新宽度</translation>
    </message>
    <message>
        <location filename="laserxwidgets/canvas_scene.cpp" line="269"/>
        <source>New Height</source>
        <translation>新高度</translation>
    </message>
</context>
<context>
    <name>ChartFrame</name>
    <message>
        <location filename="src/resources/ui/charts.ui" line="14"/>
        <source>Frame</source>
        <translation>框架</translation>
    </message>
    <message>
        <location filename="src/resources/ui/charts.ui" line="22"/>
        <source>Theme:</source>
        <translation>主题：</translation>
    </message>
    <message>
        <location filename="src/resources/ui/charts.ui" line="32"/>
        <source>Animation:</source>
        <translation>动画：</translation>
    </message>
    <message>
        <location filename="src/resources/ui/charts.ui" line="42"/>
        <source>Legend:</source>
        <translation>标题：</translation>
    </message>
    <message>
        <location filename="src/resources/ui/charts.ui" line="52"/>
        <source>Anti-aliasing</source>
        <translation>抗混叠</translation>
    </message>
</context>
<context>
    <name>CircleTemplateDialog</name>
    <message>
        <source>Circle Template</source>
        <translation type="vanished">圆模板</translation>
    </message>
    <message>
        <source>Camera</source>
        <translation type="vanished">相机</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="vanished">触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="vanished">创建模板</translation>
    </message>
    <message>
        <source>Scaled</source>
        <translation type="vanished">缩放</translation>
    </message>
    <message>
        <source>Scale Min</source>
        <translation type="vanished">最小缩放</translation>
    </message>
    <message>
        <source>Use Polarity</source>
        <translation type="vanished">使用极性</translation>
    </message>
    <message>
        <source>Radius</source>
        <translation type="vanished">半径</translation>
    </message>
    <message>
        <source>Bright</source>
        <translation type="vanished">明亮</translation>
    </message>
    <message>
        <source>Scale Max</source>
        <translation type="vanished">最小缩放</translation>
    </message>
    <message>
        <source>Min Contrast</source>
        <translation type="vanished">最小对比度</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">搜索</translation>
    </message>
    <message>
        <source>Greediness</source>
        <translation type="vanished">贪婪度</translation>
    </message>
    <message>
        <source>Sub Pixel</source>
        <translation type="vanished">亚像素</translation>
    </message>
    <message>
        <source>Min Score</source>
        <translation type="vanished">最小得分</translation>
    </message>
    <message>
        <source>Num Matches</source>
        <translation type="vanished">匹配数</translation>
    </message>
    <message>
        <source>Stop Level</source>
        <translation type="vanished">停止层</translation>
    </message>
    <message>
        <source>Start Level</source>
        <translation type="vanished">起始层</translation>
    </message>
    <message>
        <source>Max Deformation</source>
        <translation type="vanished">最大畸变</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="vanished">输出</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation type="vanished">保存图像</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">保存所有</translation>
    </message>
    <message>
        <source>Save Data</source>
        <translation type="vanished">保存结果数据</translation>
    </message>
    <message>
        <source>X Resolution</source>
        <translation type="vanished">水平方向分辨率</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="vanished">发送结果使用</translation>
    </message>
    <message>
        <source>Y Resolution</source>
        <translation type="vanished">竖直方向分辨率</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">不保存</translation>
    </message>
    <message>
        <source>ErrorOnly</source>
        <translation type="vanished">只保存错误</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Image empty error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;图像空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Template region empty error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;模板区域空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Template preview success&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;green&apos;&gt;预览模板成功&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Found %1 matches&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;green&apos;&gt;找到%1个匹配&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Template not found&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;模板没有找到&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>ClosingDeviceDialog</name>
    <message>
        <location filename="src/ui/dialog/device/closingdevicedialog.ui" line="14"/>
        <source>Closing Devices</source>
        <translation>正在关闭设备</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/closingdevicedialog.ui" line="20"/>
        <source>Closing devices...</source>
        <translation>正在关闭设备...</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/closingdevicedialog.cpp" line="34"/>
        <source>Closing serial port %1 ...</source>
        <translation>正在关闭串口%1...</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/closingdevicedialog.cpp" line="37"/>
        <source>Serial port %1 closed</source>
        <translation>串口%1关闭成功</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/closingdevicedialog.cpp" line="44"/>
        <source>Closing network listener %1 ...</source>
        <translation>正在关闭网络服务器%1...</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/closingdevicedialog.cpp" line="48"/>
        <source>Network listener %1 closed</source>
        <translation>网络服务器%1关闭成功</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/closingdevicedialog.cpp" line="58"/>
        <source>Closing camera %1 ...</source>
        <translation>正在关闭相机%1...</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/closingdevicedialog.cpp" line="62"/>
        <source>Camera %1 closed</source>
        <translation>相机%1关闭成功</translation>
    </message>
</context>
<context>
    <name>CompoundDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="348"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="349"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="350"/>
        <source>Compound</source>
        <translation>复合</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="351"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
</context>
<context>
    <name>CompoundPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/compoundpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/compoundpage.ui" line="22"/>
        <source>Compound Type</source>
        <translation>复合类型</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/compoundpage.ui" line="30"/>
        <source>Any</source>
        <translation>任意</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/compoundpage.ui" line="35"/>
        <source>All</source>
        <translation>所有</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/compoundpage.ui" line="54"/>
        <source>Any sub procedure succeeded</source>
        <translation>任意子过程成功就返回</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/compoundpage.ui" line="64"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
</context>
<context>
    <name>CompoundProcess</name>
    <message>
        <location filename="src/procedure/compoundprocess.cpp" line="76"/>
        <source>Compound type %1 not supported yet</source>
        <translation>复合命令类型%1尚不支持</translation>
    </message>
    <message>
        <location filename="src/procedure/compoundprocess.cpp" line="97"/>
        <source>Invalid procedure found in %1</source>
        <translation>在%1发现无效步骤</translation>
    </message>
    <message>
        <location filename="src/procedure/compoundprocess.cpp" line="109"/>
        <source>Only need one shape template</source>
        <translation>只需要一个形状模板</translation>
    </message>
    <message>
        <location filename="src/procedure/compoundprocess.cpp" line="119"/>
        <source>Procedure type %1 not supported yet</source>
        <translation>尚不支持步骤类型%1</translation>
    </message>
    <message>
        <location filename="src/procedure/compoundprocess.cpp" line="128"/>
        <source>No template matching procedure found</source>
        <translation>没有发现模板匹配步骤</translation>
    </message>
    <message>
        <location filename="src/procedure/compoundprocess.cpp" line="134"/>
        <source>No geometry measure procedure found</source>
        <translation>没有发现几何测量步骤</translation>
    </message>
    <message>
        <location filename="src/procedure/compoundprocess.cpp" line="140"/>
        <source>Matching procedure must precede all measure procedures</source>
        <translation>匹配步骤必须在所有其他步骤之前</translation>
    </message>
</context>
<context>
    <name>CompoundProcessDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="14"/>
        <source>Geometry Measure</source>
        <translation>几何测量</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="104"/>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="122"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="143"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="151"/>
        <source>Command Name</source>
        <translation>命令名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="175"/>
        <source>Sub Procedures</source>
        <translation>子过程</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="183"/>
        <source>Compound Type</source>
        <translation>复合类型</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="191"/>
        <source>Any</source>
        <translation>任意</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="196"/>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="308"/>
        <source>All</source>
        <translation>所有</translation>
    </message>
    <message>
        <source>Positioning and Measure</source>
        <translation type="vanished">定位加测量</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="215"/>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="113"/>
        <source>Any sub procedure succeeded</source>
        <translation>任意子过程成功就返回</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="225"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="243"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="258"/>
        <source>Save Image</source>
        <translation>保存图像</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="295"/>
        <source>Display In</source>
        <translation>结果显示在</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="285"/>
        <source>X Resolution</source>
        <translation>水平方向分辨率</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="265"/>
        <source>Y Resolution</source>
        <translation>竖直方向分辨率</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="vanished">发送结果使用</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="275"/>
        <source>Save Data</source>
        <translation>保存结果数据</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="303"/>
        <source>None</source>
        <translation>不保存</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="313"/>
        <source>ErrorOnly</source>
        <translation>只保存错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="361"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.ui" line="371"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="114"/>
        <source>All sub procedures succeeded</source>
        <translation>所有子过程成功才返回</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="145"/>
        <source>Add Sub Procedure</source>
        <translation>添加子过程</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="146"/>
        <source>Procedures</source>
        <translation>过程</translation>
    </message>
</context>
<context>
    <name>ConfigBaslerCameraPage</name>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="20"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="34"/>
        <source>GammaEnable</source>
        <translation>伽马使能</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="53"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="60"/>
        <source>TriggerDelay(us)</source>
        <translation>触发延时(us)</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="67"/>
        <source>ExposureTime(us)</source>
        <translation>曝光时间(us)</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="74"/>
        <source>Sharpness</source>
        <translation>锐度</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="81"/>
        <source>Gamma</source>
        <translation>伽马</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="88"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.ui" line="95"/>
        <source>Gain</source>
        <translation>增益</translation>
    </message>
    <message>
        <location filename="plugins/camera/basler/configbaslercamerapage.cpp" line="22"/>
        <location filename="plugins/camera/basler/configbaslercamerapage.cpp" line="27"/>
        <location filename="plugins/camera/basler/configbaslercamerapage.cpp" line="32"/>
        <location filename="plugins/camera/basler/configbaslercamerapage.cpp" line="37"/>
        <location filename="plugins/camera/basler/configbaslercamerapage.cpp" line="42"/>
        <source>Range: %1..%2</source>
        <translation>范围: %1..%2</translation>
    </message>
</context>
<context>
    <name>ConfigDahengCameraPage</name>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="20"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="34"/>
        <source>GammaEnable</source>
        <translation>伽马使能</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="53"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="60"/>
        <source>TriggerDelay(us)</source>
        <translation>触发延时(us)</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="67"/>
        <source>ExposureTime(us)</source>
        <translation>曝光时间(us)</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="74"/>
        <source>Sharpness</source>
        <translation>锐度</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="81"/>
        <source>Gamma</source>
        <translation>伽马</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="88"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.ui" line="95"/>
        <source>Gain</source>
        <translation>增益</translation>
    </message>
    <message>
        <location filename="plugins/camera/daheng/configdahengcamerapage.cpp" line="22"/>
        <location filename="plugins/camera/daheng/configdahengcamerapage.cpp" line="27"/>
        <location filename="plugins/camera/daheng/configdahengcamerapage.cpp" line="32"/>
        <location filename="plugins/camera/daheng/configdahengcamerapage.cpp" line="37"/>
        <location filename="plugins/camera/daheng/configdahengcamerapage.cpp" line="42"/>
        <source>Range: %1..%2</source>
        <translation>范围: %1..%2</translation>
    </message>
</context>
<context>
    <name>ConfigFileCameraPage</name>
    <message>
        <location filename="plugins/camera/imagefile/configfilecamerapage.ui" line="20"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefile/configfilecamerapage.ui" line="37"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefile/configfilecamerapage.ui" line="47"/>
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefile/configfilecamerapage.ui" line="57"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
</context>
<context>
    <name>ConfigFolderCameraPage</name>
    <message>
        <location filename="plugins/camera/imagefolder/configfoldercamerapage.ui" line="20"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefolder/configfoldercamerapage.ui" line="34"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefolder/configfoldercamerapage.ui" line="47"/>
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <location filename="plugins/camera/imagefolder/configfoldercamerapage.ui" line="57"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
</context>
<context>
    <name>ConfigHikGenTLCameraPage</name>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="20"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="48"/>
        <source>TriggerDelay(us)</source>
        <translation>触发延时(us)</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="61"/>
        <source>Gamma</source>
        <translation>伽马</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="68"/>
        <source>Sharpness</source>
        <translation>锐度</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="75"/>
        <source>ExposureTime(us)</source>
        <translation>曝光时间(us)</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="82"/>
        <source>BlackLevel</source>
        <translation>黑色水平</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="98"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="105"/>
        <source>GammaEnable</source>
        <translation>伽马使能</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="122"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="plugins/camera/hkgentl/confighikgentlcamerapage.ui" line="129"/>
        <source>Gain</source>
        <translation>增益</translation>
    </message>
</context>
<context>
    <name>ConfigPage</name>
    <message>
        <location filename="src/ui/configpage.cpp" line="50"/>
        <source>Image Acquisition</source>
        <translation>图像采集</translation>
    </message>
    <message>
        <location filename="src/ui/configpage.cpp" line="51"/>
        <source>Positioning</source>
        <translation>定位</translation>
    </message>
    <message>
        <location filename="src/ui/configpage.cpp" line="52"/>
        <source>Trigger / Event</source>
        <translation>触发/事件</translation>
    </message>
    <message>
        <location filename="src/ui/configpage.cpp" line="53"/>
        <source>OCR</source>
        <translation>光学字符识别</translation>
    </message>
</context>
<context>
    <name>ConfigVideoCameraPage</name>
    <message>
        <location filename="plugins/camera/videofile/configvideocamerapage.ui" line="20"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="plugins/camera/videofile/configvideocamerapage.ui" line="37"/>
        <source>Path</source>
        <translation>路径</translation>
    </message>
    <message>
        <location filename="plugins/camera/videofile/configvideocamerapage.ui" line="50"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="plugins/camera/videofile/configvideocamerapage.ui" line="57"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
</context>
<context>
    <name>CustomOCRDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="231"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="232"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="233"/>
        <source>Custom OCR</source>
        <translation>定制OCR</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="234"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
</context>
<context>
    <name>CustomOCRPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="28"/>
        <source>Char Box</source>
        <translation>字符框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="35"/>
        <source>Hide Char Box</source>
        <translation>隐藏字符框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="42"/>
        <source>Sample Char Box</source>
        <translation>显示字符样本框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="49"/>
        <source>Search Char Box</source>
        <translation>显示字符搜索框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="62"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="88"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="267"/>
        <source>Train</source>
        <translation>训练</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="95"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="143"/>
        <source>Segment</source>
        <translation>分割</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="105"/>
        <source>Font Name</source>
        <translation>字体名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="115"/>
        <source>Add Sample</source>
        <translation>添加样本</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="132"/>
        <source>Rectify</source>
        <translation>矫正</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="177"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="228"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="301"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="182"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="233"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="306"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="191"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="242"/>
        <source>Feature</source>
        <translation>特征</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="318"/>
        <source>Save Sample</source>
        <translation>保存样本</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="341"/>
        <source>Orientation</source>
        <translation>方位角</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="354"/>
        <source>Edit Sample</source>
        <translation>编辑样本</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="364"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="399"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="388"/>
        <source>Fixed</source>
        <translation>固定</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="406"/>
        <source>Load Font</source>
        <translation>加载字体</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="413"/>
        <source>Min Confidence</source>
        <translation>最小得分</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.ui" line="433"/>
        <source>Positioning</source>
        <translation>定位</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="101"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="108"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="117"/>
        <source>&lt;font color=&apos;red&apos;&gt;Font file not exists&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;字体文件不存在&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="144"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="158"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="456"/>
        <source>&lt;font color=&apos;red&apos;&gt;Font name empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;字体名字为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="174"/>
        <source>&lt;font color=&apos;red&apos;&gt;Font name invalid error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;字体名字无效错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="181"/>
        <source>&lt;font color=&apos;red&apos;&gt;Empty char box error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;字符框为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Invalid char name error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;字符名字无效错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="219"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="495"/>
        <source>Char segemnt error</source>
        <translation>字符分割错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="249"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="526"/>
        <source>&lt;font color=&apos;green&apos;&gt;Saved %1 of total %2 sample(s)&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;保存总共%2个样本中的%1个&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="253"/>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="530"/>
        <source>&lt;font color=&apos;red&apos;&gt;Saved %1 of total %2 sample(s)&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;保存总共%2个样本中的%1个&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="292"/>
        <source>&lt;font color=&apos;green&apos;&gt;Traing final error: %1&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;最终训练误差: %1&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="297"/>
        <source>&lt;font color=&apos;red&apos;&gt;Traing samples failed with error message: %1&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;样本训练失败: %1&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/customocrpage.cpp" line="478"/>
        <source>&lt;font color=&apos;red&apos;&gt;No samples in %1&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;%1里面没有样本&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>DieBonding00</name>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="14"/>
        <source>Frame</source>
        <translation>Frame</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="105"/>
        <source>Camera Live Control</source>
        <translation>相机实时显示控制</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="191"/>
        <source>StopAll</source>
        <translation>停止所有</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="209"/>
        <source>AlignBotRight</source>
        <translation>右下对位</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="274"/>
        <source>RightTopAll</source>
        <translation>右上所有</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="313"/>
        <source>AlignTopLeft</source>
        <translation>左上对位</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="352"/>
        <source>LeftBotAll</source>
        <translation>左下所有</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="378"/>
        <source>RightTopOne</source>
        <translation>右上一颗</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="365"/>
        <source>LeftTopCalib</source>
        <translation>左上标定</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="287"/>
        <source>RightBotOne</source>
        <translation>右下一颗</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="248"/>
        <source>RightTopCalib</source>
        <translation>右上标定</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="261"/>
        <source>RightBotCalib</source>
        <translation>右下标定</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="326"/>
        <source>LeftBotCalib</source>
        <translation>左下标定</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="222"/>
        <source>LeftTopOne</source>
        <translation>左上一颗</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="300"/>
        <source>RightBotAll</source>
        <translation>右下所有</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="235"/>
        <source>MiddleCalib</source>
        <translation>中间标定</translation>
    </message>
    <message>
        <source>MiddleAll</source>
        <translation type="vanished">中间所有</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="391"/>
        <source>LeftTopAll</source>
        <translation>左上所有</translation>
    </message>
    <message>
        <source>MiddleOne</source>
        <translation type="vanished">中间一颗</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="339"/>
        <source>LeftBotOne</source>
        <translation>左下一颗</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="158"/>
        <source>RightTopLive</source>
        <translation>右上时实</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="145"/>
        <source>MiddleLive</source>
        <translation>中间实时</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="132"/>
        <source>LeftTopLive</source>
        <translation>左上实时</translation>
    </message>
    <message>
        <source>Command A</source>
        <translation type="vanished">命令A</translation>
    </message>
    <message>
        <source>Command B</source>
        <translation type="vanished">命令B</translation>
    </message>
    <message>
        <source>Command C</source>
        <translation type="vanished">命令C</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="184"/>
        <source>RightBotLive</source>
        <translation>右下实时</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding00.ui" line="171"/>
        <source>LeftBotLive</source>
        <translation>左下实时</translation>
    </message>
    <message>
        <source>Command D</source>
        <translation type="vanished">命令D</translation>
    </message>
    <message>
        <source>Command E</source>
        <translation type="vanished">命令E</translation>
    </message>
    <message>
        <source>Command F</source>
        <translation type="vanished">命令F</translation>
    </message>
</context>
<context>
    <name>DieBonding01</name>
    <message>
        <location filename="src/resources/ui/DieBonding01.ui" line="14"/>
        <source>Frame</source>
        <translation>边框</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding01.ui" line="105"/>
        <source>Camera Live Control</source>
        <translation>相机实时显示控制</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding01.ui" line="132"/>
        <source>LeftLive</source>
        <translation>左边实时</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding01.ui" line="145"/>
        <source>MiddleTopLive</source>
        <translation>中上实时</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding01.ui" line="158"/>
        <source>RightFrontLive</source>
        <translation>右前实时</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding01.ui" line="171"/>
        <source>StopAll</source>
        <translation>停止所有</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding01.ui" line="184"/>
        <source>RightBackLive</source>
        <translation>右后实时</translation>
    </message>
    <message>
        <location filename="src/resources/ui/DieBonding01.ui" line="191"/>
        <source>MiddleBotLive</source>
        <translation>中下实时</translation>
    </message>
</context>
<context>
    <name>EditCharDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.ui" line="14"/>
        <source>OCR Samples</source>
        <translation>OCR样本</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.ui" line="68"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.ui" line="84"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.cpp" line="117"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.cpp" line="136"/>
        <source>Discard changes</source>
        <translation>丢弃修改</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.cpp" line="137"/>
        <source>Samples changed. Are you sure you want to discard changes?</source>
        <translation>样本修改了。你确定放弃修改吗？</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.cpp" line="172"/>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.cpp" line="185"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.cpp" line="182"/>
        <source>List View</source>
        <translation>列表视图模式</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/editchardialog.cpp" line="183"/>
        <source>Icon View</source>
        <translation>图标视图模式</translation>
    </message>
</context>
<context>
    <name>FlowChartViewer</name>
    <message>
        <location filename="src/ui/dialog/flowchartviewer.ui" line="14"/>
        <source>Flowchart Viewer</source>
        <translation>流程图查看器</translation>
    </message>
</context>
<context>
    <name>FlowScene</name>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="78"/>
        <source>Link two Procedures</source>
        <translation>连接两个步骤</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="180"/>
        <location filename="src/ui/flowchart/flowscene.cpp" line="324"/>
        <location filename="src/ui/flowchart/flowscene.cpp" line="848"/>
        <source>Change Items Geometry</source>
        <translation>改变位置大小</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="221"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="222"/>
        <source>Rename</source>
        <translation>重命名</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="226"/>
        <source>Align Width</source>
        <translation>宽度对齐</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="227"/>
        <source>Align Height</source>
        <translation>高度对齐</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="229"/>
        <source>Align Left</source>
        <translation>左对齐</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="230"/>
        <source>Align Right</source>
        <translation>右对齐</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="231"/>
        <source>Align Top</source>
        <translation>顶部对齐</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="232"/>
        <source>Align Bottom</source>
        <translation>底部对齐</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="234"/>
        <source>Align Vertical Center</source>
        <translation>竖直中心对齐</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="235"/>
        <source>Align Horizontal Center</source>
        <translation>水平中心对齐</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="262"/>
        <source>Delete Items</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="394"/>
        <location filename="src/ui/flowchart/flowscene.cpp" line="400"/>
        <location filename="src/ui/flowchart/flowscene.cpp" line="437"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="394"/>
        <source>The flowchart has invalid procedure(s).</source>
        <translation>流程图有无效步骤。</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="400"/>
        <source>The flowchart has infinite procedure(s).</source>
        <translation>流程图有无限循环步骤。</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="437"/>
        <source>The graph has a cycle.</source>
        <translation>检测到环。</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="887"/>
        <source>New Name</source>
        <translation>新名字</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/flowscene.cpp" line="887"/>
        <source>New Name:</source>
        <translation>新名字：</translation>
    </message>
</context>
<context>
    <name>Frame</name>
    <message>
        <location filename="src/resources/ui/canvas.ui" line="14"/>
        <location filename="src/resources/ui/clock.ui" line="14"/>
        <location filename="src/resources/ui/scripting.ui" line="14"/>
        <location filename="src/resources/ui/scripting_button.ui" line="14"/>
        <source>Frame</source>
        <translation type="unfinished">Frame</translation>
    </message>
    <message>
        <location filename="src/resources/ui/canvas.ui" line="20"/>
        <source>Canvas display image and roi.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/canvas.ui" line="26"/>
        <source>N/A 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting.ui" line="45"/>
        <source>Run</source>
        <translation type="unfinished">运行</translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting.ui" line="48"/>
        <source>plainTextEditPythonSource</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting.ui" line="51"/>
        <source>plainTextEditPythonOutput</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="34"/>
        <source>Scripts Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="50"/>
        <location filename="src/resources/ui/scripting_button.ui" line="81"/>
        <location filename="src/resources/ui/scripting_button.ui" line="106"/>
        <location filename="src/resources/ui/scripting_button.ui" line="135"/>
        <source>The Python 3 Scripting Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="53"/>
        <location filename="src/resources/ui/scripting_button.ui" line="84"/>
        <location filename="src/resources/ui/scripting_button.ui" line="109"/>
        <location filename="src/resources/ui/scripting_button.ui" line="138"/>
        <source>Scripting Button execute attached Python 3 scripts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="56"/>
        <source>Execute2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="87"/>
        <source>Execute1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="112"/>
        <source>Execute3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="141"/>
        <source>Execute4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="167"/>
        <source>Command Buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="181"/>
        <location filename="src/resources/ui/scripting_button.ui" line="204"/>
        <location filename="src/resources/ui/scripting_button.ui" line="228"/>
        <location filename="src/resources/ui/scripting_button.ui" line="246"/>
        <location filename="src/resources/ui/scripting_button.ui" line="269"/>
        <location filename="src/resources/ui/scripting_button.ui" line="293"/>
        <source>Command Button execute attached Python 3 scripts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="184"/>
        <source>Platform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="207"/>
        <source>Copyright</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="231"/>
        <source>OS Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="249"/>
        <source>Python Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="272"/>
        <source>Version Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/resources/ui/scripting_button.ui" line="296"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GeneralOCRDialog</name>
    <message>
        <source>General OCR</source>
        <translation type="vanished">通用OCR</translation>
    </message>
    <message>
        <source>Camera</source>
        <translation type="vanished">相机</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="vanished">触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">搜索字符</translation>
    </message>
    <message>
        <source>Stroke Width</source>
        <translation type="vanished">笔画宽度</translation>
    </message>
    <message>
        <source>Classifier</source>
        <translation type="vanished">分类器</translation>
    </message>
    <message>
        <source>Char Height</source>
        <translation type="vanished">字符高度</translation>
    </message>
    <message>
        <source>Min Contrast</source>
        <translation type="vanished">最小对比度</translation>
    </message>
    <message>
        <source>Char Width</source>
        <translation type="vanished">字符高度</translation>
    </message>
    <message>
        <source>Max</source>
        <translation type="vanished">最大值</translation>
    </message>
    <message>
        <source>Min</source>
        <translation type="vanished">最小值</translation>
    </message>
    <message>
        <source>Dark On Light</source>
        <translation type="vanished">暗字符</translation>
    </message>
    <message>
        <source>Light On Dark</source>
        <translation type="vanished">亮字符</translation>
    </message>
    <message>
        <source>Both</source>
        <translation type="vanished">两者都有</translation>
    </message>
    <message>
        <source>Polarity</source>
        <translation type="vanished">极性</translation>
    </message>
    <message>
        <source>Min Confidence</source>
        <translation type="vanished">最小得分</translation>
    </message>
    <message>
        <source>Positioning</source>
        <translation type="vanished">定位</translation>
    </message>
    <message>
        <source>Fixed</source>
        <translation type="vanished">固定</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="vanished">输出</translation>
    </message>
    <message>
        <source>Y Resolution(μm)</source>
        <translation type="vanished">竖直方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>X Resolution(μm)</source>
        <translation type="vanished">水平方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
</context>
<context>
    <name>GeomFinderDialog</name>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="22"/>
        <source>Semi Smooth Width</source>
        <translation>半平滑宽度</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="42"/>
        <source>Sigma</source>
        <translation>西格玛</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="68"/>
        <source>Threshold</source>
        <translation>阈值</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="88"/>
        <source>Num Sample Points</source>
        <translation>采样点数</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="108"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="119"/>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="148"/>
        <source>all</source>
        <translation>所有</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="124"/>
        <source>first</source>
        <translation>第一个</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="129"/>
        <source>last</source>
        <translation>最后一个</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="137"/>
        <source>Transition</source>
        <translation>边缘过度</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="153"/>
        <source>negative</source>
        <translation>从白到黑</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="158"/>
        <source>positive</source>
        <translation>从黑到白</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="163"/>
        <source>uniform</source>
        <translation>统一过度</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/geomfinderdialog.ui" line="210"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>GeomMeasureDialog</name>
    <message>
        <source>Geometry Measure</source>
        <translation type="vanished">几何测量</translation>
    </message>
    <message>
        <source>Camera</source>
        <translation type="vanished">相机</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="vanished">触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <source>Measure Items</source>
        <translation type="vanished">测量</translation>
    </message>
    <message>
        <source>Measure</source>
        <translation type="vanished">测量</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="vanished">输出</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation type="vanished">保存图像</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>X Resolution</source>
        <translation type="vanished">水平方向分辨率</translation>
    </message>
    <message>
        <source>Y Resolution</source>
        <translation type="vanished">竖直方向分辨率</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="obsolete">发送结果使用</translation>
    </message>
    <message>
        <source>Save Data</source>
        <translation type="vanished">保存结果数据</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">不保存</translation>
    </message>
    <message>
        <source>Post Calculation</source>
        <translation type="vanished">后处理</translation>
    </message>
    <message>
        <source>Positioning</source>
        <translation type="vanished">定位</translation>
    </message>
    <message>
        <source>Fixed</source>
        <translation type="vanished">固定</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">保存所有</translation>
    </message>
    <message>
        <source>ErrorOnly</source>
        <translation type="vanished">只保存错误</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
</context>
<context>
    <name>GetItemDialog</name>
    <message>
        <location filename="src/ui/dialog/getitemdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/getitemdialog.ui" line="22"/>
        <source>Items</source>
        <translation>可选项</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/getitemdialog.ui" line="65"/>
        <source>Ok</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/getitemdialog.ui" line="75"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
<context>
    <name>GrabPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/grabpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/grabpage.ui" line="23"/>
        <source>Grab</source>
        <translation>抓取</translation>
    </message>
</context>
<context>
    <name>GrayMatchDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="153"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="154"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="155"/>
        <source>Matching</source>
        <translation>匹配</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="156"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
</context>
<context>
    <name>GrayMatchPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="40"/>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="91"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="57"/>
        <source>ROI</source>
        <translation>ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="64"/>
        <source>Parameters</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="50"/>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="133"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="77"/>
        <source>Save As</source>
        <translation>另存为</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="119"/>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="158"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="124"/>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="163"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="175"/>
        <source>Show Search ROI</source>
        <translation>显示搜索ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="182"/>
        <source>Show Create ROI</source>
        <translation>显示模板ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.ui" line="189"/>
        <source>Hide ROI</source>
        <oldsource>Hide</oldsource>
        <translation>隐藏ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.cpp" line="99"/>
        <source>&lt;font color=&apos;green&apos;&gt;Found: (x=%1, y=%2, angle=%3, score=%4)&lt;/font&gt;</source>
        <translation>找到: (x=%1, y=%2, angle=%3, score=%4)&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.cpp" line="103"/>
        <source>&lt;font color=&apos;red&apos;&gt;Template not found&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;模板没有找到&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.cpp" line="114"/>
        <source>Save template file</source>
        <translation>保存模板文件</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/graymatchpage.cpp" line="114"/>
        <source>Template files(*.ncm)</source>
        <translation>模板文件(*.ncm)</translation>
    </message>
</context>
<context>
    <name>ImageGrabberDialog</name>
    <message>
        <source>Image Grabber</source>
        <translation type="vanished">图像抓取</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="75"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="76"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="77"/>
        <source>Grab</source>
        <translation>抓取</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="78"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <source>Y Resolution(μm)</source>
        <translation type="vanished">竖直方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="obsolete">发送结果使用</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>X Resolution(μm)</source>
        <translation type="vanished">水平方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
</context>
<context>
    <name>ImageLiveDialog</name>
    <message>
        <source>Image Live</source>
        <translation type="vanished">实时图像</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="113"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="114"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="115"/>
        <source>Live</source>
        <translation>实时显示</translation>
    </message>
    <message>
        <source>Start Live</source>
        <translation type="vanished">开始实时显示</translation>
    </message>
    <message>
        <source>Live Type</source>
        <translation type="vanished">实时类型</translation>
    </message>
    <message>
        <source>Stop Live</source>
        <translation type="vanished">停止实时显示</translation>
    </message>
    <message>
        <source>Toggle Live</source>
        <translation type="vanished">翻转实时显示</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="116"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
    <message>
        <source>Y Resolution(μm)</source>
        <translation type="vanished">竖直方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="obsolete">发送结果使用</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>X Resolution(μm)</source>
        <translation type="vanished">水平方向分辨率(μm)</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
</context>
<context>
    <name>ImageProcessor</name>
    <message>
        <source>Command received from %1:%2: %3</source>
        <translation type="vanished">从%1:%2: %3收到命令</translation>
    </message>
</context>
<context>
    <name>ImageResourceDialog</name>
    <message>
        <location filename="src/ui/dialog/imageresourcedialog.ui" line="14"/>
        <source>Image Resource</source>
        <translation>图像资源</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/imageresourcedialog.ui" line="27"/>
        <source> Add Image Resource</source>
        <translation>添加图像资源</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/imageresourcedialog.ui" line="44"/>
        <source>Delete Image Resource</source>
        <translation>删除图像资源</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/imageresourcedialog.ui" line="61"/>
        <source>Edit Image Resource</source>
        <translation>编辑图像资源</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/imageresourcedialog.cpp" line="51"/>
        <source>Read Image Error</source>
        <translation>打开图像错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/imageresourcedialog.cpp" line="51"/>
        <source>Can&apos;t read image file %1</source>
        <translation>不能打开图像文件%1</translation>
    </message>
</context>
<context>
    <name>ImageSourceToolBox</name>
    <message>
        <location filename="src/ui/flowchart/toolbox/imagesourcetoolbox.cpp" line="65"/>
        <source>Image Acquisition Toolbox</source>
        <translation>图像采集工具箱</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/imagesourcetoolbox.cpp" line="66"/>
        <source>Snap Image</source>
        <oldsource>Snap</oldsource>
        <translation>抓取图像</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/imagesourcetoolbox.cpp" line="67"/>
        <source>Live</source>
        <translation>实时显示图像</translation>
    </message>
</context>
<context>
    <name>LaserXAnalogClock</name>
    <message>
        <location filename="laserxwidgets/laser_x_analog_clock.cpp" line="15"/>
        <source>Analog Clock</source>
        <translation>模拟时钟</translation>
    </message>
</context>
<context>
    <name>LaserXCanvas</name>
    <message>
        <location filename="laserxwidgets/laser_x_canvas.cpp" line="959"/>
        <source>Images(*.png *.jpg *.tiff *.tif *.bmp *.dib)</source>
        <translation>图像(*.png *.jpg *.tiff *.tif *.bmp *.dib)</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas.cpp" line="960"/>
        <source>Save Image File</source>
        <translation>保存图像</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="35"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="36"/>
        <source>Draw Line</source>
        <translation>画线</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="37"/>
        <source>Draw Square</source>
        <translation>画矩形</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="38"/>
        <source>Draw Line Finder Box</source>
        <translation>画直线搜索框</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="39"/>
        <source>Draw Circle Finder Box</source>
        <translation>画圆搜索框</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="40"/>
        <source>Draw Rectangle Finder Box</source>
        <translation>画矩形搜索框</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="41"/>
        <source>Draw Ellipse Finder Box</source>
        <translation>画椭圆搜索框</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="42"/>
        <source>Draw Ellipse</source>
        <translation>画椭圆</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="43"/>
        <source>Draw Polygon</source>
        <translation>画多边形</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="44"/>
        <source>Draw Char Box</source>
        <translation>画字符框</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="45"/>
        <source>Snapshot</source>
        <translation>快照</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="46"/>
        <source>Live</source>
        <translation>实时</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="47"/>
        <source>Break Camera Link</source>
        <translation>断开相加连接</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="48"/>
        <source>Toggle Cross Line</source>
        <translation>显示/隐藏十字线</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="49"/>
        <source>Toggle Reference Point</source>
        <translation>显示隐藏参考点</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="50"/>
        <source>Hide ROI</source>
        <translation>隐藏ROI</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="51"/>
        <source>Save Image</source>
        <translation>保存图像</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_canvas_p.cpp" line="52"/>
        <source>Color Picker</source>
        <translation>信息拾取</translation>
    </message>
</context>
<context>
    <name>LaserXCanvasPrivate</name>
    <message>
        <source>Select</source>
        <translation type="obsolete">选择</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation type="obsolete">保存图像</translation>
    </message>
</context>
<context>
    <name>LaserXCommandButton</name>
    <message>
        <location filename="laserxwidgets/laser_x_command_button.cpp" line="11"/>
        <source>Command</source>
        <translation>命令</translation>
    </message>
</context>
<context>
    <name>LaserXDeviceWidget</name>
    <message>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="31"/>
        <source>Devices</source>
        <translation>设备</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="44"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="44"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="44"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="44"/>
        <source>Data</source>
        <translation>数据</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="61"/>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="416"/>
        <source>Serial Port</source>
        <translation>串口</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="67"/>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="448"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="73"/>
        <location filename="laserxwidgets/laser_x_device_widget.cpp" line="480"/>
        <source>Network</source>
        <translation>网络</translation>
    </message>
</context>
<context>
    <name>LaserXLogWidget</name>
    <message>
        <location filename="laserxwidgets/laser_x_log_widget.cpp" line="52"/>
        <source>Clear</source>
        <translation>清空</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_log_widget.cpp" line="55"/>
        <source>Export</source>
        <translation>输出</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_log_widget.cpp" line="56"/>
        <source>Export HTML</source>
        <translation>输出HTML格式</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_log_widget.cpp" line="58"/>
        <source>Block</source>
        <translation>停止刷新</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_log_widget.cpp" line="71"/>
        <location filename="laserxwidgets/laser_x_log_widget.cpp" line="76"/>
        <source>Save log file</source>
        <translation>保存日志文件</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_log_widget.cpp" line="71"/>
        <source>HTML files(*.htm *.html)</source>
        <translation>HTML文件(*.htm *.html)</translation>
    </message>
    <message>
        <source>HTML files(*.htm *html)</source>
        <translation type="vanished">HTML文件(*.htm *html)</translation>
    </message>
    <message>
        <location filename="laserxwidgets/laser_x_log_widget.cpp" line="76"/>
        <source>Text files (*.txt)</source>
        <translation>文本文件(*.htm *html)</translation>
    </message>
</context>
<context>
    <name>LaserXScriptingButton</name>
    <message>
        <location filename="laserxwidgets/laser_x_scripting_button.cpp" line="13"/>
        <source>Execute</source>
        <translation>执行</translation>
    </message>
</context>
<context>
    <name>LensDialog</name>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="14"/>
        <source>Lens Manager</source>
        <translation>镜头管理</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="78"/>
        <source>Set Magnification</source>
        <translation>设置放大倍数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="88"/>
        <source>Go Home</source>
        <translation>回零</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="95"/>
        <source>Zoom Error Num Pulses</source>
        <translation>误差脉冲数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="130"/>
        <source>Zoom Remaining Num Pulses</source>
        <translation>剩余脉冲数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="137"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="144"/>
        <source>Home Remaining Num Pulses</source>
        <translation>回零剩余脉冲数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="158"/>
        <source>Motor Status</source>
        <translation>马达状态</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="123"/>
        <source>Communication Type</source>
        <translation>通信类型</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="116"/>
        <source>Communication Device</source>
        <translation>通信设备</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lensdialog.ui" line="54"/>
        <source>Magnification</source>
        <translation>放大倍数</translation>
    </message>
</context>
<context>
    <name>LightSourceDialog</name>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="14"/>
        <source>Light Source Manager</source>
        <translation>光源管理器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="33"/>
        <source>Device</source>
        <translation>设备</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="38"/>
        <source>Status</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="43"/>
        <source>Desciption</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="48"/>
        <source>Controller</source>
        <translation>控制器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="80"/>
        <source>Num Channels</source>
        <translation>通道数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="87"/>
        <source>Communication Type</source>
        <translation>通信类型</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="108"/>
        <source>Brightness All</source>
        <translation>所有亮度</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="122"/>
        <source>Controller Name</source>
        <translation>控制器名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="129"/>
        <source>Switch All</source>
        <translation>开关所有通道</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="143"/>
        <source>Communication Source</source>
        <translation>通信源</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="174"/>
        <source>Channel State</source>
        <translation>通道状态</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="181"/>
        <source>Channel Name</source>
        <translation>通道名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="191"/>
        <source>Channel ID</source>
        <translation>通道号</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.ui" line="212"/>
        <source>Channel Brightness</source>
        <translation>通道亮度</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.cpp" line="41"/>
        <source>Add</source>
        <translation>添加控制器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/lightsourcedialog.cpp" line="45"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
</context>
<context>
    <name>LivePage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/livepage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/livepage.ui" line="25"/>
        <location filename="src/ui/dialog/procedure/procpage/livepage.ui" line="40"/>
        <location filename="src/ui/dialog/procedure/procpage/livepage.cpp" line="45"/>
        <location filename="src/ui/dialog/procedure/procpage/livepage.cpp" line="48"/>
        <source>Start Live</source>
        <translation>开始实时显示</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/livepage.ui" line="32"/>
        <source>Live Type</source>
        <translation>实时类型</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/livepage.ui" line="45"/>
        <location filename="src/ui/dialog/procedure/procpage/livepage.cpp" line="46"/>
        <source>Stop Live</source>
        <translation>停止实时显示</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/livepage.ui" line="50"/>
        <location filename="src/ui/dialog/procedure/procpage/livepage.cpp" line="47"/>
        <source>Toggle Live</source>
        <translation>翻转实时显示</translation>
    </message>
</context>
<context>
    <name>LoginDialog</name>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>登录对话框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="116"/>
        <source>Please Login</source>
        <translation>请登录</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="148"/>
        <source>Restart</source>
        <translation>重启程序</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="180"/>
        <source>Shutdown</source>
        <translation>关闭程序</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="291"/>
        <source>Operator</source>
        <translation>操作员</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="296"/>
        <source>Engineer</source>
        <translation>工程师</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="323"/>
        <source>Login</source>
        <translation>登录</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="330"/>
        <source>Group</source>
        <translation>群组</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="337"/>
        <source>User Name</source>
        <translation>用户名</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.ui" line="344"/>
        <source>Password</source>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.cpp" line="58"/>
        <source>Name empty error</source>
        <translation>名字空错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.cpp" line="62"/>
        <source>Password empty error</source>
        <translation>密码空错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.cpp" line="73"/>
        <source>User name or group error</source>
        <translation>用户名或群组错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/account/logindialog.cpp" line="81"/>
        <source>Password error</source>
        <translation>密码错误</translation>
    </message>
</context>
<context>
    <name>MainFrame</name>
    <message>
        <location filename="src/ui/mainframe.cpp" line="132"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="133"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="134"/>
        <source>File</source>
        <translation>文件</translation>
    </message>
    <message>
        <source>Edit</source>
        <translation type="vanished">编辑</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="135"/>
        <source>Resource</source>
        <translation>资源</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="136"/>
        <source>Help</source>
        <translation>帮助</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="137"/>
        <source>User</source>
        <translation>用户</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="138"/>
        <source>Switch Project...</source>
        <translation>切换项目...</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="139"/>
        <source>New Project...</source>
        <translation>新项目...</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="140"/>
        <source>Dark</source>
        <translation>深色</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="141"/>
        <source>Light</source>
        <translation>浅色</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="142"/>
        <source>Logout</source>
        <translation>登出</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="143"/>
        <source>Restart Program</source>
        <translation>重启</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="144"/>
        <source>Exit</source>
        <translation>退出</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="145"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="146"/>
        <source>Save As...</source>
        <translation>另存为...</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="147"/>
        <source>Settings...</source>
        <translation>设置...</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="148"/>
        <source>Start</source>
        <translation>启动</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="149"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="150"/>
        <source>Undo</source>
        <translation>撤销</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="151"/>
        <source>Redo</source>
        <translation>重做</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="152"/>
        <location filename="src/ui/mainframe.cpp" line="170"/>
        <source>Procedures</source>
        <translation>过程</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="153"/>
        <source>View Setting Search Paths</source>
        <translation>设置文件路径</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="154"/>
        <source>Serial Port Trigger</source>
        <translation>串口触发</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="155"/>
        <source>Network Client Trigger</source>
        <translation>客户端触发</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="156"/>
        <source>Network Server Trigger</source>
        <translation>服务端触发</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="157"/>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="158"/>
        <source>Add User</source>
        <translation>添加用户</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="159"/>
        <source>Delete User</source>
        <translation>删除用户</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="160"/>
        <source>Edit User</source>
        <translation>编辑用户</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="161"/>
        <source>Serial Port</source>
        <translation>串口</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="162"/>
        <source>Network Client</source>
        <translation>网络客户</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="163"/>
        <source>Network Server</source>
        <translation>网络服务器</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="164"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="165"/>
        <source>Image Resource</source>
        <translation>图像资源</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="166"/>
        <source>Light Source</source>
        <translation>光源</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="167"/>
        <source>Run</source>
        <translation>运行</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="168"/>
        <source>Config</source>
        <translation>配置</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="169"/>
        <source>Ready</source>
        <translation>就绪</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="380"/>
        <source>Import Image</source>
        <translation>导入图像</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="384"/>
        <location filename="src/ui/mainframe.cpp" line="745"/>
        <source>Image Files (*.png *.jpg *.bmp)</source>
        <translation>图像文件(*.png *.jpg *.bmp)</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="395"/>
        <source>New Laser X Project File</source>
        <translation>新项目文件</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="399"/>
        <location filename="src/ui/mainframe.cpp" line="425"/>
        <source>Laser X Project Files (*.db *.lxp)</source>
        <translation>项目文件(*.db *.lxp)</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="421"/>
        <source>Save Laser X Project File As...</source>
        <translation>项目文件另存为...</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="460"/>
        <source>No Valid Project</source>
        <translation>没有有效项目</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="460"/>
        <source>Can&apos;t find valid project in project list</source>
        <translation>项目列表里面找不到有效项目</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="469"/>
        <source>Not a Valid Project</source>
        <translation>不是一个有效的项目</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="469"/>
        <source>Project %1 is not a valid project</source>
        <translation>项目%1无效</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="624"/>
        <source>Setting file (settings.db) Search Paths</source>
        <translation>设置文件搜索路径</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="690"/>
        <source>User: %1</source>
        <translation>用户: %1</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="691"/>
        <source>Group: %1</source>
        <translation>群组: %1</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="745"/>
        <source>Save Application Shot As...</source>
        <translation>保存程序界面截屏为...</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="1231"/>
        <source>Operator</source>
        <translation>操作员</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="1232"/>
        <source>Engineer</source>
        <translation>工程师</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="1233"/>
        <source>Administrator</source>
        <translation>管理员</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="1234"/>
        <source>Developer</source>
        <translation>开发者</translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="1235"/>
        <source>Invalid</source>
        <translation>无效</translation>
    </message>
</context>
<context>
    <name>MeasureDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="309"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="310"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="311"/>
        <source>Measure</source>
        <translation>测量</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="312"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
</context>
<context>
    <name>MeasurePage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/measurepage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/measurepage.ui" line="25"/>
        <source>Post Calculation</source>
        <translation>后处理</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/measurepage.ui" line="32"/>
        <source>Measure</source>
        <translation>测量</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/measurepage.ui" line="39"/>
        <source>Positioning</source>
        <translation>定位</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/measurepage.ui" line="47"/>
        <source>Fixed</source>
        <translation>固定</translation>
    </message>
</context>
<context>
    <name>NCCTemplateDialog</name>
    <message>
        <source>Grayscale Template</source>
        <translation type="vanished">灰度模板</translation>
    </message>
    <message>
        <source>Camera</source>
        <translation type="vanished">相机</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="vanished">触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="vanished">创建</translation>
    </message>
    <message>
        <source>Use Polarity</source>
        <translation type="vanished">使用极性</translation>
    </message>
    <message>
        <source>5</source>
        <translation type="vanished">5</translation>
    </message>
    <message>
        <source>Auto Angle Step</source>
        <translation type="vanished">自动角度步长</translation>
    </message>
    <message>
        <source>Angle Step</source>
        <translation type="vanished">角度步长</translation>
    </message>
    <message>
        <source>3</source>
        <translation type="vanished">3</translation>
    </message>
    <message>
        <source>Auto Num Levels</source>
        <translation type="vanished">自动金字塔层数</translation>
    </message>
    <message>
        <source>Angle Start</source>
        <translation type="vanished">起始角度</translation>
    </message>
    <message>
        <source>Angle Extent</source>
        <translation type="vanished">角度范围</translation>
    </message>
    <message>
        <source>Num Levels</source>
        <translation type="vanished">金字塔层数</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">搜索模板</translation>
    </message>
    <message>
        <source>Min Score</source>
        <translation type="vanished">最小得分</translation>
    </message>
    <message>
        <source>Sub Pixel</source>
        <translation type="vanished">亚像素</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="vanished">输出</translation>
    </message>
    <message>
        <source>Save Data</source>
        <translation type="vanished">保存结果数据</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="obsolete">发送结果使用</translation>
    </message>
    <message>
        <source>X Resolution</source>
        <translation type="vanished">水平方向分辨率</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>Y Resolution</source>
        <translation type="vanished">竖直方向分辨率</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation type="vanished">保存图像</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">不保存</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">保存所有</translation>
    </message>
    <message>
        <source>ErrorOnly</source>
        <translation type="vanished">只保存错误</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Found: (x=%1, y=%2, angle=%3, score=%4)&lt;/font&gt;</source>
        <translation type="vanished">找到: (x=%1, y=%2, angle=%3, score=%4)&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Template not found&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;模板没有找到&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>NetClientDialog</name>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.ui" line="14"/>
        <source>Net Client Manager</source>
        <translation>网络客户管理器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.ui" line="27"/>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.ui" line="34"/>
        <source>Test Data</source>
        <translation>测试数据</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.ui" line="54"/>
        <source>Connect Wait(ms)</source>
        <translation>连接超时(ms)</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.ui" line="71"/>
        <source>Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.ui" line="81"/>
        <source>Send</source>
        <translation>发送</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.ui" line="147"/>
        <source>Connect</source>
        <translation>连接</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.ui" line="169"/>
        <source>Disconnect</source>
        <translation>断开连接</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.cpp" line="75"/>
        <source>&lt;font color=&apos;red&apos;&gt;Invalid connection error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;无效连接错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.cpp" line="83"/>
        <source>&lt;font color=&apos;red&apos;&gt;Test data empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;测试数据为空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.cpp" line="111"/>
        <source>&lt;font color=&apos;red&apos;&gt;Network error %1 occurred&lt;/font&gt;</source>
        <translation>发生网络错误%1</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.cpp" line="122"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.cpp" line="123"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.cpp" line="162"/>
        <source>State changed to %1</source>
        <translation>状态变成%1</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.cpp" line="177"/>
        <source>&lt;font color=&apos;red&apos;&gt;%1 occurred&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;事件%1发生&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/netclientdialog.cpp" line="183"/>
        <source>&lt;font color=&apos;green&apos;&gt;Write %1 bytes&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;发送%1个字节&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>NetServerTriggerDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/netservertriggerdialog.ui" line="14"/>
        <source>Network Trigger</source>
        <translation>网络触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/netservertriggerdialog.ui" line="27"/>
        <source>Command Name</source>
        <translation>命令名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/netservertriggerdialog.ui" line="37"/>
        <source>Network Server</source>
        <translation>网络服务器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/netservertriggerdialog.ui" line="47"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/netservertriggerdialog.ui" line="81"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/netservertriggerdialog.ui" line="88"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>NetworkDialog</name>
    <message>
        <location filename="src/ui/dialog/device/networkdialog.ui" line="14"/>
        <source>Network</source>
        <translation>网络服务器管理</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/networkdialog.ui" line="27"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/networkdialog.ui" line="41"/>
        <source>IP Address</source>
        <translation>地址</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/networkdialog.ui" line="55"/>
        <source>Port</source>
        <translation>端口</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/networkdialog.cpp" line="30"/>
        <source>Add</source>
        <translation>添加</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/networkdialog.cpp" line="31"/>
        <source>Delete</source>
        <translation>删除</translation>
    </message>
</context>
<context>
    <name>OCRBoxDialog</name>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.ui" line="14"/>
        <source>OCR Box Settings</source>
        <translation>OCR框设置</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.ui" line="35"/>
        <source>Line</source>
        <translation>行号</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.ui" line="40"/>
        <source>Structure</source>
        <translation>结构</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.ui" line="45"/>
        <source>Min Gap</source>
        <translation>最小间隙</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.ui" line="53"/>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.cpp" line="64"/>
        <source>Line Structure</source>
        <translation>行结构</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.ui" line="63"/>
        <source>Order</source>
        <translation>顺序</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.ui" line="70"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.cpp" line="35"/>
        <source>Add Line Structure</source>
        <translation>添加行结构</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.cpp" line="38"/>
        <source>Delete Line Structure</source>
        <translation>删除行结构</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.cpp" line="56"/>
        <source>Set Line Number</source>
        <translation>设置行号</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.cpp" line="56"/>
        <source>Line Number</source>
        <translation>行号</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.cpp" line="64"/>
        <source>Set Line Structure</source>
        <translation>设置行结构</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.cpp" line="72"/>
        <source>Set Min Word Gap</source>
        <translation>设置最小间隙</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/ocrboxdialog.cpp" line="72"/>
        <source>Min Word Gap</source>
        <translation>最小间隙</translation>
    </message>
</context>
<context>
    <name>OCRToolBox</name>
    <message>
        <location filename="src/ui/flowchart/toolbox/ocrtoolbox.cpp" line="69"/>
        <source>OCR Toolbox</source>
        <translation>OCR工具箱</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/ocrtoolbox.cpp" line="70"/>
        <source>General OCR</source>
        <translation>通用OCR</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/ocrtoolbox.cpp" line="71"/>
        <source>Pretrained OCR</source>
        <oldsource>Fixed OCR</oldsource>
        <translation>预训练OCR</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/ocrtoolbox.cpp" line="72"/>
        <source>Custom OCR</source>
        <translation>定制OCR</translation>
    </message>
    <message>
        <source>Add OCR Font</source>
        <translation type="vanished">添加新OCR字体</translation>
    </message>
</context>
<context>
    <name>OptionPage</name>
    <message>
        <location filename="src/ui/optionpage.cpp" line="56"/>
        <source>Dark</source>
        <translation>深色</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="57"/>
        <source>Light</source>
        <translation>浅色</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="58"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="59"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="60"/>
        <source>Show Image Center Cross Mark</source>
        <translation>显示图像中心十字</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="61"/>
        <location filename="src/ui/optionpage.cpp" line="62"/>
        <source>Show XY Coordinate Axis</source>
        <translation>显示坐标轴</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="63"/>
        <source>Environment</source>
        <translation>环境</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="64"/>
        <location filename="src/ui/optionpage.cpp" line="79"/>
        <source>General</source>
        <translation>一般</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="65"/>
        <source>Image View</source>
        <translation>图像视图</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="66"/>
        <source>Flow Chart View</source>
        <translation>过程视图</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="67"/>
        <source>Enable Image Process Feature</source>
        <translation>使能图像处理</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="68"/>
        <source>Run UI</source>
        <translation>运行界面</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="69"/>
        <source>Undo Limit</source>
        <translation>撤销次数上限</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="70"/>
        <source>Project Directory</source>
        <translation>项目目录</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="71"/>
        <source>Set</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="72"/>
        <source>Project List</source>
        <translation>项目列表</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="73"/>
        <source>Add Directory</source>
        <translation>添加目录</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="74"/>
        <source>Add Project</source>
        <translation>添加项目</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="75"/>
        <source>Delete Project</source>
        <translation>删除项目</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="76"/>
        <source>Move Up</source>
        <translation>上移</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="77"/>
        <source>Move Down</source>
        <translation>下移</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="78"/>
        <source>Project</source>
        <translation>项目</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="80"/>
        <source>Select</source>
        <translation>选择</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="81"/>
        <source>Logging Directory</source>
        <translation>日志目录</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="82"/>
        <source>Main Window Width</source>
        <translation>主界面宽度</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="83"/>
        <source>Main Window Anchor</source>
        <translation>主界面停靠</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="84"/>
        <source>Anchor Left</source>
        <translation>左停靠</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="85"/>
        <source>Anchor Right</source>
        <translation>右停靠</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="86"/>
        <source>Settings</source>
        <translation>程序设置</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="101"/>
        <source>Select Logging Directory</source>
        <translation>选择日志目录</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="461"/>
        <location filename="src/ui/optionpage.cpp" line="467"/>
        <location filename="src/ui/optionpage.cpp" line="473"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="461"/>
        <source>Project name can&apos;t be empty.</source>
        <translation>项目名不能为空.</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="467"/>
        <source>Project name conflict with existing project.</source>
        <translation>项目名字冲突.</translation>
    </message>
    <message>
        <location filename="src/ui/optionpage.cpp" line="473"/>
        <source>Invalid Project path %1.</source>
        <translation>项目路径%1无效.</translation>
    </message>
</context>
<context>
    <name>OutputPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/outputpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/outputpage.ui" line="22"/>
        <source>X Resolution(μm)</source>
        <translation>水平方向分辨率(μm)</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/outputpage.ui" line="32"/>
        <source>Y Resolution(μm)</source>
        <translation>竖直方向分辨率(μm)</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/outputpage.ui" line="42"/>
        <source>Display In</source>
        <translation>结果显示在</translation>
    </message>
</context>
<context>
    <name>PositionToolBox</name>
    <message>
        <location filename="src/ui/flowchart/toolbox/positiontoolbox.cpp" line="85"/>
        <source>Positioning Toolbox</source>
        <translation>定位工具箱</translation>
    </message>
    <message>
        <source>Gray</source>
        <translation type="vanished">灰度模板</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/positiontoolbox.cpp" line="87"/>
        <source>Shape Template</source>
        <oldsource>Shape</oldsource>
        <translation>形状模板</translation>
    </message>
    <message>
        <source>Blob</source>
        <translation type="vanished">区域分析</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/positiontoolbox.cpp" line="86"/>
        <source>Grayscale Template</source>
        <oldsource>Gray Template</oldsource>
        <translation>灰度模板</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/positiontoolbox.cpp" line="88"/>
        <source>Blob Analysis</source>
        <translation>区域分析</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/positiontoolbox.cpp" line="89"/>
        <source>Rectangle Template</source>
        <oldsource>Rectangle</oldsource>
        <translation>矩形模板</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/positiontoolbox.cpp" line="90"/>
        <source>Circle Template</source>
        <oldsource>Circle</oldsource>
        <translation>圆模板</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/positiontoolbox.cpp" line="91"/>
        <source>Geometry Measure</source>
        <oldsource>Measure</oldsource>
        <translation>几何测量</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/positiontoolbox.cpp" line="92"/>
        <source>Compound Procedure</source>
        <oldsource>Compound</oldsource>
        <translation>复合过程</translation>
    </message>
</context>
<context>
    <name>PretrainedOCRDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="270"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="271"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="272"/>
        <source>Pretrained OCR</source>
        <translation>预训练OCR</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="273"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
</context>
<context>
    <name>PretrainedOCRPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="194"/>
        <source>Classifier</source>
        <translation>分类器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="55"/>
        <source>Hide OCR Box</source>
        <translation>隐藏OCR框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="80"/>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="168"/>
        <source>Auto</source>
        <translation>自动</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="108"/>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="150"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="113"/>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="155"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="122"/>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="173"/>
        <source>Manual</source>
        <translation>手动</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="228"/>
        <source>Substitution</source>
        <translation>替换字符</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="23"/>
        <source>Fixed</source>
        <translation>固定</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="62"/>
        <source>ROI</source>
        <translation>ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="201"/>
        <source>Parameters</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="211"/>
        <source>Positioning</source>
        <translation>定位</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="48"/>
        <source>Mode</source>
        <translation>模式</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="31"/>
        <source>Min Confidence</source>
        <translation>最小得分</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="69"/>
        <source>Show OCR Box</source>
        <translation>显示OCR框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/pretrainedocrpage.ui" line="221"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
</context>
<context>
    <name>ProcedureDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.ui" line="26"/>
        <source>Dialog</source>
        <translation>对话框</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.ui" line="88"/>
        <source>Page Placeholder</source>
        <translation>占位页</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.ui" line="108"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.ui" line="118"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="67"/>
        <source>Save changes</source>
        <oldsource>Discard changes</oldsource>
        <translation>保存修改</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="68"/>
        <source>Parameter changed. Do you want to save changes?</source>
        <oldsource>Parameter changed. Are you sure you want to discard changes?</oldsource>
        <translation>参数已修改。你想保存参数修改吗?</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="159"/>
        <source>Add Parameter</source>
        <translation>添加参数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="159"/>
        <source>Parameters</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="378"/>
        <source>Change Parameter %1</source>
        <translation>修改参数%1</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="411"/>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="432"/>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="411"/>
        <location filename="src/ui/dialog/procedure/proceduredialog.cpp" line="432"/>
        <source>Invalid parameters value %1</source>
        <translation>参数值%1无效</translation>
    </message>
</context>
<context>
    <name>QChartsPlugin</name>
    <message>
        <location filename="plugins/qchartsplugin/qchartsplugin.cpp" line="57"/>
        <source>Qt Charts Widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/qchartsplugin/qchartsplugin.cpp" line="67"/>
        <source>A Qt Charts view widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/qchartsplugin/qchartsplugin.cpp" line="72"/>
        <source>This widget is presents QChartView widget</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QODBCDriver</name>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="2025"/>
        <source>Unable to connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="2032"/>
        <source>Unable to connect - Driver doesn&apos;t support all functionality required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="2314"/>
        <source>Unable to disable autocommit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="2332"/>
        <source>Unable to commit transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="2350"/>
        <source>Unable to rollback transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="2366"/>
        <source>Unable to enable autocommit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QODBCResult</name>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1023"/>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1374"/>
        <source>QODBCResult::reset: Unable to set &apos;SQL_CURSOR_STATIC&apos; as statement attribute. Please check your ODBC driver configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1033"/>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1706"/>
        <source>Unable to execute statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1088"/>
        <source>Unable to fetch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1111"/>
        <source>Unable to fetch next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1134"/>
        <source>Unable to fetch first</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1154"/>
        <source>Unable to fetch previous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1186"/>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1849"/>
        <source>Unable to fetch last</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1385"/>
        <source>Unable to prepare statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/odbc/qsql_odbc.cpp" line="1698"/>
        <source>Unable to bind variable</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="src/commands/flowchart/addlinker.cpp" line="18"/>
        <source>Link two Procedures</source>
        <translation type="unfinished">连接两个步骤</translation>
    </message>
    <message>
        <location filename="src/commands/flowchart/deletetopitems.cpp" line="11"/>
        <source>Delete Items</source>
        <translation type="unfinished">删除</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="122"/>
        <source>Add Sub Procedure</source>
        <translation type="unfinished">添加子过程</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="126"/>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="35"/>
        <source>Delete</source>
        <translation type="unfinished">删除控制器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="156"/>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="163"/>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="72"/>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="108"/>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="141"/>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="174"/>
        <source>Error</source>
        <translation type="unfinished">错误</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="156"/>
        <source>Invalid procedure selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/compoundprocessdialog.cpp" line="163"/>
        <source>Sub Procedure %1 existing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/util/quihelper.cpp" line="40"/>
        <source>Ready</source>
        <translation>就绪</translation>
    </message>
    <message>
        <location filename="src/util/quihelper.cpp" line="41"/>
        <source>UI language switch to English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/util/quihelper.cpp" line="42"/>
        <source>UI language switch to Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Select</source>
        <translation type="obsolete">选择</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation type="obsolete">保存图像</translation>
    </message>
    <message>
        <location filename="src/commands/flowchart/addprocedure.cpp" line="27"/>
        <source>Add %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/commands/flowchart/changegeometry.cpp" line="18"/>
        <source>Change Geometry of %1 items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/commands/flowchart/changegeometry.cpp" line="115"/>
        <source>Change Geometry of %1 Linkers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/commands/flowchart/changeprocedure.cpp" line="24"/>
        <source>Change Data of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/commands/flowchart/changeprocedure.cpp" line="65"/>
        <source>Change Name of %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/commands/flowchart/deletelinkers.cpp" line="16"/>
        <source>Delete Linkers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/commands/flowchart/deleteprocedures.cpp" line="16"/>
        <source>Delete Procedures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="45"/>
        <source>The application can&apos;t open logging file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="60"/>
        <source>The application can&apos;t load vision plugin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/main.cpp" line="85"/>
        <source>The application is already running.
Allowed to run only one instance of the application.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="56"/>
        <source>Select Command Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="56"/>
        <source>Command Button:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="72"/>
        <source>Command Button %1 existing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="92"/>
        <source>Select Serial Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="92"/>
        <source>Serial Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="108"/>
        <source>Serial Port %1 existing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="125"/>
        <source>Select Net Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="125"/>
        <source>Net Client:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="141"/>
        <source>Net Client %1 existing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="158"/>
        <source>Select Net Server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="158"/>
        <source>Net Server:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="174"/>
        <source>Net Server %1 existing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="28"/>
        <source>Add Button Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="29"/>
        <source>Add Serial Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="30"/>
        <source>Add Net Client Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.cpp" line="31"/>
        <source>Add Net Server Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="465"/>
        <source>Select Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/mainframe.cpp" line="465"/>
        <source>Project</source>
        <translation type="unfinished">项目</translation>
    </message>
    <message>
        <location filename="src/util/qapphelper.cpp" line="109"/>
        <source>The application setting directory name is confict with regular file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/util/qapphelper.cpp" line="123"/>
        <source>The application setting directory %1 not existing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/util/qapphelper.cpp" line="158"/>
        <source>The application projects directory %1 not existing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="111"/>
        <source>Add Light Source</source>
        <translation type="unfinished">添加光源控制器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="114"/>
        <source>Delete Light Source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/camerapage.cpp" line="120"/>
        <source>Set Light Source</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSQLiteDriver</name>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="798"/>
        <source>Error opening database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="826"/>
        <source>Error closing database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="845"/>
        <source>Unable to begin transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="860"/>
        <source>Unable to commit transaction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="875"/>
        <source>Unable to rollback transaction</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QSQLiteResult</name>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="274"/>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="336"/>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="344"/>
        <source>Unable to fetch row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="275"/>
        <source>No query</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="402"/>
        <source>Unable to execute statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="407"/>
        <source>Unable to execute multiple statements at a time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="451"/>
        <source>Unable to reset statement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="557"/>
        <source>Unable to bind parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="plugins/sqlcipher/qsql_sqlite.cpp" line="564"/>
        <source>Parameter count mismatch</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RectTemplateDialog</name>
    <message>
        <source>Rectangle Template</source>
        <translation type="vanished">矩形模板</translation>
    </message>
    <message>
        <source>Camera</source>
        <translation type="vanished">相机</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="vanished">触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="vanished">创建模板</translation>
    </message>
    <message>
        <source>Half Width</source>
        <translation type="vanished">半宽</translation>
    </message>
    <message>
        <source>Scaled</source>
        <translation type="vanished">缩放</translation>
    </message>
    <message>
        <source>Scale Max</source>
        <translation type="vanished">最小缩放</translation>
    </message>
    <message>
        <source>Bright</source>
        <translation type="vanished">明亮</translation>
    </message>
    <message>
        <source>Scale Min</source>
        <translation type="vanished">最小缩放</translation>
    </message>
    <message>
        <source>Half Height</source>
        <translation type="vanished">半高</translation>
    </message>
    <message>
        <source>Angle Extent</source>
        <translation type="vanished">角度范围</translation>
    </message>
    <message>
        <source>Angle Start</source>
        <translation type="vanished">起始角度</translation>
    </message>
    <message>
        <source>Use Polarity</source>
        <translation type="vanished">使用极性</translation>
    </message>
    <message>
        <source>Min Contrast</source>
        <translation type="vanished">最小对比度</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">搜索模板</translation>
    </message>
    <message>
        <source>Start Level</source>
        <translation type="vanished">起始层</translation>
    </message>
    <message>
        <source>Stop Level</source>
        <translation type="vanished">停止层</translation>
    </message>
    <message>
        <source>Greediness</source>
        <translation type="vanished">贪婪度</translation>
    </message>
    <message>
        <source>Sub Pixel</source>
        <translation type="vanished">亚像素</translation>
    </message>
    <message>
        <source>Num Matches</source>
        <translation type="vanished">匹配数</translation>
    </message>
    <message>
        <source>Min Score</source>
        <translation type="vanished">最小得分</translation>
    </message>
    <message>
        <source>Max Deformation</source>
        <translation type="vanished">最大畸变</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="vanished">结果输出</translation>
    </message>
    <message>
        <source>X Resolution</source>
        <translation type="vanished">水平方向分辨率</translation>
    </message>
    <message>
        <source>Save Data</source>
        <translation type="vanished">保存结果数据</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="vanished">发送结果使用</translation>
    </message>
    <message>
        <source>Y Resolution</source>
        <translation type="vanished">竖直方向分辨率</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation type="vanished">保存图像</translation>
    </message>
    <message>
        <source>Center X/Y</source>
        <translation type="vanished">中心X/Y</translation>
    </message>
    <message>
        <source>Angle Start/Extent</source>
        <translation type="vanished">角度开始/范围</translation>
    </message>
    <message>
        <source>Half Width/Height</source>
        <translation type="vanished">半宽/高</translation>
    </message>
    <message>
        <source>Scale Min/Max</source>
        <translation type="vanished">缩放最小/最大</translation>
    </message>
    <message>
        <source>Angle</source>
        <translation type="vanished">角度</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">不保存</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">所有</translation>
    </message>
    <message>
        <source>ErrorOnly</source>
        <translation type="vanished">只保存错误</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Image empty error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;图像空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Template region empty error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;模板区域空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Template preview success&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;green&apos;&gt;预览模板成功&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Found %1 matches&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;green&apos;&gt;找到%1个匹配&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Template not found&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;模板没有找到&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>ReferencePointDialog</name>
    <message>
        <location filename="laserxwidgets/geomitems/referencepointdialog.ui" line="14"/>
        <source>Reference Point</source>
        <translation>参考点</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/referencepointdialog.ui" line="22"/>
        <source>X</source>
        <translation>X</translation>
    </message>
    <message>
        <location filename="laserxwidgets/geomitems/referencepointdialog.ui" line="36"/>
        <source>Y</source>
        <translation>Y</translation>
    </message>
</context>
<context>
    <name>RunPage</name>
    <message>
        <source>Command received from %1:%2: %3</source>
        <translation type="obsolete">从%1:%2: %3收到命令</translation>
    </message>
    <message>
        <location filename="src/ui/runpage.cpp" line="826"/>
        <source>Execute Python scripts error</source>
        <translation>执行Python脚本错误</translation>
    </message>
</context>
<context>
    <name>SerialPortDialog</name>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="14"/>
        <source>Serial Port Manager</source>
        <translation>串口管理</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="38"/>
        <source>Stop Bits</source>
        <translation>停止位</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="49"/>
        <source>NoFlowControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="54"/>
        <source>HardwareControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="59"/>
        <source>SoftwareControl</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="71"/>
        <source>NoParity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="76"/>
        <source>EvenParity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="81"/>
        <source>OddParity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="86"/>
        <source>SpaceParity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="91"/>
        <source>MarkParity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="103"/>
        <source>Baud1200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="108"/>
        <source>Baud2400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="113"/>
        <source>Baud4800</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="118"/>
        <source>Baud9600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="123"/>
        <source>Baud19200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="128"/>
        <source>Baud38400</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="133"/>
        <source>Baud57600</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="138"/>
        <source>Baud115200</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="146"/>
        <source>Parity</source>
        <translation>奇偶校检</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="157"/>
        <source>OneStop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="162"/>
        <source>OneAndHalfStop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="167"/>
        <source>TwoStop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="176"/>
        <source>Data5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="181"/>
        <source>Data6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="186"/>
        <source>Data7</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="191"/>
        <source>Data8</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="199"/>
        <source>Data Bits</source>
        <translation>数据位</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="206"/>
        <source>System Location</source>
        <translation>系统位置</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="213"/>
        <source>Baud Rate</source>
        <translation>波特率</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="220"/>
        <source>Direction</source>
        <translation>方向</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="234"/>
        <source>Description</source>
        <translation>描述</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="248"/>
        <source>Flow Control</source>
        <translation>流量控制</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="262"/>
        <source>Port Name</source>
        <translation>端口名</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="273"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="278"/>
        <source>Output</source>
        <translation type="unfinished">输出</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="283"/>
        <source>AllDirections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="291"/>
        <source>Status</source>
        <translation type="unfinished">状态</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="324"/>
        <source>Open Port</source>
        <translation>打开端口</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.ui" line="337"/>
        <source>Close Port</source>
        <translation>关闭端口</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="67"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="72"/>
        <source>Delete</source>
        <translation type="unfinished">删除控制器</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="77"/>
        <source>Send</source>
        <translation type="unfinished">发送</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="78"/>
        <source>Close</source>
        <translation type="unfinished">关闭</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="82"/>
        <source>Open</source>
        <translation type="unfinished">打开</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="150"/>
        <source>Port %1 is closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="174"/>
        <source>Port %1 is opened</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="184"/>
        <source>Please Input Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="184"/>
        <source>Message</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="184"/>
        <source>Hi, I&apos;m %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="278"/>
        <source>&lt;font color=&apos;green&apos;&gt;Port is opened&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="282"/>
        <source>&lt;font color=&apos;red&apos;&gt;Port is closed&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="290"/>
        <source>Port %1 error %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="300"/>
        <source>Port %1 error %2 is occured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/ui/dialog/device/serialportdialog.cpp" line="310"/>
        <source>Port %1 write %2 bytes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ShapeMatchDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="192"/>
        <source>Camera</source>
        <translation>相机</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="193"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="194"/>
        <source>Matching</source>
        <translation>匹配</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/miscdialogs.cpp" line="195"/>
        <source>Output</source>
        <translation>输出</translation>
    </message>
</context>
<context>
    <name>ShapeMatchPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="40"/>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="119"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="71"/>
        <source>Preview</source>
        <translation>预览</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="98"/>
        <source>Save As</source>
        <translation>另存为</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="105"/>
        <source>Parameters</source>
        <translation>参数</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="61"/>
        <source>ROI</source>
        <translation>ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="88"/>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="158"/>
        <source>Search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="144"/>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="183"/>
        <source>Name</source>
        <translation>名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="149"/>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="188"/>
        <source>Value</source>
        <translation>值</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="47"/>
        <source>Hide ROI</source>
        <translation>隐藏ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="78"/>
        <source>Show Create ROI</source>
        <translation>显示模板ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.ui" line="54"/>
        <source>Show Search ROI</source>
        <translation>显示搜索ROI</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.cpp" line="80"/>
        <source>&lt;font color=&apos;red&apos;&gt;Image empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;图像空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.cpp" line="87"/>
        <source>&lt;font color=&apos;red&apos;&gt;Template region empty error&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;模板区域空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.cpp" line="113"/>
        <source>&lt;font color=&apos;green&apos;&gt;Template preview success&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;预览模板成功&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.cpp" line="136"/>
        <source>Save template file</source>
        <translation>保存模板文件</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.cpp" line="136"/>
        <source>Template files(*.shm)</source>
        <translation>模板文件(*.shm)</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.cpp" line="164"/>
        <source>&lt;font color=&apos;green&apos;&gt;Found %1 matches&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;找到%1个匹配&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/procpage/shapematchpage.cpp" line="168"/>
        <source>&lt;font color=&apos;red&apos;&gt;Template not found&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;模板没有找到&lt;/font&gt;</translation>
    </message>
</context>
<context>
    <name>ShapeTemplateDialog</name>
    <message>
        <source>Shape Template</source>
        <translation type="vanished">形状模板</translation>
    </message>
    <message>
        <source>Camera</source>
        <translation type="vanished">相机</translation>
    </message>
    <message>
        <source>Trigger</source>
        <translation type="vanished">触发</translation>
    </message>
    <message>
        <source>Command Name</source>
        <translation type="vanished">命令名字</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="vanished">创建模板</translation>
    </message>
    <message>
        <source>Scaled</source>
        <translation type="vanished">缩放</translation>
    </message>
    <message>
        <source>Auto Num Levels</source>
        <translation type="vanished">自动金字塔层数</translation>
    </message>
    <message>
        <source>Angle Start</source>
        <translation type="vanished">起始角度</translation>
    </message>
    <message>
        <source>Angle Extent</source>
        <translation type="vanished">角度范围</translation>
    </message>
    <message>
        <source>Scale Max</source>
        <translation type="vanished">最小缩放</translation>
    </message>
    <message>
        <source>Num Levels</source>
        <translation type="vanished">金字塔层数</translation>
    </message>
    <message>
        <source>Minimum Size</source>
        <translation type="vanished">最小边缘大小</translation>
    </message>
    <message>
        <source>Use Polarity</source>
        <translation type="vanished">使用极性</translation>
    </message>
    <message>
        <source>Lower Contrast</source>
        <translation type="vanished">低对比度</translation>
    </message>
    <message>
        <source>Preview</source>
        <translation type="vanished">预览模板</translation>
    </message>
    <message>
        <source>Scale Min</source>
        <translation type="vanished">最小缩放</translation>
    </message>
    <message>
        <source>Upper Contrast</source>
        <translation type="vanished">高对比度</translation>
    </message>
    <message>
        <source>Min Contrast</source>
        <translation type="vanished">最小对比度</translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="vanished">搜索模板</translation>
    </message>
    <message>
        <source>Min Score</source>
        <translation type="vanished">最小得分</translation>
    </message>
    <message>
        <source>Max Deformation</source>
        <translation type="vanished">最大畸变</translation>
    </message>
    <message>
        <source>Stop Level</source>
        <translation type="vanished">停止层</translation>
    </message>
    <message>
        <source>Greediness</source>
        <translation type="vanished">贪婪度</translation>
    </message>
    <message>
        <source>Sub Pixel</source>
        <translation type="vanished">亚像素</translation>
    </message>
    <message>
        <source>Num Matches</source>
        <translation type="vanished">匹配数</translation>
    </message>
    <message>
        <source>Start Level</source>
        <translation type="vanished">起始层</translation>
    </message>
    <message>
        <source>Output</source>
        <translation type="vanished">结果输出</translation>
    </message>
    <message>
        <source>Save Image</source>
        <translation type="vanished">保存图像</translation>
    </message>
    <message>
        <source>Display In</source>
        <translation type="vanished">结果显示在</translation>
    </message>
    <message>
        <source>X Resolution</source>
        <translation type="vanished">水平方向分辨率</translation>
    </message>
    <message>
        <source>Y Resolution</source>
        <translation type="vanished">竖直方向分辨率</translation>
    </message>
    <message>
        <source>Send Data Use</source>
        <translation type="vanished">发送结果使用</translation>
    </message>
    <message>
        <source>Save Data</source>
        <translation type="vanished">保存结果数据</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="vanished">不保存</translation>
    </message>
    <message>
        <source>All</source>
        <translation type="vanished">保存所有</translation>
    </message>
    <message>
        <source>ErrorOnly</source>
        <translation type="vanished">只保存错误</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="vanished">应用</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Image empty error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;图像空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Template region empty error&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;模板区域空错误&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Template preview success&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;green&apos;&gt;预览模板成功&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;green&apos;&gt;Found %1 matches&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;green&apos;&gt;找到%1个匹配&lt;/font&gt;</translation>
    </message>
    <message>
        <source>&lt;font color=&apos;red&apos;&gt;Template not found&lt;/font&gt;</source>
        <translation type="vanished">&lt;font color=&apos;red&apos;&gt;模板没有找到&lt;/font&gt;</translation>
    </message>
    <message>
        <source>Discard changes</source>
        <translation type="vanished">丢弃修改</translation>
    </message>
    <message>
        <source>Parameter changed. Are you sure you want to discard changes?</source>
        <translation type="vanished">你确定要丢弃参数修改吗?</translation>
    </message>
</context>
<context>
    <name>SoftTriggerDialog</name>
    <message>
        <source>Dialog</source>
        <translation type="vanished">对话框</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="vanished">名字</translation>
    </message>
    <message>
        <source>Button</source>
        <translation type="vanished">触发按钮</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/softtriggerdialog.ui" line="14"/>
        <source>Soft Trigger</source>
        <translation>软触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/softtriggerdialog.ui" line="27"/>
        <source>Trigger Button</source>
        <translation>触发按钮</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/softtriggerdialog.ui" line="40"/>
        <source>Trigger</source>
        <translation>触发</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/softtriggerdialog.ui" line="61"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/softtriggerdialog.ui" line="68"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
</context>
<context>
    <name>TimerTriggerDialog</name>
    <message>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.ui" line="14"/>
        <source>Timer Trigger</source>
        <translation>定时器触发</translation>
    </message>
    <message>
        <source>Name</source>
        <translation type="obsolete">名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.ui" line="27"/>
        <source>Interval(ms)</source>
        <translation>时间间隔(ms)</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.ui" line="53"/>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.cpp" line="63"/>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.cpp" line="113"/>
        <source>Start</source>
        <translation>启动</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.ui" line="74"/>
        <source>Apply</source>
        <translation>应用</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.ui" line="81"/>
        <source>Close</source>
        <translation>关闭</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.cpp" line="64"/>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.cpp" line="114"/>
        <source>Stopped</source>
        <translation>停止状态</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.cpp" line="71"/>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.cpp" line="107"/>
        <source>Stop</source>
        <translation>停止</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.cpp" line="72"/>
        <location filename="src/ui/dialog/procedure/timertriggerdialog.cpp" line="108"/>
        <source>Active</source>
        <translation>活动状态</translation>
    </message>
</context>
<context>
    <name>TriggerPage</name>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.ui" line="14"/>
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/procedure/configpage/triggerpage.ui" line="22"/>
        <source>Command Name</source>
        <translation>命令名字</translation>
    </message>
</context>
<context>
    <name>TriggerToolBox</name>
    <message>
        <location filename="src/ui/flowchart/toolbox/triggertoolbox.cpp" line="74"/>
        <source>Trigger Toolbox</source>
        <translation>触发工具箱</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/triggertoolbox.cpp" line="75"/>
        <source>Digital IO</source>
        <translation>数字I/O触发</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/triggertoolbox.cpp" line="76"/>
        <source>Serial Port</source>
        <oldsource>Serial</oldsource>
        <translation>串口触发</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/triggertoolbox.cpp" line="77"/>
        <source>Network</source>
        <translation>网口触发</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/triggertoolbox.cpp" line="78"/>
        <source>Soft</source>
        <translation>软触发</translation>
    </message>
    <message>
        <location filename="src/ui/flowchart/toolbox/triggertoolbox.cpp" line="79"/>
        <source>Timer</source>
        <translation>定时器触发</translation>
    </message>
</context>
<context>
    <name>UpdateProjectDialog</name>
    <message>
        <location filename="src/ui/dialog/project/updateprojectdialog.ui" line="14"/>
        <source>Update Project</source>
        <translation>更新项目</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/updateprojectdialog.ui" line="25"/>
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/updateprojectdialog.ui" line="35"/>
        <source>Project Path</source>
        <translation>项目路径</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/updateprojectdialog.ui" line="42"/>
        <source>Project Name</source>
        <translation>项目名字</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/updateprojectdialog.cpp" line="13"/>
        <source>Update</source>
        <translation>更新</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/updateprojectdialog.cpp" line="47"/>
        <source>Open Project File</source>
        <translation>打开项目文件</translation>
    </message>
    <message>
        <location filename="src/ui/dialog/project/updateprojectdialog.cpp" line="47"/>
        <source>Laser X Project Files (*.db *.lxp)</source>
        <translation>项目文件(*.db *.lxp)</translation>
    </message>
</context>
</TS>
