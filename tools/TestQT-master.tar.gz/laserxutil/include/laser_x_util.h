#ifndef LASER_X_UTIL_H
#define LASER_X_UTIL_H
#include <QtCore>
constexpr qreal EPSILON = 1e-6; //1e-18;
#define QSL(s) QStringLiteral(s)
inline QPointF rot90(QPointF const& p)
{
    return QPointF(-p.y(), p.x());
}

inline QPointF rrot90(QPointF const& p)
{
    return QPointF(p.y(), -p.x());
}

inline qreal dot(QPointF const& a, QPointF const& b)
{
    return a.x() * b.x() + a.y() * b.y();
}

inline qreal cross(QPointF const& a, QPointF const& b)
{
    return a.x() * b.y() - a.y() * b.x();
}

inline QPointF lerp(qreal t, QPointF const& a, QPointF const& b)
{
    return (1 - t) * a + t * b;
}

inline qreal length(QPointF const& a)
{
    return std::hypot(a.x(), a.y());
}

inline qreal L2sq(QPointF const& p)
{
    return p.x() * p.x() + p.y() * p.y();
}

inline qreal distance(QPointF const& a, QPointF const& b)
{
    return length(a - b);
}

inline qreal distanceSq(QPointF const& a, QPointF const& b)
{
    return L2sq(a - b);
}

inline QPointF middle_point(QPointF const& p1, QPointF const& p2)
{
    return lerp(0.5, p1, p2);
}

inline bool isDegenerate(const QLineF& l)
{
    return L2sq(l.p1() - l.p2()) < EPSILON;
}

inline QPointF vector(const QLineF& l)
{
    return l.p2() - l.p1();
}

inline qreal timeAtProjection(const QLineF& l, QPointF const& p)
{
    if (isDegenerate(l)) return 0;
    QPointF v = vector(l);
    return dot(p - l.p1(), v) / dot(v, v);
}

inline qreal nearestTime(const QLineF& l, QPointF const& p)
{
    return timeAtProjection(l, p);
}

inline qreal distance(QPointF const& p, QLineF const& line)
{
    if (isDegenerate(line))
    {
        return distance(p, line.p1());
    }
    else
    {
        qreal t = nearestTime(line, p);
        return distance(line.pointAt(t), p);
    }
}

inline qreal sdistance(QPointF const& p, QLineF const& line)
{
    if (isDegenerate(line))
    {
        return distance(p, line.p1());
    }
    else
    {
        const QPointF v1 = p - line.p1();
        const QPointF v2 = line.p2() - line.p1();
        return cross(v1, v2) / distance(line.p1(), line.p2());
    }
}

inline qreal sdistance(QPointF const& p, QPointF const& p1, QPointF const& p2)
{
    if (isDegenerate(QLineF(p1, p2)))
    {
        return distance(p, p1);
    }
    else
    {
        const QPointF v1 = p - p1;
        const QPointF v2 = p2 - p1;
        return cross(v1, v2) / distance(p1, p2);
    }
}

inline QJsonObject toJson(const QPointF& val)
{
    QJsonObject obj;
    obj[QLatin1String("x")] = val.x();
    obj[QLatin1String("y")] = val.y();
    return obj;
}

inline QJsonArray toJson(const QVector<QPointF>& val)
{
    QJsonArray jArr;
    for (const QPointF& iPoint : val)
    {
        jArr.push_back(toJson(iPoint));
    }
    return jArr;
}

inline QJsonObject toJson(const QLineF& val)
{
    QJsonObject obj;
    obj[QLatin1String("p1")] = toJson(val.p1());
    obj[QLatin1String("p2")] = toJson(val.p2());
    return obj;
}

inline QJsonArray toJson(const QVector<QLineF>& val)
{
    QJsonArray jArr;
    for (const QLineF& iLine : val)
    {
        jArr.push_back(toJson(iLine));
    }
    return jArr;
}

inline QJsonObject toJson(const QRectF& val)
{
    QJsonObject obj;
    obj[QLatin1String("x")] = val.x();
    obj[QLatin1String("y")] = val.y();
    obj[QLatin1String("width")] = val.width();
    obj[QLatin1String("height")] = val.height();
    return obj;
}

inline QJsonArray toJson(const QVector<QRectF> &val)
{
    QJsonArray jArr;
    for (const QRectF &iRect : val)
    {
        jArr.push_back(toJson(iRect));
    }
    return jArr;
}

inline qreal fromJson(const QJsonObject& obj, const QLatin1String& name, const qreal& defVal)
{
    if (obj.contains(name) && obj[name].isDouble())
    {
        return obj[name].toDouble();
    }
    else
    {
        return defVal;
    }
}

inline QString fromJson(const QJsonObject& obj, const QLatin1String& name, const QString& defVal)
{
    if (obj.contains(name) && obj[name].isString())
    {
        return obj[name].toString();
    }
    else
    {
        return defVal;
    }
}

inline bool fromJson(const QJsonObject& obj, const QLatin1String& name, const bool& defVal)
{
    if (obj.contains(name) && obj[name].isBool())
    {
        return obj[name].toBool();
    }
    else
    {
        return defVal;
    }
}

inline int fromJson(const QJsonObject& obj, const QLatin1String& name, const int& defVal)
{
    if (obj.contains(name) && obj[name].isDouble())
    {
        return obj[name].toInt(defVal);
    }
    else
    {
        return defVal;
    }
}

inline qlonglong fromJson(const QJsonObject& obj, const QLatin1String& name, const qlonglong& defVal)
{
    if (obj.contains(name) && obj[name].isDouble())
    {
        return obj[name].toInteger(defVal);
    }
    else
    {
        return defVal;
    }
}

inline QJsonObject getJsonObject(const QJsonObject& obj, const QLatin1String& name)
{
    if (obj.contains(name) && obj[name].isObject())
    {
        return obj[name].toObject();
    }
    else
    {
        return QJsonObject();
    }
}

inline QStringList fromJson(const QJsonObject& obj, const QLatin1String& name, const QStringList& defVal)
{
    if (obj.contains(name) && obj[name].isArray())
    {
        QStringList strs;
        QJsonArray objs = obj[name].toArray();
        for (const auto& obj : objs)
        {
            if (obj.isString())
            {
                strs.push_back(obj.toString());
            }
        }
        return strs;
    }
    else
    {
        return defVal;
    }
}

inline QJsonArray fromJson(const QJsonObject& obj, const QLatin1String& name, const QJsonArray& defVal)
{
    if (obj.contains(name) && obj[name].isArray())
    {
        QJsonArray objs = obj[name].toArray();
        return objs;
    }
    else
    {
        return defVal;
    }
}

inline QPointF fromJson(const QJsonObject& obj, const QLatin1String& name, const QPointF& defVal)
{
    qreal x = defVal.x(), y = defVal.y();
    if (obj.contains(name) && obj[name].isObject())
    {
        QJsonObject posObject = obj[QLatin1String(name)].toObject();
        x = fromJson(posObject, QLatin1String("x"), defVal.x());
        y = fromJson(posObject, QLatin1String("y"), defVal.y());
    }
    return QPointF(x, y);
}

inline QPointF fromJson(const QJsonValueRef& val, const QPointF& defVal)
{
    qreal x = defVal.x(), y = defVal.y();
    if (val.isObject())
    {
        QJsonObject posObject = val.toObject();
        x = fromJson(posObject, QLatin1String("x"), defVal.x());
        y = fromJson(posObject, QLatin1String("y"), defVal.y());
    }
    return QPointF(x, y);
}

inline QRectF fromJson(const QJsonObject& obj, const QLatin1String& name, const QRectF& defVal)
{
    qreal x = defVal.x(), y = defVal.y(), width = defVal.width(), height = defVal.height();
    if (obj.contains(name) && obj[name].isObject())
    {
        QJsonObject rcObject = obj[QLatin1String(name)].toObject();
        x = fromJson(rcObject, QLatin1String("x"), defVal.x());
        y = fromJson(rcObject, QLatin1String("y"), defVal.y());
        width = fromJson(rcObject, QLatin1String("width"), defVal.width());
        height = fromJson(rcObject, QLatin1String("height"), defVal.height());
    }
    return QRectF(x, y, width, height);
}

inline QRectF fromJson(const QJsonValueRef& val, const QRectF& defVal)
{
    qreal x = defVal.x(), y = defVal.y(), width = defVal.width(), height = defVal.height();
    if (val.isObject())
    {
        QJsonObject rcObject = val.toObject();
        x = fromJson(rcObject, QLatin1String("x"), defVal.x());
        y = fromJson(rcObject, QLatin1String("y"), defVal.y());
        width = fromJson(rcObject, QLatin1String("width"), defVal.width());
        height = fromJson(rcObject, QLatin1String("height"), defVal.height());
    }
    return QRectF(x, y, width, height);
}

inline QVector<QRectF> fromJson(const QJsonObject& obj, const QLatin1String& name, const QVector<QRectF> &defVal)
{
    if (obj.contains(name) && obj[name].isArray())
    {
        QVector<QRectF> iRects;
        QJsonArray jRects = obj[name].toArray();
        for (const QJsonValueRef &jRect : jRects)
        {
            iRects.push_back(fromJson(jRect, QRectF()));
        }
        return iRects;
    }
    else
    {
        return defVal;
    }
}

inline QVector<QPointF> fromJson(const QJsonObject& obj, const QLatin1String& name, const QVector<QPointF>& defVal)
{
    if (obj.contains(name) && obj[name].isArray())
    {
        QVector<QPointF> iPoints;
        QJsonArray jPoints = obj[name].toArray();
        for (const QJsonValueRef& jPoint : jPoints)
        {
            iPoints.push_back(fromJson(jPoint, QPointF()));
        }
        return iPoints;
    }
    else
    {
        return defVal;
    }
}

inline QLineF fromJson(const QJsonObject& obj, const QLatin1String& name, const QLineF& defVal)
{
    QPointF p1 = defVal.p1(), p2 = defVal.p2();
    if (obj.contains(name) && obj[name].isObject())
    {
        QJsonObject lineObject = obj[QLatin1String(name)].toObject();
        p1 = fromJson(lineObject, QLatin1String("p1"), defVal.p1());
        p2 = fromJson(lineObject, QLatin1String("p2"), defVal.p2());
    }

    return QLineF(p1, p2);
}

template<typename QEnum>
QString QtEnumToString(const QEnum value)
{
    return QString::fromLatin1(QMetaEnum::fromType<QEnum>().valueToKey(value));
}

template<typename QEnum>
QEnum QtStringToEnum(const QString& key, const QEnum defaultVal)
{
    bool ok = false;
    int val = QMetaEnum::fromType<QEnum>().keyToValue(key.toLatin1().constData(), &ok);
    if (ok)
    {
        return static_cast<QEnum>(val);
    }
    else
    {
        return defaultVal;
    }
}

inline qreal toFixed(const qreal v, const int n)
{
    return QString::number(v, 'f', n).toDouble();
}

#endif // LASER_X_UTIL_H
