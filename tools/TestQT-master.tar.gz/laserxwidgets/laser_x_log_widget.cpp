#include "laser_x_log_widget.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>

LaserXLogWidget::LaserXLogWidget(QWidget *parent)
    : QPlainTextEdit(parent)
{
    setReadOnly(true);
}

void LaserXLogWidget::appendInfo(const QString &msg)
{
    if (!mBlocking)
    {
        QTime now = QTime::currentTime();
        appendPlainText(QStringLiteral("%1 INFO %2").arg(now.toString()).arg(msg));
        ensureCursorVisible();
    }
}

void LaserXLogWidget::appendError(const QString &msg)
{
    if (!mBlocking)
    {
        QTime now = QTime::currentTime();
        appendHtml(QStringLiteral("%1 <span style='color:red;'>ERROR</span> %2").arg(now.toString()).arg(msg));
        ensureCursorVisible();
    }
}

void LaserXLogWidget::appendWarning(const QString &msg)
{
    if (!mBlocking)
    {
        QTime now = QTime::currentTime();
        appendHtml(QStringLiteral("%1 <span style='color:#ff5500;'>WARNING</span> %2").arg(now.toString()).arg(msg));
        ensureCursorVisible();
    }
}

void LaserXLogWidget::contextMenuEvent(QContextMenuEvent* event)
{
    std::unique_ptr<QMenu> menu = std::unique_ptr<QMenu>(createStandardContextMenu());
    menu->addSeparator();

    QTextDocument* doc = document();
    if (doc && !doc->isEmpty())
    {
        if (isReadOnly())
        {
            menu->addAction(tr("Clear"), [this]() { this->clear(); });
        }

        menu->addAction(tr("Export"), this, qOverload<>(&LaserXLogWidget::exportToText));
        menu->addAction(tr("Export HTML"), this, qOverload<>(&LaserXLogWidget::exportToHtml));
        menu->addSeparator();
        QAction *blockingAction = menu->addAction(tr("Block"), [this]() { setBlocking(!mBlocking); });
        blockingAction->setCheckable(true);
        blockingAction->setChecked(mBlocking);
    }

    if (!menu->children().isEmpty())
    {
        menu->exec(event->globalPos());
    }
}

void LaserXLogWidget::exportToHtml()
{
    exportToHtml(QFileDialog::getSaveFileName(this, tr("Save log file"), QStringLiteral(""), tr("HTML files(*.htm *.html)")));
}

void LaserXLogWidget::exportToText()
{
    exportToText(QFileDialog::getSaveFileName(this, tr("Save log file"), QStringLiteral(""), tr("Text files (*.txt)")));
}

void LaserXLogWidget::exportToHtml(const QString& fileName)
{
    QFile file(fileName);
    QTextDocument* doc = document();
    if (doc && !doc->isEmpty() && file.open(QFile::WriteOnly | QFile::Text))
    {
        QTextStream writer(&file);
        writer << doc->toHtml();
    }
}

void LaserXLogWidget::exportToText(const QString& fileName)
{
    QFile file(fileName);
    QTextDocument* doc = document();
    if (doc && !doc->isEmpty() && file.open(QFile::WriteOnly | QFile::Text))
    {
        QTextStream writer(&file);
        writer << doc->toPlainText();
    }
}

void LaserXLogWidget::setBlocking(const bool blocking)
{
    mBlocking = blocking;
}
