#ifndef LASER_X_LOG_WIDGET_H
#define LASER_X_LOG_WIDGET_H

#include <QPlainTextEdit>
#include "laser_x_widgets_global.h"

class LASERXWIDGETS_EXPORT LaserXLogWidget : public QPlainTextEdit
{
    Q_OBJECT

public:
    explicit LaserXLogWidget(QWidget *parent = nullptr);

protected:
    void contextMenuEvent(QContextMenuEvent* event) override;

public:
    void appendInfo(const QString &msg);
    void appendError(const QString &msg);
    void appendWarning(const QString &msg);
    void exportToHtml();
    void exportToText();
    void exportToHtml(const QString& fileName);
    void exportToText(const QString& fileName);
    void setBlocking(const bool blocking);

private:
    bool mBlocking = false;
};

#endif //LASER_X_LOG_WIDGET_H
