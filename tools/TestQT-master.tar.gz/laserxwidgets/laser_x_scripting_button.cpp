#include "laser_x_scripting_button.h"

#include <QtWidgets>
#include <QMouseEvent>
#include <QPainter>
#include <QTime>
#include <QTimer>
#include "py3_editor_popup.h"

LaserXScriptingButton::LaserXScriptingButton(QWidget *parent)
    : QToolButton(parent)
{
    setText(tr("Execute"));

    QTimer::singleShot(0, this, [=]()
    { 
        auto popup = new Py3EditorPopup(this);
        auto popupAction = new QWidgetAction(this);
        popupAction->setDefaultWidget(popup);
        setPopupMode(QToolButton::MenuButtonPopup);
        addAction(popupAction);
    });
}
