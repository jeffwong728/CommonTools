#include "laser_x_canvas_p.h"
#include "laser_x_canvas.h"
#include "canvas_scene.h"
#include <QtWidgets>
#include <QMouseEvent>
#include <QOpenGLWidget>
#include <opencv2/imgproc.hpp>
#include <laser_x_camera.h>
#include <laser_x_vision.h>
#include <geomitems/region_item.h>
#include <geomitems/child_rect_item.h>
#include <geomitems/child_polygon_item.h>
#include <geomitems/child_ellipse_item.h>
#include <geomitems/line_finder_item.h>
#include <geomitems/circle_finder_item.h>
#include <geomitems/geom_finder_item.h>
#include <geomitems/reference_point.h>
#include <boost/algorithm/string.hpp>
LaserXVisionManager* gVision = nullptr;

LaserXCanvasPrivate::LaserXCanvasPrivate(QObject* const ptr)
    : q_ptr(ptr)
    , mImageSourceName(QStringLiteral("N/A"))
    , mAcceptDropImage(false)
{
}

LaserXCanvasPrivate::~LaserXCanvasPrivate()
{
}

void LaserXCanvasPrivate::retranslateUi()
{
    if (mFlowPanel)
    {
        mFlowButtons[SelectButton]->setToolTip(LaserXCanvas::tr("Select"));
        mFlowButtons[DrawLine]->setToolTip(LaserXCanvas::tr("Draw Line"));
        mFlowButtons[DrawSquare]->setToolTip(LaserXCanvas::tr("Draw Square"));
        mFlowButtons[DrawLineFinder]->setToolTip(LaserXCanvas::tr("Draw Line Finder Box"));
        mFlowButtons[DrawCircleFinder]->setToolTip(LaserXCanvas::tr("Draw Circle Finder Box"));
        mFlowButtons[DrawRectFinder]->setToolTip(LaserXCanvas::tr("Draw Rectangle Finder Box"));
        mFlowButtons[DrawEllipseFinder]->setToolTip(LaserXCanvas::tr("Draw Ellipse Finder Box"));
        mFlowButtons[DrawEllipse]->setToolTip(LaserXCanvas::tr("Draw Ellipse"));
        mFlowButtons[DrawPolygon]->setToolTip(LaserXCanvas::tr("Draw Polygon"));
        mFlowButtons[DrawCharBox]->setToolTip(LaserXCanvas::tr("Draw Char Box"));
        mFlowButtons[SnapButton]->setToolTip(LaserXCanvas::tr("Snapshot"));
        mFlowButtons[LiveButton]->setToolTip(LaserXCanvas::tr("Live"));
        mFlowButtons[BreakLink]->setToolTip(LaserXCanvas::tr("Break Camera Link"));
        mFlowButtons[CrossLine]->setToolTip(LaserXCanvas::tr("Toggle Cross Line"));
        mFlowButtons[RefPoint]->setToolTip(LaserXCanvas::tr("Toggle Reference Point"));
        mFlowButtons[HideROI]->setToolTip(LaserXCanvas::tr("Hide ROI"));
        mFlowButtons[SaveImage]->setToolTip(LaserXCanvas::tr("Save Image"));
        mFlowButtons[ColorPicker]->setToolTip(LaserXCanvas::tr("Color Picker"));
    }
}

void LaserXCanvasPrivate::initFlowPanel()
{
    Q_Q(LaserXCanvas);
    if (mFlowPanelEnabled && !mFlowPanel)
    {
        mFlowPanel = new QWidget(q);
        mFlowPanel->setObjectName(QStringLiteral("flowPanel"));
        mFlowPanel->setVisible(false);

        QHBoxLayout* layout = new QHBoxLayout(mFlowPanel);
        layout->setSpacing(2);
        layout->setContentsMargins(0, 0, 0, 0);
        layout->addStretch();
        mFlowPanel->setLayout(layout);

        mFlowButtons[SelectButton] = new QPushButton(mFlowPanel);
        mFlowButtons[SelectButton]->setObjectName(QStringLiteral("selectButton"));
        mFlowButtons[SelectButton]->setFixedWidth(20);
        mFlowButtons[SelectButton]->setCheckable(true);
        mFlowButtons[SelectButton]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[SelectButton]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[SelectButton]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/cursor.png")));
        layout->addWidget(mFlowButtons[SelectButton]);

        mFlowButtons[DrawLine] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawLine]->setObjectName(QStringLiteral("drawLine"));
        mFlowButtons[DrawLine]->setFixedWidth(20);
        mFlowButtons[DrawLine]->setCheckable(true);
        mFlowButtons[DrawLine]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawLine]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawLine]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/draw_line.png")));
        layout->addWidget(mFlowButtons[DrawLine]);

        mFlowButtons[DrawSquare] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawSquare]->setObjectName(QStringLiteral("drawSquare"));
        mFlowButtons[DrawSquare]->setFixedWidth(20);
        mFlowButtons[DrawSquare]->setCheckable(true);
        mFlowButtons[DrawSquare]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawSquare]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawSquare]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/draw_square.png")));
        layout->addWidget(mFlowButtons[DrawSquare]);

        mFlowButtons[DrawEllipse] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawEllipse]->setObjectName(QStringLiteral("drawEllipse"));
        mFlowButtons[DrawEllipse]->setFixedWidth(20);
        mFlowButtons[DrawEllipse]->setCheckable(true);
        mFlowButtons[DrawEllipse]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawEllipse]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawEllipse]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/draw_ellipse.png")));
        layout->addWidget(mFlowButtons[DrawEllipse]);

        mFlowButtons[DrawPolygon] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawPolygon]->setObjectName(QStringLiteral("drawPolygon"));
        mFlowButtons[DrawPolygon]->setFixedWidth(20);
        mFlowButtons[DrawPolygon]->setCheckable(true);
        mFlowButtons[DrawPolygon]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawPolygon]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawPolygon]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/draw_polygon.png")));
        layout->addWidget(mFlowButtons[DrawPolygon]);

        mFlowButtons[DrawCharBox] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawCharBox]->setObjectName(QStringLiteral("drawCharBox"));
        mFlowButtons[DrawCharBox]->setFixedWidth(20);
        mFlowButtons[DrawCharBox]->setCheckable(true);
        mFlowButtons[DrawCharBox]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawCharBox]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawCharBox]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/char-box-16.png")));
        layout->addWidget(mFlowButtons[DrawCharBox]);

        mFlowButtons[DrawLineFinder] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawLineFinder]->setObjectName(QStringLiteral("drawLineFinder"));
        mFlowButtons[DrawLineFinder]->setFixedWidth(20);
        mFlowButtons[DrawLineFinder]->setCheckable(true);
        mFlowButtons[DrawLineFinder]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawLineFinder]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawLineFinder]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/line_measure_box.png")));
        layout->addWidget(mFlowButtons[DrawLineFinder]);

        mFlowButtons[DrawCircleFinder] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawCircleFinder]->setObjectName(QStringLiteral("drawCircleFinder"));
        mFlowButtons[DrawCircleFinder]->setFixedWidth(20);
        mFlowButtons[DrawCircleFinder]->setCheckable(true);
        mFlowButtons[DrawCircleFinder]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawCircleFinder]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawCircleFinder]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/circle_measure_annulus.png")));
        layout->addWidget(mFlowButtons[DrawCircleFinder]);

        mFlowButtons[DrawRectFinder] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawRectFinder]->setObjectName(QStringLiteral("drawRectFinder"));
        mFlowButtons[DrawRectFinder]->setFixedWidth(20);
        mFlowButtons[DrawRectFinder]->setCheckable(true);
        mFlowButtons[DrawRectFinder]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawRectFinder]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawRectFinder]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/rect_measure_box.png")));
        layout->addWidget(mFlowButtons[DrawRectFinder]);

        mFlowButtons[DrawEllipseFinder] = new QPushButton(mFlowPanel);
        mFlowButtons[DrawEllipseFinder]->setObjectName(QStringLiteral("drawEllipseFinder"));
        mFlowButtons[DrawEllipseFinder]->setFixedWidth(20);
        mFlowButtons[DrawEllipseFinder]->setCheckable(true);
        mFlowButtons[DrawEllipseFinder]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[DrawEllipseFinder]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[DrawEllipseFinder]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/ellipse_measure_annulus.png")));
        layout->addWidget(mFlowButtons[DrawEllipseFinder]);

        mDrawingGroup = new QButtonGroup(mFlowPanel);
        mDrawingGroup->addButton(mFlowButtons[SelectButton], 0);
        mDrawingGroup->addButton(mFlowButtons[DrawLine], 1);
        mDrawingGroup->addButton(mFlowButtons[DrawSquare], 2);
        mDrawingGroup->addButton(mFlowButtons[DrawEllipse], 3);
        mDrawingGroup->addButton(mFlowButtons[DrawPolygon], 4);
        mDrawingGroup->addButton(mFlowButtons[DrawLineFinder], 5);
        mDrawingGroup->addButton(mFlowButtons[DrawCircleFinder], 6);
        mDrawingGroup->addButton(mFlowButtons[DrawRectFinder], 7);
        mDrawingGroup->addButton(mFlowButtons[DrawEllipseFinder], 8);
        mDrawingGroup->addButton(mFlowButtons[DrawCharBox], 9);
        mDrawingGroup->setExclusive(true);
        q->connect(mDrawingGroup, QOverload<QAbstractButton*, bool>::of(&QButtonGroup::buttonToggled), this, &LaserXCanvasPrivate::drawingSwitched);

        mFlowButtons[SaveImage] = new QPushButton(mFlowPanel);
        mFlowButtons[SaveImage]->setObjectName(QStringLiteral("saveImage"));
        mFlowButtons[SaveImage]->setFixedWidth(20);
        mFlowButtons[SaveImage]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[SaveImage]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[SaveImage]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/picture_save.png")));
        q->connect(mFlowButtons[SaveImage], &QPushButton::clicked, this, &LaserXCanvasPrivate::btnClicked);
        layout->addWidget(mFlowButtons[SaveImage]);

        mFlowButtons[ColorPicker] = new QPushButton(mFlowPanel);
        mFlowButtons[ColorPicker]->setObjectName(QStringLiteral("colorButton"));
        mFlowButtons[ColorPicker]->setFixedWidth(20);
        mFlowButtons[ColorPicker]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[ColorPicker]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[ColorPicker]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/color-16.png")));
        mFlowButtons[ColorPicker]->setCheckable(true);
        q->connect(mFlowButtons[ColorPicker], &QPushButton::clicked, this, &LaserXCanvasPrivate::btnClicked);
        layout->addWidget(mFlowButtons[ColorPicker]);

        mFlowButtons[CrossLine] = new QPushButton(mFlowPanel);
        mFlowButtons[CrossLine]->setObjectName(QStringLiteral("toggleCrossLine"));
        mFlowButtons[CrossLine]->setFixedWidth(20);
        mFlowButtons[CrossLine]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[CrossLine]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[CrossLine]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/flag_red_cross.png")));
        q->connect(mFlowButtons[CrossLine], &QPushButton::clicked, this, &LaserXCanvasPrivate::btnClicked);
        layout->addWidget(mFlowButtons[CrossLine]);

        mFlowButtons[RefPoint] = new QPushButton(mFlowPanel);
        mFlowButtons[RefPoint]->setObjectName(QStringLiteral("toggleRefPoint"));
        mFlowButtons[RefPoint]->setFixedWidth(20);
        mFlowButtons[RefPoint]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[RefPoint]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[RefPoint]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/ref-point-16.png")));
        q->connect(mFlowButtons[RefPoint], &QPushButton::clicked, this, &LaserXCanvasPrivate::btnClicked);
        layout->addWidget(mFlowButtons[RefPoint]);

        mFlowButtons[HideROI] = new QPushButton(mFlowPanel);
        mFlowButtons[HideROI]->setObjectName(QStringLiteral("toggleHideROI"));
        mFlowButtons[HideROI]->setFixedWidth(20);
        mFlowButtons[HideROI]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[HideROI]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[HideROI]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/hide-16.png")));
        mFlowButtons[HideROI]->setCheckable(true);
        mFlowButtons[HideROI]->setChecked(false);
        q->connect(mFlowButtons[HideROI], &QPushButton::clicked, this, &LaserXCanvasPrivate::btnClicked);
        layout->addWidget(mFlowButtons[HideROI]);

        mFlowButtons[SnapButton] = new QPushButton(mFlowPanel);
        mFlowButtons[SnapButton]->setObjectName(QStringLiteral("snapButton"));
        mFlowButtons[SnapButton]->setFixedWidth(20);
        mFlowButtons[SnapButton]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[SnapButton]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[SnapButton]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/camera.png")));
        q->connect(mFlowButtons[SnapButton], &QPushButton::clicked, this, &LaserXCanvasPrivate::btnClicked);
        layout->addWidget(mFlowButtons[SnapButton]);

        mFlowButtons[LiveButton] = new QPushButton(mFlowPanel);
        mFlowButtons[LiveButton]->setObjectName(QStringLiteral("liveButton"));
        mFlowButtons[LiveButton]->setFixedWidth(20);
        mFlowButtons[LiveButton]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[LiveButton]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[LiveButton]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/video.png")));
        q->connect(mFlowButtons[LiveButton], &QPushButton::clicked, this, &LaserXCanvasPrivate::btnClicked);
        layout->addWidget(mFlowButtons[LiveButton]);

        mFlowButtons[BreakLink] = new QPushButton(mFlowPanel);
        mFlowButtons[BreakLink]->setObjectName(QStringLiteral("breakCameraLink"));
        mFlowButtons[BreakLink]->setFixedWidth(20);
        mFlowButtons[BreakLink]->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        mFlowButtons[BreakLink]->setFocusPolicy(Qt::NoFocus);
        mFlowButtons[BreakLink]->setIcon(QIcon(QStringLiteral(":/laserxwidgets/images/broken-link-16.png")));
        q->connect(mFlowButtons[BreakLink], &QPushButton::clicked, this, &LaserXCanvasPrivate::btnClicked);
        layout->addWidget(mFlowButtons[BreakLink]);


        QStringList qss;
        QString rgba = QStringLiteral("rgba(%1,%2,%3, 64)").arg(128).arg(128).arg(128);
        qss.append(QStringLiteral("#flowPanel{background:%1;border:none;}").arg(rgba));
        qss.append(QStringLiteral("QPushButton{border:none;background:transparent;padding:0px;border-radius:0px;}"));
        qss.append(QStringLiteral("QPushButton:hover{background-color:#565656;}"));
        qss.append(QStringLiteral("QPushButton:pressed{background-color:#2d2d2d;}"));
        qss.append(QStringLiteral("QPushButton:checked{background-color:#ffa02f;}"));
        mFlowPanel->setStyleSheet(qss.join(QStringLiteral("")));
    }

    if (mFlowPanel)
    {
        bool showSelButton = mDrawingLineEnabled;
        showSelButton = showSelButton || mDrawingRectEnabled;
        showSelButton = showSelButton || mDrawingEllipseEnabled;
        showSelButton = showSelButton || mDrawingPolygonEnabled;
        showSelButton = showSelButton || mDrawingLineFinderEnabled;
        showSelButton = showSelButton || mDrawingCircleFinderEnabled;
        showSelButton = showSelButton || mDrawingRectFinderEnabled;
        showSelButton = showSelButton || mDrawingEllipseFinderEnabled;
        showSelButton = showSelButton || mDrawingCharBoxEnabled;

        mFlowButtons[LaserXCanvasPrivate::SelectButton]->setVisible(showSelButton);
        mFlowButtons[LaserXCanvasPrivate::DrawLine]->setVisible(mDrawingLineEnabled);
        mFlowButtons[LaserXCanvasPrivate::DrawSquare]->setVisible(mDrawingRectEnabled);
        mFlowButtons[LaserXCanvasPrivate::DrawEllipse]->setVisible(mDrawingEllipseEnabled);
        mFlowButtons[LaserXCanvasPrivate::DrawPolygon]->setVisible(mDrawingPolygonEnabled);
        mFlowButtons[LaserXCanvasPrivate::DrawCharBox]->setVisible(mDrawingCharBoxEnabled);
        mFlowButtons[LaserXCanvasPrivate::DrawLineFinder]->setVisible(mDrawingLineFinderEnabled);
        mFlowButtons[LaserXCanvasPrivate::DrawCircleFinder]->setVisible(mDrawingCircleFinderEnabled);
        mFlowButtons[LaserXCanvasPrivate::DrawRectFinder]->setVisible(mDrawingRectFinderEnabled);
        mFlowButtons[LaserXCanvasPrivate::DrawEllipseFinder]->setVisible(mDrawingEllipseFinderEnabled);
        mFlowButtons[LaserXCanvasPrivate::SelectButton]->setChecked(true);

        mFlowButtons[LaserXCanvasPrivate::SnapButton]->setVisible(mCameraEnabled);
        mFlowButtons[LaserXCanvasPrivate::LiveButton]->setVisible(mCameraEnabled);
        mFlowButtons[LaserXCanvasPrivate::BreakLink]->setVisible(mCameraEnabled);
        mFlowButtons[LaserXCanvasPrivate::RefPoint]->setVisible(mRefPointEnabled);
    }

    retranslateUi();
}

void LaserXCanvasPrivate::drawingSwitched(QAbstractButton* button, bool checked)
{
    Q_Q(LaserXCanvas);
    int iId = mDrawingGroup->id(button);
    switch (iId)
    {
    case 0: mDrawingMode = DrawingMode::Select; q->setInteractive(true); break;
    case 1: mDrawingMode = DrawingMode::Line; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    case 2: mDrawingMode = DrawingMode::Square; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    case 3: mDrawingMode = DrawingMode::Ellipse; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    case 4: mDrawingMode = DrawingMode::Polygon; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    case 5: mDrawingMode = DrawingMode::LineFinder; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    case 6: mDrawingMode = DrawingMode::CircleFinder; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    case 7: mDrawingMode = DrawingMode::RectFinder; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    case 8: mDrawingMode = DrawingMode::EllipseFinder; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    case 9: mDrawingMode = DrawingMode::CharBox; q->showAllROI(); q->setInteractive(false); q->scene()->clearSelection(); break;
    default: mDrawingMode = DrawingMode::Select; q->setInteractive(true); break;
    }
}

void LaserXCanvasPrivate::btnClicked()
{
    Q_Q(LaserXCanvas);
    if (sender() == mFlowButtons[SnapButton])
    {
        if (mCamera)
        {
            mCamera->stopContinuousGrab();
            q->setMat(mCamera->snap());
        }
        emit q->snapClicked();
    }
    else if (sender() == mFlowButtons[LiveButton])
    {
        if (mCamera)
        {
            mCamera->toggleContinuousGrab();
        }
        emit q->liveClicked();
    }
    else if (sender() == mFlowButtons[SaveImage])
    {
        q->saveImage();
    }
    else if (sender() == mFlowButtons[BreakLink])
    {
        q->bindCamera(nullptr);
    }
    else if (sender() == mFlowButtons[CrossLine])
    {
        if (mHLineItem)
        {
            mHLineItem->setVisible(!mHLineItem->isVisible());
        }

        if (mVLineItem)
        {
            mVLineItem->setVisible(!mVLineItem->isVisible());
        }
    }
    else if (sender() == mFlowButtons[RefPoint])
    {
        mRefPointItem->setVisible(!mRefPointItem->isVisible());
    }
    else if (sender() == mFlowButtons[HideROI])
    {
        q->setAllROIVisible(!mFlowButtons[HideROI]->isChecked());
    }
    else if (sender() == mFlowButtons[ColorPicker])
    {
        if (!mFlowButtons[ColorPicker]->isChecked())
        {
            hideCrossLines();
        }
    }
    else
    {
        // do nothing
    }
}

cv::Mat LaserXCanvasPrivate::qImageToMatRef(const QImage& image)
{
    if (QImage::Format_Grayscale8 == image.format() || QImage::Format_Indexed8 == image.format())
    {
        return cv::Mat(image.height(), image.width(), CV_8UC1, const_cast<QImage&>(image).bits(), image.bytesPerLine());
    }
    else if (QImage::Format_RGB888 == image.format())
    {
        return cv::Mat(image.height(), image.width(), CV_8UC3, const_cast<QImage&>(image).bits(), image.bytesPerLine());
    }
    else if (QImage::Format_ARGB32 == image.format())
    {
        return cv::Mat(image.height(), image.width(), CV_8UC4, const_cast<QImage&>(image).bits(), image.bytesPerLine());
    }
    else
    {
        return cv::Mat();
    }
}

QImage LaserXCanvasPrivate::matToQImageRef(const cv::Mat& mat)
{
    if (CV_8UC1 == mat.type())
    {
        return QImage(mat.data, mat.cols, mat.rows, mat.step, QImage::Format_Grayscale8);
    }
    else if (CV_8UC3 == mat.type())
    {
        QImage image(mat.data, mat.cols, mat.rows, mat.step, QImage::Format_RGB888);
        return image.rgbSwapped();
    }
    else if (CV_8UC4 == mat.type())
    {
        return QImage(mat.data, mat.cols, mat.rows, mat.step, QImage::Format_ARGB32);
    }
    else
    {
        return QImage();
    }
}

QString LaserXCanvasPrivate::getImageFilePath(const QMimeData* mData)
{
    if (mData)
    {
        if (mData->hasUrls())
        {
            const QUrl url = mData->urls().constFirst();
            std::filesystem::path filePath = url.toLocalFile().toStdWString();
            std::wstring fileExt = filePath.extension().wstring();
            boost::algorithm::to_lower(fileExt);
            if (std::wstring_view(L".png") == fileExt ||
                std::wstring_view(L".jpg") == fileExt ||
                std::wstring_view(L".bmp") == fileExt ||
                std::wstring_view(L".gif") == fileExt)
            {
                return url.toLocalFile();
            }
        }
    }

    return QString();
}

void LaserXCanvasPrivate::dispImage(const QImage& image, bool resized)
{
    Q_Q(LaserXCanvas);
    if (!mImageItem)
    {
        mImageItem = new QGraphicsPixmapItem(QPixmap::fromImage(image));
        mImageItem->setShapeMode(QGraphicsPixmapItem::BoundingRectShape);
        q->scene()->addItem(mImageItem);
        mImageItem->setZValue(-1);
    }
    else
    {
        mImageItem->setPixmap(QPixmap::fromImage(image));
    }

    if (!mHLineItem)
    {
        mHLineItem = new QGraphicsLineItem();
        mVLineItem = new QGraphicsLineItem();
        q->scene()->addItem(mHLineItem);
        q->scene()->addItem(mVLineItem);
        mHLineItem->setZValue(-1);
        mVLineItem->setZValue(-1);

        QPen redPen(Qt::red);
        redPen.setCosmetic(true);
        redPen.setWidth(1);
        mHLineItem->setPen(redPen);
        mVLineItem->setPen(redPen);
        mHLineItem->setVisible(false);
        mVLineItem->setVisible(false);
    }

    if (mHLineItem)
    {
        mHLineItem->setLine(0., image.height()/2., image.width(), image.height() / 2.);
    }

    if (mVLineItem)
    {
        mVLineItem->setLine(image.width() / 2., 0., image.width() / 2., image.height());
    }

    if (mImageItem)
    {
        if (resized)
        {
            if (image.width() > q->width() || image.height() > q->height())
            {
                q->resetTransform();
                q->scene()->setSceneRect(mImageItem->boundingRect());
                q->fitInView(mImageItem, Qt::KeepAspectRatio);
                mInfoItem->setPos(q->mapToScene(QPoint(0, 0)));
            }
            else
            {
                q->resetTransform();
                q->scene()->setSceneRect(mImageItem->boundingRect());
                mInfoItem->setPos(q->mapToScene(QPoint(0, 0)));
            }
        }
    }

    mFrameNumber += 1;
    updateInfoItem();
}

bool LaserXCanvasPrivate::isResized(const cv::Mat& newMat)
{
    if (mImageItem)
    {
        if (mImageItem->pixmap().width() != newMat.cols || mImageItem->pixmap().height() != newMat.rows)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return true;
    }
}

bool LaserXCanvasPrivate::isResized(const QImage& newImage)
{
    if (mImageItem)
    {
        if (mImageItem->pixmap().width() != newImage.width() || mImageItem->pixmap().height() != newImage.height())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return true;
    }
}

void LaserXCanvasPrivate::createRegionItem()
{
    Q_Q(LaserXCanvas);
    if (!mRegion)
    {
        mRegion = new RegionItem();
        q->scene()->addItem(mRegion);
    }
}

void LaserXCanvasPrivate::updateRegionPath()
{
    Q_Q(LaserXCanvas);
    if (mRegion)
    {
        mRegion->updatePath();
    }
}

void LaserXCanvasPrivate::startDrawing()
{
    Q_Q(LaserXCanvas);
    q->scene()->clearSelection();
    disablePanel(true);
    q->setInteractive(false);
    q->setContextMenuPolicy(Qt::PreventContextMenu);
}

void LaserXCanvasPrivate::endDrawing()
{
    Q_Q(LaserXCanvas);
    if (mDrawingItem)
    {
        mDrawingItem->setFlag(QGraphicsItem::ItemIsMovable);
        mDrawingItem->setFlag(QGraphicsItem::ItemIsSelectable);
        mDrawingItem->updateMeasure(true);
    }
    disablePanel(false);
    q->setContextMenuPolicy(Qt::DefaultContextMenu);
    mDrawingItem = nullptr;
}

void LaserXCanvasPrivate::abortDrawing()
{
    Q_Q(LaserXCanvas);
    if (mDrawingItem)
    {
        delete mDrawingItem;
    }
    updateRegionPath();
    disablePanel(false);
    q->setContextMenuPolicy(Qt::DefaultContextMenu);
    mDrawingItem = nullptr;
}

void LaserXCanvasPrivate::disablePanel(const bool disabled)
{
    mFlowPanel->setDisabled(disabled);
}

void LaserXCanvasPrivate::loadVisionPlugin()
{
}

LXWMeasureModel LaserXCanvasPrivate::getMeasure()
{
    if (!mMeasure && gVision)
    {
        QVariantMap params;
        if (!mMat.empty())
        {
            params[QStringLiteral("Width")] = mMat.cols;
            params[QStringLiteral("Height")] = mMat.rows;
        }
        mMeasure = gVision->createMeasureModel(params);
    }

    return mMeasure;
}

void LaserXCanvasPrivate::updateAllMeasures()
{
    Q_Q(LaserXCanvas);
    CanvasScene* iScene = dynamic_cast<CanvasScene*>(q->scene());
    LXWMeasureModel wMeasure = getMeasure();
    LXMeasureModel iMeasure = wMeasure.lock();
    if (iMeasure && iScene)
    {
        QVector<ChildPathItem*> iSubPaths = iScene->getAllSubPaths();
        for (ChildPathItem* iSubPath : iSubPaths)
        {
            iSubPath->updateMeasure(true);
        }
    }
}

void LaserXCanvasPrivate::updateInfoItem()
{
    if (mInfoItem)
    {
        QString iHtml;
        iHtml.append(QStringLiteral("<span>%1  frame: %2</span>").arg(mImageSourceName).arg(mFrameNumber));
        for (const QString& iMInfo : mTemporaryInfoItems)
        {
            iHtml.append(QStringLiteral("<br/>"));
            iHtml.append(QStringLiteral("<span>%1</span>").arg(iMInfo));
        }
        mInfoItem->setHtml(iHtml);
    }
}

void LaserXCanvasPrivate::showCrossLines(const QPointF& cPoint)
{
    if (!mFlowButtons[ColorPicker]->isChecked())
    {
        return;
    }

    if (!mImageItem)
    {
        return;
    }

    Q_Q(LaserXCanvas);
    if (!mHCrossItem)
    {
        mHCrossItem = new QGraphicsLineItem();
        mVCrossItem = new QGraphicsLineItem();
        q->scene()->addItem(mHCrossItem);
        q->scene()->addItem(mVCrossItem);
        mHCrossItem->setZValue(-1);
        mVCrossItem->setZValue(-1);

        QPen redPen(Qt::green);
        redPen.setCosmetic(true);
        redPen.setWidth(1);
        mHCrossItem->setPen(redPen);
        mVCrossItem->setPen(redPen);
    }

    if (mHCrossItem)
    {
        mHCrossItem->setLine(std::min(0., cPoint.x()), cPoint.y(), std::max(mMat.cols+0.0, cPoint.x()), cPoint.y());
        mHCrossItem->setVisible(true);
    }

    if (mVCrossItem)
    {
        mVCrossItem->setLine(cPoint.x(), std::min(0., cPoint.y()), cPoint.x(), std::max(mMat.rows+0.0, cPoint.y()));
        mVCrossItem->setVisible(true);
    }
}

void LaserXCanvasPrivate::hideCrossLines()
{
    if (mHCrossItem)
    {
        mHCrossItem->setVisible(false);
    }

    if (mVCrossItem)
    {
        mVCrossItem->setVisible(false);
    }
}
