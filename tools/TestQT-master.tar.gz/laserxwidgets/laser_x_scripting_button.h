#ifndef SCRIPTING_BUTTON_H
#define SCRIPTING_BUTTON_H

#include <QToolButton>
#include "laser_x_widgets_global.h"

class LASERXWIDGETS_EXPORT LaserXScriptingButton : public QToolButton
{
    Q_OBJECT
    Q_PROPERTY(QString scripts READ scripts WRITE setScripts)
    Q_PROPERTY(bool readOnly READ readOnly WRITE setReadOnly)

public:
    explicit LaserXScriptingButton(QWidget *parent = nullptr);

public:
    void setScripts(const QString& scripts)
    {
        mScripts = scripts;
    }

    QString scripts() const
    {
        return mScripts;
    }

    void setReadOnly(const bool readOnly)
    {
        mReadOnly = readOnly;
    }

    bool readOnly() const
    {
        return mReadOnly;
    }

private:
    QString mScripts;
    bool mReadOnly = false;
};

#endif //SCRIPTING_BUTTON_H
