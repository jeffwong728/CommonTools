#ifndef COMMAND_BUTTON_H
#define COMMAND_BUTTON_H

#include <QPushButton>
#include "laser_x_widgets_global.h"

class LASERXWIDGETS_EXPORT LaserXCommandButton : public QPushButton
{
    Q_OBJECT
    Q_PROPERTY(QString scripts READ scripts WRITE setScripts)

public:
    explicit LaserXCommandButton(QWidget *parent = nullptr);

public:
    void setScripts(const QString& scripts)
    {
        mScripts = scripts;
    }

    QString scripts() const
    {
        return mScripts;
    }

private:
    QString mScripts;
};

#endif //COMMAND_BUTTON_H
