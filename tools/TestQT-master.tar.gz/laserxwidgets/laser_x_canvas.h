#ifndef LASER_X_CANVAS_H
#define LASER_X_CANVAS_H

#include <QGraphicsView>
#include <laser_x_image.h>
#include "laser_x_widgets_global.h"

class LaserXCamera;
class LaserXVisionManager;
class LaserXCanvasPrivate;

class LASERXWIDGETS_EXPORT LaserXCanvas : public QGraphicsView
{
    Q_OBJECT
    Q_PROPERTY(QString imageSourceName READ getImageSourceName WRITE setImageSourceName)
    Q_PROPERTY(bool acceptDropImage READ getAcceptDropImage WRITE setAcceptDropImage)
    Q_PROPERTY(bool flowPanelEnabled READ getFlowPanelEnabled WRITE setFlowPanelEnabled)
    Q_PROPERTY(bool drawingLineEnabled READ getDrawingLineEnabled WRITE setDrawingLineEnabled)
    Q_PROPERTY(bool drawingRectEnabled READ getDrawingRectEnabled WRITE setDrawingRectEnabled)
    Q_PROPERTY(bool drawingEllipseEnabled READ getDrawingEllipseEnabled WRITE setDrawingEllipseEnabled)
    Q_PROPERTY(bool drawingPolygonEnabled READ getDrawingPolygonEnabled WRITE setDrawingPolygonEnabled)
    Q_PROPERTY(bool drawingCharBoxEnabled READ getDrawingCharBoxEnabled WRITE setDrawingCharBoxEnabled)
    Q_PROPERTY(bool drawingLineFinderEnabled READ getDrawingLineFinderEnabled WRITE setDrawingLineFinderEnabled)
    Q_PROPERTY(bool drawingCircleFinderEnabled READ getDrawingCircleFinderEnabled WRITE setDrawingCircleFinderEnabled)
    Q_PROPERTY(bool drawingRectFinderEnabled READ getDrawingRectFinderEnabled WRITE setDrawingRectFinderEnabled)
    Q_PROPERTY(bool drawingEllipseFinderEnabled READ getDrawingEllipseFinderEnabled WRITE setDrawingEllipseFinderEnabled)
    Q_PROPERTY(bool cameraEnabled READ getCameraEnabled WRITE setCameraEnabled)
    Q_PROPERTY(bool refPointEnabled READ getRefPointEnabled WRITE setRefPointEnabled)

public:
    explicit LaserXCanvas(QWidget* parent = nullptr);
    ~LaserXCanvas();

public:
    void setImageSourceName(const QString& imageSourceName);
    QString getImageSourceName() const;

    void setAcceptDropImage(const bool acceptDropImage);
    bool getAcceptDropImage() const;

    void setFlowPanelEnabled(const bool flowPanelEnabled);
    bool getFlowPanelEnabled() const;

    bool getDrawingLineEnabled() const;
    void setDrawingLineEnabled(const bool enabled);

    bool getDrawingRectEnabled() const;
    void setDrawingRectEnabled(const bool enabled);

    bool getDrawingEllipseEnabled() const;
    void setDrawingEllipseEnabled(const bool enabled);

    bool getDrawingPolygonEnabled() const;
    void setDrawingPolygonEnabled(const bool enabled);

    bool getDrawingCharBoxEnabled() const;
    void setDrawingCharBoxEnabled(const bool enabled);

    bool getCameraEnabled() const;
    void setCameraEnabled(const bool enabled);

    bool getDrawingLineFinderEnabled() const;
    void setDrawingLineFinderEnabled(const bool enabled);

    bool getDrawingCircleFinderEnabled() const;
    void setDrawingCircleFinderEnabled(const bool enabled);

    bool getDrawingRectFinderEnabled() const;
    void setDrawingRectFinderEnabled(const bool enabled);

    bool getDrawingEllipseFinderEnabled() const;
    void setDrawingEllipseFinderEnabled(const bool enabled);

    bool getRefPointEnabled() const;
    void setRefPointEnabled(const bool enabled);

public:
    void setVisionManager(LaserXVisionManager *iVision);
    cv::Mat mat() const;
    LaserXCamera* camera() const;
    void setMat(const cv::Mat& newMat);
    void loadImage(const QString& fileName);
    void saveImage();
    void bindCamera(LaserXCamera* camera);
    QJsonObject currentROI() const;
    void setCurrentROI(const QJsonObject &region);
    QJsonValue charBoxs() const;
    void setCharBoxs(const QJsonValue &nVal);
    QPointF refPoint() const;
    void setRefPoint(const QPointF &val);
    void clearROI();
    void clearAllTemporaryItems();
    void addTemporaryItem(QGraphicsItem *item);
    void clearAllInfoItems();
    void addInfoItem(const QString& strInfo);
    void addInfoItems(const QStringList &strInfos);
    void hideAllROI();
    void showAllROI();
    void setAllROIVisible(const bool visible);
    void fitView();

    QByteArray measureModel() const;
    QJsonObject measureParams() const;
    void setMeasureParams(const QJsonObject &params);

protected:
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;

protected:
    void dragEnterEvent(QDragEnterEvent* event) override;
    void dragLeaveEvent(QDragLeaveEvent* event) override;
    void dragMoveEvent(QDragMoveEvent* event) override;
    void dropEvent(QDropEvent* event) override;
    void changeEvent(QEvent* event) override;
    void focusInEvent(QFocusEvent* event) override;
    bool focusNextPrevChild(bool next) override;
    void focusOutEvent(QFocusEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;
    void keyReleaseEvent(QKeyEvent* event) override;
    void mouseDoubleClickEvent(QMouseEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;
    void mouseMoveEvent(QMouseEvent* event) override;
    void mouseReleaseEvent(QMouseEvent* event) override;
    void wheelEvent(QWheelEvent* event) override;
    void resizeEvent(QResizeEvent* event) override;
    void enterEvent(QEnterEvent*) override;
    void leaveEvent(QEvent*) override;
    bool viewportEvent(QEvent* event) override;
    void contextMenuEvent(QContextMenuEvent* event) override;

signals:
    void snapClicked();
    void liveClicked();
    void cameraDroped(QString camUUID);

private:
    void loaded();
    void onImageReady(cv::Mat img, QVariantMap infos);
    void onCameraAboutToDelete(LaserXCamera* camera);

private:
    QScopedPointer<LaserXCanvasPrivate> mDptr;
    Q_DECLARE_PRIVATE_D(mDptr, LaserXCanvas)
    Q_DISABLE_COPY(LaserXCanvas)
};

#endif //LASER_X_CANVAS_H
