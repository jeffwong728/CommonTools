#include "laser_x_canvas.h"
#include "laser_x_canvas_p.h"
#include "canvas_scene.h"
#include <QtWidgets>
#include <QMouseEvent>
#include <QOpenGLWidget>
#include <opencv2/imgproc.hpp>
#include <laser_x_camera.h>
#include <laser_x_measure_model.h>
#include <geomitems/region_item.h>
#include <geomitems/child_line_item.h>
#include <geomitems/child_rect_item.h>
#include <geomitems/child_polygon_item.h>
#include <geomitems/child_ellipse_item.h>
#include <geomitems/child_char_box_item.h>
#include <geomitems/line_finder_item.h>
#include <geomitems/circle_finder_item.h>
#include <geomitems/rect_finder_item.h>
#include <geomitems/ellipse_finder_item.h>
#include <geomitems/geom_finder_item.h>
#include <geomitems/reference_point.h>
extern LaserXVisionManager* gVision;

LaserXCanvas::LaserXCanvas(QWidget* parent)
    : QGraphicsView(parent)
    , mDptr(new LaserXCanvasPrivate(this))
{
    setMouseTracking(true);
    setAttribute(Qt::WA_NoMousePropagation);
    setViewportUpdateMode(QGraphicsView::SmartViewportUpdate);
    setDragMode(QGraphicsView::RubberBandDrag);
    setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    setTransformationAnchor(QGraphicsView::NoAnchor);
    setCacheMode(QGraphicsView::CacheBackground);

    Q_D(LaserXCanvas);
    d->mScene = new CanvasScene(this);
    setScene(d->mScene);
    setAcceptDrops(true);

    d->mInfoItem = scene()->addText(d->mImageSourceName);
    d->mRefPointItem = new ReferencePoint(nullptr);
    scene()->addItem(d->mRefPointItem);
    QTimer::singleShot(0, this, &LaserXCanvas::loaded);
}

LaserXCanvas::~LaserXCanvas()
{
}

void LaserXCanvas::setImageSourceName(const QString& imageSourceName)
{
    Q_D(LaserXCanvas);
    if (d->mImageSourceName != imageSourceName)
    {
        d->mImageSourceName = imageSourceName;
        d->updateInfoItem();
    }
}

QString LaserXCanvas::getImageSourceName() const
{
    Q_D(const LaserXCanvas);
    return d->mImageSourceName;
}

void LaserXCanvas::setAcceptDropImage(const bool acceptDropImage)
{
    Q_D(LaserXCanvas);
    if (d->mAcceptDropImage != acceptDropImage)
    {
        d->mAcceptDropImage = acceptDropImage;
    }
}

bool LaserXCanvas::getAcceptDropImage() const
{
    Q_D(const LaserXCanvas);
    return d->mAcceptDropImage;
}

void LaserXCanvas::setFlowPanelEnabled(const bool flowPanelEnabled)
{
    Q_D(LaserXCanvas);
    if (d->mFlowPanelEnabled != flowPanelEnabled)
    {
        d->mFlowPanelEnabled = flowPanelEnabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getFlowPanelEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mFlowPanelEnabled;
}

bool LaserXCanvas::getDrawingLineEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingLineEnabled;
}

void LaserXCanvas::setDrawingLineEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingLineEnabled != enabled)
    {
        d->mDrawingLineEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getDrawingRectEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingRectEnabled;
}

void LaserXCanvas::setDrawingRectEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingRectEnabled != enabled)
    {
        d->mDrawingRectEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getDrawingEllipseEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingEllipseEnabled;
}

void LaserXCanvas::setDrawingEllipseEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingEllipseEnabled != enabled)
    {
        d->mDrawingEllipseEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getDrawingPolygonEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingPolygonEnabled;
}

void LaserXCanvas::setDrawingPolygonEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingPolygonEnabled != enabled)
    {
        d->mDrawingPolygonEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getDrawingCharBoxEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingCharBoxEnabled;
}

void LaserXCanvas::setDrawingCharBoxEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingCharBoxEnabled != enabled)
    {
        d->mDrawingCharBoxEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getCameraEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mCameraEnabled;
}

void LaserXCanvas::setCameraEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mCameraEnabled != enabled)
    {
        d->mCameraEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getDrawingLineFinderEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingLineFinderEnabled;
}

void LaserXCanvas::setDrawingLineFinderEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingLineFinderEnabled != enabled)
    {
        d->mDrawingLineFinderEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getDrawingCircleFinderEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingCircleFinderEnabled;
}

void LaserXCanvas::setDrawingCircleFinderEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingCircleFinderEnabled != enabled)
    {
        d->mDrawingCircleFinderEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getDrawingRectFinderEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingRectFinderEnabled;
}

void LaserXCanvas::setDrawingRectFinderEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingRectFinderEnabled != enabled)
    {
        d->mDrawingRectFinderEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getDrawingEllipseFinderEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mDrawingEllipseFinderEnabled;
}

void LaserXCanvas::setDrawingEllipseFinderEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mDrawingEllipseFinderEnabled != enabled)
    {
        d->mDrawingEllipseFinderEnabled = enabled;
        d->initFlowPanel();
    }
}

bool LaserXCanvas::getRefPointEnabled() const
{
    Q_D(const LaserXCanvas);
    return d->mRefPointEnabled;
}

void LaserXCanvas::setRefPointEnabled(const bool enabled)
{
    Q_D(LaserXCanvas);
    if (d->mRefPointEnabled != enabled)
    {
        d->mRefPointEnabled = enabled;
        d->initFlowPanel();
    }
}

void LaserXCanvas::dragEnterEvent(QDragEnterEvent* event)
{
    Q_D(LaserXCanvas);
    QString imageFilePath;
    if (d->mAcceptDropImage)
    {
        imageFilePath = d->getImageFilePath(event->mimeData());
    }

    if (event->mimeData()->hasFormat(QStringLiteral("application/x-qabstractitemmodeldatalist")))
    {
        QByteArray itemData = event->mimeData()->data(QStringLiteral("application/x-qabstractitemmodeldatalist"));
        QDataStream stream(&itemData, QIODevice::ReadOnly);
        int row = -1, col = -1;
        QMap<int, QVariant> valueMap;
        stream >> row >> col >> valueMap;
        if (QStringLiteral("LaserXCamera") == valueMap[Qt::UserRole].toString())
        {
            event->acceptProposedAction();
        }
        else
        {
            QGraphicsView::dragEnterEvent(event);
        }
    }
    else if (!imageFilePath.isEmpty())
    {
        event->acceptProposedAction();
    }
    else
    {
        QGraphicsView::dragEnterEvent(event);
    }
}

void LaserXCanvas::dragLeaveEvent(QDragLeaveEvent* event)
{
    Q_D(LaserXCanvas);
    QGraphicsView::dragLeaveEvent(event);
}

void LaserXCanvas::dragMoveEvent(QDragMoveEvent* event)
{
    Q_D(LaserXCanvas);
    QString imageFilePath;
    if (d->mAcceptDropImage)
    {
        imageFilePath = d->getImageFilePath(event->mimeData());
    }

    if (event->mimeData()->hasFormat(QStringLiteral("application/x-qabstractitemmodeldatalist")))
    {
        QByteArray itemData = event->mimeData()->data(QStringLiteral("application/x-qabstractitemmodeldatalist"));
        QDataStream stream(&itemData, QIODevice::ReadOnly);
        int row = -1, col = -1;
        QMap<int, QVariant> valueMap;
        stream >> row >> col >> valueMap;
        if (QStringLiteral("LaserXCamera") == valueMap[Qt::UserRole].toString())
        {
            event->acceptProposedAction();
        }
        else
        {
            QGraphicsView::dragMoveEvent(event);
        }
    }
    else if (!imageFilePath.isEmpty())
    {
        event->acceptProposedAction();
    }
    else
    {
        QGraphicsView::dragMoveEvent(event);
    }
}

void LaserXCanvas::dropEvent(QDropEvent* event)
{
    Q_D(LaserXCanvas);
    QString imageFilePath;
    if (d->mAcceptDropImage)
    {
        imageFilePath = d->getImageFilePath(event->mimeData());
    }

    if (event->mimeData()->hasFormat(QStringLiteral("application/x-qabstractitemmodeldatalist")))
    {
        QByteArray itemData = event->mimeData()->data(QStringLiteral("application/x-qabstractitemmodeldatalist"));
        QDataStream stream(&itemData, QIODevice::ReadOnly);
        int row = -1, col = -1;
        QMap<int, QVariant> valueMap;
        stream >> row >> col >> valueMap;
        if (QStringLiteral("LaserXCamera") == valueMap[Qt::UserRole].toString())
        {
            emit cameraDroped(valueMap[Qt::UserRole+1].toString());
            event->acceptProposedAction();
        }
        else
        {
            QGraphicsView::dropEvent(event);
        }
    }
    else if (!imageFilePath.isEmpty())
    {
        loadImage(imageFilePath);
        event->acceptProposedAction();
    }
    else
    {
        QGraphicsView::dropEvent(event);
    }
}

void LaserXCanvas::changeEvent(QEvent* event)
{
    if (QEvent::LanguageChange == event->type())
    {
        Q_D(LaserXCanvas);
        d->retranslateUi();
    }
    QGraphicsView::changeEvent(event);
}

void LaserXCanvas::focusInEvent(QFocusEvent* event)
{
    QGraphicsView::focusInEvent(event);
}

bool LaserXCanvas::focusNextPrevChild(bool next)
{
    return QGraphicsView::focusNextPrevChild(next);
}

void LaserXCanvas::focusOutEvent(QFocusEvent* event)
{
    QGraphicsView::focusOutEvent(event);
}

void LaserXCanvas::keyPressEvent(QKeyEvent* event)
{
    Q_D(LaserXCanvas);
    switch (event->key())
    {
    case Qt::Key_Escape: d->abortDrawing(); break;
    default: QGraphicsView::keyPressEvent(event); break;
    }
}

void LaserXCanvas::keyReleaseEvent(QKeyEvent* event)
{
    QGraphicsView::keyReleaseEvent(event);
}

void LaserXCanvas::mouseDoubleClickEvent(QMouseEvent* event)
{
    const auto btns = event->buttons();
    const bool isLeft = btns.testFlag(Qt::LeftButton);
    const bool isRight = btns.testFlag(Qt::RightButton);

    Q_D(LaserXCanvas);
    if (Qt::RightButton == event->button() && d->mImageItem)
    {
        resetTransform();
        scene()->setSceneRect(d->mImageItem->boundingRect());
        d->mInfoItem->setPos(mapToScene(QPoint(0, 0)));
    }
    else if (d->mDrawingItem && LaserXCanvasPrivate::DrawingMode::Polygon == d->mDrawingMode && isLeft && !isRight)
    {
        d->mDrawingItem->onMouseDoubleClick(mapToScene(event->pos()));
        if (d->mDrawingItem->empty())
        {
            d->abortDrawing();
        }
        else
        {
            d->endDrawing();
            d->updateRegionPath();
        }
        d->mAnchorPoint = event->pos();
        d->mLastPoint = event->pos();
    }
    else
    {
        QGraphicsView::mouseDoubleClickEvent(event);
    }
}

void LaserXCanvas::mousePressEvent(QMouseEvent* event)
{
    const auto btns = event->buttons();
    const bool isLeft = btns.testFlag(Qt::LeftButton);
    const bool isRight = btns.testFlag(Qt::RightButton);

    Q_D(LaserXCanvas);
    if (LaserXCanvasPrivate::DrawingMode::Select == d->mDrawingMode)
    {
        if (isLeft && isRight && d->mImageItem)
        {
            scene()->setSceneRect(d->mImageItem->boundingRect());
            fitInView(d->mImageItem, Qt::KeepAspectRatio);
            d->mInfoItem->setPos(mapToScene(QPoint(0, 0)));
        }
        else if (isRight && d->mImageItem)
        {
            d->mMoving = true;
            setInteractive(false);
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
        }
        else
        {
            QGraphicsView::mousePressEvent(event);
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::Line == d->mDrawingMode && isLeft && !isRight)
    {
        d->createRegionItem();
        if (d->mDrawingItem)
        {
            d->endDrawing();
        }
        else
        {
            d->mDrawingItem = new ChildLineItem(d->mRegion);
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::Square == d->mDrawingMode && isLeft && !isRight)
    {
        d->createRegionItem();
        if (d->mDrawingItem)
        {
            d->endDrawing();
        }
        else
        {
            d->mDrawingItem = new ChildRectItem(d->mRegion);
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::CharBox == d->mDrawingMode && isLeft && !isRight)
    {
        d->createRegionItem();
        if (d->mDrawingItem)
        {
            d->endDrawing();
        }
        else
        {
            d->mDrawingItem = new ChildCharBoxItem(d->mRegion);
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::Ellipse == d->mDrawingMode && isLeft && !isRight)
    {
        d->createRegionItem();
        if (d->mDrawingItem)
        {
            d->endDrawing();
        }
        else
        {
            d->mDrawingItem = new ChildEllipseItem(d->mRegion);
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::Polygon == d->mDrawingMode && isLeft && !isRight)
    {
        d->createRegionItem();
        if (d->mDrawingItem)
        {
            d->mDrawingItem->onMousePress(mapToScene(event->pos()));
        }
        else
        {
            d->mDrawingItem = new ChildPolygonItem(d->mRegion);
            d->mDrawingItem->onMousePress(mapToScene(event->pos()));
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::LineFinder == d->mDrawingMode && isLeft && !isRight)
    {
        if (d->mDrawingItem)
        {
            if (d->mDrawingItem->empty())
            {
                d->abortDrawing();
            }
            else
            {
                d->endDrawing();
            }
        }
        else
        {
            d->mDrawingItem = new LineFinderItem(nullptr, d);
            scene()->addItem(d->mDrawingItem);
            d->mDrawingItem->onMousePress(mapToScene(event->pos()));
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::CircleFinder == d->mDrawingMode && isLeft && !isRight)
    {
        if (d->mDrawingItem)
        {
            if (d->mDrawingItem->empty())
            {
                d->abortDrawing();
            }
            else
            {
                d->endDrawing();
            }
        }
        else
        {
            d->mDrawingItem = new CircleFinderItem(nullptr, d);
            scene()->addItem(d->mDrawingItem);
            d->mDrawingItem->onMousePress(mapToScene(event->pos()));
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::RectFinder == d->mDrawingMode && isLeft && !isRight)
    {
        if (d->mDrawingItem)
        {
            d->mDrawingItem->onMousePress(mapToScene(event->pos()));
            RectFinderItem* iItem = dynamic_cast<RectFinderItem*>(d->mDrawingItem);
            if (3 == iItem->leftMouseClicked())
            {
                if (iItem->empty())
                {
                    d->abortDrawing();
                }
                else
                {
                    d->endDrawing();
                }
            }
        }
        else
        {
            d->mDrawingItem = new RectFinderItem(nullptr, d);
            scene()->addItem(d->mDrawingItem);
            d->mDrawingItem->onMousePress(mapToScene(event->pos()));
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (LaserXCanvasPrivate::DrawingMode::EllipseFinder == d->mDrawingMode && isLeft && !isRight)
    {
        if (d->mDrawingItem)
        {
            d->mDrawingItem->onMousePress(mapToScene(event->pos()));
            EllipseFinderItem* iItem = dynamic_cast<EllipseFinderItem*>(d->mDrawingItem);
            if (3 == iItem->leftMouseClicked())
            {
                if (iItem->empty())
                {
                    d->abortDrawing();
                }
                else
                {
                    d->endDrawing();
                }
            }
        }
        else
        {
            d->mDrawingItem = new EllipseFinderItem(nullptr, d);
            scene()->addItem(d->mDrawingItem);
            d->mDrawingItem->onMousePress(mapToScene(event->pos()));
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
            d->startDrawing();
        }
    }
    else if (!isLeft && isRight && d->mImageItem)
    {
        d->mMoving = true;
        setInteractive(false);
        d->mAnchorPoint = event->pos();
        d->mLastPoint = event->pos();
    }
    else
    {
        QGraphicsView::mousePressEvent(event);
    }
}

void LaserXCanvas::mouseMoveEvent(QMouseEvent* event)
{
    Q_D(LaserXCanvas);
    if (d->mMoving && d->mImageItem)
    {
        const QPointF deltaXY = mapToScene(event->pos()) - mapToScene(d->mLastPoint);
        const QTransform& oldTtransform = transform().translate(deltaXY.x(), deltaXY.y());
        const QRectF mSceneRect = scene()->sceneRect();
        const QRectF newSceneRect(mSceneRect.x() - deltaXY.x(), mSceneRect.y() - deltaXY.y(), mSceneRect.width(), mSceneRect.height());
        scene()->setSceneRect(newSceneRect);
        setTransform(oldTtransform);
        d->mLastPoint = event->pos();
        d->mInfoItem->setPos(mapToScene(QPoint(0, 0)));
    }
    else if (d->mDrawingItem)
    {
        d->mDrawingItem->onMouseMove(mapToScene(event->pos()), mapToScene(d->mAnchorPoint));
        d->updateRegionPath();
    }
    else
    {
        QGraphicsView::mouseMoveEvent(event);
    }
}

void LaserXCanvas::mouseReleaseEvent(QMouseEvent* event)
{
    Q_D(LaserXCanvas);
    if (d->mMoving)
    {
        d->mMoving = false;
        setInteractive(true);
        QPoint dXY = event->pos() - d->mAnchorPoint;
        if (std::abs(dXY.x()) > 0 || std::abs(dXY.y()) > 0)
        {
            setContextMenuPolicy(Qt::PreventContextMenu);
        }
        else
        {
            setContextMenuPolicy(Qt::DefaultContextMenu);
        }
        d->mAnchorPoint = event->pos();
        d->mLastPoint = event->pos();
    }
    else if (d->mDrawingItem
        && (LaserXCanvasPrivate::DrawingMode::Line == d->mDrawingMode
            || LaserXCanvasPrivate::DrawingMode::Square == d->mDrawingMode
            || LaserXCanvasPrivate::DrawingMode::CharBox == d->mDrawingMode
            || LaserXCanvasPrivate::DrawingMode::Ellipse == d->mDrawingMode
            || LaserXCanvasPrivate::DrawingMode::CircleFinder == d->mDrawingMode
            || LaserXCanvasPrivate::DrawingMode::LineFinder == d->mDrawingMode)
        && Qt::LeftButton == event->button())
    {
        if ((d->mAnchorPoint - event->pos()).manhattanLength() > 3)
        {
            d->mDrawingItem->onMouseRelease(mapToScene(event->pos()), mapToScene(d->mAnchorPoint));
            d->updateRegionPath();
            d->endDrawing();
            d->mAnchorPoint = event->pos();
            d->mLastPoint = event->pos();
        }
        else
        {
            d->mDrawingItem->onMouseRelease(mapToScene(event->pos()), mapToScene(d->mAnchorPoint));
            d->updateRegionPath();
        }
    }
    else
    {
        QGraphicsView::mouseReleaseEvent(event);
    }
}

void LaserXCanvas::wheelEvent(QWheelEvent* event)
{
    Q_D(LaserXCanvas);
    if (event->modifiers().testFlag(Qt::ControlModifier))
    {
        if (d->mImageItem && event->angleDelta().y() > 0)
        {
            this->scale(1.2, 1.2);
            d->mInfoItem->setPos(mapToScene(QPoint(0, 0)));
        }
        else if (d->mImageItem && event->angleDelta().y() < 0)
        {
            this->scale(0.8, 0.8);
            d->mInfoItem->setPos(mapToScene(QPoint(0, 0)));
        }
        else
        {
            QGraphicsView::wheelEvent(event);
        }
    }
    else
    {
        QGraphicsView::wheelEvent(event);
    }
}

void LaserXCanvas::resizeEvent(QResizeEvent* event)
{
    Q_D(LaserXCanvas);
    QGraphicsView::resizeEvent(event);
    if (d->mImageItem && d->mInfoItem)
    {
        d->mInfoItem->setPos(mapToScene(QPoint(0, 0)));
    }

    constexpr int height = 20;
    constexpr int borderWidth = 2;
    if (d->mFlowPanel)
    {
        d->mFlowPanel->setGeometry(borderWidth, borderWidth, this->width() - (borderWidth * 2), height);
    }
}

void LaserXCanvas::enterEvent(QEnterEvent* e)
{
    Q_D(LaserXCanvas);
    if (d->mFlowPanel && d->mFlowPanelEnabled)
    {
        d->mFlowPanel->setVisible(true);
    }
    QGraphicsView::enterEvent(e);
}

void LaserXCanvas::leaveEvent(QEvent* e)
{
    Q_D(LaserXCanvas);
    if (d->mFlowPanel)
    {
        d->mFlowPanel->setVisible(false);
    }
    QGraphicsView::leaveEvent(e);
}

bool LaserXCanvas::viewportEvent(QEvent* event)
{
    Q_D(LaserXCanvas);
    if (event->type() == QEvent::ToolTip && d->mImageItem &&
        d->mFlowButtons[LaserXCanvasPrivate::ColorPicker] && d->mFlowButtons[LaserXCanvasPrivate::ColorPicker]->isChecked())
    {
        QHelpEvent* helpEvent = static_cast<QHelpEvent*>(event);
        if (!d->mMat.empty())
        {
            QPointF xy = d->mImageItem->mapFromScene(mapToScene(helpEvent->pos()));
            QString strTip = QStringLiteral("x=%1, y=%2").arg(xy.x()).arg(xy.y());
            strTip.append(QStringLiteral("<br/><bold>Width: %1</bold>").arg(d->mMat.cols));
            strTip.append(QStringLiteral("<br/><bold>Height: %1</bold>").arg(d->mMat.rows));
            const int dph = d->mMat.depth();
            const int cnl = d->mMat.channels();
            QRect imgRect(0, 0, d->mMat.cols, d->mMat.rows);
            const int x = qRound(xy.x());
            const int y = qRound(xy.y());
            if (CV_8U == dph && (1 == cnl || 3 == cnl || 4 == cnl) && imgRect.contains(x, y))
            {
                if (1 == cnl)
                {
                    auto pPixel = d->mMat.data + y * d->mMat.step1() + x;
                    auto pixelVal = pPixel[0];
                    strTip.append(QStringLiteral("<br/><bold>Grayscale: %1</bold>").arg(pPixel[0]));
                }
                else if (3 == cnl)
                {
                    auto pPixel = d->mMat.data + y * d->mMat.step1() + x * 3;
                    strTip.append(QStringLiteral("<br/><bold><font color='red'>R: %1</font></bold>").arg(pPixel[2]));
                    strTip.append(QStringLiteral("<br/><bold><font color='green'>G: %1</font></bold>").arg(pPixel[1]));
                    strTip.append(QStringLiteral("<br/><bold><font color='blue'>B: %1</font></bold>").arg(pPixel[0]));
                }
                else
                {
                    auto pPixel = d->mMat.data + y * d->mMat.step1() + x * 4;
                    strTip.append(QStringLiteral("<br/><bold><font color='red'>R: %1</font></bold>").arg(pPixel[2]));
                    strTip.append(QStringLiteral("<br/><bold><font color='green'>G: %1</font></bold>").arg(pPixel[1]));
                    strTip.append(QStringLiteral("<br/><bold><font color='blue'>B: %1</font></bold>").arg(pPixel[0]));
                    strTip.append(QStringLiteral("<br/><bold><font color='black'>Alpha: %1</font></bold>").arg(pPixel[3]));
                }
            }
            QToolTip::showText(helpEvent->globalPos(), strTip);
            return true;
        }
        else if (!d->mMat.empty())
        {
            QPointF xy = d->mImageItem->mapFromScene(mapToScene(helpEvent->pos()));
            QString strTip = QStringLiteral("x=%1, y=%2").arg(xy.x()).arg(xy.y());
            QToolTip::showText(helpEvent->globalPos(), strTip);
            return true;
        }
        else
        {
            return QGraphicsView::viewportEvent(event);
        }
    }

    return QGraphicsView::viewportEvent(event);
}

void LaserXCanvas::contextMenuEvent(QContextMenuEvent* event)
{
    Q_D(LaserXCanvas);
    QGraphicsView::contextMenuEvent(event);
}

void LaserXCanvas::loaded()
{
    Q_D(LaserXCanvas);
    d->mInfoItem->setDefaultTextColor(Qt::red);
    d->mInfoItem->setFlag(QGraphicsItem::ItemIgnoresTransformations);
    d->updateInfoItem();

    d->retranslateUi();
}

void LaserXCanvas::onImageReady(cv::Mat img, QVariantMap infos)
{
    Q_D(LaserXCanvas);
    LaserXCamera* iCam = dynamic_cast<LaserXCamera*>(sender());
    if (iCam)
    {
        iCam->imageConsumed();
    }
    setMat(img);
}

void LaserXCanvas::onCameraAboutToDelete(LaserXCamera* camera)
{
    Q_D(LaserXCanvas);
    if (camera == d->mCamera)
    {
        d->mCamera = nullptr;
    }
}

void LaserXCanvas::setVisionManager(LaserXVisionManager* iVision)
{
    gVision = iVision;
}

cv::Mat LaserXCanvas::mat() const
{
    Q_D(const LaserXCanvas);
    return d->mMat;
}

LaserXCamera* LaserXCanvas::camera() const
{
    Q_D(const LaserXCanvas);
    return d->mCamera;
}

void LaserXCanvas::setMat(const cv::Mat& newMat)
{
    Q_D(LaserXCanvas);
    if (!newMat.empty())
    {
        const bool iResized = d->isResized(newMat);
        d->mMat = newMat;
        const QImage imageRef = d->matToQImageRef(newMat);
        d->dispImage(imageRef, iResized);

        LXWMeasureModel wMeasure = d->getMeasure();
        LXMeasureModel iMeasure = wMeasure.lock();
        if (iMeasure && !d->mMat.empty() && iResized)
        {
            iMeasure->setModelImageSize(QSize(d->mMat.cols, d->mMat.rows));
        }
        d->updateAllMeasures();
    }
}

void LaserXCanvas::loadImage(const QString& fileName)
{
    Q_D(LaserXCanvas);
    QImageReader reader(fileName);
    reader.setAutoTransform(true);
    const QImage newImage = reader.read();
    setImageSourceName(QFileInfo(fileName).fileName());
    cv::Mat iMat = d->qImageToMatRef(newImage).clone();
    setMat(iMat);
}

void LaserXCanvas::saveImage()
{
    Q_D(LaserXCanvas);
    QString filter(tr("Images(*.png *.jpg *.tiff *.tif *.bmp *.dib)"));
    QString filePath = QFileDialog::getSaveFileName(this, tr("Save Image File"), QStringLiteral(""), filter);
    if (!filePath.isEmpty())
    {
        if (!d->mMat.empty())
        {
            cv::imwrite(filePath.toStdString(), d->mMat);
            const QImage imageRef = d->matToQImageRef(d->mMat);
            QImageWriter writer(filePath);
            writer.write(imageRef);
        }
        else
        {
            qWarning() << QStringLiteral("Image empty error");
        }
    }
}

void LaserXCanvas::bindCamera(LaserXCamera* camera)
{
    Q_D(LaserXCanvas);
    if (camera != d->mCamera)
    {
        if (d->mCamera)
        {
            d->mCamera->stopContinuousGrab();
            disconnect(d->mCamera, &LaserXCamera::imageReady, this, &LaserXCanvas::onImageReady);
            disconnect(d->mCamera->getManager(), &LaserXCameraManager::cameraAboutToDelete, this, &LaserXCanvas::onCameraAboutToDelete);
            d->mCamera = nullptr;
        }

        if (camera)
        {
            d->mCamera = camera;
            connect(d->mCamera, &LaserXCamera::imageReady, this, &LaserXCanvas::onImageReady, Qt::QueuedConnection);
            connect(d->mCamera->getManager(), &LaserXCameraManager::cameraAboutToDelete, this, &LaserXCanvas::onCameraAboutToDelete);
        }
    }
}

QJsonObject LaserXCanvas::currentROI() const
{
    QJsonArray rects;
    QJsonArray ellipses;
    QJsonArray polygons;
    Q_D(const LaserXCanvas);
    QList<QGraphicsItem*> iItems  = scene()->items();
    for (QGraphicsItem* iItem : iItems)
    {
        if (ChildRectItem *iRectItem = dynamic_cast<ChildRectItem *>(iItem))
        {
            rects.push_back(iRectItem->getData(d->mImageItem));
        }
        else if (ChildEllipseItem* iEllipseItem = dynamic_cast<ChildEllipseItem*>(iItem))
        {
            ellipses.push_back(iEllipseItem->getData(d->mImageItem));
        }
        else if (ChildPolygonItem* iPolygonItem = dynamic_cast<ChildPolygonItem*>(iItem))
        {
            polygons.push_back(iPolygonItem->getData(d->mImageItem));
        }
        else
        {
            // not a subpath
        }
    }

    QJsonObject obj;

    if (!rects.empty())
    {
        obj[QStringLiteral("rects")] = rects;
    }

    if (!ellipses.empty())
    {
        obj[QStringLiteral("ellipses")] = ellipses;
    }

    if (!polygons.empty())
    {
        obj[QStringLiteral("polygons")] = polygons;
    }

    return obj;
}

void LaserXCanvas::setCurrentROI(const QJsonObject& region)
{
    Q_D(LaserXCanvas);
    clearROI();
    d->createRegionItem();

    if (region.contains(QStringLiteral("rects")))
    {
        QJsonValue val = region.value(QStringLiteral("rects"));
        if (val.isArray())
        {
            QJsonArray rects = val.toArray();
            for (const auto &rect : rects)
            {
                ChildRectItem::create(d->mRegion, rect.toObject());
            }
        }
    }

    if (region.contains(QStringLiteral("ellipses")))
    {
        QJsonValue val = region.value(QStringLiteral("ellipses"));
        if (val.isArray())
        {
            QJsonArray ellipses = val.toArray();
            for (const auto& ellipse : ellipses)
            {
                ChildEllipseItem::create(d->mRegion, ellipse.toObject());
            }
        }
    }

    if (region.contains(QStringLiteral("polygons")))
    {
        QJsonValue val = region.value(QStringLiteral("polygons"));
        if (val.isArray())
        {
            QJsonArray polygons = val.toArray();
            for (const auto& polygon : polygons)
            {
                ChildPolygonItem::create(d->mRegion, polygon.toObject());
            }
        }
    }

    d->updateRegionPath();
}

QJsonValue LaserXCanvas::charBoxs() const
{
    Q_D(const LaserXCanvas);
    QJsonArray jArray;
    QList<QGraphicsItem*> iItems = scene()->items();
    std::vector<ChildCharBoxItem*> iCharItems;

    for (QGraphicsItem* iItem : iItems)
    {
        if (ChildCharBoxItem* iCharItem = dynamic_cast<ChildCharBoxItem*>(iItem))
        {
            iCharItems.push_back(iCharItem);
        }
    }

    std::sort(iCharItems.begin(), iCharItems.end(), [](const ChildCharBoxItem* item1, const ChildCharBoxItem* item2) { return item1->getChar() < item2->getChar(); });
    for (ChildCharBoxItem* iCharItem : iCharItems)
    {
        const QRectF iRect = iCharItem->getCharRect();
        jArray.push_back(iCharItem->getData(d->mImageItem));
    }

    return jArray;
}

void LaserXCanvas::setCharBoxs(const QJsonValue& nVal)
{
    Q_D(LaserXCanvas);
    clearROI();

    if (!nVal.isArray())
    {
        return;
    }

    QJsonArray jArray = nVal.toArray();
    d->createRegionItem();
    for (const QJsonValueRef &jVal : jArray)
    {
        if (jVal.isObject())
        {
            ChildCharBoxItem::create(d->mRegion, jVal.toObject());
        }
    }

    d->updateRegionPath();
}

QPointF LaserXCanvas::refPoint() const
{
    Q_D(const LaserXCanvas);
    return d->mRefPointItem->pos();
}

void LaserXCanvas::setRefPoint(const QPointF& val)
{
    Q_D(LaserXCanvas);
    d->mRefPointItem->setPos(val);
}

void LaserXCanvas::clearROI()
{
    QVector<ChildPathItem*> delItems;
    QList<QGraphicsItem*> iItems = scene()->items();
    for (QGraphicsItem* iItem : iItems)
    {
        ChildPathItem* iPathItem = dynamic_cast<ChildPathItem*>(iItem);
        GeomFinderItem* iGeomItem = dynamic_cast<GeomFinderItem*>(iItem);
        if (iPathItem && !iGeomItem)
        {
            delItems.push_back(iPathItem);
        }
    }

    Q_D(LaserXCanvas);
    qDeleteAll(delItems);
    d->updateRegionPath();
}

void LaserXCanvas::clearAllTemporaryItems()
{
    Q_D(LaserXCanvas);
    qDeleteAll(d->mTemporaryItems);
    d->mTemporaryItems.clear();

    clearAllInfoItems();
}

void LaserXCanvas::addTemporaryItem(QGraphicsItem* item)
{
    Q_D(LaserXCanvas);

    scene()->addItem(item);
    d->mTemporaryItems.push_back(item);
}

void LaserXCanvas::clearAllInfoItems()
{
    Q_D(LaserXCanvas);
    d->mTemporaryInfoItems.clear();
    d->updateInfoItem();
}

void LaserXCanvas::addInfoItem(const QString& strInfo)
{
    Q_D(LaserXCanvas);
    d->mTemporaryInfoItems.append(strInfo);
    d->updateInfoItem();
}

void LaserXCanvas::addInfoItems(const QStringList& strInfos)
{
    Q_D(LaserXCanvas);
    d->mTemporaryInfoItems.append(strInfos);
    d->updateInfoItem();
}

void LaserXCanvas::hideAllROI()
{
    Q_D(LaserXCanvas);
    if (d->mRegion) d->mRegion->hide();
    QList<QGraphicsItem*> iItems = scene()->items();
    for (QGraphicsItem* iItem : iItems)
    {
        if (ChildPathItem* iPathItem = dynamic_cast<ChildPathItem*>(iItem))
        {
            iPathItem->hide();
        }
    }
}

void LaserXCanvas::showAllROI()
{
    Q_D(LaserXCanvas);
    if (d->mRegion) d->mRegion->show();
    QList<QGraphicsItem*> iItems = scene()->items();
    for (QGraphicsItem* iItem : iItems)
    {
        if (ChildPathItem* iPathItem = dynamic_cast<ChildPathItem*>(iItem))
        {
            iPathItem->show();
        }
    }
}

void LaserXCanvas::setAllROIVisible(const bool visible)
{
    Q_D(LaserXCanvas);
    if (visible)
    {
        LaserXCanvas::showAllROI();
    }
    else
    {
        LaserXCanvas::hideAllROI();
    }
}

void LaserXCanvas::fitView()
{
    Q_D(LaserXCanvas);
    if (d->mImageItem)
    {
        scene()->setSceneRect(d->mImageItem->boundingRect());
        fitInView(d->mImageItem, Qt::KeepAspectRatio);
        d->mInfoItem->setPos(mapToScene(QPoint(0, 0)));
    }
}

QByteArray LaserXCanvas::measureModel() const
{
    Q_D(const LaserXCanvas);
    if (d->mMeasure)
    {
        return d->mMeasure->getBlob();
    }
    else
    {
        return QByteArray();
    }
}

QJsonObject LaserXCanvas::measureParams() const
{
    QJsonArray iLines;
    QJsonArray iRects;
    QJsonArray iCircles;
    QJsonArray iEllipses;
    Q_D(const LaserXCanvas);
    QList<QGraphicsItem*> iItems = scene()->items();
    for (QGraphicsItem* iItem : iItems)
    {
        if (LineFinderItem* iLineItem = dynamic_cast<LineFinderItem*>(iItem))
        {
            iLines.push_back(iLineItem->getData(d->mImageItem));
        }
        else if (RectFinderItem* iRectItem = dynamic_cast<RectFinderItem*>(iItem))
        {
            iRects.push_back(iRectItem->getData(d->mImageItem));
        }
        else if (CircleFinderItem* iCircleItem = dynamic_cast<CircleFinderItem*>(iItem))
        {
            iCircles.push_back(iCircleItem->getData(d->mImageItem));
        }
        else if (EllipseFinderItem* iEllipseItem = dynamic_cast<EllipseFinderItem*>(iItem))
        {
            iEllipses.push_back(iEllipseItem->getData(d->mImageItem));
        }
        else
        {
            // not a measure item
        }
    }

    QJsonObject obj;
    if (!iLines.empty())
    {
        obj[QStringLiteral("Lines")] = iLines;
    }

    if (!iRects.empty())
    {
        obj[QStringLiteral("Rects")] = iRects;
    }

    if (!iCircles.empty())
    {
        obj[QStringLiteral("Circles")] = iCircles;
    }

    if (!iEllipses.empty())
    {
        obj[QStringLiteral("Ellipses")] = iEllipses;
    }

    return obj;
}

void LaserXCanvas::setMeasureParams(const QJsonObject& params)
{
    Q_D(LaserXCanvas);
    if (params.contains(QStringLiteral("Lines")))
    {
        QJsonValue val = params.value(QStringLiteral("Lines"));
        if (val.isArray())
        {
            QJsonArray iLines = val.toArray();
            for (const auto& iLine : iLines)
            {
                ChildPathItem* iItem = LineFinderItem::create(nullptr, iLine.toObject(), d);
                if (iItem)
                {
                    scene()->addItem(iItem);
                    iItem->updateMeasure(true);
                }
            }
        }
    }

    if (params.contains(QStringLiteral("Rects")))
    {
        QJsonValue val = params.value(QStringLiteral("Rects"));
        if (val.isArray())
        {
            QJsonArray iRects = val.toArray();
            for (const auto& iRect : iRects)
            {
                ChildPathItem* iItem = RectFinderItem::create(nullptr, iRect.toObject(), d);
                if (iItem)
                {
                    scene()->addItem(iItem);
                    iItem->updateMeasure(true);
                }
            }
        }
    }

    if (params.contains(QStringLiteral("Circles")))
    {
        QJsonValue val = params.value(QStringLiteral("Circles"));
        if (val.isArray())
        {
            QJsonArray iCircles = val.toArray();
            for (const auto& iCircle : iCircles)
            {
                ChildPathItem* iItem = CircleFinderItem::create(nullptr, iCircle.toObject(), d);
                if (iItem)
                {
                    scene()->addItem(iItem);
                    iItem->updateMeasure(true);
                }
            }
        }
    }

    if (params.contains(QStringLiteral("Ellipses")))
    {
        QJsonValue val = params.value(QStringLiteral("Ellipses"));
        if (val.isArray())
        {
            QJsonArray iEllipses = val.toArray();
            for (const auto& iEllipse : iEllipses)
            {
                ChildPathItem* iItem = EllipseFinderItem::create(nullptr, iEllipse.toObject(), d);
                if (iItem)
                {
                    scene()->addItem(iItem);
                    iItem->updateMeasure(true);
                }
            }
        }
    }
}

QSize LaserXCanvas::sizeHint() const
{
    return QSize(320, 240);
}

QSize LaserXCanvas::minimumSizeHint() const
{
    return QSize(32, 24);
}