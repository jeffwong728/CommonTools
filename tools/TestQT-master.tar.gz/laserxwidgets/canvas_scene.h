#ifndef CANVAS_SCENE_H
#define CANVAS_SCENE_H

#include <QGraphicsScene>
#include <QGraphicsView>
#include <QGraphicsPixmapItem>
class RegionItem;
class ChildPathItem;

class CanvasScene : public QGraphicsScene
{
    Q_OBJECT

public:
    explicit CanvasScene(QObject *parent = nullptr);

protected:
    void dragEnterEvent(QGraphicsSceneDragDropEvent* event) override;
    void dragMoveEvent(QGraphicsSceneDragDropEvent* event) override;
    void dragLeaveEvent(QGraphicsSceneDragDropEvent* event) override;
    void dropEvent(QGraphicsSceneDragDropEvent* event) override;
    void contextMenuEvent(QGraphicsSceneContextMenuEvent* event) override;
    void mousePressEvent(QGraphicsSceneMouseEvent* event) override;
    void mouseMoveEvent(QGraphicsSceneMouseEvent* event) override;
    void mouseReleaseEvent(QGraphicsSceneMouseEvent* event) override;
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event) override;
    void wheelEvent(QGraphicsSceneWheelEvent* event) override;
    void keyPressEvent(QKeyEvent* event) override;

public:
    QVector<ChildPathItem*> getSelSubPaths(QGraphicsItem* item);
    QVector<ChildPathItem*> getAllSubPaths();

private:
    void onRename(QGraphicsItem* item);
    void onDelete(QGraphicsItem* item);
    void onReverse(QGraphicsItem* item);
    void onMoveFront(QGraphicsItem* item);
    void onMoveBack(QGraphicsItem* item);
    void onSetWidth(QGraphicsItem* item);
    void onSetHeight(QGraphicsItem* item);
    void translateSelectedItems(const qreal dx, const qreal dy);

private:
    void updateRegionItem() const;
    RegionItem* findRegionItem() const;
};

#endif //CANVAS_SCENE_H
