#include "laser_x_device_widget.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>
#include <laser_x_camera.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>

LaserXDeviceWidget::LaserXDeviceWidget(QWidget *parent)
    : QTreeWidget(parent)
{
    setSortingEnabled(false);

    QTreeWidgetItem* deviceItem = new QTreeWidgetItem(this);
    deviceItem->setIcon(0, QIcon(QStringLiteral(":/laserxwidgets/images/pci.png")));
    header()->setSectionResizeMode(0, QHeaderView::Interactive);
    setIndentation(10);
    setDragEnabled(true);
    setAcceptDrops(false);
    setDropIndicatorShown(false);
    setDragDropMode(QAbstractItemView::DragOnly);
    QTimer::singleShot(0, this, [this]() { retranslateUi(); });
}

void LaserXDeviceWidget::retranslateUi()
{
    QTreeWidgetItem* rootItem = invisibleRootItem();
    QTreeWidgetItem* deviceItem = rootItem->child(0);
    deviceItem->setText(0, tr("Devices"));

    QVector<QTreeWidgetItem*> redundantItems;
    if (rootItem->childCount() > 1)
    {
        for (int cc = 1; cc < rootItem->childCount(); ++cc)
        {
            redundantItems.push_back(rootItem->child(cc));
        }
        qDeleteAll(redundantItems);
    }

    QStringList labels;
    labels << tr("Name") << tr("Status") << tr("Description") << tr("Data");
    if (QTreeWidgetItem* header = headerItem())
    {
        for (qsizetype ii = 0; ii < labels.count(); ++ii)
        {
            header->setText(ii, labels.at(ii));
        }
    } 
    else
    {
        setColumnCount(labels.count());
        setHeaderLabels(labels);
    }

    QTreeWidgetItem* serialRootItem = findSerialPortRoot();
    if (serialRootItem)
    {
        serialRootItem->setText(0, tr("Serial Port"));
    }

    QTreeWidgetItem* cameraRootItem = findCameraRoot();
    if (cameraRootItem)
    {
        cameraRootItem->setText(0, tr("Camera"));
    }

    QTreeWidgetItem* netRootItem = findNetRoot();
    if (netRootItem)
    {
        netRootItem->setText(0, tr("Network"));
    }
}

void LaserXDeviceWidget::changeEvent(QEvent* event)
{
    if (QEvent::LanguageChange == event->type())
    {
        retranslateUi();
    }
    QTreeWidget::changeEvent(event);
}

void LaserXDeviceWidget::mousePressEvent(QMouseEvent* event)
{
    QTreeView::mousePressEvent(event);
    QModelIndex item = indexAt(event->pos());
    if (!item.isValid())
    {
        clearSelection();
        const QModelIndex index;
        selectionModel()->setCurrentIndex(index, QItemSelectionModel::Select);
    }
}

bool LaserXDeviceWidget::addSerialPort(const QString& uuid, const QVariant& info)
{
    QTreeWidgetItem* serialRootItem = getSerialPortRoot();
    for (int cc = 0; cc < serialRootItem->childCount(); ++cc)
    {
        if (uuid == serialRootItem->child(cc)->data(0, Qt::UserRole+1).toString())
        {
            return false;
        }
    }

    const auto comPort = static_cast<LaserXSerialPort*>(info.value<void*>());
    if (comPort)
    {
        QTreeWidgetItem* serialItem = new QTreeWidgetItem(serialRootItem);
        serialItem->setText(0, comPort->portName());
        serialItem->setIcon(0, QIcon(QStringLiteral(":/qss_icons/images/port-icon.png")));
        serialItem->setData(0, Qt::UserRole+1, uuid);
        serialItem->setData(0, Qt::UserRole, QStringLiteral("LaserXSerialPort"));
        serialItem->setTextAlignment(1, Qt::AlignCenter);
        serialItem->setText(2, comPort->description());

        if (QSerialPort::NoError == comPort->error())
        {
            if (comPort->isOpen())
            {
                serialItem->setIcon(1, QIcon(QStringLiteral(":/images/green")));
            }
            else
            {
                serialItem->setIcon(1, QIcon(QStringLiteral(":/images/gray")));
            }
        }
        else
        {
            serialItem->setText(1, QtEnumToString(comPort->error()));
            serialItem->setIcon(1, QIcon(QStringLiteral(":/images/red")));
        }

        QTreeWidgetItem* rootItem = invisibleRootItem();
        QTreeWidgetItem* deviceItem = rootItem->child(0);
        deviceItem->setExpanded(true);
        serialRootItem->setExpanded(true);
    }

    return true;
}

void LaserXDeviceWidget::deleteSerialPort(const QString& uuid)
{
    QTreeWidgetItem* serialRootItem = findSerialPortRoot();
    if (serialRootItem) {
        for (int cc = 0; cc < serialRootItem->childCount(); ++cc)
        {
            if (uuid == serialRootItem->child(cc)->data(0, Qt::UserRole+1).toString())
            {
                delete serialRootItem->child(cc);
            }
        }
    }
}

void LaserXDeviceWidget::updateSerialPort(const QString &uuid, const QVariant &info)
{
    QTreeWidgetItem* serialRootItem = findSerialPortRoot();
    if (serialRootItem) {
        for (int cc = 0; cc < serialRootItem->childCount(); ++cc)
        {
            QTreeWidgetItem* serialItem = serialRootItem->child(cc);
            if (uuid == serialItem->data(0, Qt::UserRole+1).toString())
            {
                const auto comPort = static_cast<LaserXSerialPort*>(info.value<void*>());
                if (comPort)
                {
                    if (QSerialPort::NoError == comPort->error())
                    {
                        if (comPort->isOpen())
                        {
                            serialItem->setIcon(1, QIcon(QStringLiteral(":/images/green")));
                        }
                        else
                        {
                            serialItem->setIcon(1, QIcon(QStringLiteral(":/images/gray")));
                        }
                        serialItem->setText(1, QStringLiteral(""));
                    }
                    else
                    {
                        serialItem->setText(1, QtEnumToString(comPort->error()));
                        serialItem->setIcon(1, QIcon(QStringLiteral(":/images/red")));
                    }
                }
            }
        }
    }
}

bool LaserXDeviceWidget::addCamera(const QString& uuid, const QVariant& info)
{
    QTreeWidgetItem* cameraRootItem = getCameraRoot();
    for (int cc = 0; cc < cameraRootItem->childCount(); ++cc)
    {
        if (uuid == cameraRootItem->child(cc)->data(0, Qt::UserRole+1).toString())
        {
            return false;
        }
    }

    const LaserXCamera* camera = static_cast<LaserXCamera*>(info.value<void*>());
    if (camera)
    {
        QTreeWidgetItem* cameraItem = new QTreeWidgetItem(cameraRootItem);
        cameraItem->setText(0, camera->name());
        cameraItem->setIcon(0, camera->getManager()->getIcon());
        cameraItem->setData(0, Qt::UserRole+1, uuid);
        cameraItem->setData(0, Qt::UserRole, QStringLiteral("LaserXCamera"));
        cameraItem->setTextAlignment(1, Qt::AlignCenter);
        cameraItem->setText(2, camera->description());

        if (LaserXCamera::NoError == camera->error())
        {
            if (camera->isOpened())
            {
                cameraItem->setIcon(1, QIcon(QStringLiteral(":/images/green")));
            }
            else
            {
                cameraItem->setIcon(1, QIcon(QStringLiteral(":/images/gray")));
            }
        }
        else if (LaserXCamera::ReadParameterError == camera->error() || LaserXCamera::WriteParameterError == camera->error())
        {
            cameraItem->setText(1, QtEnumToString(camera->error()));
            cameraItem->setIcon(1, QIcon(QStringLiteral(":/images/yellow")));
        }
        else
        {
            cameraItem->setText(1, QtEnumToString(camera->error()));
            cameraItem->setIcon(1, QIcon(QStringLiteral(":/images/red")));
        }

        QTreeWidgetItem* rootItem = invisibleRootItem();
        QTreeWidgetItem* deviceItem = rootItem->child(0);
        deviceItem->setExpanded(true);
        cameraRootItem->setExpanded(true);
    }

    return true;
}

void LaserXDeviceWidget::deleteCamera(const QString& uuid)
{
    QTreeWidgetItem* cameraRootItem = findCameraRoot();
    if (cameraRootItem) {
        for (int cc = 0; cc < cameraRootItem->childCount(); ++cc)
        {
            if (uuid == cameraRootItem->child(cc)->data(0, Qt::UserRole+1).toString())
            {
                delete cameraRootItem->child(cc);
            }
        }
    }
}

void LaserXDeviceWidget::updateCamera(const QString& uuid, const QVariant& info)
{
    QTreeWidgetItem* cameraRootItem = findCameraRoot();
    if (cameraRootItem) {
        for (int cc = 0; cc < cameraRootItem->childCount(); ++cc)
        {
            QTreeWidgetItem* cameraItem = cameraRootItem->child(cc);
            if (uuid == cameraItem->data(0, Qt::UserRole+1).toString())
            {
                const LaserXCamera* camera = static_cast<LaserXCamera*>(info.value<void*>());
                if (camera)
                {
                    cameraItem->setText(0, camera->name());
                    cameraItem->setText(2, camera->description());
                    if (LaserXCamera::NoError == camera->error())
                    {
                        if (camera->isOpened())
                        {
                            cameraItem->setIcon(1, QIcon(QStringLiteral(":/images/green")));
                        }
                        else
                        {
                            cameraItem->setIcon(1, QIcon(QStringLiteral(":/images/gray")));
                        }
                        cameraItem->setText(1, QStringLiteral(""));
                    }
                    else if (LaserXCamera::ReadParameterError == camera->error() || LaserXCamera::WriteParameterError == camera->error())
                    {
                        cameraItem->setText(1, QtEnumToString(camera->error()));
                        cameraItem->setIcon(1, QIcon(QStringLiteral(":/images/yellow")));
                    }
                    else
                    {
                        cameraItem->setText(1, QtEnumToString(camera->error()));
                        cameraItem->setIcon(1, QIcon(QStringLiteral(":/images/red")));
                    }
                }
            }
        }
    }
}

bool LaserXDeviceWidget::addNetServer(const QString& uuid, const QVariant& info)
{
    return false;
}

void LaserXDeviceWidget::deleteNetServer(const QString& uuid)
{

}

void LaserXDeviceWidget::updateNetServer(const QString& uuid, const QVariant& info)
{

}

bool LaserXDeviceWidget::addNetClient(const QString& uuid, const QVariant& info)
{
    QTreeWidgetItem* netRootItem = getNetRoot();
    for (int cc = 0; cc < netRootItem->childCount(); ++cc)
    {
        if (uuid == netRootItem->child(cc)->data(0, Qt::UserRole + 1).toString())
        {
            return false;
        }
    }

    const auto iNet = static_cast<LaserXNetSender*>(info.value<void*>());
    if (iNet)
    {
        QTreeWidgetItem* netItem = new QTreeWidgetItem(netRootItem);
        netItem->setText(0, iNet->name());
        netItem->setIcon(0, QIcon(QStringLiteral(":/laserxwidgets/images/network_ethernet.png")));
        netItem->setData(0, Qt::UserRole + 1, uuid);
        netItem->setData(0, Qt::UserRole, QStringLiteral("LaserXNetSender"));
        netItem->setTextAlignment(1, Qt::AlignCenter);
        netItem->setText(2, QStringLiteral("%1:%2").arg(iNet->address().toString()).arg(iNet->port()));

        if (QTcpSocket::ConnectedState == iNet->state())
        {
            netItem->setIcon(1, QIcon(QStringLiteral(":/images/green")));
        }
        else if (QTcpSocket::UnconnectedState == iNet->state())
        {
            netItem->setIcon(1, QIcon(QStringLiteral(":/images/red")));
        }
        else
        {
            netItem->setIcon(1, QIcon(QStringLiteral(":/images/gray")));
        }

        QTreeWidgetItem* rootItem = invisibleRootItem();
        QTreeWidgetItem* deviceItem = rootItem->child(0);
        deviceItem->setExpanded(true);
        netRootItem->setExpanded(true);
    }

    return true;
}

void LaserXDeviceWidget::deleteNetClient(const QString& uuid)
{
    QTreeWidgetItem* netRootItem = findNetRoot();
    if (netRootItem) {
        for (int cc = 0; cc < netRootItem->childCount(); ++cc)
        {
            if (uuid == netRootItem->child(cc)->data(0, Qt::UserRole + 1).toString())
            {
                delete netRootItem->child(cc);
            }
        }
    }
}

void LaserXDeviceWidget::updateNetClient(const QString& uuid, const QVariant& info)
{
    QTreeWidgetItem* netRootItem = findNetRoot();
    if (netRootItem) {
        for (int cc = 0; cc < netRootItem->childCount(); ++cc)
        {
            QTreeWidgetItem* netItem = netRootItem->child(cc);
            if (uuid == netItem->data(0, Qt::UserRole + 1).toString())
            {
                const auto iNet = static_cast<LaserXNetSender*>(info.value<void*>());
                if (iNet)
                {
                    if (QTcpSocket::ConnectedState == iNet->state())
                    {
                        netItem->setIcon(1, QIcon(QStringLiteral(":/images/green")));
                    }
                    else if (QTcpSocket::UnconnectedState == iNet->state())
                    {
                        netItem->setIcon(1, QIcon(QStringLiteral(":/images/red")));
                    }
                    else
                    {
                        netItem->setIcon(1, QIcon(QStringLiteral(":/images/gray")));
                    }
                }
            }
        }
    }
}

QTreeWidgetItem* LaserXDeviceWidget::getSerialPortRoot()
{
    QTreeWidgetItem* serialRootItem = findSerialPortRoot();

    if (!serialRootItem)
    {
        QTreeWidgetItem* rootItem = invisibleRootItem();
        QTreeWidgetItem* deviceItem = rootItem->child(0);
        serialRootItem = new QTreeWidgetItem(deviceItem);
        serialRootItem->setText(0, tr("Serial Port"));
        serialRootItem->setIcon(0, QIcon(QStringLiteral(":/qss_icons/images/port-icon.png")));
        serialRootItem->setData(0, Qt::UserRole, QStringLiteral("LaserXSerialPortRoot"));
    }

    return serialRootItem;
}

QTreeWidgetItem* LaserXDeviceWidget::findSerialPortRoot()
{
    QTreeWidgetItem* rootItem = invisibleRootItem();
    QTreeWidgetItem* deviceItem = rootItem->child(0);
    for (int cc = 0; cc < deviceItem->childCount(); ++cc)
    {
        if (QStringLiteral("LaserXSerialPortRoot") == deviceItem->child(cc)->data(0, Qt::UserRole).toString())
        {
            return deviceItem->child(cc);
        }
    }

    return nullptr;
}

QTreeWidgetItem* LaserXDeviceWidget::getCameraRoot()
{
    QTreeWidgetItem* cameraRootItem = findCameraRoot();

    if (!cameraRootItem)
    {
        QTreeWidgetItem* rootItem = invisibleRootItem();
        QTreeWidgetItem* deviceItem = rootItem->child(0);
        cameraRootItem = new QTreeWidgetItem(deviceItem);
        cameraRootItem->setText(0, tr("Camera"));
        cameraRootItem->setIcon(0, QIcon(QStringLiteral(":/laserxwidgets/images/camera.png")));
        cameraRootItem->setData(0, Qt::UserRole, QStringLiteral("LaserXCameraRoot"));
    }

    return cameraRootItem;
}

QTreeWidgetItem* LaserXDeviceWidget::findCameraRoot()
{
    QTreeWidgetItem* rootItem = invisibleRootItem();
    QTreeWidgetItem* deviceItem = rootItem->child(0);
    for (int cc = 0; cc < deviceItem->childCount(); ++cc)
    {
        if (QStringLiteral("LaserXCameraRoot") == deviceItem->child(cc)->data(0, Qt::UserRole).toString())
        {
            return deviceItem->child(cc);
        }
    }

    return nullptr;
}

QTreeWidgetItem* LaserXDeviceWidget::getNetRoot()
{
    QTreeWidgetItem* netRootItem = findNetRoot();

    if (!netRootItem)
    {
        QTreeWidgetItem* rootItem = invisibleRootItem();
        QTreeWidgetItem* deviceItem = rootItem->child(0);
        netRootItem = new QTreeWidgetItem(deviceItem);
        netRootItem->setText(0, tr("Network"));
        netRootItem->setIcon(0, QIcon(QStringLiteral(":/laserxwidgets/images/network_ethernet.png")));
        netRootItem->setData(0, Qt::UserRole, QStringLiteral("LaserXNetRoot"));
    }

    return netRootItem;
}

QTreeWidgetItem* LaserXDeviceWidget::findNetRoot()
{
    QTreeWidgetItem* rootItem = invisibleRootItem();
    QTreeWidgetItem* deviceItem = rootItem->child(0);
    for (int cc = 0; cc < deviceItem->childCount(); ++cc)
    {
        if (QStringLiteral("LaserXNetRoot") == deviceItem->child(cc)->data(0, Qt::UserRole).toString())
        {
            return deviceItem->child(cc);
        }
    }

    return nullptr;
}
