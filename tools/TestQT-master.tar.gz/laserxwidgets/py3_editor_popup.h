#ifndef PY3_EDITOR_POPUP_H
#define PY3_EDITOR_POPUP_H
#include <QWidget>
#include <QTextEdit>
class CodeEditor;

class Py3EditorPopup : public QWidget
{
    Q_OBJECT
public:
    explicit Py3EditorPopup(QWidget* parent = nullptr);

protected:
    QSize sizeHint() const override;
    QSize minimumSizeHint() const override;
    bool eventFilter(QObject* object, QEvent* evt) override;
    void changeEvent(QEvent* event) override;
    void closeEvent(QCloseEvent* event) override;

private:
    QWidget* mToolButton = nullptr;
    CodeEditor*mTextEdit = nullptr;
};
#endif //PY3_EDITOR_POPUP_H

