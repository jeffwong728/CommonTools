#include "laser_x_video_box.h"
#include <QtWidgets>
#include <QJsonDocument>

struct LaserXCanvasCell
{
    QString objName;
    QString srcName;
    int row = 0;
    int col = 0;
    int rowSpan = 0;
    int colSpan = 0;

    bool read(const QJsonObject& json)
    {
        if (json.contains(QLatin1String("objName")) && json[QLatin1String("objName")].isString() &&
            json.contains(QLatin1String("srcName")) && json[QLatin1String("srcName")].isString() &&
            json.contains(QLatin1String("row")) && json[QLatin1String("row")].isDouble() &&
            json.contains(QLatin1String("col")) && json[QLatin1String("col")].isDouble() &&
            json.contains(QLatin1String("rowSpan")) && json[QLatin1String("rowSpan")].isDouble() &&
            json.contains(QLatin1String("colSpan")) && json[QLatin1String("colSpan")].isDouble())
        {
            objName = json[QLatin1String("objName")].toString();
            srcName = json[QLatin1String("srcName")].toString();
            row     = json[QLatin1String("row")].toInt();
            col     = json[QLatin1String("col")].toInt();
            rowSpan = json[QLatin1String("rowSpan")].toInt();
            colSpan = json[QLatin1String("colSpan")].toInt();
            return true;
        }
        else
        {
            return false;
        }
    }

    void write(QJsonObject& json) const
    {
        json[QLatin1String("objName")] = objName;
        json[QLatin1String("srcName")] = srcName;
        json[QLatin1String("row")] = row;
        json[QLatin1String("col")] = col;
        json[QLatin1String("rowSpan")] = rowSpan;
        json[QLatin1String("colSpan")] = colSpan;
    }
};

LaserXVideoBox::LaserXVideoBox(QWidget *parent)
    : QWidget(parent)
    , mJsonManifest()
    , mAcceptDropImage(false)
{
    setAcceptDrops(false);
}

void LaserXVideoBox::setJsonManifest(const QString& jsonManifest)
{
    if (mJsonManifest.isEmpty())
    {
        mJsonManifest = jsonManifest;
        loaded();
    }
}

QString LaserXVideoBox::getJsonManifest() const
{
    return mJsonManifest;
}

void LaserXVideoBox::setAcceptDropImage(const bool acceptDropImage)
{
    mAcceptDropImage = acceptDropImage;
}

bool LaserXVideoBox::getAcceptDropImage() const
{
    return mAcceptDropImage;
}

void LaserXVideoBox::restoreLayout()
{
    if (mVideoMax)
    {
        LaserXCanvas* canvas = nullptr;
        for (const auto xCanvas : mWidgets)
        {
            if (xCanvas->isVisible())
            {
                canvas = xCanvas;
                break;
            }
        }

        if (canvas)
        {
            mVideoMax = false;
            mLayout->removeWidget(canvas);
            showAll(canvas);

            QTimer::singleShot(0, [=]() { canvas->fitView(); });
        }
    }
}

bool LaserXVideoBox::eventFilter(QObject* object, QEvent* evt)
{
    bool evtHandled = false;
    LaserXCanvas* xCanvas = qobject_cast<LaserXCanvas*>(object->parent());
    auto itFound = std::find(mWidgets.cbegin(), mWidgets.cend(), xCanvas);
    if (itFound != mWidgets.cend())
    {
        switch (evt->type())
        {
        case QEvent::MouseButtonDblClick:
            canvasMouseDoubleClickEvent(dynamic_cast<QMouseEvent*>(evt), xCanvas);
            break;

        case QEvent::MouseButtonPress:
            canvasMousePressEvent(dynamic_cast<QMouseEvent*>(evt), xCanvas);
            break;

        case QEvent::MouseButtonRelease:
            canvasMouseReleaseEvent(dynamic_cast<QMouseEvent*>(evt), xCanvas);
            break;

        case QEvent::MouseMove:
            canvasMouseMoveEvent(dynamic_cast<QMouseEvent*>(evt), xCanvas);
            break;

        case QEvent::DragEnter:
            evtHandled = canvasDragEnterEvent(dynamic_cast<QDragEnterEvent*>(evt), xCanvas);
            break;

        case QEvent::DragMove:
            evtHandled = canvasDragMoveEvent(dynamic_cast<QDragMoveEvent*>(evt), xCanvas);
            break;

        case QEvent::Drop:
            evtHandled = canvasDropEvent(dynamic_cast<QDropEvent*>(evt), xCanvas);
            break;

        default:
            break;
        }
    }

    if (evtHandled)
    {
        return evtHandled;
    }
    else
    {
        return QWidget::eventFilter(object, evt);
    }
}

void LaserXVideoBox::loaded()
{
    QByteArray jsonData = mJsonManifest.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qDebug() << Q_FUNC_INFO << jsonError.errorString();
    }

    std::vector<LaserXCanvasCell> cells;
    const QJsonObject jsonObj = loadDoc.object();
    if (jsonObj.contains(QLatin1String("LaserXCanvasCells")) && jsonObj[QLatin1String("LaserXCanvasCells")].isArray())
    {
        QJsonArray cellArray = jsonObj[QLatin1String("LaserXCanvasCells")].toArray();
        for (int cellIndex = 0; cellIndex < cellArray.size(); ++cellIndex) {
            QJsonObject cellObject = cellArray[cellIndex].toObject();
            LaserXCanvasCell cell;
            if (cell.read(cellObject))
            {
                cells.emplace_back(cell);
            }
            else
            {
                qDebug() << Q_FUNC_INFO << QLatin1String("Data corrupted");
                return;
            }
        }
    }

    if (!cells.empty())
    {
        mLayout = new QGridLayout();
        mLayout->setSpacing(1);
        mLayout->setContentsMargins(0, 0, 0, 0);
        for (const LaserXCanvasCell &cell : cells)
        {
            LaserXCanvas *xCanvas = new LaserXCanvas(this);
            xCanvas->setObjectName(cell.objName);
            xCanvas->setImageSourceName(cell.srcName);
            xCanvas->setAcceptDropImage(mAcceptDropImage);
            xCanvas->setFlowPanelEnabled(true);
            xCanvas->setCameraEnabled(false);
            xCanvas->viewport()->installEventFilter(this);
            xCanvas->setInteractive(true);
            xCanvas->setDragMode(QGraphicsView::RubberBandDrag);
            xCanvas->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
            mLayout->addWidget(xCanvas, cell.row, cell.col, cell.rowSpan, cell.colSpan);
            xCanvas->setProperty("mCellRow", cell.row);
            xCanvas->setProperty("mCellCol", cell.col);
            xCanvas->setProperty("mCellRowSpan", cell.rowSpan);
            xCanvas->setProperty("mCellColSpan", cell.colSpan);
            mWidgets << xCanvas;
        }

        setLayout(mLayout);
    }
}

void LaserXVideoBox::hideAll(LaserXCanvas* exceptMe)
{
    if (mLayout)
    {
        for (const auto xCanvas : mWidgets) {
            mLayout->removeWidget(xCanvas);
            if (exceptMe != xCanvas)
            {
                xCanvas->setVisible(false);
            }
        }
    }
}

void LaserXVideoBox::showAll(LaserXCanvas* exceptMe)
{
    for (const auto xCanvas : mWidgets) {
        const int row = xCanvas->property("mCellRow").toInt();
        const int col = xCanvas->property("mCellCol").toInt();
        const int rowSpan = xCanvas->property("mCellRowSpan").toInt();
        const int colSpan = xCanvas->property("mCellColSpan").toInt();
        mLayout->addWidget(xCanvas, row, col, rowSpan, colSpan);
        if (exceptMe != xCanvas)
        {
            xCanvas->setVisible(true);
        }
    }
}

bool LaserXVideoBox::canvasDragEnterEvent(QDragEnterEvent* event, LaserXCanvas* canvas)
{
    if (canvas && event->mimeData()->hasFormat(QStringLiteral("application/laserx/canvas-widget-layout")) && event->source() != canvas) {
        event->acceptProposedAction();
        return true;
    } else {
        event->ignore();
        return false;
    }
}

bool LaserXVideoBox::canvasDragMoveEvent(QDragMoveEvent* event, LaserXCanvas* canvas)
{
    if (canvas && event->mimeData()->hasFormat(QStringLiteral("application/laserx/canvas-widget-layout")) && event->source() != canvas) {
        event->acceptProposedAction();
        return true;
    } else {
        event->ignore();
        return false;
    }
}

bool LaserXVideoBox::canvasDropEvent(QDropEvent* event, LaserXCanvas* canvas)
{
    if (canvas && event->mimeData()->hasFormat(QStringLiteral("application/laserx/canvas-widget-layout")) && event->source() != canvas) {
        event->acceptProposedAction();
        LaserXCanvas* srcCanvas = qobject_cast<LaserXCanvas*>(event->source());

        int row = srcCanvas->property("mCellRow").toInt();
        int col = srcCanvas->property("mCellCol").toInt();
        int rowSpan = srcCanvas->property("mCellRowSpan").toInt();
        int colSpan = srcCanvas->property("mCellColSpan").toInt();

        srcCanvas->setProperty("mCellRow",      canvas->property("mCellRow"));
        srcCanvas->setProperty("mCellCol",      canvas->property("mCellCol"));
        srcCanvas->setProperty("mCellRowSpan",  canvas->property("mCellRowSpan"));
        srcCanvas->setProperty("mCellColSpan",  canvas->property("mCellColSpan"));

        canvas->setProperty("mCellRow", row);
        canvas->setProperty("mCellCol", col);
        canvas->setProperty("mCellRowSpan", rowSpan);
        canvas->setProperty("mCellColSpan", colSpan);

        for (const auto xCanvas : mWidgets)
        {
            mLayout->removeWidget(xCanvas);
        }

        for (const auto xCanvas : mWidgets)
        {
            const int row = xCanvas->property("mCellRow").toInt();
            const int col = xCanvas->property("mCellCol").toInt();
            const int rowSpan = xCanvas->property("mCellRowSpan").toInt();
            const int colSpan = xCanvas->property("mCellColSpan").toInt();
            mLayout->addWidget(xCanvas, row, col, rowSpan, colSpan);
        }

        return true;
    }
    else
    {
        event->ignore();
        return false;
    }
}

void LaserXVideoBox::canvasMousePressEvent(QMouseEvent* event, LaserXCanvas* canvas)
{
    if (event && canvas && Qt::LeftButton == event->button())
    {
        mDraging = true;
        mAnchorPos = event->globalPosition();
    }
}

void LaserXVideoBox::canvasMouseReleaseEvent(QMouseEvent* event, LaserXCanvas* canvas)
{
    if (event && canvas && Qt::LeftButton == event->button())
    {
    }

    if (mDraging)
    {
        mDraging = false;
        mAnchorPos = QPointF();
    }
}

void LaserXVideoBox::canvasMouseDoubleClickEvent(QMouseEvent* event, LaserXCanvas* canvas)
{
    if (event && canvas && Qt::LeftButton == event->button())
    {
        if (mVideoMax)
        {
            mVideoMax = false;
            mLayout->removeWidget(canvas);
            showAll(canvas);
        }
        else
        {
            mVideoMax = true;
            hideAll(canvas);
            mLayout->addWidget(canvas, 0, 0);
            canvas->setFocus();
        }

        QTimer::singleShot(0, [=]() { canvas->fitView(); });
    }
}

void LaserXVideoBox::canvasMouseMoveEvent(QMouseEvent* event, LaserXCanvas* canvas)
{
    if (event && canvas && event->buttons().testFlag(Qt::MiddleButton) && event->modifiers().testFlag(Qt::AltModifier))
    {
        if (QLineF(event->globalPosition(), mAnchorPos).length() > QApplication::startDragDistance())
        {
            QByteArray itemData;
            QDataStream dataStream(&itemData, QIODevice::WriteOnly);
            dataStream << canvas->property("mCellRow").toInt();
            dataStream << canvas->property("mCellCol").toInt();
            dataStream << canvas->property("mCellRowSpan").toInt();
            dataStream << canvas->property("mCellColSpan").toInt();

            QMimeData* mimeData = new QMimeData;
            mimeData->setData(QStringLiteral("application/laserx/canvas-widget-layout"), itemData);

            QDrag* drag = new QDrag(canvas);
            drag->setMimeData(mimeData);
            drag->exec(Qt::MoveAction, Qt::MoveAction);
        }
    }
}
