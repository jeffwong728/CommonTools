#ifndef LASER_X_CANVAS_PRIVATE_H
#define LASER_X_CANVAS_PRIVATE_H

#include <QtCore>
#include <QGraphicsPixmapItem>
#include <QGraphicsTextItem>
#include <opencv2/opencv.hpp>
#include <laser_x_vision.h>
#include "laser_x_canvas.h"

class QMimeData;
class CanvasScene;
class QPushButton;
class LaserXCamera;
class RegionItem;
class ChildPathItem;
class QAbstractButton;
class QButtonGroup;
class QGraphicsTextItem;
class QGraphicsPixmapItem;
class QGraphicsEllipseItem;
class ReferencePoint;
class LaserXVisionManager;
extern LaserXVisionManager* gVision;

class LaserXCanvasPrivate : public QObject
{
    Q_OBJECT
    enum FlowPushButton
    {
        SelectButton,
        DrawLine,
        DrawSquare,
        DrawEllipse,
        DrawPolygon,
        DrawCharBox,
        DrawLineFinder,
        DrawCircleFinder,
        DrawRectFinder,
        DrawEllipseFinder,
        SaveImage,
        ColorPicker,
        SnapButton,
        LiveButton,
        BreakLink,
        CrossLine,
        RefPoint,
        HideROI,
        FlowPushButtonGuard
    };

    enum class DrawingMode
    {
        Select,
        Line,
        Square,
        Ellipse,
        Polygon,
        CharBox,
        LineFinder,
        CircleFinder,
        RectFinder,
        EllipseFinder,
        DrawingModeGuard
    };

    QObject* const q_ptr;
    Q_DECLARE_PUBLIC(LaserXCanvas)
public:
    explicit LaserXCanvasPrivate(QObject* const ptr);
    ~LaserXCanvasPrivate();

public:
    void retranslateUi();
    void initFlowPanel();
    void drawingSwitched(QAbstractButton* button, bool checked);
    void btnClicked();
    cv::Mat qImageToMatRef(const QImage& image);
    QImage matToQImageRef(const cv::Mat &mat);
    QString getImageFilePath(const QMimeData* mData);
    void dispImage(const QImage& image, bool resized);
    bool isResized(const cv::Mat& newMat);
    bool isResized(const QImage& newImage);
    void createRegionItem();
    void updateRegionPath();
    void startDrawing();
    void endDrawing();
    void abortDrawing();
    void disablePanel(const bool disabled);
    void loadVisionPlugin();
    LXWMeasureModel getMeasure();
    void updateAllMeasures();
    void updateInfoItem();

public:
    QStringList mTemporaryInfoItems;
    QVector<QGraphicsItem*> mTemporaryItems;
    LaserXCamera* mCamera = nullptr;
    CanvasScene* mScene = nullptr;
    QGraphicsPixmapItem* mImageItem = nullptr;
    QGraphicsLineItem* mHLineItem = nullptr;
    QGraphicsLineItem* mVLineItem = nullptr;
    QGraphicsTextItem* mInfoItem = nullptr;
    ReferencePoint* mRefPointItem = nullptr;
    RegionItem* mRegion = nullptr;
    ChildPathItem* mDrawingItem = nullptr;
    QWidget* mFlowPanel = nullptr;
    QPushButton* mFlowButtons[FlowPushButtonGuard] = {nullptr};
    QButtonGroup* mDrawingGroup = nullptr;
    QString mImageSourceName;
    QString mVisionPluginPath;
    QPoint mAnchorPoint;
    QPoint mLastPoint;
    cv::Mat mMat;
    LXMeasureModel mMeasure;
    DrawingMode mDrawingMode = DrawingMode::Select;
    qulonglong mFrameNumber = 0.;
    bool mMoving = false;
    bool mAcceptDropImage = false;
    bool mFlowPanelEnabled = false;
    bool mDrawingRectEnabled = false;
    bool mDrawingEllipseEnabled = false;
    bool mDrawingPolygonEnabled = false;
    bool mDrawingCharBoxEnabled = false;
    bool mDrawingLineEnabled = false;
    bool mDrawingLineFinderEnabled = false;
    bool mDrawingCircleFinderEnabled = false;
    bool mDrawingRectFinderEnabled = false;
    bool mDrawingEllipseFinderEnabled = false;
    bool mCameraEnabled = false;
    bool mRefPointEnabled = false;
};

#endif //LASER_X_CANVAS_PRIVATE_H
