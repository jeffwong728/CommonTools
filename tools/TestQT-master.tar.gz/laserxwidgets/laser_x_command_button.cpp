#include "laser_x_command_button.h"
#include <QtWidgets>
#include <QMouseEvent>
#include <QPainter>
#include <QTime>
#include <QTimer>

LaserXCommandButton::LaserXCommandButton(QWidget *parent)
    : QPushButton(parent)
{
    setText(tr("Command"));
}
