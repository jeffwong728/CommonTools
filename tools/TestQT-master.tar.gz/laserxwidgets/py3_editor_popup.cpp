#include "py3_editor_popup.h"
#include "code_editor.h"
#include<QtWidgets>
#include<QVBoxLayout>
#include<QPushButton>

Py3EditorPopup::Py3EditorPopup(QWidget* parent)
    : QWidget(parent)
{
    auto layout = new QVBoxLayout();
    auto botLayout = new QHBoxLayout();
    mTextEdit = new CodeEditor(this);
    layout->setContentsMargins(0, 0, 0, 0);
    botLayout->addStretch(1);
    botLayout->addWidget(new QSizeGrip(this));
    layout->addWidget(mTextEdit, 1);
    layout->addLayout(botLayout);

    mToolButton = parent;
    QTimer::singleShot(0, this, [=]() 
    { 
        mTextEdit->setReadOnly(parent->property("readOnly").toBool());
        mTextEdit->setPlainText(parent->property("scripts").toString()); 
    });

    setMinimumSize(QSize(100, 60));
    setLayout(layout);
}

QSize Py3EditorPopup::sizeHint() const
{
    return QSize(300, 200);
}

QSize Py3EditorPopup::minimumSizeHint() const
{
    return QSize(100, 60);
}

bool Py3EditorPopup::eventFilter(QObject* object, QEvent* evt)
{
    if (object == parentWidget())
    {
        if (QEvent::Resize == evt->type())
        {
            auto parSize = parentWidget()->size();
            setGeometry(5, 5, parSize.width() - 10, parSize.height() - 10);
            return true;
        }

        if (QEvent::Close == evt->type())
        {
            mToolButton->setProperty("scripts", mTextEdit->toPlainText());
        }
    }

    return QWidget::eventFilter(object, evt);
}

void Py3EditorPopup::changeEvent(QEvent* event)
{
    if (QEvent::ParentChange == event->type())
    {
        if (parentWidget())
        {
            parentWidget()->installEventFilter(this);
        }
    }
}

void Py3EditorPopup::closeEvent(QCloseEvent* event)
{
    qDebug() << Q_FUNC_INFO;
}
