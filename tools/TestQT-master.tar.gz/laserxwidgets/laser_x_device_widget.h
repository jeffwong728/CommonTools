#ifndef LASER_X_DEVICE_WIDGET_H
#define LASER_X_DEVICE_WIDGET_H

#include <QTreeWidget>
#include "laser_x_widgets_global.h"

class LASERXWIDGETS_EXPORT LaserXDeviceWidget : public QTreeWidget
{
    Q_OBJECT

public:
    explicit LaserXDeviceWidget(QWidget *parent = nullptr);

protected:
    void changeEvent(QEvent* event) override;
    void mousePressEvent(QMouseEvent* event) override;

public:
    bool addSerialPort(const QString& uuid, const QVariant& info);
    void deleteSerialPort(const QString& uuid);
    void updateSerialPort(const QString &uuid, const QVariant &info);

    bool addCamera(const QString& uuid, const QVariant& info);
    void deleteCamera(const QString& uuid);
    void updateCamera(const QString& uuid, const QVariant& info);

    bool addNetServer(const QString& uuid, const QVariant& info);
    void deleteNetServer(const QString& uuid);
    void updateNetServer(const QString& uuid, const QVariant& info);

    bool addNetClient(const QString& uuid, const QVariant& info);
    void deleteNetClient(const QString& uuid);
    void updateNetClient(const QString& uuid, const QVariant& info);

private:
    void retranslateUi();

private:
    QTreeWidgetItem* getSerialPortRoot();
    QTreeWidgetItem* findSerialPortRoot();

    QTreeWidgetItem* getCameraRoot();
    QTreeWidgetItem* findCameraRoot();

    QTreeWidgetItem* getNetRoot();
    QTreeWidgetItem* findNetRoot();
};

#endif //LASER_X_DEVICE_WIDGET_H
