#ifndef LASER_X_VIDEO_BOX_H
#define LASER_X_VIDEO_BOX_H

#include <QFrame>
#include "laser_x_widgets_global.h"
#include "laser_x_canvas.h"
class QGridLayout;

class LASERXWIDGETS_EXPORT LaserXVideoBox : public QWidget
{
    Q_OBJECT
    Q_PROPERTY(QString jsonManifest READ getJsonManifest WRITE setJsonManifest)
    Q_PROPERTY(bool acceptDropImage READ getAcceptDropImage WRITE setAcceptDropImage)

public:
    explicit LaserXVideoBox(QWidget *parent = nullptr);

public:
    void setJsonManifest(const QString& jsonManifest);
    QString getJsonManifest() const;
    void setAcceptDropImage(const bool acceptDropImage);
    bool getAcceptDropImage() const;

protected:
    bool eventFilter(QObject* object, QEvent* evt) override;

private slots:
    void loaded();

private:
    void hideAll(LaserXCanvas* exceptMe);
    void showAll(LaserXCanvas* exceptMe);
    bool canvasDragEnterEvent(QDragEnterEvent* event, LaserXCanvas *canvas);
    bool canvasDragMoveEvent(QDragMoveEvent* event, LaserXCanvas* canvas);
    bool canvasDropEvent(QDropEvent* event, LaserXCanvas* canvas);
    void canvasMousePressEvent(QMouseEvent* event, LaserXCanvas* canvas);
    void canvasMouseReleaseEvent(QMouseEvent* event, LaserXCanvas* canvas);
    void canvasMouseDoubleClickEvent(QMouseEvent* event, LaserXCanvas* canvas);
    void canvasMouseMoveEvent(QMouseEvent* event, LaserXCanvas* canvas);

private:
    QGridLayout *mLayout = nullptr;
    QList<LaserXCanvas*> mWidgets;
    QString mJsonManifest;
    QPointF mAnchorPos;
    bool mAcceptDropImage = false;
    bool mVideoMax = false;
    bool mDraging = false;
};

#endif //LASER_X_VIDEO_BOX_H
