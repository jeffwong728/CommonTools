#include "laser_x_canvas.h"
#include "canvas_scene.h"
#include <geomitems/region_item.h>
#include <geomitems/child_rect_item.h>
#include <geomitems/child_polygon_item.h>
#include <geomitems/child_ellipse_item.h>
#include <geomitems/child_char_box_item.h>
#include <geomitems/line_finder_item.h>
#include <geomitems/geom_finder_item.h>
#include <QtWidgets>
#include <QMouseEvent>

CanvasScene::CanvasScene(QObject*parent)
    : QGraphicsScene(parent)
{
    setBackgroundBrush(QBrush(Qt::black));
    setItemIndexMethod(QGraphicsScene::ItemIndexMethod::NoIndex);
}

void CanvasScene::dragEnterEvent(QGraphicsSceneDragDropEvent* event)
{
    QGraphicsScene::dragEnterEvent(event);
}

void CanvasScene::dragMoveEvent(QGraphicsSceneDragDropEvent* event)
{
    QGraphicsScene::dragMoveEvent(event);
}

void CanvasScene::dragLeaveEvent(QGraphicsSceneDragDropEvent* event)
{
    QGraphicsScene::dragLeaveEvent(event);
}

void CanvasScene::dropEvent(QGraphicsSceneDragDropEvent* event)
{
    QGraphicsScene::dropEvent(event);
}

void CanvasScene::contextMenuEvent(QGraphicsSceneContextMenuEvent* event)
{
    QGraphicsItem* item = dynamic_cast<ChildPathItem *>(itemAt(event->scenePos(), QTransform()));
    QList<QGraphicsItem*> selItems = selectedItems();
    if (item || !selItems.empty())
    {
        std::unique_ptr<QMenu> iMenu = std::make_unique<QMenu>();
        iMenu->addAction(tr("Rename"), [this, item]() { onRename(item); });
        iMenu->addSeparator();
        iMenu->addAction(QIcon(QStringLiteral(":/laserxwidgets/images/reverse-16.png")), tr("Reverse"), [this, item]() { onReverse(item); });
        iMenu->addAction(QIcon(QStringLiteral(":/qss_icons/images/cross-24.png")), tr("Delete"), [this, item]() { onDelete(item); });
        iMenu->addSeparator();
        iMenu->addAction(QIcon(QStringLiteral(":/laserxwidgets/images/shape_move_back.png")), tr("Move Back"), [this, item]() { onMoveBack(item); });
        iMenu->addAction(QIcon(QStringLiteral(":/laserxwidgets/images/shape_move_front.png")), tr("Move Front"), [this, item]() { onMoveFront(item); });
        iMenu->addSeparator();
        iMenu->addAction(tr("Change Width"), [this, item]() { onSetWidth(item); });
        iMenu->addAction(tr("Change Height"), [this, item]() { onSetHeight(item); });

        QPoint globalPos = event->screenPos();
        iMenu->exec(globalPos);
    }
    else
    {
        QGraphicsScene::contextMenuEvent(event);
    }
}

void CanvasScene::mousePressEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsScene::mousePressEvent(event);
}

void CanvasScene::mouseMoveEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsScene::mouseMoveEvent(event);
}

void CanvasScene::mouseReleaseEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsScene::mouseReleaseEvent(event);
}

void CanvasScene::mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsScene::mouseDoubleClickEvent(event);
}

void CanvasScene::wheelEvent(QGraphicsSceneWheelEvent* event)
{
    QGraphicsScene::wheelEvent(event);
}

void CanvasScene::keyPressEvent(QKeyEvent* event)
{
    switch (event->key())
    {
    case Qt::Key_Delete: onDelete(nullptr); break;
    case Qt::Key_Left: translateSelectedItems(-1, 0); break;
    case Qt::Key_Right: translateSelectedItems(1, 0); break;
    case Qt::Key_Up: translateSelectedItems(0, -1); break;
    case Qt::Key_Down: translateSelectedItems(0, 1); break;
    default: QGraphicsScene::keyPressEvent(event); break;
    }
}

void CanvasScene::onRename(QGraphicsItem* item)
{
    QVector<ChildPathItem*> iSubPaths = getSelSubPaths(item);
    QVector<GeomFinderItem*> iGeomFinders;
    QVector<ChildCharBoxItem*> iCharBoxs;
    for (ChildPathItem* iItem : iSubPaths)
    {
        GeomFinderItem* iGeomItem = dynamic_cast<GeomFinderItem*>(iItem);
        if (iGeomItem)
        {
            iGeomFinders.push_back(iGeomItem);
        }

        ChildCharBoxItem* iCharBoxItem = dynamic_cast<ChildCharBoxItem*>(iItem);
        if (iCharBoxItem)
        {
            iCharBoxs.push_back(iCharBoxItem);
        }
    }

    if (!iGeomFinders.empty())
    {
        bool ok = false;
        QString iText = tr("New Name");
        QString iNewName = QInputDialog::getText(views().front(), iText, iText, QLineEdit::Normal, QStringLiteral("line"), &ok);
        if (ok && !iNewName.isEmpty())
        {
            for (GeomFinderItem* iGeomFinder : iGeomFinders)
            {
                iGeomFinder->setName(iNewName);
            }
        }
    }
    else
    {
        if (!iCharBoxs.empty())
        {
            bool ok = false;
            QString iText = tr("Change Char");
            QString iNewName = QInputDialog::getText(views().front(), iText, iText, QLineEdit::Normal, QStringLiteral("*"), &ok);
            if (ok && !iNewName.isEmpty())
            {
                for (ChildCharBoxItem* iCharBoxItem : iCharBoxs)
                {
                    iCharBoxItem->setChar(iNewName);
                }
            }
        }
    }
}

void CanvasScene::onDelete(QGraphicsItem* item)
{
    QVector<ChildPathItem*> iSubPaths = getSelSubPaths(item);
    if (!iSubPaths.empty())
    {
        qDeleteAll(iSubPaths);
        updateRegionItem();
    }
}

void CanvasScene::onReverse(QGraphicsItem* item)
{
    QVector<ChildPathItem*> iSubPaths = getSelSubPaths(item);
    if (!iSubPaths.empty())
    {
        for (ChildPathItem* iSubPath : iSubPaths)
        {
            iSubPath->toggleReversed();
        }
        updateRegionItem();
    }
}

void CanvasScene::onMoveFront(QGraphicsItem* item)
{
    QVector<ChildPathItem*> allSubPaths = getAllSubPaths();
    for (ChildPathItem* item : allSubPaths)
    {
        item->setZValue(1);
        for (QGraphicsItem* iChild : item->childItems())
        {
            iChild->setZValue(2);
        }
    }

    QVector<ChildPathItem*> allSelPaths = getSelSubPaths(item);
    for (ChildPathItem* item : allSelPaths)
    {
        item->setZValue(5);
        for (QGraphicsItem* iChild : item->childItems())
        {
            iChild->setZValue(6);
        }
    }
}

void CanvasScene::onMoveBack(QGraphicsItem* item)
{
    QVector<ChildPathItem*> allSubPaths = getAllSubPaths();
    for (ChildPathItem* item : allSubPaths)
    {
        item->setZValue(5);
        for (QGraphicsItem* iChild : item->childItems())
        {
            iChild->setZValue(6);
        }
    }

    QVector<ChildPathItem*> allSelPaths = getSelSubPaths(item);
    for (ChildPathItem* item : allSelPaths)
    {
        item->setZValue(1);
        for (QGraphicsItem* iChild : item->childItems())
        {
            iChild->setZValue(2);
        }
    }
}

void CanvasScene::onSetWidth(QGraphicsItem* item)
{
    QVector<ChildCharBoxItem*> iCharBoxs;
    QVector<ChildPathItem*> iSubPaths = getSelSubPaths(item);
    for (ChildPathItem* iItem : iSubPaths)
    {
        ChildCharBoxItem* iCharBoxItem = dynamic_cast<ChildCharBoxItem*>(iItem);
        if (iCharBoxItem)
        {
            iCharBoxs.push_back(iCharBoxItem);
        }
    }

    if (!iCharBoxs.empty())
    {
        const qreal iOldVal = iCharBoxs.front()->getCharRect().width();
        QString iText = tr("New Width");
        const qreal iNewVal = QInputDialog::getDouble(views().front(), iText, iText, iOldVal);
        if (iNewVal > 0.1)
        {
            for (ChildCharBoxItem* iCharBoxItem : iCharBoxs)
            {
                iCharBoxItem->setWidth(iNewVal);
            }
        }
    }
}

void CanvasScene::onSetHeight(QGraphicsItem* item)
{
    QVector<ChildCharBoxItem*> iCharBoxs;
    QVector<ChildPathItem*> iSubPaths = getSelSubPaths(item);
    for (ChildPathItem* iItem : iSubPaths)
    {
        ChildCharBoxItem* iCharBoxItem = dynamic_cast<ChildCharBoxItem*>(iItem);
        if (iCharBoxItem)
        {
            iCharBoxs.push_back(iCharBoxItem);
        }
    }

    if (!iCharBoxs.empty())
    {
        const qreal iOldVal = iCharBoxs.front()->getCharRect().height();
        QString iText = tr("New Height");
        const qreal iNewVal = QInputDialog::getDouble(views().front(), iText, iText, iOldVal);
        if (iNewVal > 0.1)
        {
            for (ChildCharBoxItem* iCharBoxItem : iCharBoxs)
            {
                iCharBoxItem->setHeight(iNewVal);
            }
        }
    }
}

void CanvasScene::translateSelectedItems(const qreal dx, const qreal dy)
{
    QVector<ChildPathItem*> iSubPaths = getSelSubPaths(nullptr);
    if (!iSubPaths.empty())
    {
        for (ChildPathItem* iSubPath : iSubPaths)
        {
            iSubPath->moveBy(dx, dy);
        }
    }
}

QVector<ChildPathItem*> CanvasScene::getSelSubPaths(QGraphicsItem* item)
{
    QVector<ChildPathItem*> iSubPaths;
    if (item)
    {
        ChildPathItem* iSubItem = dynamic_cast<ChildPathItem*>(item);
        if (iSubItem)
        {
            iSubPaths.push_back(iSubItem);
        }
        else
        {
            iSubItem = dynamic_cast<ChildPathItem*>(item->parentItem());
            if (iSubItem)
            {
                iSubPaths.push_back(iSubItem);
            }
        }
    }

    const QList<QGraphicsItem*> iSelItems = selectedItems();
    for (QGraphicsItem* iSelItem : iSelItems)
    {
        ChildPathItem* iSubItem = dynamic_cast<ChildPathItem*>(iSelItem);
        if (iSubItem)
        {
            iSubPaths.push_back(iSubItem);
        }
        else
        {
            iSubItem = dynamic_cast<ChildPathItem*>(iSelItem->parentItem());
            if (iSubItem)
            {
                iSubPaths.push_back(iSubItem);
            }
        }
    }

    std::sort(iSubPaths.begin(), iSubPaths.end());
    auto newEndIt = std::unique(iSubPaths.begin(), iSubPaths.end());
    iSubPaths.erase(newEndIt, iSubPaths.end());

    return iSubPaths;
}

QVector<ChildPathItem*> CanvasScene::getAllSubPaths()
{
    QVector<ChildPathItem*> iSubPaths;
    const QList<QGraphicsItem*> iItems = items();
    for (QGraphicsItem* iItem : iItems)
    {
        ChildPathItem* iSubItem = dynamic_cast<ChildPathItem*>(iItem);
        if (iSubItem)
        {
            iSubPaths.push_back(iSubItem);
        }
    }

    std::sort(iSubPaths.begin(), iSubPaths.end());
    auto newEndIt = std::unique(iSubPaths.begin(), iSubPaths.end());
    iSubPaths.erase(newEndIt, iSubPaths.end());

    return iSubPaths;
}

void CanvasScene::updateRegionItem() const
{
    RegionItem* iRgnItem = findRegionItem();
    if (iRgnItem)
    {
        iRgnItem->updatePath();
    }
}

RegionItem* CanvasScene::findRegionItem() const
{
    const QList<QGraphicsItem*> iAllItems = items();
    for (QGraphicsItem* item : iAllItems)
    {
        RegionItem* iRgnItem = dynamic_cast<RegionItem *>(item);
        if (iRgnItem)
        {
            return iRgnItem;
        }
    }

    return nullptr;
}
