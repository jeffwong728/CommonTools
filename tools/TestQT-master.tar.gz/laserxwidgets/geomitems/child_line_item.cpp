#include "child_line_item.h"
#include "region_item.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>

ChildLineItem::ChildLineItem(QGraphicsItem* parent)
    : ChildPathItem(parent), mVertices(2)
{
    mHandles.resize(2);
    int id = 0;
    for (auto& handle : mHandles)
    {
        handle = new HandleItem(id++, this);
        handle->setVisible(false);
        handle->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
    }

    mInfoItem = new QGraphicsTextItem(this);
    mInfoItem->setTextInteractionFlags(Qt::NoTextInteraction);
    mInfoItem->setDefaultTextColor(Qt::red);
    mInfoItem->setScale(1.0);
    mInfoItem->setZValue(10);

    setAcceptHoverEvents(true);
}

ChildLineItem::~ChildLineItem()
{
}

ChildLineItem* ChildLineItem::create(QGraphicsItem* parent, const QJsonObject& data)
{
    if (!data.contains(QStringLiteral("vertices")))
    {
        return nullptr;
    }

    QJsonValue val = data.value(QStringLiteral("vertices"));
    if (!val.isArray())
    {
        return nullptr;
    }

    QJsonArray vertices = val.toArray();
    if (2 != vertices.count())
    {
        return nullptr;
    }

    ChildLineItem* item = new ChildLineItem(parent);
    item->setReversed(data.value(QStringLiteral("Reversed")).toBool());
    item->mVertices.clear();
    for (const auto& vertex : vertices)
    {
        item->mVertices.push_back(fromJson(vertex, QPointF()));
    }

    item->updatePath();
    item->updateHandleRects();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

bool ChildLineItem::empty() const
{
    const qreal iLen = distanceSq(mVertices.at(0), mVertices.at(1));
    return iLen < 1.;
}

void ChildLineItem::buildSubPath(QPainterPath& path) const
{
    Q_UNUSED(path);
}

void ChildLineItem::onMousePress(const QPointF& pos)
{
    mVertices[0] = pos;
    mVertices[1] = pos;
    updateHandleRects();
}

void ChildLineItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    mVertices[0] = anchorPos;
    mVertices[1] = pos;
    updateHandleRects();
    updatePath();
}

void ChildLineItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
    onMouseMove(pos, anchorPos);
}

QJsonObject ChildLineItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = ChildPathItem::getData(mImageItem);
    QJsonArray vertices;
    for (const auto& vertex : mVertices)
    {
        vertices.push_back(toJson(vertex + pos()));
    }
    obj[QStringLiteral("vertices")] = vertices;
    return obj;
}

void ChildLineItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    Q_UNUSED(widget);

    if (option->state & QStyle::State_MouseOver)
    {
        painter->setBrush(Qt::NoBrush);
        painter->setPen(QPen(Qt::magenta));
        painter->drawLine(mVertices[0], mVertices[1]);
    }
    else
    {
        painter->setPen(pen());
        painter->setBrush(brush());
        painter->drawLine(mVertices[0], mVertices[1]);
    }
}

void ChildLineItem::updatePath()
{
    if (!empty())
    {
        QPainterPath iPath;
        iPath.moveTo(mVertices[0]);
        iPath.lineTo(mVertices[1]);
        iPath.closeSubpath();

        QPen iPen = pen();
        iPen.setWidth(3);
        QPainterPath nPath = qt_graphicsItem_shapeFromPath(iPath, iPen);
        setPath(nPath);
    }
}

void ChildLineItem::updateHandleRects()
{
    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);

    mHandles[0]->setRect(QRectF(mVertices.at(0) + o, s));
    mHandles[1]->setRect(QRectF(mVertices.at(1) + o, s));
    updateInfoLabel();
}

void ChildLineItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    const QPointF dXY = e->pos() - e->lastPos();
    switch (handleId)
    {
    case 0: mVertices[0] += dXY; break;
    case 1: mVertices[1] += dXY; break;
    default: break;
    }

    updateHandleRects();
    updatePath();

    RegionItem* iRgnItem = dynamic_cast<RegionItem*>(parentItem());
    if (iRgnItem)
    {
        iRgnItem->updatePath();
    }
}

void ChildLineItem::updateInfoLabel()
{
    QLineF iLine(mVertices[0], mVertices[1]);
    mInfoItem->setPos(((iLine.p1() + iLine.p2()) / 2));
    const qreal a = iLine.angle();
    if (a > 90 && a < 270)
    {
        mInfoItem->setRotation(180 - iLine.angle());
    }
    else
    {
        mInfoItem->setRotation(0 - iLine.angle());
    }
    mInfoItem->setPlainText(QStringLiteral("%1pix : %2deg").arg(iLine.length(), 0, 'f', 1).arg(iLine.angle(), 0, 'f', 1));
}
