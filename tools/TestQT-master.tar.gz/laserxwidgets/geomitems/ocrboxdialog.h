#ifndef OCRBOXDIALOG_H
#define OCRBOXDIALOG_H

#include <QtCore>
#include <QDialog>
#include "ui_ocrboxdialog.h"
class ChildCharBoxItem;
class QTreeWidgetItem;

class OCRBoxDialog : public QDialog, public Ui::OCRBoxDialog
{
    Q_OBJECT

public:
    explicit OCRBoxDialog(ChildCharBoxItem *item, QWidget *parent);
    ~OCRBoxDialog();

private slots:
    void on_treeWidgetLineStructure_customContextMenuRequested(const QPoint& pos);
    void on_treeWidgetLineStructure_itemDoubleClicked(QTreeWidgetItem* item, int column);

private:
    void addLineStructure();
    void deleteLineStructure();

public:
    QJsonArray getLineStructures() const;
    QString getName() const;
    int getOrder() const;
};

#endif // OCRBOXDIALOG_H
