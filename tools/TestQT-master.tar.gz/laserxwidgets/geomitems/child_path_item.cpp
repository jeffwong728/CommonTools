#include "child_path_item.h"
#include "region_item.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <2geom.h>
#include <laser_x_util.h>

ChildPathItem::ChildPathItem(QGraphicsItem* parent)
    : QGraphicsPathItem(parent)
{
    QPen pen(Qt::blue);
    pen.setCosmetic(true);
    pen.setWidth(1);
    setPen(pen);

    setFlag(QGraphicsItem::ItemSendsGeometryChanges);
}

ChildPathItem::~ChildPathItem()
{
}

bool ChildPathItem::isValidData(const QJsonObject& data)
{
    return true;
}

void ChildPathItem::setData(ChildPathItem* item, const QJsonObject& data)
{
    item->mReversed = fromJson(data, QLatin1String("Reversed"), false);
}

void ChildPathItem::setReversed(const bool reversed)
{
    if (mReversed != reversed)
    {
        mReversed = reversed;
    }
}

void ChildPathItem::toggleReversed()
{
    mReversed = !mReversed;
}

#pragma warning( push )
#pragma warning( disable : 26812 )
QVariant ChildPathItem::itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant& value)
#pragma warning( pop )
{
    if (change == QGraphicsItem::ItemPositionHasChanged)
    {
        RegionItem *iRgnItem = dynamic_cast<RegionItem*>(parentItem());
        if (iRgnItem)
        {
            iRgnItem->updatePath();
        }
    }

    if (change == QGraphicsItem::ItemSelectedChange)
    {
        for (HandleItem* hand : mHandles)
        {
            hand->setVisible(value.toBool());
        }
    }

    return QGraphicsItem::itemChange(change, value);
}

QPainterPath ChildPathItem::qt_graphicsItem_shapeFromPath(const QPainterPath& path, const QPen& pen)
{
    // We unfortunately need this hack as QPainterPathStroker will set a width of 1.0
    // if we pass a value of 0.0 to QPainterPathStroker::setWidth()
    const qreal penWidthZero = qreal(0.00000001);

    if (path == QPainterPath() || pen == Qt::NoPen)
        return path;
    QPainterPathStroker ps;
    ps.setCapStyle(pen.capStyle());
    if (pen.widthF() <= 0.0)
        ps.setWidth(penWidthZero);
    else
        ps.setWidth(pen.widthF());
    ps.setJoinStyle(pen.joinStyle());
    ps.setMiterLimit(pen.miterLimit());
    QPainterPath p = ps.createStroke(path);
    p.addPath(path);
    return p;
}

QPolygonF ChildPathItem::arrow(const QPointF& start_point, const QPointF& end_point, const qreal head_size)
{
    QPolygonF iPolygon;
    if (head_size < 3)
    {
        return iPolygon;
    }

    Geom::Point sPt(start_point.x(), start_point.y());
    Geom::Point ePt(end_point.x(), end_point.y());
    Geom::Coord arrowLen = Geom::distance(sPt, ePt);
    if (arrowLen < head_size)
    {
        return iPolygon;
    }

    Geom::Point arrowBase = Geom::lerp(head_size / arrowLen, ePt, sPt);
    Geom::Point tPt = arrowBase + Geom::rot90(ePt - arrowBase);
    Geom::Point rPt = Geom::lerp(0.618, tPt, arrowBase);
    Geom::Point lPt = Geom::lerp(2, rPt, arrowBase);

    iPolygon << QPointF(ePt.x(), ePt.y()) << QPointF(rPt.x(), rPt.y()) << QPointF(lPt.x(), lPt.y());
    return iPolygon;
}

void ChildPathItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
}

void ChildPathItem::onMouseDoubleClick(const QPointF& pos)
{
}

QJsonObject ChildPathItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj;
    obj[QStringLiteral("Reversed")] = mReversed;
    return obj;
}

void ChildPathItem::updateMeasure(const bool fitting)
{
    Q_UNUSED(fitting);
}

void ChildPathItem::setWidth(const qreal nVal)
{
    Q_UNUSED(nVal);
}

void ChildPathItem::setHeight(const qreal nVal)
{
    Q_UNUSED(nVal);
}
