#ifndef REFERENCE_POINT_H
#define REFERENCE_POINT_H
#include <boost/signals2.hpp>
#include <QGraphicsEllipseItem>
class QGraphicsDropShadowEffect;

class ReferencePoint : public QGraphicsEllipseItem
{
public:
    explicit ReferencePoint(QGraphicsItem* parent);

public:
    void applyHighlight();
    void removeHighlight();

public:
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget = nullptr) override;

protected:
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent* event) override;
    void hoverMoveEvent(QGraphicsSceneHoverEvent* event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent* event) override;
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event) override;

private:
    Q_DISABLE_COPY_MOVE(ReferencePoint)

private:
    QGraphicsLineItem* mHLine = nullptr;
    QGraphicsLineItem* mVLine = nullptr;
    QGraphicsDropShadowEffect* mEffect = nullptr;
};

#endif // REFERENCE_POINT_H
