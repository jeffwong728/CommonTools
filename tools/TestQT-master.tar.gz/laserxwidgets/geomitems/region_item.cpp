#include "region_item.h"
#include "child_rect_item.h"
#include "child_polygon_item.h"
#include "child_ellipse_item.h"
#include <QtCore>
#include <QtGui>

RegionItem::RegionItem()
{
    QPen pen(Qt::transparent);
    pen.setCosmetic(true);
    pen.setWidth(1);
    setPen(pen);
    setBrush(QBrush(QColor(255, 140, 0, 64)));
}

RegionItem::~RegionItem()
{
}

void RegionItem::updatePath()
{
    QList<QGraphicsItem*> subItems = childItems();
    QPainterPath iPath;
    iPath.setFillRule(Qt::WindingFill);
    for (QGraphicsItem* item : subItems)
    {
        ChildPathItem* subPathItem = dynamic_cast<ChildPathItem*>(item);
        if (subPathItem)
        {
            subPathItem->buildSubPath(iPath);
        }
    }

    setPath(iPath);
}
