#include "child_ellipse_item.h"
#include "region_item.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>

ChildEllipseItem::ChildEllipseItem(QGraphicsItem* parent)
    : ChildPathItem(parent), mVertices(4)
{
    mHandles.resize(8);
    int id = 0;
    for (auto& handle : mHandles)
    {
        handle = new HandleItem(id++, this);
        handle->setVisible(false);
        handle->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
    }
}

ChildEllipseItem::~ChildEllipseItem()
{
}

ChildEllipseItem* ChildEllipseItem::create(QGraphicsItem* parent, const QJsonObject& data)
{
    if (!data.contains(QStringLiteral("vertices")))
    {
        return nullptr;
    }

    QJsonValue val = data.value(QStringLiteral("vertices"));
    if (!val.isArray())
    {
        return nullptr;
    }

    QJsonArray vertices = val.toArray();
    if (4 != vertices.count())
    {
        return nullptr;
    }

    ChildEllipseItem* item = new ChildEllipseItem(parent);
    item->setReversed(data.value(QStringLiteral("Reversed")).toBool());
    item->mVertices.clear();
    for (const auto& vertex : vertices)
    {
        item->mVertices.push_back(fromJson(vertex, QPointF()));
    }

    item->updatePath();
    item->updateHandleRects();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

bool ChildEllipseItem::empty() const
{
    const qreal iWidth = distanceSq(mVertices.at(0), mVertices.at(1));
    const qreal iHeight = distanceSq(mVertices.at(0), mVertices.at(3));

    return !(iWidth > 0 || iHeight > 0);
}

void ChildEllipseItem::buildSubPath(QPainterPath& path) const
{
    QPointF iTopLeft = mVertices.at(0) + pos();
    QPointF iRightCenter = (mVertices.at(1) + mVertices.at(2)) / 2 + pos();
    const qreal iWidth = distance(mVertices.at(0), mVertices.at(1));
    const qreal iHeight = distance(mVertices.at(0), mVertices.at(3));

    if (iWidth > 0 && iHeight > 0)
    {
        path.moveTo(iRightCenter);
        if (mReversed)
        {
            path.arcTo(iTopLeft.x(), iTopLeft.y(), iWidth, iHeight, 0, -360);
        }
        else
        {
            path.arcTo(iTopLeft.x(), iTopLeft.y(), iWidth, iHeight, 0, 360);
        }
        path.closeSubpath();
    }
}

void ChildEllipseItem::onMousePress(const QPointF& pos)
{
    mVertices[0] = pos;
    mVertices[1] = pos;
    mVertices[2] = pos;
    mVertices[3] = pos;
    updateHandleRects();
}

void ChildEllipseItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    QRectF iRect(anchorPos, pos);
    QRectF nRect = iRect.normalized();
    mVertices[0] = nRect.topLeft();
    mVertices[1] = nRect.topRight();
    mVertices[2] = nRect.bottomRight();
    mVertices[3] = nRect.bottomLeft();
    updateHandleRects();

    QPointF iTopLeft = mVertices.at(0);
    QPointF iRightCenter = (mVertices.at(1) + mVertices.at(2)) / 2;
    const qreal iWidth = distance(mVertices.at(0), mVertices.at(1));
    const qreal iHeight = distance(mVertices.at(0), mVertices.at(3));

    if (iWidth > 0 && iHeight > 0)
    {
        QPainterPath iPath;
        iPath.moveTo(iRightCenter);
        iPath.arcTo(iTopLeft.x(), iTopLeft.y(), iWidth, iHeight, 0, 360);
        iPath.closeSubpath();
        setPath(iPath);
    }
}

void ChildEllipseItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
    onMouseMove(pos, anchorPos);
}

QJsonObject ChildEllipseItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = ChildPathItem::getData(mImageItem);
    QJsonArray vertices;
    for (const auto& vertex : mVertices)
    {
        vertices.push_back(toJson(vertex + pos()));
    }
    obj[QStringLiteral("vertices")] = vertices;
    return obj;
}

void ChildEllipseItem::updatePath()
{
    QPointF iTopLeft = mVertices.at(0);
    QPointF iRightCenter = (mVertices.at(1) + mVertices.at(2)) / 2;
    const qreal iWidth = distance(mVertices.at(0), mVertices.at(1));
    const qreal iHeight = distance(mVertices.at(0), mVertices.at(3));

    if (iWidth > 0 && iHeight > 0)
    {
        QPainterPath iPath;
        iPath.moveTo(iRightCenter);
        iPath.arcTo(iTopLeft.x(), iTopLeft.y(), iWidth, iHeight, 0, 360);
        iPath.closeSubpath();
        setPath(iPath);
    }
}

void ChildEllipseItem::updateHandleRects()
{
    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);

    mHandles[0]->setRect(QRectF(mVertices.at(0) + o, s));
    mHandles[1]->setRect(QRectF((mVertices.at(0) + mVertices.at(1)) / 2 + o, s));
    mHandles[2]->setRect(QRectF(mVertices.at(1) + o, s));
    mHandles[3]->setRect(QRectF((mVertices.at(1) + mVertices.at(2)) / 2 + o, s));
    mHandles[4]->setRect(QRectF(mVertices.at(2) + o, s));
    mHandles[5]->setRect(QRectF((mVertices.at(3) + mVertices.at(2)) / 2 + o, s));
    mHandles[6]->setRect(QRectF(mVertices.at(3) + o, s));
    mHandles[7]->setRect(QRectF((mVertices.at(3) + mVertices.at(0)) / 2 + o, s));
}

void ChildEllipseItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    const QPointF dXY = e->pos() - e->lastPos();
    QRectF newRect(mVertices.at(0), mVertices.at(2));

    switch (handleId)
    {
    case 0: newRect.setLeft(newRect.left() + dXY.x()); newRect.setTop(newRect.top() + dXY.y()); break;
    case 1: newRect.setTop(newRect.top() + dXY.y()); break;
    case 2: newRect.setRight(newRect.right() + dXY.x()); newRect.setTop(newRect.top() + dXY.y()); break;
    case 3: newRect.setRight(newRect.right() + dXY.x()); break;
    case 4: newRect.setRight(newRect.right() + dXY.x()); newRect.setBottom(newRect.bottom() + dXY.y()); break;
    case 5: newRect.setBottom(newRect.bottom() + dXY.y()); break;
    case 6: newRect.setBottom(newRect.bottom() + dXY.y()); newRect.setLeft(newRect.left() + dXY.x()); break;
    case 7: newRect.setLeft(newRect.left() + dXY.x()); break;
    default: break;
    }

    QRectF nRect = newRect.normalized();
    mVertices[0] = nRect.topLeft();
    mVertices[1] = nRect.topRight();
    mVertices[2] = nRect.bottomRight();
    mVertices[3] = nRect.bottomLeft();
    updateHandleRects();

    QPointF iTopLeft = mVertices.at(0);
    QPointF iRightCenter = (mVertices.at(1) + mVertices.at(2)) / 2;
    const qreal iWidth = distance(mVertices.at(0), mVertices.at(1));
    const qreal iHeight = distance(mVertices.at(0), mVertices.at(3));

    if (iWidth > 0 && iHeight > 0)
    {
        QPainterPath iPath;
        iPath.moveTo(iRightCenter);
        iPath.arcTo(iTopLeft.x(), iTopLeft.y(), iWidth, iHeight, 0, 360);
        iPath.closeSubpath();
        setPath(iPath);
    }

    RegionItem* iRgnItem = dynamic_cast<RegionItem*>(parentItem());
    if (iRgnItem)
    {
        iRgnItem->updatePath();
    }
}
