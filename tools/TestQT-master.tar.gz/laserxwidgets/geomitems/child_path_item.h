#ifndef CHILD_PATH_ITEM_H
#define CHILD_PATH_ITEM_H
#include "handle_item.h"
#include <QGraphicsPathItem>
class QMouseEvent;

class ChildPathItem : public QGraphicsPathItem
{
public:
    explicit ChildPathItem(QGraphicsItem* parent);
    ~ChildPathItem();

    static bool isValidData(const QJsonObject& data);
    static void setData(ChildPathItem* item, const QJsonObject& data);

public:
    bool reversed() const { return mReversed; }
    virtual void setReversed(const bool reversed);
    virtual void toggleReversed();

public:
    virtual bool empty() const = 0;
    virtual void buildSubPath(QPainterPath &path) const = 0;
    virtual void onMousePress(const QPointF &pos) = 0;
    virtual void onMouseMove(const QPointF& pos, const QPointF& anchorPos) = 0;
    virtual void onMouseRelease(const QPointF& pos, const QPointF& anchorPos);
    virtual void onMouseDoubleClick(const QPointF& pos);
    virtual QJsonObject getData(QGraphicsPixmapItem* mImageItem) const;
    virtual void updateMeasure(const bool fitting);
    virtual void setWidth(const qreal nVal);
    virtual void setHeight(const qreal nVal);

protected:
    QVariant itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant& value) override;

protected:
    static QPainterPath qt_graphicsItem_shapeFromPath(const QPainterPath& path, const QPen& pen);
    static QPolygonF arrow(const QPointF& start_point, const QPointF& end_point, const qreal head_size);

private:
    Q_DISABLE_COPY_MOVE(ChildPathItem)

protected:
    QVector<HandleItem*> mHandles;
    QGraphicsLineItem* mHCrossLine = nullptr;
    QGraphicsLineItem* mVCrossLine = nullptr;
    bool mReversed = false;
};

#endif // CHILD_PATH_ITEM_H
