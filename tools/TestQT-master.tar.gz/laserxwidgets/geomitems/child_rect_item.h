#ifndef CHILD_RECT_ITEM_H
#define CHILD_RECT_ITEM_H
#include "child_path_item.h"

class ChildRectItem : public ChildPathItem
{
public:
    explicit ChildRectItem(QGraphicsItem* parent);
    ~ChildRectItem();

    static ChildRectItem *create(QGraphicsItem* parent, const QJsonObject &data);

public:
    bool empty() const override;
    void buildSubPath(QPainterPath& path) const override;
    void onMousePress(const QPointF& pos) override;
    void onMouseMove(const QPointF& pos, const QPointF& anchorPos) override;
    void onMouseRelease(const QPointF& pos, const QPointF& anchorPos) override;
    QJsonObject getData(QGraphicsPixmapItem* mImageItem) const override;

private:
    void updatePath();
    void updateHandles();
    void onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e);

private:
    Q_DISABLE_COPY_MOVE(ChildRectItem)

private:
    QPolygonF mVertices;
};

#endif // CHILD_RECT_ITEM_H
