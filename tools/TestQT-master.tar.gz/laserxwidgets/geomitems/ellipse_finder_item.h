#ifndef ELLIPSE_FINDER_ITEM_H
#define ELLIPSE_FINDER_ITEM_H
#include "geom_finder_item.h"

class EllipseFinderItem : public GeomFinderItem
{
public:
    explicit EllipseFinderItem(QGraphicsItem* parent, LaserXCanvasPrivate* iCanvasPrivate);
    ~EllipseFinderItem();
    int leftMouseClicked() const;

    static EllipseFinderItem* create(QGraphicsItem* parent, const QJsonObject &data, LaserXCanvasPrivate* iCanvasPrivate);

public:
    void setReversed(const bool reversed) override;
    void toggleReversed() override;
    bool empty() const override;
    void buildSubPath(QPainterPath& path) const override;
    void onMousePress(const QPointF& pos) override;
    void onMouseMove(const QPointF& pos, const QPointF& anchorPos) override;
    void onMouseRelease(const QPointF& pos, const QPointF& anchorPos) override;
    QJsonObject getData(QGraphicsPixmapItem* mImageItem) const override;
    void updateMeasure(const bool fitting) override;
    void updateInfoLabelPose() override;
    QPointF center() const override;

public:
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget = nullptr) override;

private:
    void updatePath();
    void updateHandleRects();
    void updateBoundaryBand();
    void onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e);

protected:
    QVariant itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant& value) override;

private:
    Q_DISABLE_COPY_MOVE(EllipseFinderItem)

private:
    const int mClicked = 0;
    QPolygonF mPoints;
    qreal mStartAngle = 0;
    qreal mSpanAngle = 360;
    QGraphicsPathItem* mBoundaryBand = nullptr;
};

#endif // ELLIPSE_FINDER_ITEM_H
