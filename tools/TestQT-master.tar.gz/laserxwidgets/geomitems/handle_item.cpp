#include "handle_item.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>

HandleItem::HandleItem(const int handleId, QGraphicsItem *parent)
    : HandleItem(handleId, RectShape, parent)
{
}

HandleItem::HandleItem(const int handleId, const int handleShape, QGraphicsItem* parent)
    : QGraphicsRectItem(parent)
    , mHandleId(handleId)
    , mHandleShape(handleShape)
{
    QPen pen(Qt::red);
    pen.setCosmetic(true);
    pen.setWidth(1);

    setPen(pen);
    setBrush(QBrush(Qt::NoBrush));
    setFlag(QGraphicsItem::ItemIsMovable);
    setAcceptHoverEvents(true);
    setZValue(11);
}

void HandleItem::setHandleId(const int handleId)
{
    if (handleId != mHandleId)
    {
        mHandleId = handleId;
    }
}

void HandleItem::applyHighlight()
{
    if (!mEffect)
    {
        mEffect = new QGraphicsDropShadowEffect();
        mEffect->setBlurRadius(10);
        mEffect->setOffset(0);
        mEffect->setColor(Qt::white);
        setGraphicsEffect(mEffect);
    }

    if (mEffect && !mEffect->isEnabled())
    {
        mEffect->setEnabled(true);
        sigApplyEffect();
    }
}

void HandleItem::removeHighlight()
{
    if (mEffect && mEffect->isEnabled())
    {
        mEffect->setEnabled(false);
    }
}

void HandleItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    Q_UNUSED(widget);

    if (option->state & QStyle::State_MouseOver)
    {
        QBrush myBrush(QColor(238, 188, 29, 128), Qt::SolidPattern);
        painter->setBrush(myBrush);
        painter->setPen(QPen(Qt::NoPen));
        painter->drawEllipse(rect().adjusted(-5, -5, 5, 5));
    }

    painter->setPen(pen());
    painter->setBrush(brush());

    if (RectShape == mHandleShape)
    {
        painter->drawRect(rect());
    }
    else
    {
        painter->drawEllipse(rect());
    }
}

void HandleItem::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    sigMoving(mHandleId, event);
}

void HandleItem::hoverEnterEvent(QGraphicsSceneHoverEvent* event)
{
    applyHighlight();
}

void HandleItem::hoverMoveEvent(QGraphicsSceneHoverEvent* event)
{
    applyHighlight();
}

void HandleItem::hoverLeaveEvent(QGraphicsSceneHoverEvent* event)
{
    removeHighlight();
}

void HandleItem::mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event)
{
    QGraphicsRectItem::mouseDoubleClickEvent(event);
}
