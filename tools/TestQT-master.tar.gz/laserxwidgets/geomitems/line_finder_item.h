#ifndef LINE_FINDER_ITEM_H
#define LINE_FINDER_ITEM_H
#include "geom_finder_item.h"

class LineFinderItem : public GeomFinderItem
{
public:
    explicit LineFinderItem(QGraphicsItem* parent, LaserXCanvasPrivate* iCanvasPrivate);
    ~LineFinderItem();

    static LineFinderItem* create(QGraphicsItem* parent, const QJsonObject &data, LaserXCanvasPrivate* iCanvasPrivate);

public:
    void setReversed(const bool reversed) override;
    void toggleReversed() override;
    bool empty() const override;
    void buildSubPath(QPainterPath& path) const override;
    void onMousePress(const QPointF& pos) override;
    void onMouseMove(const QPointF& pos, const QPointF& anchorPos) override;
    void onMouseRelease(const QPointF& pos, const QPointF& anchorPos) override;
    QJsonObject getData(QGraphicsPixmapItem* mImageItem) const override;
    void updateMeasure(const bool fitting) override;
    void updateInfoLabelPose() override;
    QPointF center() const override;

public:
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget = nullptr) override;

private:
    void updatePath();
    void updateHandleRects();
    void onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e);

protected:
    QVariant itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant& value) override;

private:
    Q_DISABLE_COPY_MOVE(LineFinderItem)

private:
    QLineF mLine;
    QGraphicsPolygonItem* mBoundaryBox = nullptr;
    QGraphicsPolygonItem* mDirItems[2] = { nullptr, nullptr };
};

#endif // LINE_FINDER_ITEM_H
