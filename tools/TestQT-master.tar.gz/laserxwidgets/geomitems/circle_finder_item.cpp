#include "circle_finder_item.h"
#include "region_item.h"
#include "laser_x_canvas_p.h"
#include <laser_x_measure_model.h>
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>
#include <2geom.h>
#include <2geom/circle.h>

CircleFinderItem::CircleFinderItem(QGraphicsItem* parent, LaserXCanvasPrivate* iCanvasPrivate)
    : GeomFinderItem(parent, QStringLiteral("Circle"), iCanvasPrivate)
{
    int id = 0;
    mHandles.resize(5);
    const std::array<int, 5> iHandleShapes{ HandleItem::CircleShape, HandleItem::CircleShape, HandleItem::RectShape, HandleItem::RectShape, HandleItem::RectShape };
    for (auto &handle : mHandles)
    {
        handle = new HandleItem(id, iHandleShapes[id], this);
        handle->setVisible(false);
        handle->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
        id += 1;
    }

    mBoundaryBox = new QGraphicsPathItem(this);
    QPen pen(Qt::darkYellow);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QColor iFillColor(Qt::darkYellow);
    iFillColor.setAlpha(64);
    mBoundaryBox->setPen(pen);
    mBoundaryBox->setBrush(QBrush(iFillColor));
    mBoundaryBox->setAcceptHoverEvents(false);
    mBoundaryBox->setZValue(0);
    mBoundaryBox->setVisible(false);
}

CircleFinderItem::~CircleFinderItem()
{
}

CircleFinderItem* CircleFinderItem::create(QGraphicsItem* parent, const QJsonObject& data, LaserXCanvasPrivate* iCanvasPrivate)
{
    if (!GeomFinderItem::isValidData(data))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Center")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Radius")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("StartAngle")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("SpanAngle")))
    {
        return nullptr;
    }

    CircleFinderItem* item = new CircleFinderItem(parent, iCanvasPrivate);
    GeomFinderItem::setData(item, data, QStringLiteral("Circle"));
    item->mCenter = fromJson(data, QLatin1String("Center"), QPointF());
    item->mRadius = fromJson(data, QLatin1String("Radius"), 10.0);
    item->mStartAngle = fromJson(data, QLatin1String("StartAngle"), 0.0);
    item->mSpanAngle = fromJson(data, QLatin1String("SpanAngle"), 360.0);

    item->updatePath();
    item->updateHandleRects();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

void CircleFinderItem::setReversed(const bool reversed)
{
    ChildPathItem::setReversed(reversed);
    updateHandleRects();
}

void CircleFinderItem::toggleReversed()
{
    ChildPathItem::toggleReversed();
    updateHandleRects();
}

bool CircleFinderItem::empty() const
{
    return mRadius < 2 || mSemiSearchLength < 2;
}

void CircleFinderItem::buildSubPath(QPainterPath& path) const
{
    Q_UNUSED(path);
}

void CircleFinderItem::onMousePress(const QPointF& pos)
{
    mDefinePoints[0] = pos;
    mDefinePoints[1] = pos;

    fitCircleByDefinePoints();
    updateHandleRects();
    updatePath();
}

void CircleFinderItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    Q_UNUSED(anchorPos);
    mDefinePoints[1] = pos;
    fitCircleByDefinePoints();
    updateHandleRects();
    updatePath();
}

void CircleFinderItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
    onMouseMove(pos, anchorPos);
}

QJsonObject CircleFinderItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = GeomFinderItem::getData(mImageItem);
    obj[QStringLiteral("Center")] = toJson(mCenter + pos());
    obj[QStringLiteral("Radius")] = mRadius;
    obj[QStringLiteral("StartAngle")] = mStartAngle;
    obj[QStringLiteral("SpanAngle")] = mSpanAngle;
    return obj;
}

void CircleFinderItem::updateMeasure(const bool fitting)
{
    mMeasureInfos.resize(0);
    qDeleteAll(mMeasureResultsItems);
    mMeasureResultsItems.resize(0);

    mMeasure = mCanvasPrivate->getMeasure();
    LXMeasureModel iMeasure = mMeasure.lock();
    if (iMeasure && !mCanvasPrivate->mMat.empty())
    {
        iMeasure->clearMeasure(mMeasureIndex);

        QVariantMap params;
        params[QStringLiteral("CenterPoint")] = mCenter + pos();
        params[QStringLiteral("Radius")] = mRadius;
        params[QStringLiteral("StartAngle")] = mStartAngle;
        params[QStringLiteral("EndAngle")] = mStartAngle + mSpanAngle;
        params[QStringLiteral("SemiSearchLength")] = mSemiSearchLength;
        params[QStringLiteral("SemiSmoothLength")] = mSemiSmoothLength;
        params[QStringLiteral("Sigma")] = mSigma;
        params[QStringLiteral("Threshold")] = mThreshold;
        params[QStringLiteral("NumSamplePoints")] = mNumSamplePoints;
        params[QStringLiteral("Select")] = mSelect;
        params[QStringLiteral("Transition")] = mTransition;
        params[QStringLiteral("MinScore")] = mMinScore;
        params[QStringLiteral("NumInstances")] = mNumInstances;
        mMeasureIndex = iMeasure->addCircleMeasure(params);
        iMeasure->applyMeasure(mCanvasPrivate->mMat);
        QVariantMap iResultEdges = iMeasure->getAllBoxEdges(mMeasureIndex);

        if (iResultEdges.contains(QStringLiteral("AllEdges")))
        {
            QPen pen(Qt::magenta);
            pen.setCosmetic(true);
            pen.setWidth(1);

            QVector<QPointF> iAllEdges = iResultEdges[QStringLiteral("AllEdges")].value<QVector<QPointF>>();
            for (const QPointF& iEdge : iAllEdges)
            {
                QGraphicsLineItem* iHLine = scene()->addLine(QLineF(iEdge + QPointF(-2, 0), iEdge + QPointF(2, 0)), pen);
                QGraphicsLineItem* iVLine = scene()->addLine(QLineF(iEdge + QPointF(0, -2), iEdge + QPointF(0, 2)), pen);
                iHLine->setParentItem(this);
                iVLine->setParentItem(this);
                iVLine->setPos(-pos());
                iHLine->setPos(-pos());
                mMeasureResultsItems.push_back(iHLine);
                mMeasureResultsItems.push_back(iVLine);
            }
        }

        qlonglong iNumInstances = iMeasure->getNumInstances(mMeasureIndex);
        if (1 == iNumInstances)
        {
            QVariant instance = 0;
            QVariantMap iResult = iMeasure->getMeasureResult(mMeasureIndex, instance);
            qreal iScore = iResult[QStringLiteral("Score")].toReal();
            QVector<QPointF> iUsedEdges = iResult[QStringLiteral("UsedEdges")].value<QVector<QPointF>>();
            QPointF iCenterPoint = iResult[QStringLiteral("CenterPoint")].toPointF();
            qreal iRadius = iResult[QStringLiteral("Radius")].toReal();

            mMeasureInfos.append(QStringLiteral("Center: x=%1, y=%2").arg(iCenterPoint.x(), 0, 'f', 3).arg(iCenterPoint.y(), 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Radius: %1").arg(iRadius, 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Score: %1").arg(iScore, 0, 'f', 3));

            QPen pen(Qt::green);
            pen.setCosmetic(true);
            pen.setWidth(1);
            for (const QPointF& iEdge : iUsedEdges)
            {
                QGraphicsLineItem* iHLine = scene()->addLine(QLineF(iEdge + QPointF(-2, 0), iEdge + QPointF(2, 0)), pen);
                QGraphicsLineItem* iVLine = scene()->addLine(QLineF(iEdge + QPointF(0, -2), iEdge + QPointF(0, 2)), pen);
                iHLine->setParentItem(this);
                iVLine->setParentItem(this);
                iVLine->setPos(-pos());
                iHLine->setPos(-pos());
                mMeasureResultsItems.push_back(iHLine);
                mMeasureResultsItems.push_back(iVLine);
            }

            pen.setWidth(2);
            QGraphicsEllipseItem* iResultEllipse = scene()->addEllipse(QRectF(iCenterPoint + QPointF(-iRadius, -iRadius), iCenterPoint + QPointF(iRadius, iRadius)), pen);
            iResultEllipse->setParentItem(this);
            iResultEllipse->setPos(-pos());
            mMeasureResultsItems.push_back(iResultEllipse);
        }
    }

    updateInfoLabel();
}

void CircleFinderItem::updateInfoLabelPose()
{
    QRectF iNameRect = mInfoItem->boundingRect();
    mInfoItem->setPos(mCenter + QPointF(-iNameRect.width() / 2, -iNameRect.height() / 2));
}

QPointF CircleFinderItem::center() const
{
    return mCenter + pos();
}

void CircleFinderItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    Q_UNUSED(widget);

    QRectF r;
    r.setTop(mCenter.y() - mRadius);
    r.setLeft(mCenter.x() - mRadius);
    r.setWidth(mRadius * 2);
    r.setHeight(mRadius * 2);

    int iStartAngle = qRound(mStartAngle * 16);
    int iSpanAngle = qRound(mSpanAngle * 16);

    if (option->state & QStyle::State_MouseOver)
    {
        painter->setBrush(Qt::NoBrush);
        painter->setPen(QPen(Qt::magenta));
        painter->drawArc(r, iStartAngle, iSpanAngle);
    }
    else
    {
        painter->setPen(pen());
        painter->setBrush(brush());
        painter->drawArc(r, iStartAngle, iSpanAngle);
    }
}

void CircleFinderItem::updatePath()
{
    QRectF r;
    r.setTop(mCenter.y() - mRadius);
    r.setLeft(mCenter.x() - mRadius);
    r.setWidth(mRadius * 2);
    r.setHeight(mRadius * 2);

    QPainterPath iPath;
    Geom::Point iCenter(mCenter.x(), mCenter.y());
    Geom::Circle iCircle(iCenter, mRadius);
    Geom::Point iStartPoint = iCircle.pointAt(Geom::rad_from_deg(-mStartAngle));
    iPath.moveTo(iStartPoint.x(), iStartPoint.y());
    iPath.arcTo(r, mStartAngle, mSpanAngle);
    iPath.arcTo(r, mStartAngle + mSpanAngle, -mSpanAngle);
    iPath.closeSubpath();
    QPen iPen = pen();
    iPen.setWidth(3);
    QPainterPath nPath = qt_graphicsItem_shapeFromPath(iPath, iPen);
    setPath(nPath);
}

void CircleFinderItem::updateHandleRects()
{
    Geom::Point iCenter(mCenter.x(), mCenter.y());
    qreal iInnerRadius = std::max(0., mRadius - mSemiSearchLength);
    qreal iOuterRadius = mRadius + mSemiSearchLength;
    Geom::Circle iCircle(iCenter, mRadius);
    Geom::Circle iOuterCircle(iCenter, iOuterRadius);
    Geom::Circle iInnerCircle(iCenter, iInnerRadius);
    Geom::Point iStartPoint = iCircle.pointAt(Geom::rad_from_deg(- mStartAngle));
    Geom::Point iMiddlePoint = iCircle.pointAt(Geom::rad_from_deg(- mStartAngle - mSpanAngle / 2));
    Geom::Point iInnerMiddlePoint = iInnerCircle.pointAt(Geom::rad_from_deg(- mStartAngle - mSpanAngle / 2));
    Geom::Point iOuterMiddlePoint = iOuterCircle.pointAt(Geom::rad_from_deg(- mStartAngle - mSpanAngle / 2));
    Geom::Point iEndPoint = iCircle.pointAt(Geom::rad_from_deg(- mStartAngle - mSpanAngle));

    updateInfoLabelPose();

    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);

    QPointF iSPt(iStartPoint.x(), iStartPoint.y());
    QPointF iEPt(iEndPoint.x(), iEndPoint.y());
    QPointF iMPt(iMiddlePoint.x(), iMiddlePoint.y());
    QPointF iInnerMPt(iInnerMiddlePoint.x(), iInnerMiddlePoint.y());
    QPointF iOuterMPt(iOuterMiddlePoint.x(), iOuterMiddlePoint.y());

    mHandles[0]->setRect(QRectF(iSPt + o, s));
    mHandles[1]->setRect(QRectF(iEPt + o, s));
    mHandles[2]->setRect(QRectF(iMPt + o, s));
    mHandles[3]->setRect(QRectF(iInnerMPt + o, s));
    mHandles[4]->setRect(QRectF(iOuterMPt + o, s));

    QPainterPath iPath;
    Geom::Point iOuterStartPoint = iOuterCircle.pointAt(Geom::rad_from_deg(-mStartAngle));
    Geom::Point iOuterEndPoint = iOuterCircle.pointAt(Geom::rad_from_deg(-mStartAngle - mSpanAngle));
    Geom::Point iInnerStartPoint = iInnerCircle.pointAt(Geom::rad_from_deg(-mStartAngle));
    Geom::Point iInnerEndPoint = iInnerCircle.pointAt(Geom::rad_from_deg(-mStartAngle - mSpanAngle));

    QRectF iInnerRect;
    iInnerRect.setTop(mCenter.y() - iInnerRadius);
    iInnerRect.setLeft(mCenter.x() - iInnerRadius);
    iInnerRect.setWidth(iInnerRadius * 2);
    iInnerRect.setHeight(iInnerRadius * 2);

    QRectF iOuterRect;
    iOuterRect.setTop(mCenter.y() - iOuterRadius);
    iOuterRect.setLeft(mCenter.x() - iOuterRadius);
    iOuterRect.setWidth(iOuterRadius * 2);
    iOuterRect.setHeight(iOuterRadius * 2);

    iPath.moveTo(iOuterStartPoint.x(), iOuterStartPoint.y());
    iPath.arcTo(iOuterRect, mStartAngle, mSpanAngle);
    iPath.lineTo(iInnerEndPoint.x(), iInnerEndPoint.y());
    iPath.arcTo(iInnerRect, mStartAngle + mSpanAngle, -mSpanAngle);
    iPath.closeSubpath();
    mBoundaryBox->setPath(iPath);
}

void CircleFinderItem::fitCircleByDefinePoints()
{
    std::vector<Geom::Point> iPoints;
    qDebug() << mDefinePoints;
    for (const QPointF &iPoint : mDefinePoints)
    {
        iPoints.emplace_back(iPoint.x(), iPoint.y());
    }
    Geom::Circle iCircle;
    if (iPoints.size() < 1)
    {
        mCenter.setX(0);
        mCenter.setY(0);
        mRadius = 0;
    }
    else
    {
        iCircle.fit(iPoints);
        mCenter.setX(iCircle.center().x());
        mCenter.setY(iCircle.center().y());
        mRadius = iCircle.radius();
    }
}

void CircleFinderItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    switch (handleId)
    {
    case 0:
    {
        const QPointF iPoint = e->pos();
        const Geom::Point iStartPoint(iPoint.x(), iPoint.y());
        const Geom::Point iCenter(mCenter.x(), mCenter.y());
        const Geom::Point iVector = iStartPoint - iCenter;
        const Geom::Coord iStartAngle = Geom::deg_from_rad(std::atan2(-iVector.y(), iVector.x()));
        qreal iEndAngle = mStartAngle + mSpanAngle;
        iEndAngle = iEndAngle > 360 ? (iEndAngle - 360) : iEndAngle;

        mStartAngle = iStartAngle < 0 ? (iStartAngle + 360) : iStartAngle;
        if (mStartAngle < iEndAngle)
        {
            mSpanAngle = iEndAngle - mStartAngle;
        }
        else
        {
            mSpanAngle = 360 + iEndAngle - mStartAngle;
        }
    }
    break;
    case 1:
    {
        const QPointF iPoint = e->pos();
        const Geom::Point iEndPoint(iPoint.x(), iPoint.y());
        const Geom::Point iCenter(mCenter.x(), mCenter.y());
        const Geom::Point iVector = iEndPoint - iCenter;
        Geom::Coord iEndAngle = Geom::deg_from_rad(std::atan2(-iVector.y(), iVector.x()));
        iEndAngle = iEndAngle < 0 ? (iEndAngle + 360) : iEndAngle;
        if (mStartAngle < iEndAngle)
        {
            mSpanAngle = iEndAngle - mStartAngle;
        }
        else
        {
            mSpanAngle = 360 + iEndAngle - mStartAngle;
        }
    }
    break;
    case 2:
    {
        const QPointF iPoint = e->pos();
        mRadius = distance(iPoint, mCenter);
    }
    break;
    case 3:
    {
        const QPointF iPoint = e->pos();
        const qreal iInnerRadius = distance(iPoint, mCenter);
        mSemiSearchLength = mRadius - iInnerRadius;
        mSemiSearchLength = std::max(mSemiSearchLength, 5.);
    }
    break;
    case 4:
    {
        const QPointF iPoint = e->pos();
        const qreal iOuterRadius = distance(iPoint, mCenter);
        mSemiSearchLength = iOuterRadius - mRadius;
        mSemiSearchLength = std::max(mSemiSearchLength, 5.);
    }
    break;
    default: break;
    }

    updateHandleRects();
    updatePath();
    updateMeasure(true);
}

#pragma warning( push )
#pragma warning( disable : 26812 )
QVariant CircleFinderItem::itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant& value)
#pragma warning( pop )
{
    if (change == QGraphicsItem::ItemSelectedChange)
    {
        mBoundaryBox->setVisible(value.toBool());
    }

    if (change == QGraphicsItem::ItemPositionChange)
    {
        updateMeasure(true);
    }

    return ChildPathItem::itemChange(change, value);
}
