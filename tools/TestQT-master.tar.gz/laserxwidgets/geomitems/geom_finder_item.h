#ifndef GEOM_FINDER_ITEM_H
#define GEOM_FINDER_ITEM_H
#include "child_path_item.h"
#include <laser_x_measure_model.h>
class LaserXCanvasPrivate;
constexpr qreal kMinSearchLength = 3.0;

class GeomFinderItem : public ChildPathItem
{
public:
    explicit GeomFinderItem(QGraphicsItem* parent, const QString& iName, LaserXCanvasPrivate* iCanvasPrivate);
    ~GeomFinderItem();

    static bool isValidData(const QJsonObject& data);
    static void setData(GeomFinderItem* item, const QJsonObject& data, const QString &defName);

public:
    QString name() const;
    void setName(const QString &newName);
    void updateInfoLabel();
    virtual void updateInfoLabelPose() = 0;

    qreal labelPosition() const;
    void setLabelPosition(const qreal newLabelPosition);

    qreal semiSmoothLength() const;
    void setSemiSmoothLength(const qreal newSemiSmoothLength);

    qreal sigma() const;
    void setSigma(const qreal newSigma);

    qreal threshold() const;
    void setThreshold(const qreal newThreshold);

    int numSamplePoints() const;
    void setNumSamplePoints(const int newNumSamplePoints);

    QString select() const;
    void setSelect(const QString &newSelect);

    QString transition() const;
    void setTransition(const QString& newTransition);

    virtual QPointF center() const = 0;

public:
    QJsonObject getData(QGraphicsPixmapItem* mImageItem) const override;

protected:
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event) override;

private:
    Q_DISABLE_COPY_MOVE(GeomFinderItem)

protected:
    QString mName;
    qreal mLabelPosition = 0.0;
    qreal mSemiSearchLength = 5.0;
    qreal mSemiSmoothLength = 3.0;
    qreal mSigma = 1.0;
    qreal mThreshold = 20.0;
    qreal mMinScore = 0.75;
    int mNumSamplePoints = 20;
    int mNumInstances = 1;
    QString mSelect;
    QString mTransition;
    QGraphicsTextItem* mInfoItem = nullptr;
    LaserXCanvasPrivate* mCanvasPrivate = nullptr;
    LXWMeasureModel mMeasure;
    QVariant mMeasureIndex;
    QVector<QGraphicsItem*> mMeasureResultsItems;
    QStringList mMeasureInfos;
};

#endif // GEOM_FINDER_ITEM_H
