#ifndef CHILD_CHAR_BOX_ITEM_H
#define CHILD_CHAR_BOX_ITEM_H
#include <QtCore>
#include "child_path_item.h"

class ChildCharBoxItem : public ChildPathItem
{
public:
    explicit ChildCharBoxItem(QGraphicsItem* parent);
    ~ChildCharBoxItem();

    static ChildCharBoxItem* create(QGraphicsItem* parent, const QJsonObject& data);

protected:
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event) override;

public:
    bool empty() const override;
    void buildSubPath(QPainterPath& path) const override;
    void onMousePress(const QPointF& pos) override;
    void onMouseMove(const QPointF& pos, const QPointF& anchorPos) override;
    void onMouseRelease(const QPointF& pos, const QPointF& anchorPos) override;
    QJsonObject getData(QGraphicsPixmapItem* mImageItem) const override;
    QString getChar() const;
    void setChar(const QString& nVal);
    QRectF getCharRect() const;
    void setWidth(const qreal nVal) override;
    void setHeight(const qreal nVal) override;

private:
    void updatePath();
    void updateHandles();
    void onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e);
    void updateInfoLabel();

private:
    Q_DISABLE_COPY_MOVE(ChildCharBoxItem)

public:
    QString mName;
    QJsonArray mLineStructures;
    QPolygonF mVertices;
    int mOrder = 0;
    QGraphicsTextItem* mCharItem = nullptr;
};

#endif // CHILD_CHAR_BOX_ITEM_H
