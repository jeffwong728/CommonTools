#include "child_char_box_item.h"
#include "region_item.h"
#include "ocrboxdialog.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>

ChildCharBoxItem::ChildCharBoxItem(QGraphicsItem* parent)
    : ChildPathItem(parent), mVertices(4), mName(QSL("*"))
{
    mHandles.resize(8);
    int id = 0;
    for (auto &handle : mHandles)
    {
        handle = new HandleItem(id++, this);
        handle->setVisible(false);
        handle->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
    }

    mCharItem = new QGraphicsTextItem(this);
    mCharItem->setTextInteractionFlags(Qt::NoTextInteraction);
    mCharItem->setDefaultTextColor(Qt::green);
    mCharItem->setScale(1.0);
    mCharItem->setZValue(10);
}

ChildCharBoxItem::~ChildCharBoxItem()
{
}

ChildCharBoxItem* ChildCharBoxItem::create(QGraphicsItem* parent, const QJsonObject& data)
{
    if (!data.contains(QSL("Rect")))
    {
        return nullptr;
    }

    ChildCharBoxItem* item = new ChildCharBoxItem(parent);
    ChildPathItem::setData(item, data);
    item->mName           = fromJson(data, QLatin1String("Name"), QSL("*"));
    item->mLineStructures = fromJson(data, QLatin1String("LineStructures"), QJsonArray());
    item->mOrder          = fromJson(data, QLatin1String("Order"), 0);
    QRectF iRect          = fromJson(data, QLatin1String("Rect"), QRectF());
    item->mVertices[0] = iRect.topLeft();
    item->mVertices[1] = iRect.topRight();
    item->mVertices[2] = iRect.bottomRight();
    item->mVertices[3] = iRect.bottomLeft();

    item->updatePath();
    item->updateHandles();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

void ChildCharBoxItem::mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event)
{
    QList<QGraphicsView*> iViews = scene()->views();
    OCRBoxDialog dlg(this, iViews.empty() ? nullptr : iViews.front());
    int iRet = dlg.exec();
    if (QDialog::Accepted == iRet)
    {
        setChar(dlg.getName());
        mLineStructures = dlg.getLineStructures();
        mOrder = dlg.getOrder();
    }
}

bool ChildCharBoxItem::empty() const
{
    const qreal iWidth = distanceSq(mVertices.at(0), mVertices.at(1));
    const qreal iHeight = distanceSq(mVertices.at(0), mVertices.at(3));

    return !(iWidth > 0 || iHeight > 0);
}

void ChildCharBoxItem::buildSubPath(QPainterPath& path) const
{
    Q_UNUSED(path);
}

void ChildCharBoxItem::onMousePress(const QPointF& pos)
{
    mVertices[0] = pos;
    mVertices[1] = pos;
    mVertices[2] = pos;
    mVertices[3] = pos;
    updateHandles();
}

void ChildCharBoxItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    QRectF iRect(anchorPos, pos);
    QRectF nRect = iRect.normalized();
    mVertices[0] = nRect.topLeft();
    mVertices[1] = nRect.topRight();
    mVertices[2] = nRect.bottomRight();
    mVertices[3] = nRect.bottomLeft();
    updateHandles();
    updatePath();
}

void ChildCharBoxItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
    onMouseMove(pos, anchorPos);
}

QJsonObject ChildCharBoxItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = ChildPathItem::getData(mImageItem);
    obj[QSL("Name")]       = mName;
    obj[QSL("Rect")]            = toJson(getCharRect());
    obj[QSL("LineStructures")]  = mLineStructures;
    obj[QSL("Order")]           = mOrder;

    return obj;
}

QString ChildCharBoxItem::getChar() const
{
    return mName;
}

void ChildCharBoxItem::setChar(const QString& nVal)
{
    if (nVal != mName)
    {
        mName = nVal;
        updateInfoLabel();
    }
}

QRectF ChildCharBoxItem::getCharRect() const
{
    QRectF iRect(mVertices[0] + pos(), mVertices[2] + pos());
    return iRect;
}

void ChildCharBoxItem::setWidth(const qreal nVal)
{
    QRectF nRect(mVertices[0], mVertices[2]);
    nRect.setWidth(nVal);
    mVertices[0] = nRect.topLeft();
    mVertices[1] = nRect.topRight();
    mVertices[2] = nRect.bottomRight();
    mVertices[3] = nRect.bottomLeft();
    updateHandles();
    updatePath();
}

void ChildCharBoxItem::setHeight(const qreal nVal)
{
    QRectF nRect(mVertices[0], mVertices[2]);
    nRect.setHeight(nVal);
    mVertices[0] = nRect.topLeft();
    mVertices[1] = nRect.topRight();
    mVertices[2] = nRect.bottomRight();
    mVertices[3] = nRect.bottomLeft();
    updateHandles();
    updatePath();
}

void ChildCharBoxItem::updatePath()
{
    QPainterPath iPath;
    iPath.moveTo(mVertices.at(0));
    iPath.lineTo(mVertices.at(1));
    iPath.lineTo(mVertices.at(2));
    iPath.lineTo(mVertices.at(3));
    iPath.closeSubpath();
    setPath(iPath);
}

void ChildCharBoxItem::updateHandles()
{
    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);

    mHandles[0]->setRect(QRectF(mVertices.at(0) + o, s));
    mHandles[1]->setRect(QRectF((mVertices.at(0) + mVertices.at(1)) / 2 + o, s));
    mHandles[2]->setRect(QRectF(mVertices.at(1) + o, s));
    mHandles[3]->setRect(QRectF((mVertices.at(1) + mVertices.at(2)) / 2 + o, s));
    mHandles[4]->setRect(QRectF(mVertices.at(2) + o, s));
    mHandles[5]->setRect(QRectF((mVertices.at(3) + mVertices.at(2)) / 2 + o, s));
    mHandles[6]->setRect(QRectF(mVertices.at(3) + o, s));
    mHandles[7]->setRect(QRectF((mVertices.at(3) + mVertices.at(0)) / 2 + o, s));
    updateInfoLabel();
}

void ChildCharBoxItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    const QPointF dXY = e->pos() - e->lastPos();
    QRectF newRect(mVertices.at(0), mVertices.at(2));

    switch (handleId)
    {
    case 0: newRect.setLeft(newRect.left() + dXY.x()); newRect.setTop(newRect.top() + dXY.y()); break;
    case 1: newRect.setTop(newRect.top() + dXY.y()); break;
    case 2: newRect.setRight(newRect.right() + dXY.x()); newRect.setTop(newRect.top() + dXY.y()); break;
    case 3: newRect.setRight(newRect.right() + dXY.x()); break;
    case 4: newRect.setRight(newRect.right() + dXY.x()); newRect.setBottom(newRect.bottom() + dXY.y()); break;
    case 5: newRect.setBottom(newRect.bottom() + dXY.y()); break;
    case 6: newRect.setBottom(newRect.bottom() + dXY.y()); newRect.setLeft(newRect.left() + dXY.x()); break;
    case 7: newRect.setLeft(newRect.left() + dXY.x()); break;
    default: break;
    }

    QRectF nRect = newRect.normalized();
    mVertices[0] = nRect.topLeft();
    mVertices[1] = nRect.topRight();
    mVertices[2] = nRect.bottomRight();
    mVertices[3] = nRect.bottomLeft();
    updateHandles();
    updatePath();
}

void ChildCharBoxItem::updateInfoLabel()
{
    QRectF iRect(mVertices[0], mVertices[2]);
    mCharItem->setPlainText(mName);
    mCharItem->adjustSize();
    QRectF iCharRect = mCharItem->boundingRect();
    mCharItem->setPos(iRect.left() + (iRect.width() - iCharRect.width())/2, iRect.bottom() + 3);
}
