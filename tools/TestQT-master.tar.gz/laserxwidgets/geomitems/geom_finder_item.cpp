#include "geom_finder_item.h"
#include "laser_x_canvas_p.h"
#include "geomfinderdialog.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>

GeomFinderItem::GeomFinderItem(QGraphicsItem* parent, const QString& iName, LaserXCanvasPrivate* iCanvasPrivate)
    : ChildPathItem(parent)
    , mName(iName)
    , mCanvasPrivate(iCanvasPrivate)
    , mSelect(QStringLiteral("first"))
    , mTransition(QStringLiteral("all"))
{
    mInfoItem = new QGraphicsTextItem(this);
    mInfoItem->setTextInteractionFlags(Qt::NoTextInteraction);
    mInfoItem->setDefaultTextColor(Qt::red);
    mInfoItem->setScale(1.0);
    mInfoItem->setZValue(10);

    setAcceptHoverEvents(true);
}

GeomFinderItem::~GeomFinderItem()
{
    LXMeasureModel iMeasure = mMeasure.lock();
    if (iMeasure && mMeasureIndex.isValid() && !mMeasureIndex.isNull())
    {
        iMeasure->clearMeasure(mMeasureIndex);
    }
}

bool GeomFinderItem::isValidData(const QJsonObject& data)
{
    if (!ChildPathItem::isValidData(data))
    {
        return false;
    }

    if (!data.contains(QStringLiteral("Name")))
    {
        return false;
    }

    if (!data.contains(QStringLiteral("SemiSearchLength")))
    {
        return false;
    }

    if (!data.contains(QStringLiteral("SemiSmoothLength")))
    {
        return false;
    }

    return true;
}

void GeomFinderItem::setData(GeomFinderItem* item, const QJsonObject& data, const QString& defName)
{
    ChildPathItem::setData(item, data);
    item->mName             = fromJson(data, QLatin1String("Name"), defName);
    item->mSemiSearchLength = fromJson(data, QLatin1String("SemiSearchLength"), 5.0);
    item->mSemiSmoothLength = fromJson(data, QLatin1String("SemiSmoothLength"), 3.0);
    item->mSigma            = fromJson(data, QLatin1String("Sigma"), 1.0);
    item->mThreshold        = fromJson(data, QLatin1String("Threshold"), 20.0);
    item->mMinScore         = fromJson(data, QLatin1String("MinScore"), 0.75);
    item->mNumSamplePoints  = fromJson(data, QLatin1String("NumSamplePoints"), 20);
    item->mSelect           = fromJson(data, QLatin1String("Select"), QStringLiteral("first"));
    item->mTransition       = fromJson(data, QLatin1String("Transition"), QStringLiteral("all"));
}

QString GeomFinderItem::name() const
{
    return mName;
}

void GeomFinderItem::setName(const QString& newName)
{
    if (mName != newName)
    {
        mName = newName;
        updateInfoLabel();
    }
}

void GeomFinderItem::updateInfoLabel()
{
    QString iHtml;
    iHtml.append(QStringLiteral("<span>Name: %1</span>").arg(mName));
    for (const QString& iMInfo : mMeasureInfos)
    {
        iHtml.append(QStringLiteral("<br/>"));
        iHtml.append(QStringLiteral("<span>%1</span>").arg(iMInfo));
    }
    mInfoItem->setHtml(iHtml);
    updateInfoLabelPose();
}

qreal GeomFinderItem::labelPosition() const
{
    return mLabelPosition;
}

void GeomFinderItem::setLabelPosition(const qreal newLabelPosition)
{
    if (mLabelPosition != newLabelPosition)
    {
        mLabelPosition = newLabelPosition;
        updateMeasure(true);
    }
}

qreal GeomFinderItem::semiSmoothLength() const
{
    return mSemiSmoothLength;
}

void GeomFinderItem::setSemiSmoothLength(const qreal newSemiSmoothLength)
{
    if (mSemiSmoothLength != newSemiSmoothLength)
    {
        mSemiSmoothLength = newSemiSmoothLength;
        updateMeasure(true);
    }
}

qreal GeomFinderItem::sigma() const
{
    return mSigma;
}

void GeomFinderItem::setSigma(const qreal newSigma)
{
    if (mSigma != newSigma)
    {
        mSigma = newSigma;
        updateMeasure(true);
    }
}

qreal GeomFinderItem::threshold() const
{
    return mThreshold;
}

void GeomFinderItem::setThreshold(const qreal newThreshold)
{
    if (mThreshold != newThreshold)
    {
        mThreshold = newThreshold;
        updateMeasure(true);
    }
}

int GeomFinderItem::numSamplePoints() const
{
    return mNumSamplePoints;
}

void GeomFinderItem::setNumSamplePoints(const int newNumSamplePoints)
{
    if (mNumSamplePoints != newNumSamplePoints)
    {
        mNumSamplePoints = newNumSamplePoints;
        updateMeasure(true);
    }
}

QString GeomFinderItem::select() const
{
    return mSelect;
}

void GeomFinderItem::setSelect(const QString& newSelect)
{
    if (mSelect != newSelect)
    {
        mSelect = newSelect;
        updateMeasure(true);
    }
}

QString GeomFinderItem::transition() const
{
    return mTransition;
}

void GeomFinderItem::setTransition(const QString& newTransition)
{
    if (mTransition != newTransition)
    {
        mTransition = newTransition;
        updateMeasure(true);
    }
}

QJsonObject GeomFinderItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = ChildPathItem::getData(mImageItem);
    obj[QStringLiteral("Name")] = mName;
    obj[QStringLiteral("SemiSearchLength")] = mSemiSearchLength;
    obj[QStringLiteral("SemiSmoothLength")] = mSemiSmoothLength;
    obj[QStringLiteral("Sigma")] = mSigma;
    obj[QStringLiteral("Threshold")] = mThreshold;
    obj[QStringLiteral("MinScore")] = mMinScore;
    obj[QStringLiteral("NumSamplePoints")] = mNumSamplePoints;
    obj[QStringLiteral("Select")] = mSelect;
    obj[QStringLiteral("Transition")] = mTransition;
    obj[QStringLiteral("MeasureIndex")] = mMeasureIndex.toLongLong();
    return obj;
}

void GeomFinderItem::mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event)
{
    QList<QGraphicsView*> iViews = scene()->views();
    GeomFinderDialog dlg(this, iViews.empty() ? nullptr : iViews.front());
    dlg.exec();
}
