#include "child_polygon_item.h"
#include "region_item.h"
#include <QtMath>
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>

ChildPolygonItem::ChildPolygonItem(QGraphicsItem* parent)
    : ChildPathItem(parent)
{
}

ChildPolygonItem::~ChildPolygonItem()
{
}

ChildPolygonItem* ChildPolygonItem::create(QGraphicsItem* parent, const QJsonObject& data)
{
    if (!data.contains(QStringLiteral("vertices")))
    {
        return nullptr;
    }

    QJsonValue val = data.value(QStringLiteral("vertices"));
    if (!val.isArray())
    {
        return nullptr;
    }

    QJsonArray vertices = val.toArray();
    if (vertices.count() < 2)
    {
        return nullptr;
    }

    ChildPolygonItem* item = new ChildPolygonItem(parent);
    item->setReversed(data.value(QStringLiteral("Reversed")).toBool());
    for (const auto& vertex : vertices)
    {
        item->mPolygon.push_back(fromJson(vertex, QPointF()));
    }

    item->updatePath();
    item->populateHandles();
    item->updateHandleRects();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

bool ChildPolygonItem::empty() const
{
    if (mPolygon.size() < 2)
    {
        return true;
    }
    else
    {
        for (qsizetype nn = 1; nn <= mPolygon.size(); ++nn)
        {
            if (distanceSq(mPolygon.at(nn - 1), mPolygon.at(nn == mPolygon.size() ? 0 : nn)) > 0)
            {
                return false;
            }
        }

        return false;
    }
}

void ChildPolygonItem::buildSubPath(QPainterPath& path) const
{
    if (mPolygon.size() > 1)
    {
        if (mReversed)
        {
            path.moveTo(mPolygon.at(0) + pos());
            for (qsizetype nn = mPolygon.size() - 1; nn > 0; --nn)
            {
                path.lineTo(mPolygon.at(nn) + pos());
            }
            path.closeSubpath();
        }
        else
        {
            path.moveTo(mPolygon.at(0) + pos());
            for (qsizetype nn = 1; nn < mPolygon.size(); ++nn)
            {
                path.lineTo(mPolygon.at(nn) + pos());
            }
            path.closeSubpath();
        }
    }
}

void ChildPolygonItem::onMousePress(const QPointF& pos)
{
    if (mPolygon.empty())
    {
        mPolygon.push_back(pos);
        mPolygon.push_back(pos);
    }
    else
    {
        mPolygon.push_back(pos);
    }
}

void ChildPolygonItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    if (!mPolygon.empty())
    {
        mPolygon.back() = pos;

        QPainterPath iPath;
        iPath.moveTo(mPolygon.at(0));
        for (qsizetype nn = 1; nn < mPolygon.size(); ++nn)
        {
            iPath.lineTo(mPolygon.at(nn));
        }
        setPath(iPath);
    }
}

void ChildPolygonItem::onMouseDoubleClick(const QPointF& pos)
{
    mPolygon.push_back(pos);
    auto newEndIt = std::unique(mPolygon.begin(), mPolygon.end());
    mPolygon.erase(newEndIt, mPolygon.end());

    if (!mPolygon.empty())
    {
        QPainterPath iPath;
        iPath.moveTo(mPolygon.at(0));
        for (qsizetype nn = 1; nn < mPolygon.size(); ++nn)
        {
            iPath.lineTo(mPolygon.at(nn));
        }
        iPath.closeSubpath();
        setPath(iPath);

        populateHandles();
        updateHandleRects();
    }
}

QJsonObject ChildPolygonItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = ChildPathItem::getData(mImageItem);
    QJsonArray vertices;
    for (const auto& vertex : mPolygon)
    {
        vertices.push_back(toJson(vertex + pos()));
    }
    obj[QStringLiteral("vertices")] = vertices;
    return obj;
}

void ChildPolygonItem::updatePath()
{
    if (!mPolygon.empty())
    {
        QPainterPath iPath;
        iPath.moveTo(mPolygon.at(0));
        for (qsizetype nn = 1; nn < mPolygon.size(); ++nn)
        {
            iPath.lineTo(mPolygon.at(nn));
        }
        iPath.closeSubpath();
        setPath(iPath);
    }
}

void ChildPolygonItem::populateHandles()
{
    mHandles.resize(mPolygon.size());
    for (qsizetype nn = 0; nn < mPolygon.size(); ++nn)
    {
        mHandles[nn] = new HandleItem(nn, this);
        mHandles[nn]->setVisible(false);
        mHandles[nn]->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
    }
}

void ChildPolygonItem::updateHandleRects()
{
    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);
    for (qsizetype nn = 0; nn < mPolygon.size(); ++nn)
    {
        const QPointF iPoint = mPolygon.at(nn);
        HandleItem *handle = mHandles.at(nn);
        handle->setRect(QRectF(iPoint+o, s));
        handle->setHandleId(nn);
    }
}

void ChildPolygonItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    const QPointF dXY = e->pos() - e->lastPos();
    if (handleId >= 0 && handleId < mPolygon.size())
    {
        mPolygon[handleId] += dXY;
    }
    updateHandleRects();

    if (!mPolygon.empty())
    {
        QPainterPath iPath;
        iPath.moveTo(mPolygon.at(0));
        for (qsizetype nn = 1; nn < mPolygon.size(); ++nn)
        {
            iPath.lineTo(mPolygon.at(nn));
        }
        iPath.closeSubpath();
        setPath(iPath);
    }

    RegionItem* iRgnItem = dynamic_cast<RegionItem*>(parentItem());
    if (iRgnItem)
    {
        iRgnItem->updatePath();
    }
}
