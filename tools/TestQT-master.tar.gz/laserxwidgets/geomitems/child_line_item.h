#ifndef CHILD_LINE_ITEM_H
#define CHILD_LINE_ITEM_H
#include "child_path_item.h"

class ChildLineItem : public ChildPathItem
{
public:
    explicit ChildLineItem(QGraphicsItem* parent);
    ~ChildLineItem();

    static ChildLineItem* create(QGraphicsItem* parent, const QJsonObject& data);

public:
    bool empty() const override;
    void buildSubPath(QPainterPath& path) const;
    void onMousePress(const QPointF& pos) override;
    void onMouseMove(const QPointF& pos, const QPointF& anchorPos) override;
    void onMouseRelease(const QPointF& pos, const QPointF& anchorPos) override;
    QJsonObject getData(QGraphicsPixmapItem* mImageItem) const override;

public:
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget = nullptr) override;

private:
    void updatePath();
    void updateHandleRects();
    void onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e);
    void updateInfoLabel();

private:
    Q_DISABLE_COPY_MOVE(ChildLineItem)

private:
    QPolygonF mVertices;
    QGraphicsTextItem* mInfoItem = nullptr;
};

#endif // CHILD_LINE_ITEM_H
