#include "ocrboxdialog.h"
#include "child_char_box_item.h"
#include <laser_x_util.h>
#include <QtWidgets>

OCRBoxDialog::OCRBoxDialog(ChildCharBoxItem* item, QWidget* parent) :
    QDialog(parent), Ui::OCRBoxDialog()
{
    setupUi(this);
    lineEditName->setText(item->mName);
    spinBoxOrder->setValue(item->mOrder);

    for (const QJsonValueRef &jLineStructure : item->mLineStructures)
    {
        const QJsonObject jObj = jLineStructure.toObject();
        const int iLineNumber = fromJson(jObj, QLatin1String("Number"), 0);
        const QString iLineStructure = fromJson(jObj, QLatin1String("Structure"), QSL(""));
        const qreal iMinGap = fromJson(jObj, QLatin1String("MinGap"), 0.8);

        QTreeWidgetItem* iNewItem = new QTreeWidgetItem(treeWidgetLineStructure);
        iNewItem->setText(0, QString::number(iLineNumber));
        iNewItem->setText(1, iLineStructure);
        iNewItem->setText(2, QString::number(iMinGap, 'f', 2));
        treeWidgetLineStructure->addTopLevelItem(iNewItem);
    }
}

OCRBoxDialog::~OCRBoxDialog()
{
}

void OCRBoxDialog::on_treeWidgetLineStructure_customContextMenuRequested(const QPoint& pos)
{
    QMenu iMenu;
    iMenu.addAction(tr("Add Line Structure"), this, &OCRBoxDialog::addLineStructure);
    if (!treeWidgetLineStructure->selectedItems().empty())
    {
        iMenu.addAction(tr("Delete Line Structure"), this, &OCRBoxDialog::deleteLineStructure);
    }

    QPoint globalPos = treeWidgetLineStructure->mapToGlobal(pos);
    globalPos.setY(globalPos.y() + treeWidgetLineStructure->header()->height());
    iMenu.exec(globalPos);
}

void OCRBoxDialog::on_treeWidgetLineStructure_itemDoubleClicked(QTreeWidgetItem* item, int column)
{
    if (!item)
    {
        return;
    }

    bool iOk = false;
    if (0 == column)
    {
        int nVal = QInputDialog::getInt(this, tr("Set Line Number"), tr("Line Number"), item->text(column).toInt(), 0, 999, 1, &iOk);
        if (iOk)
        {
            item->setText(column, QString::number(nVal));
        }
    }
    else if (1 == column)
    {
        QString nVal = QInputDialog::getText(this, tr("Set Line Structure"), tr("Line Structure"), QLineEdit::Normal, item->text(column), &iOk);
        if (iOk)
        {
            item->setText(column, nVal);
        }
    }
    else
    {
        qreal nVal = QInputDialog::getDouble(this, tr("Set Min Word Gap"), tr("Min Word Gap"), item->text(column).toDouble(), 0.5, 999.9, 2, &iOk, Qt::WindowFlags(), 0.05);
        if (iOk)
        {
            item->setText(column, QString::number(nVal, 'f', 2));
        }
    }
}

void OCRBoxDialog::addLineStructure()
{
    QTreeWidgetItem* iNewItem = new QTreeWidgetItem(treeWidgetLineStructure);
    iNewItem->setText(0, QSL("0"));
    iNewItem->setText(1, QSL("2 2"));
    iNewItem->setText(2, QSL("0.8"));
    treeWidgetLineStructure->addTopLevelItem(iNewItem);
}

void OCRBoxDialog::deleteLineStructure()
{
    qDeleteAll(treeWidgetLineStructure->selectedItems());
}

QJsonArray OCRBoxDialog::getLineStructures() const
{
    QJsonArray jArray;
    for (int nn = 0; nn < treeWidgetLineStructure->topLevelItemCount(); ++nn)
    {
        QJsonObject jObj;
        QTreeWidgetItem* item = treeWidgetLineStructure->topLevelItem(nn);
        jObj[QLatin1String("Number")] = item->text(0).toInt();
        jObj[QLatin1String("Structure")] = item->text(1);
        jObj[QLatin1String("MinGap")] = item->text(2).toDouble();
        jArray.push_back(jObj);
    }

    return jArray;
}

QString OCRBoxDialog::getName() const
{
    return lineEditName->text();
}

int OCRBoxDialog::getOrder() const
{
    return spinBoxOrder->value();
}
