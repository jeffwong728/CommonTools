#ifndef GEOMFINDERDIALOG_H
#define GEOMFINDERDIALOG_H

#include <QDialog>
class GeomFinderItem;

namespace Ui {
class GeomFinderDialog;
}

class GeomFinderDialog : public QDialog
{
    Q_OBJECT

public:
    explicit GeomFinderDialog(GeomFinderItem* geomFinder, QWidget *parent = nullptr);
    ~GeomFinderDialog();

private slots:
    void on_spinBoxSemiSmoothLength_valueChanged(int arg1);
    void on_doubleSpinBoxSigma_valueChanged(double arg1);
    void on_spinBoxThreshold_valueChanged(int arg1);
    void on_spinBoxNumSamplePoints_valueChanged(int arg1);
    void on_comboBoxSelect_currentIndexChanged(int index);
    void on_comboBoxTransition_currentIndexChanged(int index);
    void on_pushButtonClose_clicked();

private:
    Ui::GeomFinderDialog *ui;
    GeomFinderItem* mGeomFinder = nullptr;
};

#endif // GEOMFINDERDIALOG_H
