#include "reference_point.h"
#include "referencepointdialog.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>

ReferencePoint::ReferencePoint(QGraphicsItem *parent)
    : QGraphicsEllipseItem(parent)
{
    QPen rPen(Qt::red);
    rPen.setCosmetic(true);
    rPen.setWidth(1);

    setPen(rPen);
    setBrush(QBrush(Qt::NoBrush));
    setRect(QRectF(-10, -10, 21, 21));

    QPen gPen(Qt::green);
    gPen.setCosmetic(true);
    gPen.setWidth(1);
    mHLine = new QGraphicsLineItem(0, -15, 0, 15, this);
    mVLine = new QGraphicsLineItem(-15, 0, 15, 0, this);
    mHLine->setPen(gPen);
    mVLine->setPen(gPen);

    setVisible(false);
    setFlag(QGraphicsItem::ItemIsMovable);
    setAcceptHoverEvents(true);
    setZValue(20);
}

void ReferencePoint::applyHighlight()
{
    if (!mEffect)
    {
        mEffect = new QGraphicsDropShadowEffect();
        mEffect->setBlurRadius(10);
        mEffect->setOffset(0);
        mEffect->setColor(Qt::white);
        setGraphicsEffect(mEffect);
    }

    if (mEffect && !mEffect->isEnabled())
    {
        mEffect->setEnabled(true);
    }
}

void ReferencePoint::removeHighlight()
{
    if (mEffect && mEffect->isEnabled())
    {
        mEffect->setEnabled(false);
    }
}

void ReferencePoint::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    QGraphicsEllipseItem::paint(painter, option, widget);
}

void ReferencePoint::mouseMoveEvent(QGraphicsSceneMouseEvent *event)
{
    QGraphicsEllipseItem::mouseMoveEvent(event);
}

void ReferencePoint::hoverEnterEvent(QGraphicsSceneHoverEvent* event)
{
    applyHighlight();
}

void ReferencePoint::hoverMoveEvent(QGraphicsSceneHoverEvent* event)
{
    applyHighlight();
}

void ReferencePoint::hoverLeaveEvent(QGraphicsSceneHoverEvent* event)
{
    removeHighlight();
}

void ReferencePoint::mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event)
{
    QList<QGraphicsView*> iViews = scene()->views();
    ReferencePointDialog dlg(this, iViews.empty() ? nullptr : iViews.front());
    dlg.exec();
}
