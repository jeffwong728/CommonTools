#include "ellipse_finder_item.h"
#include "laser_x_canvas_p.h"
#include <laser_x_measure_model.h>
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>
#include <2geom.h>

EllipseFinderItem::EllipseFinderItem(QGraphicsItem* parent, LaserXCanvasPrivate* iCanvasPrivate)
    : GeomFinderItem(parent, QStringLiteral("Ellipse"), iCanvasPrivate)
{
    int id = 0;
    mHandles.resize(8);
    const std::array<int, 8> iHandleShapes =
    {
        HandleItem::CircleShape,
        HandleItem::CircleShape,
        HandleItem::RectShape,
        HandleItem::RectShape,
        HandleItem::RectShape,
        HandleItem::RectShape,
        HandleItem::RectShape,
        HandleItem::RectShape
    };

    for (auto &handle : mHandles)
    {
        handle = new HandleItem(id, iHandleShapes[id], this);
        handle->setVisible(false);
        handle->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
        id += 1;
    }

    mPoints.resize(4);
    mBoundaryBand = new QGraphicsPathItem(this);

    QPen pen(Qt::darkYellow);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QColor iFillColor(Qt::darkYellow);
    iFillColor.setAlpha(64);

    mBoundaryBand->setPen(pen);
    mBoundaryBand->setBrush(QBrush(iFillColor));
    mBoundaryBand->setAcceptHoverEvents(false);
    mBoundaryBand->setZValue(0);
    mBoundaryBand->setVisible(false);
}

EllipseFinderItem::~EllipseFinderItem()
{
}

int EllipseFinderItem::leftMouseClicked() const
{
    return mClicked;
}

EllipseFinderItem* EllipseFinderItem::create(QGraphicsItem* parent, const QJsonObject& data, LaserXCanvasPrivate* iCanvasPrivate)
{
    if (!GeomFinderItem::isValidData(data))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Point0")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Point1")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Point2")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Point3")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("StartAngle")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("SpanAngle")))
    {
        return nullptr;
    }

    EllipseFinderItem* item = new EllipseFinderItem(parent, iCanvasPrivate);
    GeomFinderItem::setData(item, data, QStringLiteral("Ellipse"));
    item->mPoints[0] = fromJson(data, QLatin1String("Point0"), QPointF());
    item->mPoints[1] = fromJson(data, QLatin1String("Point1"), QPointF());
    item->mPoints[2] = fromJson(data, QLatin1String("Point2"), QPointF());
    item->mPoints[3] = fromJson(data, QLatin1String("Point3"), QPointF());
    item->mStartAngle = fromJson(data, QLatin1String("StartAngle"), 0.0);
    item->mSpanAngle = fromJson(data, QLatin1String("SpanAngle"), 360.0);

    item->updatePath();
    item->updateHandleRects();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

void EllipseFinderItem::setReversed(const bool reversed)
{
    ChildPathItem::setReversed(reversed);
    updateHandleRects();
}

void EllipseFinderItem::toggleReversed()
{
    ChildPathItem::toggleReversed();
    updateHandleRects();
}

bool EllipseFinderItem::empty() const
{
    const qreal iLen1 = distanceSq(mPoints[0], mPoints[1]);
    const qreal iLen2 = distanceSq(mPoints[1], mPoints[2]);
    return iLen1 < 5 || iLen2 < 5;
}

void EllipseFinderItem::buildSubPath(QPainterPath& path) const
{
    Q_UNUSED(path);
}

void EllipseFinderItem::onMousePress(const QPointF& pos)
{
    if (0 == mClicked)
    {
        mPoints[0] = pos;
        mPoints[1] = pos;
        mPoints[2] = pos;
        mPoints[3] = pos;
    }
    else if (1 == mClicked)
    {
        mPoints[2] = pos;
        mPoints[3] = pos;
    }
    else
    {
        Geom::Point iPoint0(mPoints[0].x(), mPoints[0].y());
        Geom::Point iPoint3(mPoints[3].x(), mPoints[3].y());
        if (Geom::are_near(iPoint0, iPoint3))
        {
            QPointF iCenter = (mPoints[0] + mPoints[1]) / 2;
            mPoints[0] = iCenter * 2 - pos;
            mPoints[1] = pos;
            mPoints[2] = pos;
            mPoints[3] = iCenter * 2 - pos;
        }
        else
        {
            QPointF iP1 = (mPoints[0] + mPoints[1]) / 2;
            QPointF iP2 = (mPoints[3] + mPoints[2]) / 2;
            QLineF iLine(iP1, iP2);
            qreal iLen = distance(iP1, iP2);
            iLen = std::max(iLen, 0.1);
            qreal iDist = distance(pos, iLine);

            QPointF iPt0 = lerp(iDist / iLen,iLine.p1(), iLine.p2());
            QPointF iPt1 = lerp(iDist / iLen,iLine.p1(), iLine.p2());
            QPointF iPt2 = lerp(iDist / iLen,iLine.p2(), iLine.p1());
            QPointF iPt3 = lerp(iDist / iLen,iLine.p2(), iLine.p1());
            mPoints[0] = iLine.p1() + rrot90((iPt0 - iLine.p1()));
            mPoints[1] = iLine.p1() + rot90((iPt1 - iLine.p1()));
            mPoints[2] = iLine.p2() + rrot90((iPt2 - iLine.p2()));
            mPoints[3] = iLine.p2() + rot90((iPt3 - iLine.p2()));
        }
    }

    int &iClicked = const_cast<int &>(mClicked);
    iClicked += 1;

    updateHandleRects();
}

void EllipseFinderItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    if (1 == mClicked)
    {
        mPoints[2] = pos;
        mPoints[3] = pos;
    }
    else if (2 == mClicked)
    {
        Geom::Point iPoint0(mPoints[0].x(), mPoints[0].y());
        Geom::Point iPoint3(mPoints[3].x(), mPoints[3].y());
        if (Geom::are_near(iPoint0, iPoint3))
        {
            QPointF iCenter = (mPoints[0] + mPoints[1]) / 2;
            mPoints[0] = iCenter * 2 - pos;
            mPoints[1] = pos;
            mPoints[2] = pos;
            mPoints[3] = iCenter * 2 - pos;
        }
        else
        {
            QPointF iP1 = (mPoints[0] + mPoints[1]) / 2;
            QPointF iP2 = (mPoints[3] + mPoints[2]) / 2;
            QLineF iLine(iP1, iP2);
            qreal iLen = distance(iP1, iP2);
            iLen = std::max(iLen, 0.1);
            qreal iDist = distance(pos, iLine);

            QPointF iPt0 = lerp(iDist / iLen, iLine.p1(), iLine.p2());
            QPointF iPt1 = lerp(iDist / iLen, iLine.p1(), iLine.p2());
            QPointF iPt2 = lerp(iDist / iLen, iLine.p2(), iLine.p1());
            QPointF iPt3 = lerp(iDist / iLen, iLine.p2(), iLine.p1());
            mPoints[0] = iLine.p1() + rrot90((iPt0 - iLine.p1()));
            mPoints[1] = iLine.p1() + rot90((iPt1 - iLine.p1()));
            mPoints[2] = iLine.p2() + rrot90((iPt2 - iLine.p2()));
            mPoints[3] = iLine.p2() + rot90((iPt3 - iLine.p2()));
        }
    }
    else
    {
        // do nothing
    }
    updateHandleRects();
    updatePath();
}

void EllipseFinderItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
    onMouseMove(pos, anchorPos);
}

QJsonObject EllipseFinderItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = GeomFinderItem::getData(mImageItem);
    obj[QStringLiteral("Point0")] = toJson(mPoints[0] + pos());
    obj[QStringLiteral("Point1")] = toJson(mPoints[1] + pos());
    obj[QStringLiteral("Point2")] = toJson(mPoints[2] + pos());
    obj[QStringLiteral("Point3")] = toJson(mPoints[3] + pos());
    obj[QStringLiteral("StartAngle")] = mStartAngle;
    obj[QStringLiteral("SpanAngle")] = mSpanAngle;
    return obj;
}

void EllipseFinderItem::updateMeasure(const bool fitting)
{
    mMeasureInfos.resize(0);
    qDeleteAll(mMeasureResultsItems);
    mMeasureResultsItems.resize(0);

    mMeasure = mCanvasPrivate->getMeasure();
    LXMeasureModel iMeasure = mMeasure.lock();
    if (iMeasure && !mCanvasPrivate->mMat.empty())
    {
        iMeasure->clearMeasure(mMeasureIndex);
        const QPointF iCenter = (mPoints[0] + mPoints[2]) / 2;

        qreal iAngle = 0;
        qreal iSemiMajorAxis = 0;
        qreal iSemiMinorAxis = 0;
        const qreal iWidth = distance(mPoints[0], mPoints[3]);
        const qreal iHeight = distance(mPoints[0], mPoints[1]);
        if (iWidth > iHeight)
        {
            const QLineF iLine(mPoints[0], mPoints[3]);
            iAngle = iLine.angle();
            iSemiMajorAxis = iWidth / 2;
            iSemiMinorAxis = iHeight / 2;
        }
        else
        {
            const QLineF iLine(mPoints[0], mPoints[1]);
            iAngle = iLine.angle();
            iSemiMajorAxis = iHeight / 2;
            iSemiMinorAxis = iWidth / 2;
        }

        QVariantMap params;
        params[QStringLiteral("CenterPoint")] = iCenter + pos();
        params[QStringLiteral("Angle")] = iAngle;
        params[QStringLiteral("SemiMajorAxis")] = iSemiMajorAxis;
        params[QStringLiteral("SemiMinorAxis")] = iSemiMinorAxis;
        params[QStringLiteral("SemiSearchLength")] = mSemiSearchLength;
        params[QStringLiteral("SemiSmoothLength")] = mSemiSmoothLength;
        params[QStringLiteral("Sigma")] = mSigma;
        params[QStringLiteral("Threshold")] = mThreshold;
        params[QStringLiteral("NumSamplePoints")] = mNumSamplePoints;
        params[QStringLiteral("Select")] = mSelect;
        params[QStringLiteral("Transition")] = mTransition;
        params[QStringLiteral("MinScore")] = mMinScore;
        params[QStringLiteral("NumInstances")] = mNumInstances;
        mMeasureIndex = iMeasure->addEllipseMeasure(params);
        iMeasure->applyMeasure(mCanvasPrivate->mMat);
        QVariantMap iResultEdges = iMeasure->getAllBoxEdges(mMeasureIndex);

        if (iResultEdges.contains(QStringLiteral("AllEdges")))
        {
            QPen pen(Qt::magenta);
            pen.setCosmetic(true);
            pen.setWidth(1);

            QVector<QPointF> iAllEdges = iResultEdges[QStringLiteral("AllEdges")].value<QVector<QPointF>>();
            for (const QPointF& iEdge : iAllEdges)
            {
                QGraphicsLineItem* iHLine = scene()->addLine(QLineF(iEdge + QPointF(-2, 0), iEdge + QPointF(2, 0)), pen);
                QGraphicsLineItem* iVLine = scene()->addLine(QLineF(iEdge + QPointF(0, -2), iEdge + QPointF(0, 2)), pen);
                iHLine->setParentItem(this);
                iVLine->setParentItem(this);
                iVLine->setPos(-pos());
                iHLine->setPos(-pos());
                mMeasureResultsItems.push_back(iHLine);
                mMeasureResultsItems.push_back(iVLine);
            }
        }

        qlonglong iNumInstances = iMeasure->getNumInstances(mMeasureIndex);
        if (1 == iNumInstances)
        {
            QVariant instance = 0;
            QVariantMap iResult = iMeasure->getMeasureResult(mMeasureIndex, instance);
            qreal iScore = iResult[QStringLiteral("Score")].toReal();
            QVector<QPointF> iUsedEdges = iResult[QStringLiteral("UsedEdges")].value<QVector<QPointF>>();
            QPointF iCenterPoint = iResult[QStringLiteral("CenterPoint")].toPointF();
            qreal iAngle = iResult[QStringLiteral("Angle")].toReal();
            qreal iSemiMajorAxis = iResult[QStringLiteral("SemiMajorAxis")].toReal();
            qreal iSemiMinorAxis = iResult[QStringLiteral("SemiMinorAxis")].toReal();

            mMeasureInfos.append(QStringLiteral("Angle: %1").arg(iAngle, 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Center: x=%1, y=%2").arg(iCenterPoint.x(), 0, 'f', 3).arg(iCenterPoint.y(), 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Radius: x=%1, y=%2").arg(iSemiMajorAxis, 0, 'f', 3).arg(iSemiMinorAxis, 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Score: %1").arg(iScore, 0, 'f', 3));

            QPen pen(Qt::green);
            pen.setCosmetic(true);
            pen.setWidth(1);
            for (const QPointF& iEdge : iUsedEdges)
            {
                QGraphicsLineItem* iHLine = scene()->addLine(QLineF(iEdge + QPointF(-2, 0), iEdge + QPointF(2, 0)), pen);
                QGraphicsLineItem* iVLine = scene()->addLine(QLineF(iEdge + QPointF(0, -2), iEdge + QPointF(0, 2)), pen);
                iHLine->setParentItem(this);
                iVLine->setParentItem(this);
                iVLine->setPos(-pos());
                iHLine->setPos(-pos());
                mMeasureResultsItems.push_back(iHLine);
                mMeasureResultsItems.push_back(iVLine);
            }

            QTransform t;
            t.translate(iCenterPoint.x(), iCenterPoint.y());
            t.rotate(-iAngle);
            t.translate(-iCenterPoint.x(), -iCenterPoint.y());

            QPainterPath iPath;
            iPath.addEllipse(iCenterPoint, iSemiMajorAxis, iSemiMinorAxis);

            pen.setWidth(2);
            QGraphicsPathItem* iResultEllipse = scene()->addPath(t.map(iPath), pen);
            iResultEllipse->setParentItem(this);
            iResultEllipse->setPos(-pos());
            mMeasureResultsItems.push_back(iResultEllipse);
        }
    }

    updateInfoLabel();
}

void EllipseFinderItem::updateInfoLabelPose()
{
    QRectF iNameRect = mInfoItem->boundingRect();
    mInfoItem->setPos((mPoints[0] + mPoints[2]) / 2 + QPointF(-iNameRect.width() / 2, -iNameRect.height() / 2));
}

QPointF EllipseFinderItem::center() const
{
    return (mPoints[0] + mPoints[2]) / 2 + pos();
}

void EllipseFinderItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    Q_UNUSED(widget);

    const qreal iWidth = distance(mPoints[0], mPoints[3]);
    const qreal iHeight = distance(mPoints[0], mPoints[1]);
    const QPointF iCenter = (mPoints[0] + mPoints[2]) / 2;
    const QPointF iTopLeft = iCenter + QPointF(-iWidth/2, -iHeight/2);
    const QLineF iLine(mPoints[0], mPoints[3]);
    const qreal iAngle = -iLine.angle();
    QRectF iRect(iTopLeft, QSizeF(iWidth, iHeight));
    int iStartAngle = qRound(mStartAngle * 16);
    int iSpanAngle = qRound(mSpanAngle * 16);

    painter->save();
    painter->translate(iCenter.x(), iCenter.y());
    painter->rotate(iAngle);
    painter->translate(-iCenter.x(), -iCenter.y());

    if (option->state & QStyle::State_MouseOver)
    {
        painter->setBrush(QBrush(Qt::NoBrush));
        painter->setPen(QPen(Qt::magenta));
        painter->drawArc(iRect, iStartAngle, iSpanAngle);
    }
    else
    {
        painter->setPen(pen());
        painter->setBrush(QBrush(Qt::NoBrush));
        painter->drawArc(iRect, iStartAngle, iSpanAngle);
    }

    painter->restore();
}

void EllipseFinderItem::updatePath()
{
    const qreal iWidth = distance(mPoints[0], mPoints[3]);
    const qreal iHeight = distance(mPoints[0], mPoints[1]);
    const QPointF iCenter = (mPoints[0] + mPoints[2]) / 2;
    const QPointF iTopLeft = iCenter + QPointF(-iWidth / 2, -iHeight / 2);
    const QLineF iLine(mPoints[0], mPoints[3]);
    const qreal iAngle = -iLine.angle();
    QRectF iRect(iTopLeft, QSizeF(iWidth, iHeight));

    QTransform t;
    t.translate(iCenter.x(), iCenter.y());
    t.rotate(iAngle);
    t.translate(-iCenter.x(), -iCenter.y());

    QPainterPath iPath;
    Geom::Point gCenter(iCenter.x(), iCenter.y());
    Geom::Point gRadius(iWidth/2, iHeight/2);
    Geom::Ellipse iEllipse(gCenter, gRadius, 0);
    Geom::Point iStartPoint = iEllipse.pointAt(Geom::rad_from_deg(-mStartAngle));
    iPath.moveTo(iStartPoint.x(), iStartPoint.y());
    iPath.arcTo(iRect, mStartAngle, mSpanAngle);
    iPath.arcTo(iRect, mStartAngle + mSpanAngle, -mSpanAngle);
    iPath.closeSubpath();
    QPen iPen = pen();
    iPen.setWidth(3);
    QPainterPath nPath = qt_graphicsItem_shapeFromPath(t.map(iPath), iPen);
    setPath(nPath);
}

void EllipseFinderItem::updateHandleRects()
{
    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);

    mHandles[0]->setRect(QRectF((mPoints[0] + mPoints[1]) / 2 + o, s));
    mHandles[1]->setRect(QRectF((mPoints[2] + mPoints[3]) / 2 + o, s));
    mHandles[2]->setRect(QRectF((mPoints[0] + mPoints[3]) / 2 + o, s));
    mHandles[3]->setRect(QRectF((mPoints[1] + mPoints[2]) / 2 + o, s));

    qreal iLen1 = distance(mPoints[0], mPoints[1]);
    qreal iLen2 = distance(mPoints[0], mPoints[3]);
    iLen1 = std::max(iLen1, 1.);
    iLen2 = std::max(iLen2, 1.);
    const qreal r = iLen1 / iLen2;

    QPointF iPoints[4];
    iPoints[0] = lerp(r, mPoints[3], mPoints[0]);
    iPoints[1] = lerp(r, mPoints[2], mPoints[1]);
    iPoints[2] = lerp(r, mPoints[1], mPoints[2]);
    iPoints[3] = lerp(r, mPoints[0], mPoints[3]);

    qreal iLen = distance(mPoints[0], iPoints[2]);
    iLen = std::max(iLen, 1.);
    const qreal t = (mSemiSearchLength * M_SQRT2) / iLen;

    QPolygonF iInnerPolygon(5);
    QPolygonF iOuterPolygon(5);

    iInnerPolygon[0] = lerp(t, mPoints[0], iPoints[2]);
    iInnerPolygon[1] = lerp(t, mPoints[1], iPoints[3]);
    iInnerPolygon[2] = lerp(t, mPoints[2], iPoints[0]);
    iInnerPolygon[3] = lerp(t, mPoints[3], iPoints[1]);
    iInnerPolygon[4] = iInnerPolygon[0];

    iOuterPolygon[3] = lerp(-t, mPoints[0], iPoints[2]);
    iOuterPolygon[2] = lerp(-t, mPoints[1], iPoints[3]);
    iOuterPolygon[1] = lerp(-t, mPoints[2], iPoints[0]);
    iOuterPolygon[0] = lerp(-t, mPoints[3], iPoints[1]);
    iOuterPolygon[4] = iOuterPolygon[0];

    mHandles[4]->setRect(QRectF((iInnerPolygon[0] + iInnerPolygon[3]) / 2 + o, s));
    mHandles[5]->setRect(QRectF((iInnerPolygon[1] + iInnerPolygon[2]) / 2 + o, s));
    mHandles[6]->setRect(QRectF((iOuterPolygon[0] + iOuterPolygon[3]) / 2 + o, s));
    mHandles[7]->setRect(QRectF((iOuterPolygon[1] + iOuterPolygon[2]) / 2 + o, s));

    updateInfoLabelPose();
    updateBoundaryBand();
}

void EllipseFinderItem::updateBoundaryBand()
{
    const qreal iWidth = distance(mPoints[0], mPoints[3]);
    const qreal iHeight = distance(mPoints[0], mPoints[1]);
    const qreal iInnerWidth  = std::max(0., iWidth - 2 * mSemiSearchLength);
    const qreal iInnerHeight = std::max(0., iHeight - 2 * mSemiSearchLength);
    const qreal iOuterWidth = iWidth + 2 * mSemiSearchLength;
    const qreal iOuterHeight = iHeight + 2 * mSemiSearchLength;

    const QPointF iCenter = (mPoints[0] + mPoints[2]) / 2;
    const QPointF iInnerTopLeft = iCenter + QPointF(-iInnerWidth / 2, -iInnerHeight / 2);
    const QPointF iOuterTopLeft = iCenter + QPointF(-iOuterWidth / 2, -iOuterHeight / 2);
    const QLineF iLine(mPoints[0], mPoints[3]);
    const qreal iAngle = -iLine.angle();
    QRectF iInnerRect(iInnerTopLeft, QSizeF(iInnerWidth, iInnerHeight));
    QRectF iOuterRect(iOuterTopLeft, QSizeF(iOuterWidth, iOuterHeight));

    Geom::Point gCenter(iCenter.x(), iCenter.y());
    Geom::Point gInnerRadius(iInnerWidth / 2, iInnerHeight / 2);
    Geom::Point gOuterRadius(iOuterWidth / 2, iOuterHeight / 2);

    Geom::Ellipse iOuterEllipse(gCenter, gOuterRadius, 0.);
    Geom::Ellipse iInnerEllipse(gCenter, gInnerRadius, 0.);

    QPainterPath iPath;
    Geom::Point iOuterStartPoint = iOuterEllipse.pointAt(Geom::rad_from_deg(-mStartAngle));
    Geom::Point iOuterEndPoint = iOuterEllipse.pointAt(Geom::rad_from_deg(-mStartAngle - mSpanAngle));
    Geom::Point iInnerStartPoint = iInnerEllipse.pointAt(Geom::rad_from_deg(-mStartAngle));
    Geom::Point iInnerEndPoint = iInnerEllipse.pointAt(Geom::rad_from_deg(-mStartAngle - mSpanAngle));

    iPath.moveTo(iOuterStartPoint.x(), iOuterStartPoint.y());
    iPath.arcTo(iOuterRect, mStartAngle, mSpanAngle);
    iPath.lineTo(iInnerEndPoint.x(), iInnerEndPoint.y());
    iPath.arcTo(iInnerRect, mStartAngle + mSpanAngle, -mSpanAngle);
    iPath.closeSubpath();

    QTransform t;
    t.translate(iCenter.x(), iCenter.y());
    t.rotate(iAngle);
    t.translate(-iCenter.x(), -iCenter.y());

    mBoundaryBand->setPath(t.map(iPath));
}

void EllipseFinderItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    const int iSign = cross(mPoints[0] - mPoints[1], mPoints[2] - mPoints[1]) > 0 ? 1 : -1;
    switch (handleId)
    {
    case 0:
    {
        const qreal iDist = sdistance(e->pos(), mPoints[2], mPoints[3]) * iSign;
        if (iDist > mSemiSearchLength * 2)
        {
            QPointF iPointMoving = e->pos();
            QPointF iPointAnchor = (mPoints[2] + mPoints[3]) / 2;
            const qreal iLen = distance(iPointMoving, iPointAnchor);
            const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
            const qreal iTime = iHalfHeight / iLen;

            QPointF iPt0 = lerp(iTime, iPointMoving, iPointAnchor);
            QPointF iPt1 = lerp(iTime, iPointMoving, iPointAnchor);
            QPointF iPt2 = lerp(iTime, iPointAnchor, iPointMoving);
            QPointF iPt3 = lerp(iTime, iPointAnchor, iPointMoving);
            iPt0 = iPointMoving + rrot90((iPt0 - iPointMoving));
            iPt1 = iPointMoving + rot90((iPt1 - iPointMoving));
            iPt2 = iPointAnchor + rrot90((iPt2 - iPointAnchor));
            iPt3 = iPointAnchor + rot90((iPt3 - iPointAnchor));

            mPoints[0] = iPt0;
            mPoints[1] = iPt1;
            mPoints[2] = iPt2;
            mPoints[3] = iPt3;
        }
    }
    break;
    case 1:
    {
        const qreal iDist = sdistance(e->pos(), mPoints[0], mPoints[1]) * iSign;
        if (iDist > mSemiSearchLength * 2)
        {
            QPointF iPointMoving = e->pos();
            QPointF iPointAnchor = (mPoints[0] + mPoints[1]) / 2;
            const qreal iLen = distance(iPointMoving, iPointAnchor);
            const qreal iHalfHeight = distance(mPoints[2], mPoints[3]) / 2;
            const qreal iTime = iHalfHeight / iLen;

            QPointF iPt0 = lerp(iTime, iPointAnchor, iPointMoving);
            QPointF iPt1 = lerp(iTime, iPointAnchor, iPointMoving);
            QPointF iPt2 = lerp(iTime, iPointMoving, iPointAnchor);
            QPointF iPt3 = lerp(iTime, iPointMoving, iPointAnchor);
            iPt0 = iPointAnchor + rrot90((iPt0 - iPointAnchor));
            iPt1 = iPointAnchor + rot90((iPt1 - iPointAnchor));
            iPt2 = iPointMoving + rrot90((iPt2 - iPointMoving));
            iPt3 = iPointMoving + rot90((iPt3 - iPointMoving));

            mPoints[0] = iPt0;
            mPoints[1] = iPt1;
            mPoints[2] = iPt2;
            mPoints[3] = iPt3;
        }
    }
    break;
    case 2:
    {
        const qreal iDist = sdistance(e->pos(), mPoints[1], mPoints[2]) * iSign;
        if (iDist > mSemiSearchLength * 2)
        {
            const qreal iLen = distance(mPoints[1], mPoints[2]);
            const qreal iTime = iDist / iLen;
            QPointF iPt0 = lerp(iTime, mPoints[1], mPoints[2]);
            QPointF iPt3 = lerp(iTime, mPoints[2], mPoints[1]);
            iPt0 = mPoints[1] + rrot90((iPt0 - mPoints[1]));
            iPt3 = mPoints[2] + rot90((iPt3 - mPoints[2]));
            mPoints[0] = iPt0;
            mPoints[3] = iPt3;
        }
    }
    break;
    case 3:
    {
        const qreal iDist = sdistance(e->pos(), mPoints[3], mPoints[0]) * iSign;
        if (iDist > mSemiSearchLength * 2)
        {
            const qreal iLen = distance(mPoints[0], mPoints[3]);
            const qreal iTime = iDist / iLen;
            QPointF iPt1 = lerp(iTime, mPoints[0], mPoints[3]);
            QPointF iPt2 = lerp(iTime, mPoints[3], mPoints[0]);
            iPt1 = mPoints[0] + rot90((iPt1 - mPoints[0]));
            iPt2 = mPoints[3] + rrot90((iPt2 - mPoints[3]));
            mPoints[1] = iPt1;
            mPoints[2] = iPt2;
        }
    }
    break;
    case 4:
    {
        const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
        const qreal iDist1 = sdistance(e->pos(), mPoints[3], mPoints[0]) * iSign;
        const qreal iDist2 = sdistance(e->pos(), mPoints[1], mPoints[2]) * iSign;
        if (iDist1 > kMinSearchLength && iDist2 > iHalfHeight)
        {
            mSemiSearchLength = iDist1;
        }
    }
    break;
    case 5:
    {
        const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
        const qreal iDist1 = sdistance(e->pos(), mPoints[1], mPoints[2]) * iSign;
        const qreal iDist2 = sdistance(e->pos(), mPoints[3], mPoints[0]) * iSign;
        if (iDist1 > kMinSearchLength && iDist2 > iHalfHeight)
        {
            mSemiSearchLength = iDist1;
        }
    }
    break;
    case 6:
    {
        const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
        const qreal iDist = sdistance(e->pos(), mPoints[0], mPoints[3]) * iSign;
        if (iDist > kMinSearchLength && iDist < iHalfHeight)
        {
            mSemiSearchLength = iDist;
        }
    }
    break;
    case 7:
    {
        const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
        const qreal iDist = sdistance(e->pos(), mPoints[2], mPoints[1]) * iSign;
        if (iDist > kMinSearchLength && iDist < iHalfHeight)
        {
            mSemiSearchLength = iDist;
        }
    }
    break;
    default:
        break;
    }

    updateHandleRects();
    updatePath();
    updateMeasure(true);
}

#pragma warning( push )
#pragma warning( disable : 26812 )
QVariant EllipseFinderItem::itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant& value)
#pragma warning( pop )
{
    if (change == QGraphicsItem::ItemSelectedChange)
    {
        mBoundaryBand->setVisible(value.toBool());
    }

    if (change == QGraphicsItem::ItemPositionChange)
    {
        updateMeasure(true);
    }

    return ChildPathItem::itemChange(change, value);
}
