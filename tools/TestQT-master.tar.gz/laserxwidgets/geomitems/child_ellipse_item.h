#ifndef CHILD_ELLIPSE_ITEM_H
#define CHILD_ELLIPSE_ITEM_H
#include "child_path_item.h"

class ChildEllipseItem : public ChildPathItem
{
public:
    explicit ChildEllipseItem(QGraphicsItem* parent);
    ~ChildEllipseItem();

    static ChildEllipseItem* create(QGraphicsItem* parent, const QJsonObject& data);

public:
    bool empty() const override;
    void buildSubPath(QPainterPath& path) const;
    void onMousePress(const QPointF& pos) override;
    void onMouseMove(const QPointF& pos, const QPointF& anchorPos) override;
    void onMouseRelease(const QPointF& pos, const QPointF& anchorPos) override;
    QJsonObject getData(QGraphicsPixmapItem* mImageItem) const override;

private:
    void updatePath();
    void updateHandleRects();
    void onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e);

private:
    Q_DISABLE_COPY_MOVE(ChildEllipseItem)

private:
    QPolygonF mVertices;
};

#endif // CHILD_ELLIPSE_ITEM_H
