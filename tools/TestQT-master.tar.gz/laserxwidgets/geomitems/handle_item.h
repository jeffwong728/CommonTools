#ifndef HANDLE_ITEM_H
#define HANDLE_ITEM_H
#include <boost/signals2.hpp>
#include <QGraphicsEllipseItem>
class QGraphicsDropShadowEffect;
namespace bs2 = boost::signals2;

class HandleItem : public QGraphicsRectItem
{
public:
    enum {RectShape, CircleShape};
public:
    explicit HandleItem(const int handleId, QGraphicsItem* parent);
    explicit HandleItem(const int handleId, const int handleShape, QGraphicsItem *parent);

public:
    typedef bs2::keywords::mutex_type<bs2::dummy_mutex> bs2_dummy_mutex;
    bs2::signal_type<void(void), bs2_dummy_mutex>::type sigApplyEffect;
    bs2::signal_type<void(const int handleId, const QGraphicsSceneMouseEvent *const e), bs2_dummy_mutex>::type sigMoving;

public:
    const int handleId() const { return mHandleId; }
    void setHandleId(const int handleId);
    void applyHighlight();
    void removeHighlight();

public:
    void paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget = nullptr) override;

protected:
    void mouseMoveEvent(QGraphicsSceneMouseEvent *event) override;
    void hoverEnterEvent(QGraphicsSceneHoverEvent* event) override;
    void hoverMoveEvent(QGraphicsSceneHoverEvent* event) override;
    void hoverLeaveEvent(QGraphicsSceneHoverEvent* event) override;
    void mouseDoubleClickEvent(QGraphicsSceneMouseEvent* event) override;

private:
    Q_DISABLE_COPY_MOVE(HandleItem)

private:
    int mHandleId;
    const int mHandleShape;
    QGraphicsDropShadowEffect* mEffect = nullptr;
};

#endif // HANDLE_ITEM_H
