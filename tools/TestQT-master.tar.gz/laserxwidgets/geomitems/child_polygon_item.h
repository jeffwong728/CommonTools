#ifndef CHILD_POLYGON_ITEM_H
#define CHILD_POLYGON_ITEM_H
#include "child_path_item.h"

class ChildPolygonItem : public ChildPathItem
{
public:
    explicit ChildPolygonItem(QGraphicsItem* parent);
    ~ChildPolygonItem();

    static ChildPolygonItem* create(QGraphicsItem* parent, const QJsonObject& data);

public:
    bool empty() const override;
    void buildSubPath(QPainterPath& path) const override;
    void onMousePress(const QPointF& pos) override;
    void onMouseMove(const QPointF& pos, const QPointF& anchorPos) override;
    void onMouseDoubleClick(const QPointF& pos) override;
    QJsonObject getData(QGraphicsPixmapItem* mImageItem) const override;

private:
    void updatePath();
    void populateHandles();
    void updateHandleRects();
    void onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e);

private:
    Q_DISABLE_COPY_MOVE(ChildPolygonItem)

private:
    QPolygonF mPolygon;
};

#endif // CHILD_POLYGON_ITEM_H
