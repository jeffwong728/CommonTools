#include "line_finder_item.h"
#include "region_item.h"
#include "laser_x_canvas_p.h"
#include <laser_x_measure_model.h>
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>

LineFinderItem::LineFinderItem(QGraphicsItem* parent, LaserXCanvasPrivate* iCanvasPrivate)
    : GeomFinderItem(parent, QStringLiteral("Line"), iCanvasPrivate)
{
    int id = 0;
    mHandles.resize(4);
    const std::array<int, 4> iHandleShapes{ HandleItem::CircleShape, HandleItem::CircleShape, HandleItem::RectShape, HandleItem::RectShape };
    for (auto &handle : mHandles)
    {
        handle = new HandleItem(id, iHandleShapes[id], this);
        handle->setVisible(false);
        handle->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
        id += 1;
    }

    mBoundaryBox = new QGraphicsPolygonItem(this);
    QPen pen(Qt::darkYellow);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QColor iFillColor(Qt::darkYellow);
    iFillColor.setAlpha(64);
    mBoundaryBox->setPen(pen);
    mBoundaryBox->setBrush(QBrush(iFillColor));
    mBoundaryBox->setAcceptHoverEvents(false);
    mBoundaryBox->setZValue(0);
    mBoundaryBox->setVisible(false);

    mDirItems[0] = new QGraphicsPolygonItem(this);
    mDirItems[1] = new QGraphicsPolygonItem(this);

    for (QGraphicsPolygonItem* iDirItem : mDirItems)
    {
        iDirItem->setPen(pen);
        iDirItem->setBrush(QBrush(Qt::NoBrush));
        iDirItem->setAcceptHoverEvents(false);
        iDirItem->setZValue(0);
        iDirItem->setVisible(false);
    }
}

LineFinderItem::~LineFinderItem()
{
}

LineFinderItem* LineFinderItem::create(QGraphicsItem* parent, const QJsonObject& data, LaserXCanvasPrivate* iCanvasPrivate)
{
    if (!GeomFinderItem::isValidData(data))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Line")))
    {
        return nullptr;
    }

    LineFinderItem* item = new LineFinderItem(parent, iCanvasPrivate);
    GeomFinderItem::setData(item, data, QStringLiteral("Line"));
    item->mLine = fromJson(data, QLatin1String("Line"), QLineF());

    item->updatePath();
    item->updateHandleRects();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

void LineFinderItem::setReversed(const bool reversed)
{
    ChildPathItem::setReversed(reversed);
    updateHandleRects();
}

void LineFinderItem::toggleReversed()
{
    ChildPathItem::toggleReversed();
    updateHandleRects();
}

bool LineFinderItem::empty() const
{
    const qreal iLen = distanceSq(mLine.p1(), mLine.p2());
    return iLen < 2 || mSemiSearchLength < 2;
}

void LineFinderItem::buildSubPath(QPainterPath& path) const
{
    Q_UNUSED(path);
}

void LineFinderItem::onMousePress(const QPointF& pos)
{
    mLine.setP1(pos);
    mLine.setP2(pos);
    updateHandleRects();
}

void LineFinderItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    mLine.setP2(pos);
    updateHandleRects();
    updatePath();
}

void LineFinderItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
    onMouseMove(pos, anchorPos);
}

QJsonObject LineFinderItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = GeomFinderItem::getData(mImageItem);
    obj[QStringLiteral("Line")] = toJson(mLine.translated(pos()));
    return obj;
}

void LineFinderItem::updateMeasure(const bool fitting)
{
    mMeasureInfos.resize(0);
    qDeleteAll(mMeasureResultsItems);
    mMeasureResultsItems.resize(0);

    mMeasure = mCanvasPrivate->getMeasure();
    LXMeasureModel iMeasure = mMeasure.lock();
    if (iMeasure && !mCanvasPrivate->mMat.empty())
    {
        iMeasure->clearMeasure(mMeasureIndex);

        QVariantMap params;
        params[QStringLiteral("StartPoint")] = mLine.p1() + pos();
        params[QStringLiteral("EndPoint")] = mLine.p2() + pos();
        params[QStringLiteral("SemiSearchLength")] = mSemiSearchLength;
        params[QStringLiteral("SemiSmoothLength")] = mSemiSmoothLength;
        params[QStringLiteral("Sigma")] = mSigma;
        params[QStringLiteral("Threshold")] = mThreshold;
        params[QStringLiteral("NumSamplePoints")] = mNumSamplePoints;
        params[QStringLiteral("Select")] = mSelect;
        params[QStringLiteral("Transition")] = mTransition;
        params[QStringLiteral("MinScore")] = mMinScore;
        params[QStringLiteral("NumInstances")] = mNumInstances;
        mMeasureIndex = iMeasure->addLineMeasure(params);
        iMeasure->applyMeasure(mCanvasPrivate->mMat);
        QVariantMap iResultEdges = iMeasure->getAllBoxEdges(mMeasureIndex);

        if (iResultEdges.contains(QStringLiteral("AllEdges")))
        {
            QPen pen(Qt::magenta);
            pen.setCosmetic(true);
            pen.setWidth(1);

            QVector<QPointF> iAllEdges = iResultEdges[QStringLiteral("AllEdges")].value<QVector<QPointF>>();
            for (const QPointF &iEdge : iAllEdges)
            {
                QGraphicsLineItem *iHLine = scene()->addLine(QLineF(iEdge + QPointF(-2, 0), iEdge + QPointF(2, 0)), pen);
                QGraphicsLineItem* iVLine = scene()->addLine(QLineF(iEdge + QPointF(0, -2), iEdge + QPointF(0, 2)), pen);
                iHLine->setParentItem(this);
                iVLine->setParentItem(this);
                iVLine->setPos(-pos());
                iHLine->setPos(-pos());
                mMeasureResultsItems.push_back(iHLine);
                mMeasureResultsItems.push_back(iVLine);
            }
        }

        qlonglong iNumInstances = iMeasure->getNumInstances(mMeasureIndex);
        if (1 == iNumInstances)
        {
            QVariant instance = 0;
            QVariantMap iResult = iMeasure->getMeasureResult(mMeasureIndex, instance);
            qreal iScore = iResult[QStringLiteral("Score")].toDouble();
            QVector<QPointF> iUsedEdges = iResult[QStringLiteral("UsedEdges")].value<QVector<QPointF>>();
            QPointF iStartPoint = iResult[QStringLiteral("StartPoint")].toPointF();
            QPointF iEndPoint = iResult[QStringLiteral("EndPoint")].toPointF();

            QLineF iLine(iStartPoint, iEndPoint);
            mMeasureInfos.append(QStringLiteral("Angle: %1").arg(iLine.angle(), 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Score: %1").arg(iScore, 0, 'f', 3));

            QPen pen(Qt::green);
            pen.setCosmetic(true);
            pen.setWidth(1);
            for (const QPointF& iEdge : iUsedEdges)
            {
                QGraphicsLineItem* iHLine = scene()->addLine(QLineF(iEdge + QPointF(-2, 0), iEdge + QPointF(2, 0)), pen);
                QGraphicsLineItem* iVLine = scene()->addLine(QLineF(iEdge + QPointF(0, -2), iEdge + QPointF(0, 2)), pen);
                iHLine->setParentItem(this);
                iVLine->setParentItem(this);
                iVLine->setPos(-pos());
                iHLine->setPos(-pos());
                mMeasureResultsItems.push_back(iHLine);
                mMeasureResultsItems.push_back(iVLine);
            }

            pen.setWidth(2);
            QGraphicsLineItem* iResultLine = scene()->addLine(QLineF(iStartPoint, iEndPoint), pen);
            iResultLine->setParentItem(this);
            iResultLine->setPos(-pos());
            mMeasureResultsItems.push_back(iResultLine);
        }
    }

    updateInfoLabel();
}

void LineFinderItem::updateInfoLabelPose()
{
    mInfoItem->setPos(((mLine.p1() + mLine.p2()) / 2));
    const qreal a = mLine.angle();
    if (a > 90 && a < 270)
    {
        mInfoItem->setRotation(180 - mLine.angle());
    }
    else
    {
        mInfoItem->setRotation(0 - mLine.angle());
    }
}

QPointF LineFinderItem::center() const
{
    return (mLine.p1() + mLine.p2()) / 2 + pos();
}

void LineFinderItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    Q_UNUSED(widget);

    if (option->state & QStyle::State_MouseOver)
    {
        painter->setBrush(Qt::NoBrush);
        painter->setPen(QPen(Qt::magenta));
        painter->drawLine(mLine);
    }
    else
    {
        painter->setPen(pen());
        painter->setBrush(brush());
        painter->drawLine(mLine);
    }
}

void LineFinderItem::updatePath()
{
    QPainterPath iPath;
    iPath.moveTo(mLine.p1());
    iPath.lineTo(mLine.p2());
    iPath.closeSubpath();
    QPen iPen = pen();
    iPen.setWidth(3);
    QPainterPath nPath = qt_graphicsItem_shapeFromPath(iPath, iPen);
    setPath(nPath);
}

void LineFinderItem::updateHandleRects()
{
    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);

    mHandles[0]->setRect(QRectF(mLine.p1() + o, s));
    mHandles[1]->setRect(QRectF(mLine.p2() + o, s));

    qreal iLen = distance(mLine.p1(), mLine.p2());
    iLen = std::max(iLen, 0.1);

    QPointF iPt0 = lerp(mSemiSearchLength / iLen, mLine.p1(), mLine.p2());
    QPointF iPt1 = lerp(mSemiSearchLength / iLen, mLine.p1(), mLine.p2());
    QPointF iPt2 = lerp(mSemiSearchLength / iLen, mLine.p2(), mLine.p1());
    QPointF iPt3 = lerp(mSemiSearchLength / iLen, mLine.p2(), mLine.p1());
    iPt0 = mLine.p1() + rrot90((iPt0 - mLine.p1()));
    iPt1 = mLine.p1() + rot90((iPt1 - mLine.p1()));
    iPt2 = mLine.p2() + rrot90((iPt2 - mLine.p2()));
    iPt3 = mLine.p2() + rot90((iPt3 - mLine.p2()));
    mHandles[2]->setRect(QRectF((iPt0 + iPt3) / 2 + o, s));
    mHandles[3]->setRect(QRectF((iPt1 + iPt2) / 2 + o, s));

    QPolygonF iPolygon;
    iPolygon.push_back(iPt0);
    iPolygon.push_back(iPt1);
    iPolygon.push_back(iPt2);
    iPolygon.push_back(iPt3);
    mBoundaryBox->setPolygon(iPolygon);

    mDirItems[0]->setPolygon(arrow(iPt0, iPt1, 7));
    mDirItems[1]->setPolygon(arrow(iPt3, iPt2, 7));

    updateInfoLabelPose();
}

void LineFinderItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    const QPointF dXY = e->pos() - e->lastPos();
    switch (handleId)
    {
    case 0: mLine.setP1(mLine.p1() + dXY); break;
    case 1: mLine.setP2(mLine.p2() + dXY); break;
    case 2: 
    {
        qreal iLen = distance(mLine.p1(), mLine.p2());
        iLen = std::max(iLen, 0.1);
        QPointF iPt0 = lerp(mSemiSearchLength / iLen, mLine.p1(), mLine.p2());
        QPointF iPt3 = lerp(mSemiSearchLength / iLen, mLine.p2(), mLine.p1());
        iPt0 = mLine.p1() + rrot90((iPt0 - mLine.p1()));
        iPt3 = mLine.p2() + rot90((iPt3 - mLine.p2()));
        QPointF iPt = (iPt0 + iPt3) / 2 + dXY;
        mSemiSearchLength = distance(iPt, mLine);
        mSemiSearchLength = std::max(mSemiSearchLength, 5.0);
    }
    break;
    case 3:
    {
        qreal iLen = distance(mLine.p1(), mLine.p2());
        iLen = std::max(iLen, 0.1);
        QPointF iPt1 = lerp(mSemiSearchLength / iLen, mLine.p1(), mLine.p2());
        QPointF iPt2 = lerp(mSemiSearchLength / iLen, mLine.p2(), mLine.p1());
        iPt1 = mLine.p1() + rot90((iPt1 - mLine.p1()));
        iPt2 = mLine.p2() + rrot90((iPt2 - mLine.p2()));
        QPointF iPt = (iPt1 + iPt2) / 2 + dXY;
        mSemiSearchLength = distance(iPt, mLine);
        mSemiSearchLength = std::max(mSemiSearchLength, 5.0);
    }
    break;
    default: break;
    }
    updateHandleRects();
    updatePath();
    updateMeasure(true);
}

#pragma warning( push )
#pragma warning( disable : 26812 )
QVariant LineFinderItem::itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant& value)
#pragma warning( pop )
{
    if (change == QGraphicsItem::ItemSelectedChange)
    {
        mBoundaryBox->setVisible(value.toBool());
        mDirItems[0]->setVisible(value.toBool());
        mDirItems[1]->setVisible(value.toBool());
    }

    if (change == QGraphicsItem::ItemPositionChange)
    {
        updateMeasure(true);
    }

    return ChildPathItem::itemChange(change, value);
}
