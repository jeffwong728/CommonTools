#ifndef CHILD_REGION_ITEM_H
#define CHILD_REGION_ITEM_H
#include <QGraphicsPathItem>

class RegionItem : public QGraphicsPathItem
{
public:
    explicit RegionItem();
    ~RegionItem();

public:
    void updatePath();

private:
    Q_DISABLE_COPY_MOVE(RegionItem)

private:
};

#endif // CHILD_REGION_ITEM_H
