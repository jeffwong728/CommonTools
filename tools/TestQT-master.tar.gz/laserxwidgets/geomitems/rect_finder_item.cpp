#include "rect_finder_item.h"
#include "laser_x_canvas_p.h"
#include <laser_x_measure_model.h>
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>
#include <2geom.h>

RectFinderItem::RectFinderItem(QGraphicsItem* parent, LaserXCanvasPrivate* iCanvasPrivate)
    : GeomFinderItem(parent, QStringLiteral("Rect"), iCanvasPrivate)
{
    int id = 0;
    mHandles.resize(8);
    const std::array<int, 8> iHandleShapes =
    {
        HandleItem::CircleShape,
        HandleItem::CircleShape,
        HandleItem::RectShape,
        HandleItem::RectShape,
        HandleItem::RectShape,
        HandleItem::RectShape,
        HandleItem::RectShape,
        HandleItem::RectShape
    };

    for (auto &handle : mHandles)
    {
        handle = new HandleItem(id, iHandleShapes[id], this);
        handle->setVisible(false);
        handle->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
        id += 1;
    }

    mPoints.resize(4);
    mBoundaryBand = new QGraphicsPathItem(this);

    QPen pen(Qt::darkYellow);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QColor iFillColor(Qt::darkYellow);
    iFillColor.setAlpha(64);

    mBoundaryBand->setPen(pen);
    mBoundaryBand->setBrush(QBrush(iFillColor));
    mBoundaryBand->setAcceptHoverEvents(false);
    mBoundaryBand->setZValue(0);
    mBoundaryBand->setVisible(false);
}

RectFinderItem::~RectFinderItem()
{
}

int RectFinderItem::leftMouseClicked() const
{
    return mClicked;
}

RectFinderItem* RectFinderItem::create(QGraphicsItem* parent, const QJsonObject& data, LaserXCanvasPrivate* iCanvasPrivate)
{
    if (!GeomFinderItem::isValidData(data))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Point0")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Point1")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Point2")))
    {
        return nullptr;
    }

    if (!data.contains(QStringLiteral("Point3")))
    {
        return nullptr;
    }

    RectFinderItem* item = new RectFinderItem(parent, iCanvasPrivate);
    GeomFinderItem::setData(item, data, QStringLiteral("Rect"));
    item->mPoints[0] = fromJson(data, QLatin1String("Point0"), QPointF());
    item->mPoints[1] = fromJson(data, QLatin1String("Point1"), QPointF());
    item->mPoints[2] = fromJson(data, QLatin1String("Point2"), QPointF());
    item->mPoints[3] = fromJson(data, QLatin1String("Point3"), QPointF());

    item->updatePath();
    item->updateHandleRects();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

void RectFinderItem::setReversed(const bool reversed)
{
    ChildPathItem::setReversed(reversed);
    updateHandleRects();
}

void RectFinderItem::toggleReversed()
{
    ChildPathItem::toggleReversed();
    updateHandleRects();
}

bool RectFinderItem::empty() const
{
    const qreal iLen1 = distanceSq(mPoints[0], mPoints[1]);
    const qreal iLen2 = distanceSq(mPoints[1], mPoints[2]);
    return iLen1 < 5 || iLen2 < 5;
}

void RectFinderItem::buildSubPath(QPainterPath& path) const
{
    Q_UNUSED(path);
}

void RectFinderItem::onMousePress(const QPointF& pos)
{
    if (0 == mClicked)
    {
        mPoints[0] = pos;
        mPoints[1] = pos;
        mPoints[2] = pos;
        mPoints[3] = pos;
    }
    else if (1 == mClicked)
    {
        mPoints[1] = pos;
        mPoints[2] = pos;
    }
    else
    {
        Geom::Point iPoint0(mPoints[0].x(), mPoints[0].y());
        Geom::Point iPoint1(mPoints[1].x(), mPoints[1].y());
        if (Geom::are_near(iPoint0, iPoint1))
        {
            mPoints[2] = pos;
            mPoints[3] = pos;
        }
        else
        {
            Geom::Point iPointRot = iPoint1 + (iPoint0 - iPoint1).cw();
            if (Geom::are_near(iPointRot, iPoint1))
            {
                mPoints[2] = pos;
                mPoints[3] = pos;
            }
            else
            {
                Geom::Point iPos(pos.x(), pos.y());
                Geom::Line iLine(iPoint1, iPointRot);
                Geom::Point iPoint2 = Geom::projection(iPos, iLine);
                mPoints[2] = QPointF(iPoint2.x(), iPoint2.y());
                mPoints[3] = mPoints[0] + mPoints[2] - mPoints[1];
            }
        }
    }

    int &iClicked = const_cast<int &>(mClicked);
    iClicked += 1;

    updateHandleRects();
}

void RectFinderItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    if (1 == mClicked)
    {
        mPoints[1] = pos;
        mPoints[2] = pos;
    }
    else if (2 == mClicked)
    {
        Geom::Point iPoint0(mPoints[0].x(), mPoints[0].y());
        Geom::Point iPoint1(mPoints[1].x(), mPoints[1].y());
        if (Geom::are_near(iPoint0, iPoint1))
        {
            mPoints[2] = pos;
            mPoints[3] = pos;
        }
        else
        {
            Geom::Point iPointRot = iPoint1 + (iPoint0 - iPoint1).cw();
            if (Geom::are_near(iPointRot, iPoint1))
            {
                mPoints[2] = pos;
                mPoints[3] = pos;
            }
            else
            {
                Geom::Point iPos(pos.x(), pos.y());
                Geom::Line iLine(iPoint1, iPointRot);
                Geom::Point iPoint2 = Geom::projection(iPos, iLine);
                mPoints[2] = QPointF(iPoint2.x(), iPoint2.y());
                mPoints[3] = mPoints[0] + mPoints[2] - mPoints[1];
            }
        }
    }
    else
    {
        // do nothing
    }
    updateHandleRects();
    updatePath();
}

void RectFinderItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
    onMouseMove(pos, anchorPos);
}

QJsonObject RectFinderItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = GeomFinderItem::getData(mImageItem);
    obj[QStringLiteral("Point0")] = toJson(mPoints[0] + pos());
    obj[QStringLiteral("Point1")] = toJson(mPoints[1] + pos());
    obj[QStringLiteral("Point2")] = toJson(mPoints[2] + pos());
    obj[QStringLiteral("Point3")] = toJson(mPoints[3] + pos());
    return obj;
}

void RectFinderItem::updateMeasure(const bool fitting)
{
    mMeasureInfos.resize(0);
    qDeleteAll(mMeasureResultsItems);
    mMeasureResultsItems.resize(0);

    mMeasure = mCanvasPrivate->getMeasure();
    LXMeasureModel iMeasure = mMeasure.lock();
    if (iMeasure && !mCanvasPrivate->mMat.empty())
    {
        iMeasure->clearMeasure(mMeasureIndex);
        const QPointF iCenter = (mPoints[0] + mPoints[2]) / 2;

        qreal iAngle = 0;
        qreal iSemiMajorAxis = 0;
        qreal iSemiMinorAxis = 0;
        const qreal iWidth = distance(mPoints[0], mPoints[3]);
        const qreal iHeight = distance(mPoints[0], mPoints[1]);
        if (iWidth > iHeight)
        {
            const QLineF iLine(mPoints[0], mPoints[3]);
            iAngle = iLine.angle();
            iSemiMajorAxis = iWidth / 2;
            iSemiMinorAxis = iHeight / 2;
        }
        else
        {
            const QLineF iLine(mPoints[0], mPoints[1]);
            iAngle = iLine.angle();
            iSemiMajorAxis = iHeight / 2;
            iSemiMinorAxis = iWidth / 2;
        }

        QVariantMap params;
        params[QStringLiteral("CenterPoint")] = iCenter + pos();
        params[QStringLiteral("Angle")] = iAngle;
        params[QStringLiteral("SemiMajorAxis")] = iSemiMajorAxis;
        params[QStringLiteral("SemiMinorAxis")] = iSemiMinorAxis;
        params[QStringLiteral("SemiSearchLength")] = mSemiSearchLength;
        params[QStringLiteral("SemiSmoothLength")] = mSemiSmoothLength;
        params[QStringLiteral("Sigma")] = mSigma;
        params[QStringLiteral("Threshold")] = mThreshold;
        params[QStringLiteral("NumSamplePoints")] = mNumSamplePoints;
        params[QStringLiteral("Select")] = mSelect;
        params[QStringLiteral("Transition")] = mTransition;
        params[QStringLiteral("MinScore")] = mMinScore;
        params[QStringLiteral("NumInstances")] = mNumInstances;
        mMeasureIndex = iMeasure->addRectangle2Measure(params);
        iMeasure->applyMeasure(mCanvasPrivate->mMat);
        QVariantMap iResultEdges = iMeasure->getAllBoxEdges(mMeasureIndex);

        if (iResultEdges.contains(QStringLiteral("AllEdges")))
        {
            QPen pen(Qt::magenta);
            pen.setCosmetic(true);
            pen.setWidth(1);

            QVector<QPointF> iAllEdges = iResultEdges[QStringLiteral("AllEdges")].value<QVector<QPointF>>();
            for (const QPointF& iEdge : iAllEdges)
            {
                QGraphicsLineItem* iHLine = scene()->addLine(QLineF(iEdge + QPointF(-2, 0), iEdge + QPointF(2, 0)), pen);
                QGraphicsLineItem* iVLine = scene()->addLine(QLineF(iEdge + QPointF(0, -2), iEdge + QPointF(0, 2)), pen);
                iHLine->setParentItem(this);
                iVLine->setParentItem(this);
                iVLine->setPos(-pos());
                iHLine->setPos(-pos());
                mMeasureResultsItems.push_back(iHLine);
                mMeasureResultsItems.push_back(iVLine);
            }
        }

        qlonglong iNumInstances = iMeasure->getNumInstances(mMeasureIndex);
        if (1 == iNumInstances)
        {
            QVariant instance = 0;
            QVariantMap iResult = iMeasure->getMeasureResult(mMeasureIndex, instance);
            qreal iScore = iResult[QStringLiteral("Score")].toReal();
            QVector<QPointF> iUsedEdges = iResult[QStringLiteral("UsedEdges")].value<QVector<QPointF>>();
            QPointF iCenterPoint = iResult[QStringLiteral("CenterPoint")].toPointF();
            qreal iAngle = iResult[QStringLiteral("Angle")].toReal();
            qreal iSemiMajorAxis = iResult[QStringLiteral("SemiMajorAxis")].toReal();
            qreal iSemiMinorAxis = iResult[QStringLiteral("SemiMinorAxis")].toReal();

            mMeasureInfos.append(QStringLiteral("Angle: %1").arg(iAngle, 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Center: x=%1, y=%2").arg(iCenterPoint.x(), 0, 'f', 3).arg(iCenterPoint.y(), 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Radius: x=%1, y=%2").arg(iSemiMajorAxis, 0, 'f', 3).arg(iSemiMinorAxis, 0, 'f', 3));
            mMeasureInfos.append(QStringLiteral("Score: %1").arg(iScore, 0, 'f', 3));

            QPen pen(Qt::green);
            pen.setCosmetic(true);
            pen.setWidth(1);
            for (const QPointF& iEdge : iUsedEdges)
            {
                QGraphicsLineItem* iHLine = scene()->addLine(QLineF(iEdge + QPointF(-2, 0), iEdge + QPointF(2, 0)), pen);
                QGraphicsLineItem* iVLine = scene()->addLine(QLineF(iEdge + QPointF(0, -2), iEdge + QPointF(0, 2)), pen);
                iHLine->setParentItem(this);
                iVLine->setParentItem(this);
                iVLine->setPos(-pos());
                iHLine->setPos(-pos());
                mMeasureResultsItems.push_back(iHLine);
                mMeasureResultsItems.push_back(iVLine);
            }

            QTransform t;
            t.translate(iCenterPoint.x(), iCenterPoint.y());
            t.rotate(-iAngle);
            t.translate(-iCenterPoint.x(), -iCenterPoint.y());

            QPainterPath iPath;
            iPath.addRect(QRectF(iCenterPoint + QPointF(-iSemiMajorAxis, -iSemiMinorAxis), iCenterPoint + QPointF(iSemiMajorAxis, iSemiMinorAxis)));

            pen.setWidth(2);
            QGraphicsPathItem* iResultRect = scene()->addPath(t.map(iPath), pen);
            iResultRect->setParentItem(this);
            iResultRect->setPos(-pos());
            mMeasureResultsItems.push_back(iResultRect);
        }
    }

    updateInfoLabel();
}

void RectFinderItem::updateInfoLabelPose()
{
    QRectF iNameRect = mInfoItem->boundingRect();
    mInfoItem->setPos((mPoints[0] + mPoints[2]) / 2 + QPointF(-iNameRect.width() / 2, -iNameRect.height() / 2));
}

QPointF RectFinderItem::center() const
{
    return (mPoints[0] + mPoints[2]) / 2 + pos();
}

void RectFinderItem::paint(QPainter* painter, const QStyleOptionGraphicsItem* option, QWidget* widget)
{
    Q_UNUSED(widget);

    if (option->state & QStyle::State_MouseOver)
    {
        painter->setBrush(QBrush(Qt::NoBrush));
        painter->setPen(QPen(Qt::magenta));
        painter->drawPolygon(mPoints);
    }
    else
    {
        painter->setPen(pen());
        painter->setBrush(QBrush(Qt::NoBrush));
        painter->drawPolygon(mPoints);
    }
}

void RectFinderItem::updatePath()
{
    QPainterPath iPath;
    iPath.addPolygon(mPoints);
    QPen iPen = pen();
    iPen.setWidth(3);
    QPainterPath nPath = qt_graphicsItem_shapeFromPath(iPath, iPen);
    setPath(nPath);
}

void RectFinderItem::updateHandleRects()
{
    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);

    mHandles[0]->setRect(QRectF((mPoints[0] + mPoints[1]) / 2 + o, s));
    mHandles[1]->setRect(QRectF((mPoints[2] + mPoints[3]) / 2 + o, s));
    mHandles[2]->setRect(QRectF((mPoints[0] + mPoints[3]) / 2 + o, s));
    mHandles[3]->setRect(QRectF((mPoints[1] + mPoints[2]) / 2 + o, s));

    qreal iLen1 = distance(mPoints[0], mPoints[1]);
    qreal iLen2 = distance(mPoints[0], mPoints[3]);
    iLen1 = std::max(iLen1, 1.);
    iLen2 = std::max(iLen2, 1.);
    const qreal r = iLen1 / iLen2;

    QPointF iPoints[4];
    iPoints[0] = lerp(r, mPoints[3], mPoints[0]);
    iPoints[1] = lerp(r, mPoints[2], mPoints[1]);
    iPoints[2] = lerp(r, mPoints[1], mPoints[2]);
    iPoints[3] = lerp(r, mPoints[0], mPoints[3]);

    qreal iLen = distance(mPoints[0], iPoints[2]);
    iLen = std::max(iLen, 1.);
    const qreal t = (mSemiSearchLength * M_SQRT2) / iLen;

    QPolygonF iInnerPolygon(5);
    QPolygonF iOuterPolygon(5);

    iInnerPolygon[0] = lerp(t, mPoints[0], iPoints[2]);
    iInnerPolygon[1] = lerp(t, mPoints[1], iPoints[3]);
    iInnerPolygon[2] = lerp(t, mPoints[2], iPoints[0]);
    iInnerPolygon[3] = lerp(t, mPoints[3], iPoints[1]);
    iInnerPolygon[4] = iInnerPolygon[0];

    iOuterPolygon[3] = lerp(-t, mPoints[0], iPoints[2]);
    iOuterPolygon[2] = lerp(-t, mPoints[1], iPoints[3]);
    iOuterPolygon[1] = lerp(-t, mPoints[2], iPoints[0]);
    iOuterPolygon[0] = lerp(-t, mPoints[3], iPoints[1]);
    iOuterPolygon[4] = iOuterPolygon[0];

    QPainterPath iPath;
    iPath.addPolygon(iInnerPolygon);
    iPath.addPolygon(iOuterPolygon);
    mBoundaryBand->setPath(iPath);

    mHandles[4]->setRect(QRectF((iInnerPolygon[0] + iInnerPolygon[3]) / 2 + o, s));
    mHandles[5]->setRect(QRectF((iInnerPolygon[1] + iInnerPolygon[2]) / 2 + o, s));
    mHandles[6]->setRect(QRectF((iOuterPolygon[0] + iOuterPolygon[3]) / 2 + o, s));
    mHandles[7]->setRect(QRectF((iOuterPolygon[1] + iOuterPolygon[2]) / 2 + o, s));

    updateInfoLabelPose();
}

void RectFinderItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    const int iSign = cross(mPoints[0]- mPoints[1], mPoints[2] - mPoints[1]) > 0 ? 1 : -1;
    switch (handleId)
    {
    case 0:
    {
        const qreal iDist = sdistance(e->pos(), mPoints[2], mPoints[3]) * iSign;
        if (iDist > mSemiSearchLength * 2)
        {
            QPointF iPointMoving = e->pos();
            QPointF iPointAnchor = (mPoints[2] + mPoints[3]) / 2;
            const qreal iLen = distance(iPointMoving, iPointAnchor);
            const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
            const qreal iTime = iHalfHeight / iLen;

            QPointF iPt0 = lerp(iTime, iPointMoving, iPointAnchor);
            QPointF iPt1 = lerp(iTime, iPointMoving, iPointAnchor);
            QPointF iPt2 = lerp(iTime, iPointAnchor, iPointMoving);
            QPointF iPt3 = lerp(iTime, iPointAnchor, iPointMoving);
            iPt0 = iPointMoving + rrot90((iPt0 - iPointMoving));
            iPt1 = iPointMoving + rot90((iPt1 - iPointMoving));
            iPt2 = iPointAnchor + rrot90((iPt2 - iPointAnchor));
            iPt3 = iPointAnchor + rot90((iPt3 - iPointAnchor));

            mPoints[0] = iPt0;
            mPoints[1] = iPt1;
            mPoints[2] = iPt2;
            mPoints[3] = iPt3;
        }
    }
    break;
    case 1:
    {
        const qreal iDist = sdistance(e->pos(), mPoints[0], mPoints[1]) * iSign;
        if (iDist > mSemiSearchLength * 2)
        {
            QPointF iPointMoving = e->pos();
            QPointF iPointAnchor = (mPoints[0] + mPoints[1]) / 2;
            const qreal iLen = distance(iPointMoving, iPointAnchor);
            const qreal iHalfHeight = distance(mPoints[2], mPoints[3]) / 2;
            const qreal iTime = iHalfHeight / iLen;

            QPointF iPt0 = lerp(iTime, iPointAnchor, iPointMoving);
            QPointF iPt1 = lerp(iTime, iPointAnchor, iPointMoving);
            QPointF iPt2 = lerp(iTime, iPointMoving, iPointAnchor);
            QPointF iPt3 = lerp(iTime, iPointMoving, iPointAnchor);
            iPt0 = iPointAnchor + rrot90((iPt0 - iPointAnchor));
            iPt1 = iPointAnchor + rot90((iPt1 - iPointAnchor));
            iPt2 = iPointMoving + rrot90((iPt2 - iPointMoving));
            iPt3 = iPointMoving + rot90((iPt3 - iPointMoving));

            mPoints[0] = iPt0;
            mPoints[1] = iPt1;
            mPoints[2] = iPt2;
            mPoints[3] = iPt3;
        }
    }
    break;
    case 2:
    {
        const qreal iDist = sdistance(e->pos(), mPoints[1], mPoints[2]) * iSign;
        if (iDist > mSemiSearchLength * 2)
        {
            const qreal iLen = distance(mPoints[1], mPoints[2]);
            const qreal iTime = iDist / iLen;
            QPointF iPt0 = lerp(iTime, mPoints[1], mPoints[2]);
            QPointF iPt3 = lerp(iTime, mPoints[2], mPoints[1]);
            iPt0 = mPoints[1] + rrot90((iPt0 - mPoints[1]));
            iPt3 = mPoints[2] + rot90((iPt3 - mPoints[2]));
            mPoints[0] = iPt0;
            mPoints[3] = iPt3;
        }
    }
    break;
    case 3:
    {
        const qreal iDist = sdistance(e->pos(), mPoints[3], mPoints[0]) * iSign;
        if (iDist > mSemiSearchLength * 2)
        {
            const qreal iLen = distance(mPoints[0], mPoints[3]);
            const qreal iTime = iDist / iLen;
            QPointF iPt1 = lerp(iTime, mPoints[0], mPoints[3]);
            QPointF iPt2 = lerp(iTime, mPoints[3], mPoints[0]);
            iPt1 = mPoints[0] + rot90((iPt1 - mPoints[0]));
            iPt2 = mPoints[3] + rrot90((iPt2 - mPoints[3]));
            mPoints[1] = iPt1;
            mPoints[2] = iPt2;
        }
    }
    break;
    case 4:
    {
        const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
        const qreal iDist1 = sdistance(e->pos(), mPoints[3], mPoints[0]) * iSign;
        const qreal iDist2 = sdistance(e->pos(), mPoints[1], mPoints[2]) * iSign;
        if (iDist1 > kMinSearchLength && iDist2 > iHalfHeight)
        {
            mSemiSearchLength = iDist1;
        }
    }
    break;
    case 5:
    {
        const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
        const qreal iDist1 = sdistance(e->pos(), mPoints[1], mPoints[2]) * iSign;
        const qreal iDist2 = sdistance(e->pos(), mPoints[3], mPoints[0]) * iSign;
        if (iDist1 > kMinSearchLength && iDist2 > iHalfHeight)
        {
            mSemiSearchLength = iDist1;
        }
    }
    break;
    case 6:
    {
        const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
        const qreal iDist = sdistance(e->pos(), mPoints[0], mPoints[3]) * iSign;
        if (iDist > kMinSearchLength && iDist < iHalfHeight)
        {
            mSemiSearchLength = iDist;
        }
    }
    break;
    case 7:
    {
        const qreal iHalfHeight = distance(mPoints[0], mPoints[1]) / 2;
        const qreal iDist = sdistance(e->pos(), mPoints[2], mPoints[1]) * iSign;
        if (iDist > kMinSearchLength && iDist < iHalfHeight)
        {
            mSemiSearchLength = iDist;
        }
    }
    break;
    default:
        break;
    }

    updateHandleRects();
    updatePath();
    updateMeasure(true);
}

#pragma warning( push )
#pragma warning( disable : 26812 )
QVariant RectFinderItem::itemChange(QGraphicsItem::GraphicsItemChange change, const QVariant& value)
#pragma warning( pop )
{
    if (change == QGraphicsItem::ItemSelectedChange)
    {
        mBoundaryBand->setVisible(value.toBool());
    }

    if (change == QGraphicsItem::ItemPositionChange)
    {
        updateMeasure(true);
    }

    return ChildPathItem::itemChange(change, value);
}
