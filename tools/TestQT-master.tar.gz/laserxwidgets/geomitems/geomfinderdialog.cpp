#include "geomfinderdialog.h"
#include "ui_geomfinderdialog.h"
#include "geom_finder_item.h"

GeomFinderDialog::GeomFinderDialog(GeomFinderItem* geomFinder, QWidget *parent) :
    QDialog(parent),
    ui(new Ui::GeomFinderDialog), mGeomFinder(geomFinder)
{
    ui->setupUi(this);
    ui->spinBoxSemiSmoothLength->setValue(qRound(mGeomFinder->semiSmoothLength()));
    ui->spinBoxThreshold->setValue(qRound(mGeomFinder->threshold()));
    ui->spinBoxNumSamplePoints->setValue(mGeomFinder->numSamplePoints());
    ui->comboBoxSelect->setCurrentText(mGeomFinder->select());
    ui->comboBoxTransition->setCurrentText(mGeomFinder->transition());
}

GeomFinderDialog::~GeomFinderDialog()
{
    delete ui;
}

void GeomFinderDialog::on_spinBoxSemiSmoothLength_valueChanged(int arg1)
{
    mGeomFinder->setSemiSmoothLength(arg1);
}

void GeomFinderDialog::on_doubleSpinBoxSigma_valueChanged(double arg1)
{
    mGeomFinder->setSigma(arg1);
}

void GeomFinderDialog::on_spinBoxThreshold_valueChanged(int arg1)
{
    mGeomFinder->setThreshold(arg1);
}

void GeomFinderDialog::on_spinBoxNumSamplePoints_valueChanged(int arg1)
{
    mGeomFinder->setNumSamplePoints(arg1);
}

void GeomFinderDialog::on_comboBoxSelect_currentIndexChanged(int index)
{
    QStringList iSelects;
    iSelects << QStringLiteral("all");
    iSelects << QStringLiteral("first");
    iSelects << QStringLiteral("last");
    if (index >= 0 && index < iSelects.size())
    {
        mGeomFinder->setSelect(iSelects[index]);
    }
}

void GeomFinderDialog::on_comboBoxTransition_currentIndexChanged(int index)
{
    QStringList iTransitions;
    iTransitions << QStringLiteral("all");
    iTransitions << QStringLiteral("negative");
    iTransitions << QStringLiteral("positive");
    iTransitions << QStringLiteral("uniform");
    if (index >= 0 && index < iTransitions.size())
    {
        mGeomFinder->setTransition(iTransitions[index]);
    }
}

void GeomFinderDialog::on_pushButtonClose_clicked()
{
    QDialog::done(Accepted);
}
