#include "child_rect_item.h"
#include "region_item.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <laser_x_util.h>

ChildRectItem::ChildRectItem(QGraphicsItem* parent)
    : ChildPathItem(parent), mVertices(4)
{
    mHandles.resize(8);
    int id = 0;
    for (auto &handle : mHandles)
    {
        handle = new HandleItem(id++, this);
        handle->setVisible(false);
        handle->sigMoving.connect([this](const int handleId, const QGraphicsSceneMouseEvent *const e) { onHandleMoving(handleId, e); });
    }
}

ChildRectItem::~ChildRectItem()
{
}

ChildRectItem* ChildRectItem::create(QGraphicsItem* parent, const QJsonObject& data)
{
    if (!data.contains(QStringLiteral("vertices")))
    {
        return nullptr;
    }

    QJsonValue val = data.value(QStringLiteral("vertices"));
    if (!val.isArray())
    {
        return nullptr;
    }

    QJsonArray vertices = val.toArray();
    if (4 != vertices.count())
    {
        return nullptr;
    }

    ChildRectItem* item = new ChildRectItem(parent);
    item->setReversed(data.value(QStringLiteral("Reversed")).toBool());
    item->mVertices.clear();
    for (const auto &vertex : vertices)
    {
        item->mVertices.push_back(fromJson(vertex, QPointF()));
    }
    item->updatePath();
    item->updateHandles();
    item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setFlag(QGraphicsItem::ItemIsSelectable);

    return item;
}

bool ChildRectItem::empty() const
{
    const qreal iWidth = distanceSq(mVertices.at(0), mVertices.at(1));
    const qreal iHeight = distanceSq(mVertices.at(0), mVertices.at(3));

    return !(iWidth > 0 || iHeight > 0);
}

void ChildRectItem::buildSubPath(QPainterPath& path) const
{
    if (!empty())
    {
        if (mReversed)
        {
            path.moveTo(mVertices.at(0) + pos());
            path.lineTo(mVertices.at(3) + pos());
            path.lineTo(mVertices.at(2) + pos());
            path.lineTo(mVertices.at(1) + pos());
            path.closeSubpath();
        }
        else
        {
            path.moveTo(mVertices.at(0) + pos());
            path.lineTo(mVertices.at(1) + pos());
            path.lineTo(mVertices.at(2) + pos());
            path.lineTo(mVertices.at(3) + pos());
            path.closeSubpath();
        }
    }
}

void ChildRectItem::onMousePress(const QPointF& pos)
{
    mVertices[0] = pos;
    mVertices[1] = pos;
    mVertices[2] = pos;
    mVertices[3] = pos;
    updateHandles();
}

void ChildRectItem::onMouseMove(const QPointF& pos, const QPointF& anchorPos)
{
    QRectF iRect(anchorPos, pos);
    QRectF nRect = iRect.normalized();
    mVertices[0] = nRect.topLeft();
    mVertices[1] = nRect.topRight();
    mVertices[2] = nRect.bottomRight();
    mVertices[3] = nRect.bottomLeft();
    updateHandles();
    updatePath();
}

void ChildRectItem::onMouseRelease(const QPointF& pos, const QPointF& anchorPos)
{
    onMouseMove(pos, anchorPos);
}

QJsonObject ChildRectItem::getData(QGraphicsPixmapItem* mImageItem) const
{
    QJsonObject obj = ChildPathItem::getData(mImageItem);
    QJsonArray vertices;
    for (const auto &vertex : mVertices)
    {
        vertices.push_back(toJson(vertex + pos()));
    }
    obj[QStringLiteral("vertices")] = vertices;
    return obj;
}

void ChildRectItem::updatePath()
{
    QPainterPath iPath;
    iPath.moveTo(mVertices.at(0));
    iPath.lineTo(mVertices.at(1));
    iPath.lineTo(mVertices.at(2));
    iPath.lineTo(mVertices.at(3));
    iPath.closeSubpath();
    setPath(iPath);
}

void ChildRectItem::updateHandles()
{
    constexpr qreal w = 7.0;
    constexpr qreal hw = 3.0;
    const QSizeF s = QSizeF(w, w);
    const QPointF o = QPointF(-hw, -hw);

    mHandles[0]->setRect(QRectF(mVertices.at(0) + o, s));
    mHandles[1]->setRect(QRectF((mVertices.at(0) + mVertices.at(1)) / 2 + o, s));
    mHandles[2]->setRect(QRectF(mVertices.at(1) + o, s));
    mHandles[3]->setRect(QRectF((mVertices.at(1) + mVertices.at(2)) / 2 + o, s));
    mHandles[4]->setRect(QRectF(mVertices.at(2) + o, s));
    mHandles[5]->setRect(QRectF((mVertices.at(3) + mVertices.at(2)) / 2 + o, s));
    mHandles[6]->setRect(QRectF(mVertices.at(3) + o, s));
    mHandles[7]->setRect(QRectF((mVertices.at(3) + mVertices.at(0)) / 2 + o, s));
}

void ChildRectItem::onHandleMoving(const int handleId, const QGraphicsSceneMouseEvent *const e)
{
    const QPointF dXY = e->pos() - e->lastPos();
    QRectF newRect(mVertices.at(0), mVertices.at(2));

    switch (handleId)
    {
    case 0: newRect.setLeft(newRect.left() + dXY.x()); newRect.setTop(newRect.top() + dXY.y()); break;
    case 1: newRect.setTop(newRect.top() + dXY.y()); break;
    case 2: newRect.setRight(newRect.right() + dXY.x()); newRect.setTop(newRect.top() + dXY.y()); break;
    case 3: newRect.setRight(newRect.right() + dXY.x()); break;
    case 4: newRect.setRight(newRect.right() + dXY.x()); newRect.setBottom(newRect.bottom() + dXY.y()); break;
    case 5: newRect.setBottom(newRect.bottom() + dXY.y()); break;
    case 6: newRect.setBottom(newRect.bottom() + dXY.y()); newRect.setLeft(newRect.left() + dXY.x()); break;
    case 7: newRect.setLeft(newRect.left() + dXY.x()); break;
    default: break;
    }

    QRectF nRect = newRect.normalized();
    mVertices[0] = nRect.topLeft();
    mVertices[1] = nRect.topRight();
    mVertices[2] = nRect.bottomRight();
    mVertices[3] = nRect.bottomLeft();
    updateHandles();
    updatePath();

    RegionItem* iRgnItem = dynamic_cast<RegionItem*>(parentItem());
    if (iRgnItem)
    {
        iRgnItem->updatePath();
    }
}
