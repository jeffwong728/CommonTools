#include "referencepointdialog.h"
#include "reference_point.h"

ReferencePointDialog::ReferencePointDialog(ReferencePoint* const refPoint, QWidget *parent) :
    QDialog(parent), Ui::ReferencePointDialog(), mRefPoint(refPoint)
{
    setupUi(this);
    doubleSpinBoxX->setValue(mRefPoint->pos().x());
    doubleSpinBoxY->setValue(mRefPoint->pos().y());
}

ReferencePointDialog::~ReferencePointDialog()
{
}

void ReferencePointDialog::on_buttonBox_accepted()
{
    mRefPoint->setPos(doubleSpinBoxX->value(), doubleSpinBoxY->value());
}
