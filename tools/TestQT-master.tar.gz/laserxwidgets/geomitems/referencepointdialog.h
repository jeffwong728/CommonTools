#ifndef REFERENCEPOINTDIALOG_H
#define REFERENCEPOINTDIALOG_H

#include <QDialog>
#include "ui_referencepointdialog.h"
class ReferencePoint;

class ReferencePointDialog : public QDialog, public Ui::ReferencePointDialog
{
    Q_OBJECT

public:
    explicit ReferencePointDialog(ReferencePoint* const refPoint, QWidget *parent);
    ~ReferencePointDialog();

private slots:
    void on_buttonBox_accepted();

private:
    ReferencePoint* const mRefPoint;
};

#endif // REFERENCEPOINTDIALOG_H
