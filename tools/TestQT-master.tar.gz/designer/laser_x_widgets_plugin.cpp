#include "laser_x_widgets_plugin.h"
#include "laser_x_analog_clock_plugin.h"
#include "laser_x_log_widget_plugin.h"
#include "laser_x_device_widget_plugin.h"
#include "laser_x_command_button_plugin.h"
#include "laser_x_canvas_plugin.h"
#include "laser_x_video_box_plugin.h"
#include "laser_x_scripting_button_plugin.h"

LaserXWidgetCollectionInterface::LaserXWidgetCollectionInterface()
{
    m_plugins += new LaserXAnalogClockPlugin();
    m_plugins += new LaserXScriptingButtonPlugin();
    m_plugins += new LaserXCommandButtonPlugin();
    m_plugins += new LaserXCanvasPlugin();
    m_plugins += new LaserXVideoBoxPlugin();
    m_plugins += new LaserXLogWidgetPlugin();
    m_plugins += new LaserXDeviceWidgetPlugin();
}

LaserXWidgetCollectionInterface::~LaserXWidgetCollectionInterface()
{
    qDeleteAll( m_plugins );
}

QList<QDesignerCustomWidgetInterface*> LaserXWidgetCollectionInterface::customWidgets() const
{
    return m_plugins;
}
