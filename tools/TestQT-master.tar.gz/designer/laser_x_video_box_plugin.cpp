#include "laser_x_video_box_plugin.h"
#include <laser_x_video_box.h>

#include <QtPlugin>

LaserXVideoBoxPlugin::LaserXVideoBoxPlugin()
{
}

void LaserXVideoBoxPlugin::initialize(QDesignerFormEditorInterface * /* core */)
{
    if (initialized)
        return;

    initialized = true;
}

bool LaserXVideoBoxPlugin::isInitialized() const
{
    return initialized;
}

QWidget * LaserXVideoBoxPlugin::createWidget(QWidget *parent)
{
    return new LaserXVideoBox(parent);
}

QString LaserXVideoBoxPlugin::name() const
{
    return QStringLiteral("LaserXVideoBox");
}

QString LaserXVideoBoxPlugin::group() const
{
    return QStringLiteral("Laser X Widgets");
}

QIcon LaserXVideoBoxPlugin::icon() const
{
    return QIcon(QStringLiteral(":/images/xlogo.png"));
}

QString LaserXVideoBoxPlugin::toolTip() const
{
    return QString();
}

QString LaserXVideoBoxPlugin::whatsThis() const
{
    return QString();
}

bool LaserXVideoBoxPlugin::isContainer() const
{
    return false;
}

QString LaserXVideoBoxPlugin::domXml() const
{
    return QLatin1String(R"(
<ui language="c++">
  <widget class="LaserXVideoBox" name="laserXVideoBox">
    <property name="geometry">
      <rect>
        <x>0</x>
        <y>0</y>
        <width>180</width>
        <height>180</height>
      </rect>
    </property>
  </widget>
  <customwidgets>
      <customwidget>
          <class>LaserXVideoBox</class>
          <propertyspecifications>
              <stringpropertyspecification name="jsonManifest" notr="true" type="multiline"/>
              <tooltip name="jsonManifest">Python3 scripts executed when the button be clicked</tooltip>
          </propertyspecifications>
      </customwidget>
  </customwidgets>
</ui>
)");
}

QString LaserXVideoBoxPlugin::includeFile() const
{
    return QStringLiteral("laser_x_video_box.h");
}
