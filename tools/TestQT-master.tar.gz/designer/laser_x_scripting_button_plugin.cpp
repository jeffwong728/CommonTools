#include "laser_x_scripting_button_plugin.h"
#include <laser_x_scripting_button.h>

#include <QtPlugin>

LaserXScriptingButtonPlugin::LaserXScriptingButtonPlugin()
{
}

void LaserXScriptingButtonPlugin::initialize(QDesignerFormEditorInterface * /* core */)
{
    if (initialized)
        return;

    initialized = true;
}

bool LaserXScriptingButtonPlugin::isInitialized() const
{
    return initialized;
}

QWidget * LaserXScriptingButtonPlugin::createWidget(QWidget *parent)
{
    return new LaserXScriptingButton(parent);
}

QString LaserXScriptingButtonPlugin::name() const
{
    return QStringLiteral("LaserXScriptingButton");
}

QString LaserXScriptingButtonPlugin::group() const
{
    return QStringLiteral("Laser X Widgets");
}

QIcon LaserXScriptingButtonPlugin::icon() const
{
    return QIcon(QStringLiteral(":/images/xlogo.png"));
}

QString LaserXScriptingButtonPlugin::toolTip() const
{
    return QString();
}

QString LaserXScriptingButtonPlugin::whatsThis() const
{
    return QString();
}

bool LaserXScriptingButtonPlugin::isContainer() const
{
    return false;
}

QString LaserXScriptingButtonPlugin::domXml() const
{
    return QLatin1String(R"(
<ui language="c++">
  <widget class="LaserXScriptingButton" name="laserXScriptingButton">
    <property name="geometry">
      <rect>
        <x>0</x>
        <y>0</y>
        <width>50</width>
        <height>28</height>
      </rect>
    </property>
  </widget>
  <customwidgets>
      <customwidget>
          <class>LaserXScriptingButton</class>
          <propertyspecifications>
              <stringpropertyspecification name="scripts" notr="true" type="multiline"/>
              <tooltip name="scripts">Python3 scripts executed when the button be clicked</tooltip>
          </propertyspecifications>
      </customwidget>
  </customwidgets>
</ui>
)");
}

QString LaserXScriptingButtonPlugin::includeFile() const
{
    return QStringLiteral("laser_x_scripting_button.h");
}
