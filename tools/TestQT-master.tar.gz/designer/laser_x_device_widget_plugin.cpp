#include "laser_x_device_widget_plugin.h"
#include <laser_x_device_widget.h>

#include <QtPlugin>

LaserXDeviceWidgetPlugin::LaserXDeviceWidgetPlugin()
{
}

void LaserXDeviceWidgetPlugin::initialize(QDesignerFormEditorInterface * /* core */)
{
    if (initialized)
        return;

    initialized = true;
}

bool LaserXDeviceWidgetPlugin::isInitialized() const
{
    return initialized;
}

QWidget * LaserXDeviceWidgetPlugin::createWidget(QWidget *parent)
{
    return new LaserXDeviceWidget(parent);
}

QString LaserXDeviceWidgetPlugin::name() const
{
    return QStringLiteral("LaserXDeviceWidget");
}

QString LaserXDeviceWidgetPlugin::group() const
{
    return QStringLiteral("Laser X Widgets");
}

QIcon LaserXDeviceWidgetPlugin::icon() const
{
    return QIcon(QStringLiteral(":/images/xlogo.png"));
}

QString LaserXDeviceWidgetPlugin::toolTip() const
{
    return QString();
}

QString LaserXDeviceWidgetPlugin::whatsThis() const
{
    return QString();
}

bool LaserXDeviceWidgetPlugin::isContainer() const
{
    return false;
}

QString LaserXDeviceWidgetPlugin::domXml() const
{
    return QLatin1String(R"(
<ui language="c++">
  <widget class="LaserXDeviceWidget" name="laserXDeviceWidget">
    <property name="geometry">
      <rect>
        <x>0</x>
        <y>0</y>
        <width>100</width>
        <height>200</height>
      </rect>
    </property>
  </widget>
</ui>
)");
}

QString LaserXDeviceWidgetPlugin::includeFile() const
{
    return QStringLiteral("laser_x_device_widget.h");
}
