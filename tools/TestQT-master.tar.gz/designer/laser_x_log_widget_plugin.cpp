#include "laser_x_log_widget_plugin.h"
#include <laser_x_log_widget.h>

#include <QtPlugin>

LaserXLogWidgetPlugin::LaserXLogWidgetPlugin()
{
}

void LaserXLogWidgetPlugin::initialize(QDesignerFormEditorInterface * /* core */)
{
    if (initialized)
        return;

    initialized = true;
}

bool LaserXLogWidgetPlugin::isInitialized() const
{
    return initialized;
}

QWidget * LaserXLogWidgetPlugin::createWidget(QWidget *parent)
{
    return new LaserXLogWidget(parent);
}

QString LaserXLogWidgetPlugin::name() const
{
    return QStringLiteral("LaserXLogWidget");
}

QString LaserXLogWidgetPlugin::group() const
{
    return QStringLiteral("Laser X Widgets");
}

QIcon LaserXLogWidgetPlugin::icon() const
{
    return QIcon(QStringLiteral(":/images/xlogo.png"));
}

QString LaserXLogWidgetPlugin::toolTip() const
{
    return QString();
}

QString LaserXLogWidgetPlugin::whatsThis() const
{
    return QString();
}

bool LaserXLogWidgetPlugin::isContainer() const
{
    return false;
}

QString LaserXLogWidgetPlugin::domXml() const
{
    return QLatin1String(R"(
<ui language="c++">
  <widget class="LaserXLogWidget" name="laserXLogWidget">
    <property name="geometry">
      <rect>
        <x>0</x>
        <y>0</y>
        <width>100</width>
        <height>100</height>
      </rect>
    </property>
  </widget>
</ui>
)");
}

QString LaserXLogWidgetPlugin::includeFile() const
{
    return QStringLiteral("laser_x_log_widget.h");
}
