#include "laser_x_analog_clock_plugin.h"
#include <laser_x_analog_clock.h>

#include <QtPlugin>

LaserXAnalogClockPlugin::LaserXAnalogClockPlugin()
{
}

void LaserXAnalogClockPlugin::initialize(QDesignerFormEditorInterface * /* core */)
{
    if (initialized)
        return;

    initialized = true;
}

bool LaserXAnalogClockPlugin::isInitialized() const
{
    return initialized;
}

QWidget * LaserXAnalogClockPlugin::createWidget(QWidget *parent)
{
    return new LaserXAnalogClock(parent);
}

QString LaserXAnalogClockPlugin::name() const
{
    return QStringLiteral("LaserXAnalogClock");
}

QString LaserXAnalogClockPlugin::group() const
{
    return QStringLiteral("Laser X Widgets");
}

QIcon LaserXAnalogClockPlugin::icon() const
{
    return QIcon(QStringLiteral(":/images/xlogo.png"));
}

QString LaserXAnalogClockPlugin::toolTip() const
{
    return QString();
}

QString LaserXAnalogClockPlugin::whatsThis() const
{
    return QString();
}

bool LaserXAnalogClockPlugin::isContainer() const
{
    return false;
}

QString LaserXAnalogClockPlugin::domXml() const
{
    return QLatin1String(R"(
<ui language="c++">
  <widget class="LaserXAnalogClock" name="laserXAnalogClock">
    <property name="geometry">
      <rect>
        <x>0</x>
        <y>0</y>
        <width>100</width>
        <height>100</height>
      </rect>
    </property>
  </widget>
</ui>
)");
}

QString LaserXAnalogClockPlugin::includeFile() const
{
    return QStringLiteral("laser_x_analog_clock.h");
}
