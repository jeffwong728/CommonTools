#include "laser_x_command_button_plugin.h"
#include <laser_x_command_button.h>

#include <QtPlugin>

LaserXCommandButtonPlugin::LaserXCommandButtonPlugin()
{
}

void LaserXCommandButtonPlugin::initialize(QDesignerFormEditorInterface * /* core */)
{
    if (initialized)
        return;

    initialized = true;
}

bool LaserXCommandButtonPlugin::isInitialized() const
{
    return initialized;
}

QWidget * LaserXCommandButtonPlugin::createWidget(QWidget *parent)
{
    return new LaserXCommandButton(parent);
}

QString LaserXCommandButtonPlugin::name() const
{
    return QStringLiteral("LaserXCommandButton");
}

QString LaserXCommandButtonPlugin::group() const
{
    return QStringLiteral("Laser X Widgets");
}

QIcon LaserXCommandButtonPlugin::icon() const
{
    return QIcon(QStringLiteral(":/images/xlogo.png"));
}

QString LaserXCommandButtonPlugin::toolTip() const
{
    return QString();
}

QString LaserXCommandButtonPlugin::whatsThis() const
{
    return QString();
}

bool LaserXCommandButtonPlugin::isContainer() const
{
    return false;
}

QString LaserXCommandButtonPlugin::domXml() const
{
    return QLatin1String(R"(
<ui language="c++">
  <widget class="LaserXCommandButton" name="laserXCommandButton">
    <property name="geometry">
      <rect>
        <x>0</x>
        <y>0</y>
        <width>50</width>
        <height>28</height>
      </rect>
    </property>
  </widget>
  <customwidgets>
      <customwidget>
          <class>LaserXCommandButton</class>
          <propertyspecifications>
              <stringpropertyspecification name="scripts" notr="true" type="multiline"/>
              <tooltip name="scripts">Python3 scripts executed when the button be clicked</tooltip>
          </propertyspecifications>
      </customwidget>
  </customwidgets>
</ui>
)");
}

QString LaserXCommandButtonPlugin::includeFile() const
{
    return QStringLiteral("laser_x_command_button.h");
}
