#ifndef LASERX_WIDGET_COLLECTION_INTERFACE_H
#define LASERX_WIDGET_COLLECTION_INTERFACE_H

#include <QtCore>
#include <QtPlugin>
#include <QtUiPlugin/QDesignerCustomWidgetInterface>

class LaserXWidgetCollectionInterface
    : public QObject
    , public QDesignerCustomWidgetCollectionInterface
{
    Q_OBJECT
    Q_INTERFACES( QDesignerCustomWidgetCollectionInterface )
    Q_PLUGIN_METADATA(IID "org.qt-project.Qt.QDesignerCustomWidgetCollectionInterface" )

public:
    LaserXWidgetCollectionInterface();
    ~LaserXWidgetCollectionInterface() override;
    QList<QDesignerCustomWidgetInterface*> customWidgets() const override;

private:
    QList< QDesignerCustomWidgetInterface* > m_plugins;
};

#endif //LASERX_WIDGET_COLLECTION_INTERFACE_H
