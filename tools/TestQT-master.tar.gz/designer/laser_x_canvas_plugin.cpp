#include "laser_x_canvas_plugin.h"
#include <laser_x_canvas.h>

#include <QtPlugin>

LaserXCanvasPlugin::LaserXCanvasPlugin()
{
}

void LaserXCanvasPlugin::initialize(QDesignerFormEditorInterface * /* core */)
{
    if (initialized)
        return;

    initialized = true;
}

bool LaserXCanvasPlugin::isInitialized() const
{
    return initialized;
}

QWidget * LaserXCanvasPlugin::createWidget(QWidget *parent)
{
    return new LaserXCanvas(parent);
}

QString LaserXCanvasPlugin::name() const
{
    return QStringLiteral("LaserXCanvas");
}

QString LaserXCanvasPlugin::group() const
{
    return QStringLiteral("Laser X Widgets");
}

QIcon LaserXCanvasPlugin::icon() const
{
    return QIcon(QStringLiteral(":/images/xlogo.png"));
}

QString LaserXCanvasPlugin::toolTip() const
{
    return QString();
}

QString LaserXCanvasPlugin::whatsThis() const
{
    return QString();
}

bool LaserXCanvasPlugin::isContainer() const
{
    return false;
}

QString LaserXCanvasPlugin::domXml() const
{
    return QLatin1String(R"(
<ui language="c++">
  <widget class="LaserXCanvas" name="laserXCanvas">
    <property name="geometry">
      <rect>
        <x>0</x>
        <y>0</y>
        <width>120</width>
        <height>80</height>
      </rect>
    </property>
  </widget>
  <customwidgets>
      <customwidget>
          <class>LaserXCanvas</class>
          <propertyspecifications>
              <stringpropertyspecification name="imageSourceName" notr="true" type="singleline"/>
              <tooltip name="imageSourceName">Image Source Name</tooltip>
          </propertyspecifications>
      </customwidget>
  </customwidgets>
</ui>
)");
}

QString LaserXCanvasPlugin::includeFile() const
{
    return QStringLiteral("laser_x_canvas.h");
}
