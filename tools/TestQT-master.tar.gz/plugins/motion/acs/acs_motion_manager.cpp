#include "acs_device.h"
#include "acs_motion_manager.h"
#include "addacsdevicepage.h"
#include "configacsdevicepage.h"
#include "configacsaxispage.h"
#include <QDebug>

ACSMotionManager::ACSMotionManager()
{
}

ACSMotionManager::~ACSMotionManager()
{
}

QString ACSMotionManager::typeName()
{
    return QStringLiteral("ACSMotionControl");
}

int ACSMotionManager::numMotionDevices()
{
    return static_cast<int>(mDevices.size());
}

QList<LaserXMotionDevice*> ACSMotionManager::motionDevices()
{
    QList<LaserXMotionDevice*> devs;
    devs.reserve(mDevices.size());
    for (auto& item : mDevices)
    {
        devs.push_back(item);
    }
    return devs;
}

LaserXMotionDevice* ACSMotionManager::createMotionDevice(const QVariantMap& params)
{
    const int iNumAxis = params[QStringLiteral("NumAxis")].toInt();
    const QString iUUID = params[QStringLiteral("UUID")].toString();
    if (QUuid::fromString(iUUID).isNull())
    {
        ACSDevice* dev = new ACSDevice(this, iNumAxis);
        emit motionDeviceCreated(dev);
        return dev;
    }
    else
    {
        ACSDevice* dev = new ACSDevice(this, iUUID);
        emit motionDeviceCreated(dev);
        return dev;
    }
}

LaserXMotionDevice* ACSMotionManager::findMotionDevice(const QVariantMap& params) const
{
    const QString iCommType = params[QStringLiteral("CommType")].toString();
    if (QStringLiteral("Simulator") == iCommType)
    {
        for (const auto& devItem : mDevices)
        {
            if (devItem->commType() == iCommType)
            {
                return devItem;
            }
        }
    }
    else if (QStringLiteral("EthernetTCP") == iCommType)
    {
        const QString iIPAddress = params[QStringLiteral("IPAddress")].toString();
        for (const auto& devItem : mDevices)
        {
            if (devItem->commType() == iCommType &&
                devItem->IPAddress() == iIPAddress)
            {
                return devItem;
            }
        }
    }
    else
    {
        return nullptr;
    }

    return nullptr;
}

bool ACSMotionManager::addMotionDevice(LaserXMotionDevice* device)
{
    ACSDevice* dev = qobject_cast<ACSDevice*>(device);
    if (dev)
    {
        ACSDevice* oldDev = mDevices[dev->uuid()];
        if (oldDev)
        {
            if (oldDev != dev)
            {
                emit motionDeviceAboutToDelete(oldDev);
                oldDev->deleteLater();
                mDevices[dev->uuid()] = dev;
                emit motionDeviceAdded(dev);
                return true;
            }
        }
        else
        {
            mDevices[dev->uuid()] = dev;
            emit motionDeviceAdded(dev);
            return true;
        }
    }

    return false;
}

void ACSMotionManager::deleteMotionDevice(LaserXMotionDevice* dev)
{
    if (dev)
    {
        emit motionDeviceAboutToDelete(dev);
        mDevices.remove(dev->uuid());
        dev->deleteLater();
    }
}

LaserXAddMotionDeviceWidget* ACSMotionManager::getAddMotionDeviceWidget(QWidget* parent)
{
    return new AddACSDevicePage(parent, this);
}

LaserXConfigMotionDeviceWidget* ACSMotionManager::getConfigMotionDeviceWidget(QWidget* parent)
{
    return new ConfigACSDevicePage(parent);
}

LaserXConfigMotionAxisWidget* ACSMotionManager::getConfigMotionAxisWidget(QWidget* parent)
{
    return new ConfigACSAxisPage(parent);
}
