#include "configacsdevicepage.h"
#include "acs_device.h"

ConfigACSDevicePage::ConfigACSDevicePage(QWidget *parent)
    : LaserXConfigMotionDeviceWidget(parent)
{
    setupUi(this);
}

ConfigACSDevicePage::~ConfigACSDevicePage()
{
}

void ConfigACSDevicePage::initialize(LaserXMotionDevice* device)
{
    mDevice = dynamic_cast<ACSDevice*>(device);
    if (mDevice)
    {
        lineEditName->setText(mDevice->name());
        lineEditDescription->setText(mDevice->description());
    }
    else
    {
        lineEditName->setText(QStringLiteral("N/A"));
        lineEditDescription->setText(QStringLiteral("N/A"));
    }
}

QVariantMap ConfigACSDevicePage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = lineEditName->text();
    params[QStringLiteral("Description")] = lineEditDescription->text();
    return params;
}

void ConfigACSDevicePage::on_lineEditName_returnPressed()
{
    mDevice->setName(lineEditName->text());
}

void ConfigACSDevicePage::on_lineEditDescription_returnPressed()
{
    mDevice->setDescription(lineEditDescription->text());
}
