#ifndef ACS_DEVICE_H
#define ACS_DEVICE_H
#include "acs_axis.h"

class ACSDevice : public LaserXMotionDevice
{
    Q_OBJECT
    friend class ConfigAcsDevicePage;
public:
    ACSDevice(QObject* parent, const int numAxis);
    ACSDevice(QObject* parent, const QString& uuid);
    ~ACSDevice();

public:
    bool open(const QVariantMap& params) override;
    bool close() override;
    bool isOpened() const override;
    int countAxis() const override;
    LaserXMotionAxis* axis(const int axisNo) const override;
    LaserXMotionAxis* axis(const QString& axisUUID) const override;
    QList<bool> enabledAll() const override;
    QVariantMap setEnabledAll(const bool bEnabled) const override;
    QVariantMap getParameters() const override;
    bool setParameters(const QVariantMap& params) override;

public:
    QString commType() const { return mCommType; }
    QString IPAddress() const { return mIPAddress; }
    int port() const { return mPort; }

private:
    void initDevice();
    void closeCommunicationHandle();
    void clearAxisList();
    void invalidateAxisList();
    void installCallback();
    void unstallCallback();
    static int WINAPI commChannelClosedCB(UINT64 Param, void* UserParameter);
    static int WINAPI systemErrorCB(UINT64 Param, void* UserParameter);

private:
    HANDLE mDevHandle = ACSC_INVALID;
    QString mCommType;
    QString mIPAddress;
    int mPort = 701;
    mutable QList<ACSAxis*> mAxisList;
};

#endif // ACS_DEVICE_H
