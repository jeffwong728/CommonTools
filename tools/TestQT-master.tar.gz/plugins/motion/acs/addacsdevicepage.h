#ifndef ADDACSDEVICEPAGE_H
#define ADDACSDEVICEPAGE_H

#include <QWidget>
#include <laser_x_motion.h>
#include "ui_addacsdevicepage.h"
class ACSMotionManager;

class AddACSDevicePage : public LaserXAddMotionDeviceWidget, public Ui::AddACSDevicePage
{
    Q_OBJECT

public:
    explicit AddACSDevicePage(QWidget *parent, ACSMotionManager* motionManager);
    ~AddACSDevicePage();

public:
    void initialize(const QVariantMap& params) override;
    int countMotionDevices() const override;
    void closeAllMotionDevices() override;
    QVariantMap getParameters() const override;

private slots:
    void on_comboBoxDevice_currentIndexChanged(int index);

private:
    void updateDeviceUI(HANDLE handle);

private:
    bool mInitialized = false;
    ACSMotionManager* const mMotionManager;
    HANDLE mHandles[33];
    int mPorts[33];
};

#endif // ADDACSDEVICEPAGE_H
