#ifndef ACS_AXIS_H
#define ACS_AXIS_H

#include <QElapsedTimer>
#include <laser_x_motion.h>
#include <ACSC.h>

class ACSAxis : public LaserXMotionAxis
{
    Q_OBJECT
    friend class ConfigAcsAxisPage;
public:
    ACSAxis(QObject* parent, const HANDLE devHandle, const int axisNo);
    ~ACSAxis();

public:
    bool enabled() const override;
    QVariantMap setEnabled(const bool bEnabled) const override;
    QVariantMap motorState() const override;
    qreal actualPosition() const override;
    qreal commandPosition() const override;
    qreal actualVelocity() const override;
    qreal positionError() const override;
    qreal encoderFactor() const override;
    qreal encoderOffset() const override;
    qreal velocity() const override;
    qreal acceleration() const override;
    qreal deceleration() const override;
    qreal killDeceleration() const override;
    qreal jerk() const override;

    void setVelocity(const qreal val) override;
    void setAcceleration(const qreal val) override;
    void setDeceleration(const qreal val) override;
    void setKillDeceleration(const qreal val) override;
    void setJerk(const qreal val) override;

    void moveTo(const qreal pos) override;
    void moveMinus(const qreal distance) override;
    void movePlus(const qreal distance) override;
    void jogMinus(const qreal velocity) override;
    void jogPlus(const qreal velocity) override;
    void halt() override;

public:
    void invalidateHandle();

private:
    const HANDLE mDevHandle;
};

#endif // ACS_AXIS_H
