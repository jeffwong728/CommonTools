#ifndef CONFIGACSAXISPAGE_H
#define CONFIGACSAXISPAGE_H

#include "ui_configacsaxispage.h"
#include <laser_x_motion.h>
class ACSAxis;
class LaserXMotionAxis;

class ConfigACSAxisPage : public LaserXConfigMotionAxisWidget, public Ui::ConfigACSAxisPage
{
    Q_OBJECT

public:
    explicit ConfigACSAxisPage(QWidget *parent);
    ~ConfigACSAxisPage();

public:
    void initialize(LaserXMotionAxis* axis) override;
    QVariantMap getParameters() const override;

protected:
    bool eventFilter(QObject* object, QEvent* evt) override;

private:
    void updateAxisUI();
    void onAxisTimeout();
    void enableAllButtons(const bool enabled);

private slots:
    void on_lineEditName_returnPressed();
    void on_lineEditDescription_returnPressed();
    void on_pushButtonSetVelocity_clicked();
    void on_pushButtonSetAcceleration_clicked();
    void on_pushButtonSetDeceleration_clicked();
    void on_pushButtonSetKillDeceleration_clicked();
    void on_pushButtonSetJerk_clicked();
    void on_pushButtonMoveTo_clicked();
    void on_pushButtonMoveMinus_clicked();
    void on_pushButtonMovePlus_clicked();
    void on_pushButtonStop_clicked();

private:
    void onJogMinusPressed();
    void onJogMinusReleased();
    void onJogPlusPressed();
    void onJogPlusReleased();

private:
    ACSAxis* mAxis = nullptr;
    const int kGrayLed  = 0;
    const int kGreenLed = 1;
    const int kRedLed   = 2;
    const int kFailLed  = 3;
    QPixmap mLEDs[4];
};

#endif // CONFIGACSAXISPAGE_H
