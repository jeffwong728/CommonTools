#ifndef ACS_MOTION_MANAGER_H
#define ACS_MOTION_MANAGER_H

#include <laser_x_motion.h>
#include <QObject>
#include <memory>
class ACSDevice;

class ACSMotionManager : public LaserXMotionManager {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LaserXMotionManagerInterfaceIID)
    Q_INTERFACES(LaserXMotionManager)
public:
    ACSMotionManager();
    ~ACSMotionManager();

public:
    QString typeName() override;
    int numMotionDevices() override;
    QList<LaserXMotionDevice*> motionDevices() override;
    LaserXMotionDevice* createMotionDevice(const QVariantMap& params) override;
    LaserXMotionDevice* findMotionDevice(const QVariantMap& params) const override;
    bool addMotionDevice(LaserXMotionDevice* device) override;
    void deleteMotionDevice(LaserXMotionDevice* device) override;
    LaserXAddMotionDeviceWidget* getAddMotionDeviceWidget(QWidget* parent) override;
    LaserXConfigMotionDeviceWidget* getConfigMotionDeviceWidget(QWidget* parent) override;
    LaserXConfigMotionAxisWidget* getConfigMotionAxisWidget(QWidget* parent) override;

private:
    QMap<QString, ACSDevice*> mDevices;
};

#endif // ACS_MOTION_MANAGER_H
