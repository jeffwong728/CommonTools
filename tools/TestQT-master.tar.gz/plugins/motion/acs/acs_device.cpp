#include "acs_device.h"
#include <QtCore>
#include <QtConcurrent>
#include <QMutexLocker>

inline bool ACSEQValue(const float v0, const float v1)
{
    return std::abs(v0 - v1) < 0.001;
}

ACSDevice::ACSDevice(QObject* parent, const int numAxis)
    : LaserXMotionDevice(parent, numAxis)
    , mCommType(QStringLiteral("Simulator"))
    , mIPAddress(QStringLiteral("10.0.0.100"))
{
    mName = QStringLiteral("ACS Device");
    mDescription = QStringLiteral("ACS Device");

    mAxisNames.reserve(numAxis);
    mAxisDescriptions.reserve(numAxis);
    for (int aa = 0; aa < numAxis; ++aa)
    {
        mAxisNames.append(QStringLiteral("Axis %1").arg(aa));
        mAxisDescriptions.append(QStringLiteral("Axis %1").arg(aa));
    }

    mAxisList.resize(numAxis, nullptr);
}

ACSDevice::ACSDevice(QObject* parent, const QString& uuid)
    : LaserXMotionDevice(parent, uuid)
    , mCommType(QStringLiteral("Simulator"))
    , mIPAddress(QStringLiteral("10.0.0.100"))
{
}

ACSDevice::~ACSDevice()
{
    closeCommunicationHandle();
}

bool ACSDevice::open(const QVariantMap& params)
{
    if (mDevHandle != ACSC_INVALID)
    {
        return true;
    }

    LaserXMotionDevice::setParameters(params);
    QString iCommType = params.value(QStringLiteral("CommType")).toString();
    QString iIPAddress = params.value(QStringLiteral("IPAddress")).toString();
    int iPort = params.value(QStringLiteral("Port")).toInt();

    if (QStringLiteral("Simulator") == iCommType)
    {
        mDevHandle = acsc_OpenCommSimulator();
        if (ACSC_INVALID == mDevHandle)
        {
            QVariantMap params;
            params[QStringLiteral("ErrorMsg")] = QStringLiteral("ACS open simulator error: %1").arg(acsc_GetLastError());
            emit motionDeviceErrorOccurred(params);
            return false;
        }
        else
        {
            initDevice();
            emit motionDeviceOpened();
            return true;
        }
    }
    else if (QStringLiteral("EthernetTCP") == iCommType)
    {
        mDevHandle = acsc_OpenCommEthernetTCP(const_cast<char*>(iIPAddress.toStdString().c_str()), iPort);
        if (ACSC_INVALID == mDevHandle)
        {
            QVariantMap params;
            params[QStringLiteral("ErrorMsg")] = QStringLiteral("ACS open TCP device %1:%2 error: %3").arg(iIPAddress).arg(iPort).arg(acsc_GetLastError());
            emit motionDeviceErrorOccurred(params);
            return false;
        }
        else
        {
            initDevice();
            emit motionDeviceOpened();
            return true;
        }
    }
    else
    {
        QVariantMap params;
        params[QStringLiteral("ErrorMsg")] = QStringLiteral("ACS unknown communication type %1").arg(iCommType);
        emit motionDeviceErrorOccurred(params);
        return false;
    }
}

bool ACSDevice::close()
{
    unstallCallback();
    closeCommunicationHandle();
    clearAxisList();
    emit motionDeviceClosed();
    return true;
}

bool ACSDevice::isOpened() const
{
    return mDevHandle != ACSC_INVALID;
}

int ACSDevice::countAxis() const
{
    return static_cast<int>(mAxisList.size());
}

LaserXMotionAxis* ACSDevice::axis(const int axisNo) const
{
    if (mDevHandle == ACSC_INVALID)
    {
        qDebug() << QStringLiteral("ACS invalid communication handle");
    }

    if (axisNo < 0 || axisNo >= mAxisList.size())
    {
        qDebug() << QStringLiteral("ACS invalid axis %1").arg(axisNo);
        return nullptr;
    }

    ACSAxis* iAxis = mAxisList.constData()[axisNo];
    if (!iAxis)
    {
        iAxis = new ACSAxis(const_cast<ACSDevice*>(this), mDevHandle, axisNo);
        mAxisList[axisNo] = iAxis;
    }

    return iAxis;
}

LaserXMotionAxis* ACSDevice::axis(const QString& axisUUID) const
{
    const int axisNo = static_cast<int>(mAxisUUIDs.indexOf(axisUUID));
    return axis(axisNo);
}

QList<bool> ACSDevice::enabledAll() const
{
    QList<bool> bEnabledList(mAxisList.size(), false);
    if (mDevHandle == ACSC_INVALID)
    {
        return bEnabledList;
    }

    std::vector<int> iMotorStatus(mAxisList.size(), 0);
    int ret = acsc_ReadInteger(mDevHandle, ACSC_NONE, const_cast<char*>("MST"), 0, mAxisList.size()-1, ACSC_NONE, ACSC_NONE, iMotorStatus.data(), ACSC_SYNCHRONOUS);
    if (!ret)
    {
        return bEnabledList;
    }

    for (qsizetype aa=0; aa < mAxisList.size(); ++aa)
    {
        bEnabledList[aa] = iMotorStatus[aa] & ACSC_MST_ENABLE;
    }

    return bEnabledList;
}

QVariantMap ACSDevice::setEnabledAll(const bool bEnabled) const
{
    QVariantMap results;
    results[QStringLiteral("Success")] = false;
    if (mDevHandle == ACSC_INVALID)
    {
        results[QStringLiteral("ErrorMsg")] = QStringLiteral("Motion device disconnected");
        return results;
    }

    std::vector<int> axisList(mAxisList.size());
    std::iota(axisList.begin(), axisList.end(), 0);
    axisList.push_back(-1);

    int ret = 0;
    if (bEnabled)
    {
        ret = acsc_EnableM(mDevHandle, axisList.data(), ACSC_SYNCHRONOUS);
    }
    else
    {
        ret = acsc_DisableM(mDevHandle, axisList.data(), ACSC_SYNCHRONOUS);
    }

    if (!ret)
    {
        results[QStringLiteral("ErrorMsg")] = QStringLiteral("Axis enable error: %1").arg(acsc_GetLastError());
        return results;
    }

    for (int aa = 0; aa < mAxisList.size(); ++aa)
    {
        ret = acsc_WaitMotorEnabled(mDevHandle, aa, bEnabled, 3000);
        if (!ret)
        {
            results[QStringLiteral("ErrorMsg")] = QStringLiteral("Axis %1 enable error: %2").arg(aa).arg(acsc_GetLastError());
            return results;
        }
    }

    results[QStringLiteral("Success")] = true;
    return results;
}

QVariantMap ACSDevice::getParameters() const
{
    QVariantMap params = LaserXMotionDevice::getParameters();
    params[QStringLiteral("CommType")]  = mCommType;
    params[QStringLiteral("IPAddress")] = mIPAddress;
    params[QStringLiteral("Port")]      = mPort;
    return params;
}

bool ACSDevice::setParameters(const QVariantMap& params)
{
    LaserXMotionDevice::setParameters(params);
    mCommType   = params.value(QStringLiteral("CommType"), QStringLiteral("Simulator")).toString();
    mIPAddress  = params.value(QStringLiteral("IPAddress"), QStringLiteral("10.0.0.100")).toString();
    mPort       = params.value(QStringLiteral("Port"), 701).toInt();

    clearAxisList();
    mAxisList.resize(mAxisNames.size(), nullptr);
    return true;
}

void ACSDevice::initDevice()
{
    installCallback();
}

void ACSDevice::closeCommunicationHandle()
{
    if (mDevHandle != ACSC_INVALID)
    {
        int ret = acsc_CloseComm(mDevHandle);
        if (!ret)
        {
            QVariantMap params;
            params[QStringLiteral("ErrorMsg")] = QStringLiteral("ACS error closing communication: %1").arg(acsc_GetLastError());
            emit motionDeviceErrorOccurred(params);
        }
        mDevHandle = ACSC_INVALID;
    }
}

void ACSDevice::clearAxisList()
{
    qDeleteAll(mAxisList);
    mAxisList.fill(nullptr);
}

void ACSDevice::invalidateAxisList()
{
    for (ACSAxis* iAxis : mAxisList)
    {
        if (iAxis)
        {
            iAxis->invalidateHandle();
        }
    }
}

void ACSDevice::installCallback()
{
    if (mDevHandle == ACSC_INVALID)
    {
        return;
    }

    int ret = acsc_InstallCallback(mDevHandle, commChannelClosedCB, this, ACSC_INTR_COMM_CHANNEL_CLOSED);
    if (!ret)
    {
        qDebug() << QStringLiteral("ACS error install callback: %1").arg(acsc_GetLastError());
    }

    ret = acsc_InstallCallback(mDevHandle, systemErrorCB, this, ACSC_INTR_SYSTEM_ERROR);
    if (!ret)
    {
        qDebug() << QStringLiteral("ACS error install callback: %1").arg(acsc_GetLastError());
    }
}

void ACSDevice::unstallCallback()
{
    if (mDevHandle == ACSC_INVALID)
    {
        return;
    }

    int ret = acsc_InstallCallback(mDevHandle, NULL, this, ACSC_INTR_COMM_CHANNEL_CLOSED);
    if (!ret)
    {
        qDebug() << QStringLiteral("ACS error uninstall callback: %1").arg(acsc_GetLastError());
    }

    ret = acsc_InstallCallback(mDevHandle, NULL, this, ACSC_INTR_SYSTEM_ERROR);
    if (!ret)
    {
        qDebug() << QStringLiteral("ACS error uninstall callback: %1").arg(acsc_GetLastError());
    }
}

int WINAPI ACSDevice::commChannelClosedCB(UINT64 Param, void* UserParameter)
{
    ACSDevice* dev = reinterpret_cast<ACSDevice*>(UserParameter);
    dev->mDevHandle = ACSC_INVALID;
    dev->invalidateAxisList();
    emit dev->motionDeviceClosed();
    return 0;
}

int WINAPI ACSDevice::systemErrorCB(UINT64 Param, void* UserParameter)
{
    return 0;
}
