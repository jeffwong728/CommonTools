#include "addacsdevicepage.h"
#include "acs_motion_manager.h"
#include <ACSC.h>

AddACSDevicePage::AddACSDevicePage(QWidget *parent, ACSMotionManager* motionManager)
    : LaserXAddMotionDeviceWidget(parent)
    , mMotionManager(motionManager)
{
    setupUi(this);

    for (auto &iHandle : mHandles)
    {
        iHandle = ACSC_INVALID;
    }

    for (auto& iPort : mPorts)
    {
        iPort = 0;
    }

    unsigned int Ver = acsc_GetUMDVersion();
    labelStatus->setText(tr("SPiiPlus User Mode Driver version is %1.%2.%3.%4").arg(HIBYTE(HIWORD(Ver))).arg(LOBYTE(HIWORD(Ver))).arg(HIBYTE(LOWORD(Ver))).arg(LOBYTE(LOWORD(Ver))));
}

AddACSDevicePage::~AddACSDevicePage()
{
    for (const HANDLE iHandle : mHandles)
    {
        if (iHandle != ACSC_INVALID)
        {
            acsc_CloseComm(iHandle);
        }
    }
}

void AddACSDevicePage::on_comboBoxDevice_currentIndexChanged(int index)
{
    QString iCommType = comboBoxDevice->itemData(index).toString();
    if (QStringLiteral("Simulator") == iCommType)
    {
        if (ACSC_INVALID == mHandles[index])
        {
            mHandles[index] = acsc_OpenCommSimulator();
            if (ACSC_INVALID == mHandles[index])
            {
                qDebug() << QStringLiteral("ACS open simulator error: %1").arg(acsc_GetLastError());
            }
        }
        updateDeviceUI(mHandles[index]);
    }
    else if (QStringLiteral("EthernetTCP") == iCommType)
    {
        if (ACSC_INVALID == mHandles[index])
        {
            bool ok = false;
            std::string iAddress = comboBoxDevice->currentText().toStdString();
            int iPort = QInputDialog::getInt(this, tr("Port"), tr("Port"), ACSC_SOCKET_STREAM_PORT, 500, 65565, 1, &ok);
            mPorts[index] = ok ? iPort : ACSC_SOCKET_STREAM_PORT;
            mHandles[index] = acsc_OpenCommEthernetTCP(const_cast<char *>(iAddress.c_str()), mPorts[index]);
            if (ACSC_INVALID == mHandles[index])
            {
                qDebug() << QStringLiteral("ACS open TCP device %1:%2 error: %3").arg(comboBoxDevice->currentText()).arg(mPorts[index]).arg(acsc_GetLastError());
            }
        }
        updateDeviceUI(mHandles[index]);
    }
    else
    {
        qDebug() << QStringLiteral("ACS motion plugin bug found");
    }
}

void AddACSDevicePage::updateDeviceUI(HANDLE handle)
{
    if (handle == ACSC_INVALID)
    {
        return;
    }

    double iNumAxis = 0.0;
    int ret = acsc_SysInfo(handle, ACSC_SYS_NAXES_KEY, &iNumAxis, ACSC_SYNCHRONOUS);
    if (ret)
    {
        spinBoxNumAxis->setRange(0, qRound(iNumAxis));
        spinBoxNumAxis->setValue(qRound(iNumAxis));
    }
    else
    {
        spinBoxNumAxis->setRange(0, 0);
        spinBoxNumAxis->setValue(0);
        qDebug() << QStringLiteral("ACS get system information error: %1").arg(acsc_GetLastError());
    }

    int iReceived = 0;
    char iSerialNumber[256] = {0};
    ret = acsc_GetSerialNumber(handle, iSerialNumber, 255, &iReceived, ACSC_SYNCHRONOUS);
    if (ret)
    {
        labelStatus->setText(tr("Controller serial number is %1").arg(QString::fromLatin1(iSerialNumber)));
    }
    else
    {
        qDebug() << QStringLiteral("ACS get controller serial number error: %1").arg(acsc_GetLastError());
    }
}

void AddACSDevicePage::initialize(const QVariantMap& params)
{
    if (mInitialized)
    {
        return;
    }

    QVariantMap iDevId;
    iDevId[QStringLiteral("CommType")] = QStringLiteral("Simulator");
    if (!mMotionManager->findMotionDevice(iDevId))
    {
        comboBoxDevice->addItem(QStringLiteral("Simulator"), QStringLiteral("Simulator"));
    }

    int iNcontrollers = 0;
    in_addr iControllerInfos[32];
    std::memset(iControllerInfos, 0, sizeof(iControllerInfos));
    int ret = acsc_GetEthernetCards(iControllerInfos, 32, &iNcontrollers, ACSC_NONE);
    if (ret)
    {
        iDevId[QStringLiteral("CommType")] = QStringLiteral("EthernetTCP");
        for (int nn = 0; nn < iNcontrollers; ++nn)
        {
            QString ipAddress = QString::fromLatin1(inet_ntoa(iControllerInfos[nn]));
            iDevId[QStringLiteral("IPAddress")] = ipAddress;
            if (!mMotionManager->findMotionDevice(iDevId))
            {
                comboBoxDevice->addItem(ipAddress, QStringLiteral("EthernetTCP"));
            }
        }
    }
    else
    {
        qDebug() << QStringLiteral("ACS error get ethernet cards: %1").arg(acsc_GetLastError());
    }
    mInitialized = true;
}

int AddACSDevicePage::countMotionDevices() const
{
    return comboBoxDevice->count();
}

void AddACSDevicePage::closeAllMotionDevices()
{
    for (HANDLE &iHandle : mHandles)
    {
        if (iHandle != ACSC_INVALID)
        {
            acsc_CloseComm(iHandle);
            iHandle = ACSC_INVALID;
        }
    }
}

QVariantMap AddACSDevicePage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = lineEditName->text();
    params[QStringLiteral("Description")] = lineEditDescription->text();
    params[QStringLiteral("CommType")] = comboBoxDevice->currentData().toString();
    params[QStringLiteral("IPAddress")] = comboBoxDevice->currentText();
    params[QStringLiteral("Port")] = mPorts[comboBoxDevice->currentIndex()];
    params[QStringLiteral("NumAxis")] = spinBoxNumAxis->value();
    return params;
}
