#include "configacsaxispage.h"
#include "acs_axis.h"

ConfigACSAxisPage::ConfigACSAxisPage(QWidget *parent)
    : LaserXConfigMotionAxisWidget(parent)
{
    setupUi(this);
    mLEDs[kGrayLed] = QPixmap(QStringLiteral(":/images/gray"));
    mLEDs[kGreenLed] = QPixmap(QStringLiteral(":/images/green"));
    mLEDs[kRedLed] = QPixmap(QStringLiteral(":/images/red"));
    mLEDs[kFailLed] = QPixmap(QStringLiteral(":/images/fail"));

    lineEditMotionVelocity->setValidator(new QIntValidator(1, 1e12, lineEditMotionVelocity));
    lineEditMotionAcceleration->setValidator(new QIntValidator(1, 1e12, lineEditMotionAcceleration));
    lineEditMotionDeceleration->setValidator(new QIntValidator(1, 1e12, lineEditMotionDeceleration));
    lineEditMotionKillDeceleration->setValidator(new QIntValidator(1, 1e12, lineEditMotionKillDeceleration));
    lineEditMotionJerk->setValidator(new QIntValidator(1, 1e12, lineEditMotionJerk));
    lineEditPosition->setValidator(new QIntValidator(-1e12, 1e12, lineEditPosition));
    lineEditPosition->setText(QStringLiteral("0"));
    lineEditDistance->setValidator(new QIntValidator(1, 1e12, lineEditDistance));
    lineEditJogVelocity->setValidator(new QIntValidator(1, 1e12, lineEditJogVelocity));
    lineEditBackForth->setValidator(new QIntValidator(1, 1e12, lineEditBackForth));

    QFont font = lineEditMotionVelocity->font();
    font.setPointSizeF(font.pointSizeF()*1.25);
    lineEditMotionVelocity->setFont(font);
    lineEditMotionAcceleration->setFont(font);
    lineEditMotionDeceleration->setFont(font);
    lineEditMotionKillDeceleration->setFont(font);
    lineEditMotionJerk->setFont(font);
    lineEditPosition->setFont(font);
    lineEditDistance->setFont(font);
    lineEditJogVelocity->setFont(font);
    lineEditBackForth->setFont(font);

    lineEditPosition->setText(QStringLiteral("0"));
    lineEditDistance->setText(QStringLiteral("1000"));
    lineEditJogVelocity->setText(QStringLiteral("10000"));
    lineEditBackForth->setText(QStringLiteral("10000"));

    pushButtonJogMinus->installEventFilter(this);
    pushButtonJogPlus->installEventFilter(this);

    labelBackForth->setVisible(false);
    lineEditBackForth->setVisible(false);
    pushButtonBackForth->setVisible(false);
}

ConfigACSAxisPage::~ConfigACSAxisPage()
{
}

void ConfigACSAxisPage::initialize(LaserXMotionAxis* axis)
{
    mAxis = dynamic_cast<ACSAxis*>(axis);
    updateAxisUI();
}

QVariantMap ConfigACSAxisPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = lineEditName->text();
    params[QStringLiteral("Description")] = lineEditDescription->text();
    return params;
}

bool ConfigACSAxisPage::eventFilter(QObject* object, QEvent* evt)
{
    QPushButton* iButton = qobject_cast<QPushButton*>(object);
    if (pushButtonJogMinus == iButton)
    {
        switch (evt->type())
        {
        case QEvent::MouseButtonPress:
            onJogMinusPressed();
            break;

        case QEvent::MouseButtonRelease:
            onJogMinusReleased();
            break;

        default:
            break;
        }
    }
    else if (pushButtonJogPlus == iButton)
    {
        switch (evt->type())
        {
        case QEvent::MouseButtonPress:
            onJogPlusPressed();
            break;

        case QEvent::MouseButtonRelease:
            onJogPlusReleased();
            break;

        default:
            break;
        }
    }
    else
    {
        return LaserXConfigMotionAxisWidget::eventFilter(object, evt);
    }

    return LaserXConfigMotionAxisWidget::eventFilter(object, evt);
}

void ConfigACSAxisPage::updateAxisUI()
{
    if (mAxis)
    {
        if (!lineEditName->hasFocus())
        {
            lineEditName->setText(mAxis->name());
        }
        if (!lineEditDescription->hasFocus())
        {
            lineEditDescription->setText(mAxis->description());
        }

        QVariantMap iStates = mAxis->motorState();
        if (iStates.value(QStringLiteral("Success")).toBool())
        {
            const bool iEnable = iStates.value(QStringLiteral("Enable")).toBool();
            const bool iInPos = iStates.value(QStringLiteral("InPos")).toBool();
            const bool iMove = iStates.value(QStringLiteral("Move")).toBool();
            const bool iAcc = iStates.value(QStringLiteral("Acc")).toBool();
            enableAllButtons(iEnable);

            ledEnable->setPixmap(iEnable ? mLEDs[kGreenLed] : mLEDs[kGrayLed]);
            ledInPos->setPixmap(iInPos ? mLEDs[kGreenLed] : mLEDs[kGrayLed]);
            ledMove->setPixmap(iMove ? mLEDs[kGreenLed] : mLEDs[kGrayLed]);
            ledAcc->setPixmap(iAcc ? mLEDs[kGreenLed] : mLEDs[kGrayLed]);
            const int iLeftLimit = iStates.value(QStringLiteral("LeftLimit")).toInt();
            const int iRightLimit = iStates.value(QStringLiteral("RightLimit")).toInt();
            if (1 == iLeftLimit)
            {
                ledLeftLimit->setPixmap(mLEDs[kRedLed]);
            }
            else if (2 == iLeftLimit)
            {
                ledLeftLimit->setPixmap(mLEDs[kGreenLed]);
            }
            else
            {
                ledLeftLimit->setPixmap(mLEDs[kGrayLed]);
            }
            if (1 == iRightLimit)
            {
                ledRightLimit->setPixmap(mLEDs[kRedLed]);
            }
            else if (2 == iRightLimit)
            {
                ledRightLimit->setPixmap(mLEDs[kGreenLed]);
            }
            else
            {
                ledRightLimit->setPixmap(mLEDs[kGrayLed]);
            }
        }
        else
        {
            ledEnable->setPixmap(mLEDs[kFailLed]);
            ledInPos->setPixmap(mLEDs[kFailLed]);
            ledMove->setPixmap(mLEDs[kFailLed]);
            ledAcc->setPixmap(mLEDs[kFailLed]);
            ledLeftLimit->setPixmap(mLEDs[kFailLed]);
            ledRightLimit->setPixmap(mLEDs[kFailLed]);
            enableAllButtons(false);
        }
        lcdNumberActualPosition->display(QString::number(mAxis->actualPosition(), 'f', 3));
        lcdNumberCommandPosition->display(QString::number(mAxis->commandPosition(), 'f', 3));
        lcdNumberActualVelocity->display(QString::number(mAxis->actualVelocity(), 'f', 3));
        lcdNumberPositionError->display(QString::number(mAxis->positionError(), 'f', 3));
        lcdNumberEFAC->display(QString::number(mAxis->encoderFactor(), 'f', 9));
        lcdNumberEOFFS->display(QString::number(mAxis->encoderOffset(), 'f', 9));
        if (!lineEditMotionVelocity->hasFocus())
        {
            lineEditMotionVelocity->setText(QString::number(mAxis->velocity(), 'f', 0));
        }
        if (!lineEditMotionAcceleration->hasFocus())
        {
            lineEditMotionAcceleration->setText(QString::number(mAxis->acceleration(), 'f', 0));
        }
        if (!lineEditMotionDeceleration->hasFocus())
        {
            lineEditMotionDeceleration->setText(QString::number(mAxis->deceleration(), 'f', 0));
        }
        if (!lineEditMotionKillDeceleration->hasFocus())
        {
            lineEditMotionKillDeceleration->setText(QString::number(mAxis->killDeceleration(), 'f', 0));
        }
        if (!lineEditMotionJerk->hasFocus())
        {
            lineEditMotionJerk->setText(QString::number(mAxis->jerk(), 'f', 0));
        }
    }
    else
    {
        lineEditName->setText(QStringLiteral("N/A"));
        lineEditDescription->setText(QStringLiteral("N/A"));
        ledEnable->setPixmap(mLEDs[kFailLed]);
        ledInPos->setPixmap(mLEDs[kFailLed]);
        ledMove->setPixmap(mLEDs[kFailLed]);
        ledAcc->setPixmap(mLEDs[kFailLed]);
        ledLeftLimit->setPixmap(mLEDs[kFailLed]);
        ledRightLimit->setPixmap(mLEDs[kFailLed]);
        lcdNumberActualPosition->display(std::nan(""));
        lcdNumberCommandPosition->display(std::nan(""));
        lcdNumberActualVelocity->display(std::nan(""));
        lcdNumberPositionError->display(std::nan(""));
        lcdNumberEFAC->display(std::nan(""));
        lcdNumberEOFFS->display(std::nan(""));
        lineEditMotionVelocity->setText(QStringLiteral("nan"));
        lineEditMotionAcceleration->setText(QStringLiteral("nan"));
        lineEditMotionDeceleration->setText(QStringLiteral("nan"));
        lineEditMotionKillDeceleration->setText(QStringLiteral("nan"));
        lineEditMotionJerk->setText(QStringLiteral("nan"));
        enableAllButtons(false);
    }
}

void ConfigACSAxisPage::onAxisTimeout()
{
    updateAxisUI();
}

void ConfigACSAxisPage::enableAllButtons(const bool enabled)
{
    pushButtonSetVelocity->setEnabled(enabled);
    pushButtonSetAcceleration->setEnabled(enabled);
    pushButtonSetDeceleration->setEnabled(enabled);
    pushButtonSetKillDeceleration->setEnabled(enabled);
    pushButtonSetJerk->setEnabled(enabled);

    pushButtonMoveTo->setEnabled(enabled);
    pushButtonMoveMinus->setEnabled(enabled);
    pushButtonMovePlus->setEnabled(enabled);
    pushButtonJogMinus->setEnabled(enabled);
    pushButtonJogPlus->setEnabled(enabled);
    pushButtonBackForth->setEnabled(enabled);
}

void ConfigACSAxisPage::on_lineEditName_returnPressed()
{
    if (mAxis)
    {
        mAxis->setName(lineEditName->text());
    }
}

void ConfigACSAxisPage::on_lineEditDescription_returnPressed()
{
    if (mAxis)
    {
        mAxis->setDescription(lineEditDescription->text());
    }
}

void ConfigACSAxisPage::on_pushButtonSetVelocity_clicked()
{
    if (mAxis)
    {
        mAxis->setVelocity(lineEditMotionVelocity->text().toDouble());
    }
}

void ConfigACSAxisPage::on_pushButtonSetAcceleration_clicked()
{
    if (mAxis)
    {
        mAxis->setAcceleration(lineEditMotionAcceleration->text().toDouble());
    }
}

void ConfigACSAxisPage::on_pushButtonSetDeceleration_clicked()
{
    if (mAxis)
    {
        mAxis->setDeceleration(lineEditMotionDeceleration->text().toDouble());
    }
}

void ConfigACSAxisPage::on_pushButtonSetKillDeceleration_clicked()
{
    if (mAxis)
    {
        mAxis->setKillDeceleration(lineEditMotionKillDeceleration->text().toDouble());
    }
}

void ConfigACSAxisPage::on_pushButtonSetJerk_clicked()
{
    if (mAxis)
    {
        if (mAxis)
        mAxis->setJerk(lineEditMotionJerk->text().toDouble());
    }
}

void ConfigACSAxisPage::on_pushButtonMoveTo_clicked()
{
    if (mAxis)
    {
        QVariantMap iStates = mAxis->motorState();
        const bool iEnable = iStates.value(QStringLiteral("Enable")).toBool();
        const bool iInPos = iStates.value(QStringLiteral("InPos")).toBool();
        const bool iMove = iStates.value(QStringLiteral("Move")).toBool();
        const bool iAcc = iStates.value(QStringLiteral("Acc")).toBool();
        if (iEnable && iInPos && !iMove && !iAcc)
        {
            mAxis->moveTo(lineEditPosition->text().toDouble());
        }
        else
        {
            QMessageBox::critical(this, tr("Motion Error"), tr("Motor move in progress or fault"));
        }
    }
}

void ConfigACSAxisPage::on_pushButtonMoveMinus_clicked()
{
    if (mAxis)
    {
        QVariantMap iStates = mAxis->motorState();
        const bool iEnable = iStates.value(QStringLiteral("Enable")).toBool();
        const bool iInPos = iStates.value(QStringLiteral("InPos")).toBool();
        const bool iMove = iStates.value(QStringLiteral("Move")).toBool();
        const bool iAcc = iStates.value(QStringLiteral("Acc")).toBool();
        if (iEnable && iInPos && !iMove && !iAcc)
        {
            mAxis->moveMinus(lineEditDistance->text().toDouble());
        }
        else
        {
            QMessageBox::critical(this, tr("Motion Error"), tr("Motor move in progress or fault"));
        }
    }
}

void ConfigACSAxisPage::on_pushButtonMovePlus_clicked()
{
    if (mAxis)
    {
        QVariantMap iStates = mAxis->motorState();
        const bool iEnable = iStates.value(QStringLiteral("Enable")).toBool();
        const bool iInPos = iStates.value(QStringLiteral("InPos")).toBool();
        const bool iMove = iStates.value(QStringLiteral("Move")).toBool();
        const bool iAcc = iStates.value(QStringLiteral("Acc")).toBool();
        if (iEnable && iInPos && !iMove && !iAcc)
        {
            mAxis->movePlus(lineEditDistance->text().toDouble());
        }
        else
        {
            QMessageBox::critical(this, tr("Motion Error"), tr("Motor move in progress or fault"));
        }
    }
}

void ConfigACSAxisPage::on_pushButtonStop_clicked()
{
    if (mAxis)
    {
        mAxis->halt();
    }
}

void ConfigACSAxisPage::onJogMinusPressed()
{
    if (mAxis)
    {
        QVariantMap iStates = mAxis->motorState();
        const bool iEnable = iStates.value(QStringLiteral("Enable")).toBool();
        const bool iInPos = iStates.value(QStringLiteral("InPos")).toBool();
        const bool iMove = iStates.value(QStringLiteral("Move")).toBool();
        const bool iAcc = iStates.value(QStringLiteral("Acc")).toBool();
        if (iEnable && iInPos && !iMove && !iAcc)
        {
            mAxis->jogMinus(lineEditJogVelocity->text().toDouble());
        }
        else
        {
            QMessageBox::critical(this, tr("Motion Error"), tr("Motor move in progress or fault"));
        }
    }
}

void ConfigACSAxisPage::onJogMinusReleased()
{
    if (mAxis)
    {
        mAxis->halt();
    }
}

void ConfigACSAxisPage::onJogPlusPressed()
{
    if (mAxis)
    {
        QVariantMap iStates = mAxis->motorState();
        const bool iEnable = iStates.value(QStringLiteral("Enable")).toBool();
        const bool iInPos = iStates.value(QStringLiteral("InPos")).toBool();
        const bool iMove = iStates.value(QStringLiteral("Move")).toBool();
        const bool iAcc = iStates.value(QStringLiteral("Acc")).toBool();
        if (iEnable && iInPos && !iMove && !iAcc)
        {
            mAxis->jogPlus(lineEditJogVelocity->text().toDouble());
        }
        else
        {
            QMessageBox::critical(this, tr("Motion Error"), tr("Motor move in progress or fault"));
        }
    }
}

void ConfigACSAxisPage::onJogPlusReleased()
{
    if (mAxis)
    {
        mAxis->halt();
    }
}
