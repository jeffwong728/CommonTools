#ifndef CONFIGACSDEVICEPAGE_H
#define CONFIGACSDEVICEPAGE_H

#include "ui_configacsdevicepage.h"
#include <laser_x_motion.h>
class ACSDevice;
class LaserXMotionDevice;

class ConfigACSDevicePage : public LaserXConfigMotionDeviceWidget, public Ui::ConfigACSDevicePage
{
    Q_OBJECT

public:
    explicit ConfigACSDevicePage(QWidget *parent);
    ~ConfigACSDevicePage();

public:
    void initialize(LaserXMotionDevice* device) override;
    QVariantMap getParameters() const override;

private slots:
    void on_lineEditName_returnPressed();
    void on_lineEditDescription_returnPressed();

private:
    ACSDevice* mDevice = nullptr;
};

#endif // CONFIGACSDEVICEPAGE_H
