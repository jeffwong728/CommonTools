#include "acs_axis.h"
#include <QtCore>
#include <QtConcurrent>
#include <QMutexLocker>

inline bool ACSEQValue(const qreal v0, const qreal v1)
{
    return std::abs(v0 - v1) < 0.000001;
}

ACSAxis::ACSAxis(QObject* parent, const HANDLE devHandle, const int axisNo)
    : LaserXMotionAxis(parent, axisNo)
    , mDevHandle(devHandle)
{
}

ACSAxis::~ACSAxis()
{
}

bool ACSAxis::enabled() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return false;
    }

    int iMotorStatus = 0;
    int ret = acsc_ReadInteger(mDevHandle, ACSC_NONE, const_cast<char *>("MST"), mAxisNo, mAxisNo, ACSC_NONE, ACSC_NONE, &iMotorStatus, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        return false;
    }

    return iMotorStatus & ACSC_MST_ENABLE;
}

QVariantMap ACSAxis::setEnabled(const bool bEnabled) const
{
    QVariantMap results;
    results[QStringLiteral("Success")] = false;

    if (ACSC_INVALID == mDevHandle)
    {
        results[QStringLiteral("ErrorMsg")] = QStringLiteral("Motion device disconnected");
        return results;
    }

    int ret = 0;
    if (bEnabled)
    {
        ret = acsc_Enable(mDevHandle, mAxisNo, ACSC_SYNCHRONOUS);
    }
    else
    {
        ret = acsc_Disable(mDevHandle, mAxisNo, ACSC_SYNCHRONOUS);
    }

    if (!ret)
    {
        results[QStringLiteral("ErrorMsg")] = QStringLiteral("Axis %1 enable error: %2").arg(name()).arg(acsc_GetLastError());
        return results;
    }

    ret = acsc_WaitMotorEnabled(mDevHandle, mAxisNo, bEnabled, 3000);
    if (!ret)
    {
        results[QStringLiteral("ErrorMsg")] = QStringLiteral("Axis %1 enable error: %2").arg(name()).arg(acsc_GetLastError());
        return results;
    }

    results[QStringLiteral("Success")] = true;
    return results;
}

QVariantMap ACSAxis::motorState() const
{
    QVariantMap iStates;
    iStates[QStringLiteral("Success")]      = false;
    iStates[QStringLiteral("Enable")]       = false;
    iStates[QStringLiteral("InPos")]        = false;
    iStates[QStringLiteral("Move")]         = false;
    iStates[QStringLiteral("Acc")]          = false;
    iStates[QStringLiteral("LeftLimit")]    = 0;
    iStates[QStringLiteral("RightLimit")]   = 0;

    if (ACSC_INVALID == mDevHandle)
    {
        iStates[QStringLiteral("ErrorMsg")] = QStringLiteral("Motion device disconnected");
        return iStates;
    }

    int iState = 0;
    int ret = acsc_GetMotorState(mDevHandle, mAxisNo, &iState, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        iStates[QStringLiteral("ErrorMsg")] = QStringLiteral("Get axis %1 state error: %2").arg(name()).arg(acsc_GetLastError());
        return iStates;
    }

    int iFaultMask = 0;
    int iMotorFault = 0;
    ret = acsc_GetFaultMask(mDevHandle, mAxisNo, &iFaultMask, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        iStates[QStringLiteral("ErrorMsg")] = QStringLiteral("Get axis %1 fault mask error: %2").arg(name()).arg(acsc_GetLastError());
        return iStates;
    }

    ret = acsc_GetFault(mDevHandle, mAxisNo, &iMotorFault, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        iStates[QStringLiteral("ErrorMsg")] = QStringLiteral("Get axis %1 motor fault error: %2").arg(name()).arg(acsc_GetLastError());
        return iStates;
    }

    iStates[QStringLiteral("Success")]  = true;
    iStates[QStringLiteral("Enable")]   = static_cast<bool>(iState & ACSC_MST_ENABLE);
    iStates[QStringLiteral("InPos")]    = static_cast<bool>(iState & ACSC_MST_INPOS);
    iStates[QStringLiteral("Move")]     = static_cast<bool>(iState & ACSC_MST_MOVE);
    iStates[QStringLiteral("Acc")]      = static_cast<bool>(iState & ACSC_MST_ACC);

    if (iFaultMask & ACSC_SAFETY_LL)
    {
        iStates[QStringLiteral("LeftLimit")] = (iMotorFault & ACSC_SAFETY_LL) ? 1 : 2;
    }

    if (iFaultMask & ACSC_SAFETY_RL)
    {
        iStates[QStringLiteral("RightLimit")] = (iMotorFault & ACSC_SAFETY_RL) ? 1 : 2;
    }

    return iStates;
}

qreal ACSAxis::actualPosition() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iFPosition = 0;
    int ret = acsc_GetFPosition(mDevHandle, mAxisNo, &iFPosition, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 FPOS error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iFPosition;
}

qreal ACSAxis::commandPosition() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iRPosition = 0;
    int ret = acsc_GetRPosition(mDevHandle, mAxisNo, &iRPosition, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 RPOS error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iRPosition;
}

qreal ACSAxis::actualVelocity() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iFVelocity = 0;
    int ret = acsc_GetFVelocity(mDevHandle, mAxisNo, &iFVelocity, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 FVEL error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iFVelocity;
}

qreal ACSAxis::positionError() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iPositionErr = 0;
    int ret = acsc_ReadReal(mDevHandle, ACSC_NONE, const_cast<char*>("PE"), mAxisNo, mAxisNo, ACSC_NONE, ACSC_NONE, &iPositionErr, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 PE error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iPositionErr;
}

qreal ACSAxis::encoderFactor() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iEFAC = 0;
    int ret = acsc_ReadReal(mDevHandle, ACSC_NONE, const_cast<char*>("EFAC"), mAxisNo, mAxisNo, ACSC_NONE, ACSC_NONE, &iEFAC, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 EFAC error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iEFAC;
}

qreal ACSAxis::encoderOffset() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iEOFFS = 0;
    int ret = acsc_ReadReal(mDevHandle, ACSC_NONE, const_cast<char*>("EOFFS"), mAxisNo, mAxisNo, ACSC_NONE, ACSC_NONE, &iEOFFS, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 EOFFS error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iEOFFS;
}

qreal ACSAxis::velocity() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iVelocity = 0;
    int ret = acsc_GetVelocity(mDevHandle, mAxisNo, &iVelocity, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 velocity error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iVelocity;
}

qreal ACSAxis::acceleration() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iAcceleration = 0;
    int ret = acsc_GetAcceleration(mDevHandle, mAxisNo, &iAcceleration, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 acceleration error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iAcceleration;
}

qreal ACSAxis::deceleration() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iDeceleration = 0;
    int ret = acsc_GetDeceleration(mDevHandle, mAxisNo, &iDeceleration, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 deceleration error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iDeceleration;
}

qreal ACSAxis::killDeceleration() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iKillDeceleration = 0;
    int ret = acsc_GetKillDeceleration(mDevHandle, mAxisNo, &iKillDeceleration, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 kill deceleration error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iKillDeceleration;
}

qreal ACSAxis::jerk() const
{
    if (ACSC_INVALID == mDevHandle)
    {
        return std::nan("");
    }

    double iJerk = 0;
    int ret = acsc_GetJerk(mDevHandle, mAxisNo, &iJerk, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        qDebug() << QStringLiteral("Get axis %1 jerk error: %2").arg(name()).arg(acsc_GetLastError());
        return std::nan("");
    }

    return iJerk;
}

void ACSAxis::setVelocity(const qreal val)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_SetVelocity(mDevHandle, mAxisNo, val, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QVariantMap params;
        QString iErrorMsg = QStringLiteral("Set axis %1 velocity error: %2").arg(name()).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
    }
    else
    {
        QVariantMap params;
        params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 velocity changed to %2").arg(name()).arg(val);
        emit device()->motionDeviceParameterChanged(params);
    }
}

void ACSAxis::setAcceleration(const qreal val)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_SetAcceleration(mDevHandle, mAxisNo, val, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QVariantMap params;
        QString iErrorMsg = QStringLiteral("Set axis %1 acceleration error: %2").arg(name()).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
    }
    else
    {
        QVariantMap params;
        params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 acceleration changed to %2").arg(name()).arg(val);
        emit device()->motionDeviceParameterChanged(params);
    }
}

void ACSAxis::setDeceleration(const qreal val)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_SetDeceleration(mDevHandle, mAxisNo, val, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QVariantMap params;
        QString iErrorMsg = QStringLiteral("Set axis %1 deceleration error: %2").arg(name()).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
    }
    else
    {
        QVariantMap params;
        params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 deceleration changed to %2").arg(name()).arg(val);
        emit device()->motionDeviceParameterChanged(params);
    }
}

void ACSAxis::setKillDeceleration(const qreal val)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_SetKillDeceleration(mDevHandle, mAxisNo, val, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QVariantMap params;
        QString iErrorMsg = QStringLiteral("Set axis %1 kill deceleration error: %2").arg(name()).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
    }
    else
    {
        QVariantMap params;
        params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 kill deceleration changed to %2").arg(name()).arg(val);
        emit device()->motionDeviceParameterChanged(params);
    }
}

void ACSAxis::setJerk(const qreal val)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_SetJerk(mDevHandle, mAxisNo, val, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QVariantMap params;
        QString iErrorMsg = QStringLiteral("Set axis %1 jerk error: %2").arg(name()).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
    }
    else
    {
        QVariantMap params;
        params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 jerk changed to %2").arg(name()).arg(val);
        emit device()->motionDeviceParameterChanged(params);
    }
}

void ACSAxis::moveTo(const qreal pos)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_ToPoint(mDevHandle, 0, mAxisNo, pos, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QString iErrorMsg = QStringLiteral("Axis %1 move to %2 error: %3").arg(name()).arg(pos).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;

        QVariantMap params;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
        return;
    }

    QVariantMap params;
    params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 moved to %2").arg(name()).arg(pos);
    emit device()->motionDeviceParameterChanged(params);
}

void ACSAxis::moveMinus(const qreal distance)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_ToPoint(mDevHandle, ACSC_AMF_RELATIVE, mAxisNo, -qAbs(distance), ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QString iErrorMsg = QStringLiteral("Axis %1 move %2 error: %3").arg(name()).arg(-qAbs(distance)).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;

        QVariantMap params;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
        return;
    }

    QVariantMap params;
    params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 moved %2").arg(name()).arg(-qAbs(distance));
    emit device()->motionDeviceParameterChanged(params);
}

void ACSAxis::movePlus(const qreal distance)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_ToPoint(mDevHandle, ACSC_AMF_RELATIVE, mAxisNo, qAbs(distance), ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QString iErrorMsg = QStringLiteral("Axis %1 move %2 error: %3").arg(name()).arg(qAbs(distance)).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;

        QVariantMap params;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
        return;
    }

    QVariantMap params;
    params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 moved %2").arg(name()).arg(qAbs(distance));
    emit device()->motionDeviceParameterChanged(params);
}

void ACSAxis::jogMinus(const qreal velocity)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = 0;
    if (ACSEQValue(velocity, 0.0))
    {
        ret = acsc_Jog(mDevHandle, 0, mAxisNo, ACSC_NEGATIVE_DIRECTION, ACSC_SYNCHRONOUS);
    }
    else
    {
        ret = acsc_Jog(mDevHandle, ACSC_AMF_VELOCITY, mAxisNo, -qAbs(velocity), ACSC_SYNCHRONOUS);
    }

    if (!ret)
    {
        QString iErrorMsg = QStringLiteral("Axis %1 start negative jog error: %2").arg(name()).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;

        QVariantMap params;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
        return;
    }

    QVariantMap params;
    params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 start negative jog").arg(name());
    emit device()->motionDeviceParameterChanged(params);
}

void ACSAxis::jogPlus(const qreal velocity)
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = 0;
    if (ACSEQValue(velocity, 0.0))
    {
        ret = acsc_Jog(mDevHandle, 0, mAxisNo, ACSC_POSITIVE_DIRECTION, ACSC_SYNCHRONOUS);
    }
    else
    {
        ret = acsc_Jog(mDevHandle, ACSC_AMF_VELOCITY, mAxisNo, qAbs(velocity), ACSC_SYNCHRONOUS);
    }

    if (!ret)
    {
        QString iErrorMsg = QStringLiteral("Axis %1 start positive jog error: %2").arg(name()).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;

        QVariantMap params;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
        return;
    }

    QVariantMap params;
    params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 start positive jog").arg(name());
    emit device()->motionDeviceParameterChanged(params);
}

void ACSAxis::halt()
{
    if (ACSC_INVALID == mDevHandle)
    {
        return;
    }

    int ret = acsc_Halt(mDevHandle, mAxisNo, ACSC_SYNCHRONOUS);
    if (!ret)
    {
        QString iErrorMsg = QStringLiteral("Axis %1 halt error: %2").arg(name()).arg(acsc_GetLastError());
        qDebug() << iErrorMsg;

        QVariantMap params;
        params[QStringLiteral("ErrorMsg")] = iErrorMsg;
        emit device()->motionDeviceErrorOccurred(params);
        return;
    }

    QVariantMap params;
    params[QStringLiteral("InfoMsg")] = QStringLiteral("Axis %1 halted").arg(name());
    emit device()->motionDeviceParameterChanged(params);
}

void ACSAxis::invalidateHandle()
{
    const_cast<HANDLE&>(mDevHandle) = ACSC_INVALID;
}
