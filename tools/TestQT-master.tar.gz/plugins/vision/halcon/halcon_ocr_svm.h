#ifndef HALCON_OCR_SVM_H
#define HALCON_OCR_SVM_H

#include <laser_x_ocr.h>
#include <halconcpp/HalconCpp.h>

class HalconOCRSvm : public LaserXOCR
{
    Q_OBJECT
public:
    HalconOCRSvm(const HalconCpp::HOCRSvm &classifier);
    ~HalconOCRSvm();

public:
    QByteArray getBlob() const override;
    QVariantMap getParams() const override;
    bool writeOCR(const QString& fileName) const override;
    QVariantMap trainOCR(const QVariantMap& params) override;
    QVariantMap doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const override;
    QVariantMap doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const override;

public:
    HalconCpp::HOCRSvm mClassifier;
};

#endif // HALCON_OCR_SVM_H
