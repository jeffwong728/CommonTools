#include "halcon_shape_template.h"
#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
#include <hdevengine/HDevEngineCpp.h>
extern void doDeleteLater(QObject* obj);

HalconShapeTemplate::HalconShapeTemplate(const HalconCpp::HShapeModel& model)
    : LaserXShapeTemplate(nullptr)
    , mModel(model)
{
}

HalconShapeTemplate::~HalconShapeTemplate()
{
}

QByteArray HalconShapeTemplate::getBlob() const
{
    try
    {
        HalconCpp::HSerializedItem hSerializedItem = mModel.SerializeShapeModel();
        Hlong hSize = 0;
        void* hPointer = hSerializedItem.GetSerializedItemPtr(&hSize);

        QByteArray iByteArray(static_cast<char *>(hPointer), hSize);
        return iByteArray;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QByteArray();
    }
}

void HalconShapeTemplate::writeShapeTemplate(const QString& fileName) const
{
    try
    {
        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(fileName.toUtf8().constData());
        mModel.WriteShapeModel(hFileName);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

QVariantMap HalconShapeTemplate::findTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const
{
    QVariantMap iResult;
    if (!mModel.IsInitialized() || mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
    {
        return iResult;
    }

    try
    {
        HalconCpp::HImage rImage;
        HalconCpp::HImage hImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);

        if (region)
        {
            QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
            rImage = hImage.ReduceDomain(hRegion->mRegion);
        }
        else
        {
            rImage = hImage;
        }

        const QString progPath      = params.value(QStringLiteral("ProgPath")).toString();
        const QString procName      = params.value(QStringLiteral("ProcName")).toString();
        const double iAngleStart    = qDegreesToRadians(params.value(QStringLiteral("AngleStart"), 0.0).toReal());
        const double iAngleExtent   = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0.0).toReal());
        const double iMinScore      = params.value(QStringLiteral("MinScore"), 0.8).toReal() * 0.6;
        const double iGreediness    = params.value(QStringLiteral("Greediness"), 0.9).toReal();
        const HalconCpp::HString iSubPixel = HalconCpp::HString::FromUtf8(params.value(QStringLiteral("SubPixel"), QStringLiteral("least_squares")).toString().toUtf8());
        const Hlong iNumMatches     = params.value(QStringLiteral("NumMatches"), 1ll).toLongLong();
        const Hlong iStartLevel     = params.value(QStringLiteral("LevelStart"), 0ll).toLongLong();
        const Hlong iStopLevel      = params.value(QStringLiteral("LevelEnd"), 1ll).toLongLong();
        const Hlong iMaxDeformation = params.value(QStringLiteral("MaxDeformation"), 0ll).toLongLong();
        const double iMaxOverlap    = params.value(QStringLiteral("MaxOverlap"), 0.5).toReal();
        const QString iScaled       = params.value(QStringLiteral("Scaled"), QStringLiteral("none")).toString();
        const qreal iScaleMin       = params.value(QStringLiteral("ScaleMin"), 0.9).toReal();
        const qreal iScaleMax       = params.value(QStringLiteral("ScaleMax"), 1.1).toReal();

        HalconCpp::HTuple hNumLevels;
        hNumLevels.Append(iStartLevel).Append(iStopLevel);

        HalconCpp::HTuple hSubPixel;
        hSubPixel.Append(iSubPixel).Append(HalconCpp::HString(QStringLiteral("max_deformation %1").arg(iMaxDeformation).toStdString().c_str()));

        HalconCpp::HTuple hRow;
        HalconCpp::HTuple hColumn;
        HalconCpp::HTuple hAngle;
        HalconCpp::HTuple hScale;
        HalconCpp::HTuple hScore;

        if (progPath.isEmpty() || procName.isEmpty())
        {
            const HalconCpp::HTuple hAngleStart = iAngleStart;
            const HalconCpp::HTuple hAngleExtent = iAngleExtent;
            const HalconCpp::HTuple hScaleMin = iScaleMin;
            const HalconCpp::HTuple hScaleMax = iScaleMax;
            const HalconCpp::HTuple hMinScore = iMinScore;
            const HalconCpp::HTuple hNumMatches = iNumMatches;
            const HalconCpp::HTuple hMaxOverlap = iMaxOverlap;
            const HalconCpp::HTuple hGreediness = iGreediness;

            if (QStringLiteral("none") != iScaled)
            {
                mModel.FindScaledShapeModel(rImage, hAngleStart, hAngleExtent, hScaleMin, hScaleMax, hMinScore, hNumMatches, \
                    hMaxOverlap, hSubPixel, hNumLevels, hGreediness, &hRow, &hColumn, &hAngle, &hScale, &hScore);
                hAngle = hAngle.TupleDeg();
            }
            else
            {
                mModel.FindShapeModel(rImage, hAngleStart, hAngleExtent, hMinScore, hNumMatches, hMaxOverlap, hSubPixel, \
                    hNumLevels, hGreediness, &hRow, &hColumn, &hAngle, &hScore);
                hScale = HalconCpp::HTuple::TupleGenConst(hScore.Length(), 1.0);
                hAngle = hAngle.TupleDeg();
            }
        }
        else
        {
            HDevEngineCpp::HDevProgram hProgram;
            hProgram.LoadProgram(progPath.toStdWString().c_str());

            HalconCpp::HDict hParams;
            hParams.SetDictTuple("AngleStart", iAngleStart);
            hParams.SetDictTuple("AngleExtent", iAngleExtent);
            hParams.SetDictTuple("ScaleMin", iScaleMin);
            hParams.SetDictTuple("ScaleMax", iScaleMax);
            hParams.SetDictTuple("MinScore", iMinScore);
            hParams.SetDictTuple("NumMatches", iNumMatches);
            hParams.SetDictTuple("MaxOverlap", iMaxOverlap);
            hParams.SetDictTuple("SubPixel", hSubPixel);
            hParams.SetDictTuple("NumLevels", hNumLevels);
            hParams.SetDictTuple("Greediness", iGreediness);
            hParams.SetDictTuple("Scaled", HalconCpp::HString::FromUtf8(iScaled.toUtf8()));

            HDevEngineCpp::HDevProcedure hProc(hProgram, procName.toStdString().c_str());
            HDevEngineCpp::HDevProcedureCall hProcCall(hProc);
            hProcCall.SetInputIconicParamObject(1, rImage);
            hProcCall.SetInputCtrlParamTuple(1, mModel);
            hProcCall.SetInputCtrlParamTuple(2, hParams);
            hProcCall.Execute();

            HalconCpp::HDict hResults(hProcCall.GetOutputCtrlParamTuple(1).H());
            hRow = hResults.GetDictTuple("Row");
            hColumn = hResults.GetDictTuple("Column");
            hAngle = hResults.GetDictTuple("Angle");
            hScale = hResults.GetDictTuple("Scale");
            hScore = hResults.GetDictTuple("Score");
            iResult[QStringLiteral("ErrorId")] = hResults.GetDictTuple("ErrorId").L();
        }

        QVector<qreal> xList;
        QVector<qreal> yList;
        QVector<qreal> angleList;
        QVector<qreal> scaleList;
        QVector<qreal> scoreList;
        xList.reserve(hRow.Length());
        yList.reserve(hRow.Length());
        angleList.reserve(hRow.Length());
        scaleList.reserve(hRow.Length());
        scoreList.reserve(hRow.Length());
        for (Hlong rr = 0; rr < hRow.Length(); ++rr)
        {
            xList.push_back(hColumn[rr].D());
            yList.push_back(hRow[rr].D());
            angleList.push_back(hAngle[rr].D());
            scaleList.push_back(hScale[rr].D());
            scoreList.push_back(hScore[rr].D());
        }

        iResult[QStringLiteral("XList")] = QVariant::fromValue(xList);
        iResult[QStringLiteral("YList")] = QVariant::fromValue(yList);
        iResult[QStringLiteral("AngleList")] = QVariant::fromValue(angleList);
        iResult[QStringLiteral("ScaleList")] = QVariant::fromValue(scaleList);
        iResult[QStringLiteral("ScoreList")] = QVariant::fromValue(scoreList);

        return iResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconShapeTemplate::findTemplates(const std::vector<LXShapeTemplate>& templates,
    const cv::Mat& mat,
    const LXRegion& region,
    const QVariantMap& params) const
{
    try
    {
        QVariantMap results;
        if (templates.empty() || mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
        {
            return results;
        }

        HalconCpp::HImage hImage;
        HalconCpp::HImage rImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
        if (region)
        {
            QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
            rImage = hImage.ReduceDomain(hRegion->mRegion);
        }
        else
        {
            rImage = hImage;
        }

        std::vector<HalconCpp::HShapeModel> hShapeModels;
        hShapeModels.reserve(templates.size());
        for (const LXShapeTemplate &lxTemp : templates)
        {
            QSharedPointer<HalconShapeTemplate> hTemp = lxTemp.dynamicCast<HalconShapeTemplate>();
            if (hTemp)
            {
                hShapeModels.push_back(hTemp->mModel);
            }
        }

        if (hShapeModels.empty())
        {
            return results;
        }

        HalconCpp::HShapeModelArray hShapeModelArray(hShapeModels.data(), static_cast<Hlong>(hShapeModels.size()));
        const HalconCpp::HShapeModel* hShapeModel = hShapeModelArray.Tools();
        if (!hShapeModel)
        {
            return results;
        }

        const double iAngleStart = qDegreesToRadians(params.value(QStringLiteral("AngleStart"), 0.0).toReal());
        const double iAngleExtent = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0.0).toReal());
        const double iMinScore = params.value(QStringLiteral("MinScore"), 0.8).toReal();
        const double iGreediness = params.value(QStringLiteral("Greediness"), 0.9).toReal();
        const HalconCpp::HString iSubPixel = params[QStringLiteral("SubPixel")].toBool() ? "least_squares" : "none";
        const Hlong iNumMatches = 1;
        const double iMaxOverlap = 0.5;
        const Hlong iNumLevels = 0;

        HalconCpp::HTuple iRow;
        HalconCpp::HTuple iColumn;
        HalconCpp::HTuple iAngle;
        HalconCpp::HTuple iScale;
        HalconCpp::HTuple iScore;
        HalconCpp::HTuple iModelIndex;

        const bool iScaled = params.value(QStringLiteral("Scaled"), false).toBool();
        const qreal iScaleMin = params.value(QStringLiteral("ScaleMin"), 0.9).toReal();
        const qreal iScaleMax = params.value(QStringLiteral("ScaleMax"), 1.1).toReal();

        if (iScaled)
        {
            hShapeModel->FindScaledShapeModels(rImage, iAngleStart, iAngleExtent, iScaleMin, iScaleMax, iMinScore, iNumMatches, \
                iMaxOverlap, iSubPixel, iNumLevels, iGreediness, &iRow, &iColumn, &iAngle, &iScale, &iScore, &iModelIndex);
        }
        else
        {
            iScale.Append(1.);
            hShapeModel->FindShapeModels(rImage, iAngleStart, iAngleExtent, iMinScore, iNumMatches, iMaxOverlap, iSubPixel, \
                iNumLevels, iGreediness, &iRow, &iColumn, &iAngle, &iScore, &iModelIndex);
        }

        if (1 == iRow.Length() && 1 == iColumn.Length() \
            && 1 == iAngle.Length() && 1 == iScale.Length() \
            && 1 == iScore.Length() && 1 == iModelIndex.Length())
        {
            results[QStringLiteral("X")] = iColumn[0].D();
            results[QStringLiteral("Y")] = iRow[0].D();
            results[QStringLiteral("Angle")] = iAngle[0].D();
            results[QStringLiteral("Scale")] = iScale[0].D();
            results[QStringLiteral("Score")] = iScore[0].D();
            results[QStringLiteral("ModelIndex")] = iModelIndex[0].L();

            return results;
        }
        else
        {
            return results;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}
