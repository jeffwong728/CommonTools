#include "halcon_util.h"
#include "halcon_ocr_mlp.h"
#include "halcon_image.h"
#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
#include <hdevengine/HDevEngineCpp.h>
extern void doDeleteLater(QObject* obj);

HalconOCRMlp::HalconOCRMlp(const HalconCpp::HOCRMlp& classifier)
    : LaserXOCR(nullptr)
    , mClassifier(classifier)
{
}

HalconOCRMlp::~HalconOCRMlp()
{
}

QByteArray HalconOCRMlp::getBlob() const
{
    try
    {
        HalconCpp::HSerializedItem hSerializedItem = mClassifier.SerializeOcrClassMlp();
        Hlong hSize = 0;
        void* hPointer = hSerializedItem.GetSerializedItemPtr(&hSize);

        QByteArray iByteArray(static_cast<char*>(hPointer), hSize);
        return iByteArray;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QByteArray();
    }
}

QVariantMap HalconOCRMlp::getParams() const
{
    QVariantMap iParams;
    iParams[QStringLiteral("OCRType")] = QStringLiteral("Mlp");
    return iParams;
}

bool HalconOCRMlp::writeOCR(const QString& fileName) const
{
    try
    {
        if (!mClassifier.IsInitialized())
        {
            return false;
        }

        mClassifier.WriteOcrClassMlp(HalconCpp::HString::FromUtf8(fileName.toUtf8().constData()));
        return true;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return false;
    }
}

QVariantMap HalconOCRMlp::trainOCR(const QVariantMap& params)
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        if (!QFileInfo::exists(iTrainingFile))
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 not exists").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HalconCpp::HTuple hCharacters, hCharacterCount;
        const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
        HalconCpp::ReadOcrTrainfNames(hTrainingFile, &hCharacters, &hCharacterCount);

        const QVariantMap iTrainParams = params.value(QStringLiteral("TrainParams")).toMap();
        const HalconCpp::HTuple hWidthCharacter = HalconUtil::toHTuple(iTrainParams.value(QStringLiteral("WidthCharacter"), 8).toLongLong());
        const HalconCpp::HTuple hHeightCharacter = HalconUtil::toHTuple(iTrainParams.value(QStringLiteral("HeightCharacter"), 8).toLongLong());
        const HalconCpp::HTuple hFeatures = HalconUtil::getHParam(iTrainParams, QStringLiteral("Features"), QStringList() << QStringLiteral("default"));
        const HalconCpp::HTuple hNumHidden = HalconUtil::toHTuple(iTrainParams.value(QStringLiteral("NumHidden"), 80).toLongLong());
        const HalconCpp::HTuple hPreprocessing = HalconUtil::getHParam(iTrainParams, QStringLiteral("Preprocessing"), QStringLiteral("none"));
        const HalconCpp::HTuple hNumComponents = HalconUtil::toHTuple(iTrainParams.value(QStringLiteral("NumComponents"), 10).toLongLong());
        const HalconCpp::HTuple hMaxIterations = HalconUtil::toHTuple(iTrainParams.value(QStringLiteral("MaxIterations"), 200).toLongLong());
        const HalconCpp::HTuple hRandSeed = HalconUtil::toHTuple(iTrainParams.value(QStringLiteral("RandSeed"), 42).toLongLong());
        const HalconCpp::HTuple hWeightTolerance = HalconUtil::getHParam(iTrainParams, QStringLiteral("WeightTolerance"), 1.0);
        const HalconCpp::HTuple hErrorTolerance = HalconUtil::getHParam(iTrainParams, QStringLiteral("ErrorTolerance"), 0.01);
        const HalconCpp::HString hInterpolation = HalconUtil::getHParam(iTrainParams, QStringLiteral("Interpolation"), QStringLiteral("constant"));;

        HalconCpp::HTuple hErrorLog;
        hCharacters = hCharacters.TupleSort().TupleUniq();
        mClassifier.CreateOcrClassMlp(hWidthCharacter, hHeightCharacter, hInterpolation, hFeatures, hCharacters, hNumHidden, hPreprocessing, hNumComponents, hRandSeed);
        const qreal hError = mClassifier.TrainfOcrClassMlp(hTrainingFile, hMaxIterations, hWeightTolerance, hErrorTolerance, &hErrorLog);

        QVector<qreal> iErrorLog;
        iErrorLog.reserve(hErrorLog.Length());
        for (Hlong ll = 0; ll < hErrorLog.Length(); ++ll)
        {
            iErrorLog.push_back(hErrorLog[ll].D());
        }
        
        iResult[QStringLiteral("Success")] = true;
        iResult[QStringLiteral("Error")] = hError;
        iResult[QStringLiteral("ErrorLog")] = QVariant::fromValue(iErrorLog);
        return iResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconOCRMlp::doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    try
    {
        QVariantMap rResult;
        QSharedPointer<HalconImage> spImg = mat.dynamicCast<HalconImage>();
        if (!spImg)
        {
            return rResult;
        }

        QSharedPointer<HalconRegion> hRegion = cRegion.dynamicCast<HalconRegion>();
        if (!hRegion)
        {
            return rResult;
        }

        if (hRegion->area() < 1)
        {
            qDebug() << QStringLiteral("Char box empty error");
            return rResult;
        }

        QString iProgPath = params.value(QStringLiteral("SegmentScriptPath")).toString();
        QString iProcName = params.value(QStringLiteral("SegmentProcedureName")).toString();
        if (!QFileInfo::exists(iProgPath))
        {
            qDebug() << QStringLiteral("Segment script %1 not exists").arg(iProgPath);
            return rResult;
        }

        bool iProcExists = false;
        HDevEngineCpp::HDevProgram hProgram;
        hProgram.LoadProgram(iProgPath.toStdWString().c_str());
        HalconCpp::HTuple hProcNames = hProgram.GetLocalProcedureNames();
        for (Hlong ll = 0; ll < hProcNames.Length(); ++ll)
        {
            QString iThisName = QString::fromUtf8(hProcNames[ll].S().ToUtf8());
            if (iThisName == iProcName)
            {
                iProcExists = true;
                break;
            }
        }

        if (!iProcExists)
        {
            qDebug() << QStringLiteral("Procedure %1 not exists in %2").arg(iProcName).arg(iProgPath);
            return rResult;
        }

        HDevEngineCpp::HDevProcedure hProc(hProgram, iProcName.toStdString().c_str());
        HDevEngineCpp::HDevProcedureCall hProcCall(hProc);

        HalconCpp::HImage rImage = spImg->mImage.ReduceDomain(hRegion->mRegion);
        hProcCall.SetInputIconicParamObject(1, rImage);
        hProcCall.Execute();

        HalconCpp::HRegion hCharRegion = hProcCall.GetOutputIconicParamObject(1);
        if (!hCharRegion.IsInitialized())
        {
            return rResult;
        }

        Hlong hRow1 = 0;
        Hlong hColumn1 = 0;
        Hlong hRow2 = 0;
        Hlong hColumn2 = 0;
        hCharRegion.SmallestRectangle1(&hRow1, &hColumn1, &hRow2, &hColumn2);

        double iConfidence = 0;
        HalconCpp::HString hClass = mClassifier.DoOcrSingleClassMlp(hCharRegion, rImage, 1, &iConfidence);
        rResult[QStringLiteral("CharacterClass")] = QString::fromUtf8(hClass.ToUtf8());
        rResult[QStringLiteral("Confidence")] = iConfidence;
        rResult[QStringLiteral("CharacterRect")] = QRectF(hColumn1-3, hRow1-3, hColumn2 - hColumn1 + 6, hRow2 - hRow1 + 6);

        return rResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        qDebug() << QString::fromUtf8(e.Message());
        return QVariantMap();
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

QVariantMap HalconOCRMlp::doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    try
    {
        QVariantMap rResult;
        QSharedPointer<HalconImage> spImg = mat.dynamicCast<HalconImage>();
        if (!spImg)
        {
            return rResult;
        }

        QSharedPointer<HalconRegion> hRegion = cRegion.dynamicCast<HalconRegion>();
        if (!hRegion)
        {
            return rResult;
        }

        if (hRegion->area() < 1)
        {
            qDebug() << QStringLiteral("Char box empty error");
            return rResult;
        }

        QString iProgPath = params.value(QStringLiteral("SegmentScriptPath")).toString();
        QString iProcName = params.value(QStringLiteral("SegmentProcedureName")).toString();
        if (!QFileInfo::exists(iProgPath))
        {
            qDebug() << QStringLiteral("Segment script %1 not exists").arg(iProgPath);
            return rResult;
        }

        bool iProcExists = false;
        HDevEngineCpp::HDevProgram hProgram;
        hProgram.LoadProgram(iProgPath.toStdWString().c_str());
        HalconCpp::HTuple hProcNames = hProgram.GetLocalProcedureNames();
        for (Hlong ll = 0; ll < hProcNames.Length(); ++ll)
        {
            QString iThisName = QString::fromUtf8(hProcNames[ll].S().ToUtf8());
            if (iThisName == iProcName)
            {
                iProcExists = true;
                break;
            }
        }

        if (!iProcExists)
        {
            qDebug() << QStringLiteral("Procedure %1 not exists in %2").arg(iProcName).arg(iProgPath);
            return rResult;
        }

        HDevEngineCpp::HDevProcedure hProc(hProgram, iProcName.toStdString().c_str());
        HDevEngineCpp::HDevProcedureCall hProcCall(hProc);

        HalconCpp::HDict hSegParams = HalconUtil::toHDict(params.value(QStringLiteral("SegmentParams")).toMap());
        HalconCpp::HDict hSelParams = HalconUtil::toHDict(params.value(QStringLiteral("SelectParams")).toMap());
        HalconCpp::HImage rImage = spImg->mImage.ReduceDomain(hRegion->mRegion);
        hProcCall.SetInputIconicParamObject(1, rImage);
        hProcCall.SetInputCtrlParamTuple(1, hSegParams);
        hProcCall.SetInputCtrlParamTuple(2, hSelParams);
        hProcCall.Execute();

        HalconCpp::HRegion hCharRegions = hProcCall.GetOutputIconicParamObject(1);
        if (!hCharRegions.IsInitialized())
        {
            return rResult;
        }

        HalconCpp::HTuple hRow1 = 0;
        HalconCpp::HTuple hColumn1 = 0;
        HalconCpp::HTuple hRow2 = 0;
        HalconCpp::HTuple hColumn2 = 0;
        hCharRegions.SmallestRectangle1(&hRow1, &hColumn1, &hRow2, &hColumn2);

        HalconCpp::HTuple hConfidence;
        HalconCpp::HTuple hClasses = mClassifier.DoOcrMultiClassMlp(hCharRegions, rImage, &hConfidence);

        QStringList iCharacterClasses;
        QVector<qreal> iConfidences;
        QVector<QRectF> iCharacterRects;
        for (Hlong ll = 0; ll < hCharRegions.CountObj(); ++ll)
        {
            iCharacterClasses.push_back(QString::fromUtf8(hClasses[ll].S().ToUtf8()));
            iConfidences.push_back(hConfidence[ll].D());
            iCharacterRects.push_back(QRectF(hColumn1[ll].D() - 3, hRow1[ll].D() - 3, hColumn2[ll].D() - hColumn1[ll].D() + 6, hRow2[ll].D() - hRow1[ll].D() + 6));
        }

        rResult[QStringLiteral("CharacterClasses")] = iCharacterClasses;
        rResult[QStringLiteral("Confidences")] = QVariant::fromValue(iConfidences);
        rResult[QStringLiteral("CharacterRects")] = QVariant::fromValue(iCharacterRects);
        return rResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        qDebug() << QString::fromUtf8(e.Message());
        return QVariantMap();
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}
