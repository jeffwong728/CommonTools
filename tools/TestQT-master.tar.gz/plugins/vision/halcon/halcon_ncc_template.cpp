#include "halcon_ncc_template.h"
#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
extern void doDeleteLater(QObject* obj);

HalconNCCTemplate::HalconNCCTemplate(const HalconCpp::HNCCModel& model)
    : LaserXNCCTemplate(nullptr)
    , mModel(model)
{
}

HalconNCCTemplate::~HalconNCCTemplate()
{
}

qreal HalconNCCTemplate::getAngleStart() const
{
    try
    {
        if (mModel.IsInitialized())
        {
            double iAngleStart;
            double iAngleExtent;
            double iAngleStep;
            HalconCpp::HString iMetric;
            if (H_MSG_TRUE == mModel.GetNccModelParams(&iAngleStart, &iAngleExtent, &iAngleStep, &iMetric))
            {
                return iAngleStart;
            }
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return 0;
}

qreal HalconNCCTemplate::getAngleExtent() const
{
    try
    {
        if (mModel.IsInitialized())
        {
            double iAngleStart;
            double iAngleExtent;
            double iAngleStep;
            HalconCpp::HString iMetric;
            if (H_MSG_TRUE == mModel.GetNccModelParams(&iAngleStart, &iAngleExtent, &iAngleStep, &iMetric))
            {
                return iAngleExtent;
            }
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return 0;
}

qreal HalconNCCTemplate::getAngleStep() const
{
    try
    {
        if (mModel.IsInitialized())
        {
            double iAngleStart;
            double iAngleExtent;
            double iAngleStep;
            HalconCpp::HString iMetric;
            if (H_MSG_TRUE == mModel.GetNccModelParams(&iAngleStart, &iAngleExtent, &iAngleStep, &iMetric))
            {
                return iAngleStep;
            }
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return 0;
}

qlonglong HalconNCCTemplate::getNumLevels() const
{
    try
    {
        if (mModel.IsInitialized())
        {
            HalconCpp::HTuple iNumLevels;
            HalconCpp::HTuple iAngleStart;
            HalconCpp::HTuple iAngleExtent;
            HalconCpp::HTuple iAngleStep;
            HalconCpp::HTuple iMetric;
            HalconCpp::GetNccModelParams(mModel.GetHandle(), &iNumLevels, nullptr, nullptr, nullptr, nullptr);
            return iNumLevels.L();
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return 0;
}

bool HalconNCCTemplate::getUsePolarity() const
{
    try
    {
        if (mModel.IsInitialized())
        {
            double iAngleStart;
            double iAngleExtent;
            double iAngleStep;
            HalconCpp::HString iMetric;
            if (H_MSG_TRUE == mModel.GetNccModelParams(&iAngleStart, &iAngleExtent, &iAngleStep, &iMetric))
            {
                return HalconCpp::HString("use_polarity") == iMetric;
            }
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return false;
}

QByteArray HalconNCCTemplate::getBlob() const
{
    try
    {
        if (mModel.IsInitialized())
        {
            HalconCpp::HSerializedItem hSerializedItem = mModel.SerializeNccModel();
            Hlong hSize = 0;
            void* hPointer = hSerializedItem.GetSerializedItemPtr(&hSize);

            QByteArray iByteArray(static_cast<char *>(hPointer), hSize);
            return iByteArray;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return QByteArray();
}

void HalconNCCTemplate::writeNCCTemplate(const QString& fileName) const
{
    try
    {
        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(fileName.toUtf8().constData());
        mModel.WriteNccModel(hFileName);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

QVariantMap HalconNCCTemplate::findTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const
{
    QVariantMap iResults;
    if (!mModel.IsInitialized() || mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
    {
        return iResults;
    }

    try
    {
        HalconCpp::HImage hImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);

        const HalconCpp::HTuple hAngleStart  = qDegreesToRadians(params.value(QStringLiteral("AngleStart"), 0.0).toReal());
        const HalconCpp::HTuple hAngleExtent = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0.0).toReal());
        const HalconCpp::HTuple hMinScore    = params.value(QStringLiteral("MinScore"), 0.8).toReal();
        const HalconCpp::HTuple hNumMatches  = params.value(QStringLiteral("NumMatches"), 1).toInt();
        const HalconCpp::HTuple hMaxOverlap  = params.value(QStringLiteral("MaxOverlap"), 0.5).toReal();
        const HalconCpp::HString hSubPixel   = HalconCpp::HString::FromUtf8(params.value(QStringLiteral("SubPixel"), QStringLiteral("true")).toString().toUtf8());

        const int iLevelStart = params.value(QStringLiteral("LevelStart"), 0).toInt();
        const int iLevelEnd = params.value(QStringLiteral("LevelEnd"), 1).toInt();
        HalconCpp::HTuple iNumLevels = HalconCpp::HTuple().Append(iLevelStart).Append(iLevelEnd);

        HalconCpp::HImage rImage;
        if (region)
        {
            QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
            rImage = hImage.ReduceDomain(hRegion->mRegion);
        }
        else
        {
            rImage = hImage;
        }

        HalconCpp::HTuple hRow;
        HalconCpp::HTuple hColumn;
        HalconCpp::HTuple hAngle;
        HalconCpp::HTuple hScore;
        mModel.FindNccModel(rImage, hAngleStart, hAngleExtent, hMinScore, hNumMatches, hMaxOverlap, hSubPixel, iNumLevels, &hRow, &hColumn, &hAngle, &hScore);

        QVector<qreal> xList;
        QVector<qreal> yList;
        QVector<qreal> angleList;
        QVector<qreal> scaleList;
        QVector<qreal> scoreList;
        xList.reserve(hRow.Length());
        yList.reserve(hRow.Length());
        angleList.reserve(hRow.Length());
        scaleList.reserve(hRow.Length());
        scoreList.reserve(hRow.Length());
        for (Hlong rr = 0; rr < hRow.Length(); ++rr)
        {
            xList.push_back(hColumn[rr].D());
            yList.push_back(hRow[rr].D());
            angleList.push_back(qRadiansToDegrees(hAngle[rr].D()));
            scaleList.push_back(1.0);
            scoreList.push_back(hScore[rr].D());
        }

        iResults[QStringLiteral("XList")] = QVariant::fromValue(xList);
        iResults[QStringLiteral("YList")] = QVariant::fromValue(yList);
        iResults[QStringLiteral("AngleList")] = QVariant::fromValue(angleList);
        iResults[QStringLiteral("ScaleList")] = QVariant::fromValue(scaleList);
        iResults[QStringLiteral("ScoreList")] = QVariant::fromValue(scoreList);

        return iResults;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResults;
    }
}
