#ifndef HALCON_MEASURE_MODEL_H
#define HALCON_MEASURE_MODEL_H

#include <laser_x_measure_model.h>
#include <halconcpp/HalconCpp.h>

class HalconMeasureModel : public LaserXMeasureModel
{
    Q_OBJECT
public:
    HalconMeasureModel(const HalconCpp::HMetrologyModel &hMetrologyModel);
    ~HalconMeasureModel();

public:
    QByteArray getBlob() const override;
    void writeMeasureModel(const QString& fileName) const override;
    void setModelImageSize(const QSize& size) override;
    void setReferenceSystem(const QPointF& origin, const qreal angle) override;
    void alignModel(const QPointF& origin, const qreal angle) override;
    QVariant addLineMeasure(const QVariantMap& params) override;
    QVariant addCircleMeasure(const QVariantMap& params) override;
    QVariant addRectangle2Measure(const QVariantMap& params) override;
    QVariant addEllipseMeasure(const QVariantMap& params) override;
    void clearMeasure(const QVariant& index) override;
    void applyMeasure(const cv::Mat& mat) const override;
    qlonglong getNumInstances(const QVariant& index) const override;
    QVariantList getMeasureIndices() const override;
    QVariant getMeasureType(const QVariant &index) const override;
    QVariantMap getAllBoxEdges(const QVariant& index) const override;
    QVariantMap getMeasureResult(const QVariant& index, const QVariant& instance) const override;
    QVariantMap getPostResult(const QJsonObject& rawObj, const QString& progPath, const QString& procName) const override;

public:
    HalconCpp::HMetrologyModel mMetrologyModel;
};

#endif // HALCON_MEASURE_MODEL_H
