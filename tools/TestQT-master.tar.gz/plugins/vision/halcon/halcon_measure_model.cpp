#include "halcon_measure_model.h"
#include <QtCore>
#include <QtGui>
#include <hdevengine/HDevEngineCpp.h>
extern void doDeleteLater(QObject* obj);

HalconMeasureModel::HalconMeasureModel(const HalconCpp::HMetrologyModel &hMetrologyModel)
    : LaserXMeasureModel(nullptr)
    , mMetrologyModel(hMetrologyModel)
{
}

HalconMeasureModel::~HalconMeasureModel()
{
}

QByteArray HalconMeasureModel::getBlob() const
{
    try
    {
        HalconCpp::HSerializedItem hSerializedItem = mMetrologyModel.SerializeMetrologyModel();
        Hlong hSize = 0;
        void* hPointer = hSerializedItem.GetSerializedItemPtr(&hSize);

        QByteArray iByteArray(static_cast<char*>(hPointer), hSize);
        return iByteArray;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QByteArray();
    }
}

void HalconMeasureModel::writeMeasureModel(const QString& fileName) const
{
    try
    {
        return mMetrologyModel.WriteMetrologyModel(HalconCpp::HString::FromUtf8(fileName.toUtf8().constData()));
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

void HalconMeasureModel::setModelImageSize(const QSize& size)
{
    try
    {
        mMetrologyModel.SetMetrologyModelImageSize(size.width(), size.height());
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

void HalconMeasureModel::setReferenceSystem(const QPointF& origin, const qreal angle)
{
    try
    {
        HalconCpp::HTuple GenParamValue;
        GenParamValue.Append(origin.y()).Append(origin.x()).Append(qDegreesToRadians(angle));
        mMetrologyModel.SetMetrologyModelParam("reference_system", GenParamValue);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

void HalconMeasureModel::alignModel(const QPointF& origin, const qreal angle)
{
    try
    {
        mMetrologyModel.AlignMetrologyModel(origin.y(), origin.x(), qDegreesToRadians(angle));
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

QVariant HalconMeasureModel::addLineMeasure(const QVariantMap& params)
{
    try
    {
        const QPointF BeginPoint            = params[QStringLiteral("StartPoint")].toPointF();
        const QPointF EndPoint              = params[QStringLiteral("EndPoint")].toPointF();
        const qreal RowBegin                = BeginPoint.y();
        const qreal ColumnBegin             = BeginPoint.x();
        const qreal RowEnd                  = EndPoint.y();
        const qreal ColumnEnd               = EndPoint.x();
        const qreal MeasureLength1          = params[QStringLiteral("SemiSearchLength")].toReal();
        const qreal MeasureLength2          = params[QStringLiteral("SemiSmoothLength")].toReal();
        const qreal MeasureSigma            = params[QStringLiteral("Sigma")].toReal();
        const qreal MeasureThreshold        = params[QStringLiteral("Threshold")].toReal();
        const qlonglong num_measures        = params[QStringLiteral("NumSamplePoints")].toLongLong();
        const QString measure_select        = params[QStringLiteral("Select")].toString();
        const QString measure_transition    = params[QStringLiteral("Transition")].toString();
        const qreal min_score               = params[QStringLiteral("MinScore")].toReal();
        const qlonglong num_instances       = params[QStringLiteral("NumInstances")].toLongLong();

        HalconCpp::HTuple GenParamName;
        HalconCpp::HTuple GenParamValue;

        GenParamName.Append("num_measures");
        GenParamValue.Append(num_measures);

        GenParamName.Append("measure_select");
        GenParamValue.Append(measure_select.toStdString().c_str());

        GenParamName.Append("measure_transition");
        GenParamValue.Append(measure_transition.toStdString().c_str());

        GenParamName.Append("min_score");
        GenParamValue.Append(min_score);

        GenParamName.Append("num_instances");
        GenParamValue.Append(num_instances);

        return mMetrologyModel.AddMetrologyObjectLineMeasure(RowBegin, ColumnBegin, RowEnd, ColumnEnd, MeasureLength1, MeasureLength2, MeasureSigma, MeasureThreshold, GenParamName, GenParamValue);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return 0;
    }
}

QVariant HalconMeasureModel::addCircleMeasure(const QVariantMap& params)
{
    try
    {
        const QPointF CenterPoint           = params[QStringLiteral("CenterPoint")].toPointF();
        const qreal Row                     = CenterPoint.y();
        const qreal Column                  = CenterPoint.x();
        const qreal Radius                  = params[QStringLiteral("Radius")].toReal();
        const qreal MeasureLength1          = params[QStringLiteral("SemiSearchLength")].toReal();
        const qreal MeasureLength2          = params[QStringLiteral("SemiSmoothLength")].toReal();
        const qreal MeasureSigma            = params[QStringLiteral("Sigma")].toReal();
        const qreal MeasureThreshold        = params[QStringLiteral("Threshold")].toReal();
        const qlonglong num_measures        = params[QStringLiteral("NumSamplePoints")].toLongLong();
        const QString measure_select        = params[QStringLiteral("Select")].toString();
        const QString measure_transition    = params[QStringLiteral("Transition")].toString();
        const qreal min_score               = params[QStringLiteral("MinScore")].toReal();
        const qlonglong num_instances       = params[QStringLiteral("NumInstances")].toLongLong();

        HalconCpp::HTuple GenParamName;
        HalconCpp::HTuple GenParamValue;

        GenParamName.Append("num_measures");
        GenParamValue.Append(num_measures);

        GenParamName.Append("measure_select");
        GenParamValue.Append(measure_select.toStdString().c_str());

        GenParamName.Append("measure_transition");
        GenParamValue.Append(measure_transition.toStdString().c_str());

        GenParamName.Append("min_score");
        GenParamValue.Append(min_score);

        GenParamName.Append("num_instances");
        GenParamValue.Append(num_instances);

        GenParamName.Append("start_phi");
        GenParamValue.Append(qDegreesToRadians(params[QStringLiteral("StartAngle")].toReal()));

        GenParamName.Append("end_phi");
        GenParamValue.Append(qDegreesToRadians(params[QStringLiteral("EndAngle")].toReal()));

        GenParamName.Append("point_order");
        GenParamValue.Append("positive");

        return mMetrologyModel.AddMetrologyObjectCircleMeasure(Row, Column, Radius, MeasureLength1, MeasureLength2, MeasureSigma, MeasureThreshold, GenParamName, GenParamValue);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return 0;
    }
}

QVariant HalconMeasureModel::addRectangle2Measure(const QVariantMap& params)
{
    try
    {
        const QPointF CenterPoint           = params[QStringLiteral("CenterPoint")].toPointF();
        const qreal Row                     = CenterPoint.y();
        const qreal Column                  = CenterPoint.x();
        const qreal Phi                     = qDegreesToRadians(params[QStringLiteral("Angle")].toReal());
        const qreal Length1                 = params[QStringLiteral("SemiMajorAxis")].toReal();
        const qreal Length2                 = params[QStringLiteral("SemiMinorAxis")].toReal();
        const qreal MeasureLength1          = params[QStringLiteral("SemiSearchLength")].toReal();
        const qreal MeasureLength2          = params[QStringLiteral("SemiSmoothLength")].toReal();
        const qreal MeasureSigma            = params[QStringLiteral("Sigma")].toReal();
        const qreal MeasureThreshold        = params[QStringLiteral("Threshold")].toReal();
        const qlonglong num_measures        = params[QStringLiteral("NumSamplePoints")].toLongLong();
        const QString measure_select        = params[QStringLiteral("Select")].toString();
        const QString measure_transition    = params[QStringLiteral("Transition")].toString();
        const qreal min_score               = params[QStringLiteral("MinScore")].toReal();
        const qlonglong num_instances       = params[QStringLiteral("NumInstances")].toLongLong();

        HalconCpp::HTuple GenParamName;
        HalconCpp::HTuple GenParamValue;

        GenParamName.Append("num_measures");
        GenParamValue.Append(num_measures);

        GenParamName.Append("measure_select");
        GenParamValue.Append(measure_select.toStdString().c_str());

        GenParamName.Append("measure_transition");
        GenParamValue.Append(measure_transition.toStdString().c_str());

        GenParamName.Append("min_score");
        GenParamValue.Append(min_score);

        GenParamName.Append("num_instances");
        GenParamValue.Append(num_instances);

        return mMetrologyModel.AddMetrologyObjectRectangle2Measure(Row, Column, Phi, Length1, Length2, MeasureLength1, MeasureLength2, MeasureSigma, MeasureThreshold, GenParamName, GenParamValue);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return 0;
    }
}

QVariant HalconMeasureModel::addEllipseMeasure(const QVariantMap& params)
{
    try
    {
        const QPointF CenterPoint           = params[QStringLiteral("CenterPoint")].toPointF();
        const qreal Row                     = CenterPoint.y();
        const qreal Column                  = CenterPoint.x();
        const qreal Phi                     = qDegreesToRadians(params[QStringLiteral("Angle")].toReal());
        const qreal Radius1                 = params[QStringLiteral("SemiMajorAxis")].toReal();
        const qreal Radius2                 = params[QStringLiteral("SemiMinorAxis")].toReal();
        const qreal MeasureLength1          = params[QStringLiteral("SemiSearchLength")].toReal();
        const qreal MeasureLength2          = params[QStringLiteral("SemiSmoothLength")].toReal();
        const qreal MeasureSigma            = params[QStringLiteral("Sigma")].toReal();
        const qreal MeasureThreshold        = params[QStringLiteral("Threshold")].toReal();
        const qlonglong num_measures        = params[QStringLiteral("NumSamplePoints")].toLongLong();
        const QString measure_select        = params[QStringLiteral("Select")].toString();
        const QString measure_transition    = params[QStringLiteral("Transition")].toString();
        const qreal min_score               = params[QStringLiteral("MinScore")].toReal();
        const qlonglong num_instances       = params[QStringLiteral("NumInstances")].toLongLong();

        HalconCpp::HTuple GenParamName;
        HalconCpp::HTuple GenParamValue;

        GenParamName.Append("num_measures");
        GenParamValue.Append(num_measures);

        GenParamName.Append("measure_select");
        GenParamValue.Append(measure_select.toStdString().c_str());

        GenParamName.Append("measure_transition");
        GenParamValue.Append(measure_transition.toStdString().c_str());

        GenParamName.Append("min_score");
        GenParamValue.Append(min_score);

        GenParamName.Append("num_instances");
        GenParamValue.Append(num_instances);

        GenParamName.Append("start_phi");
        GenParamValue.Append(0.);

        GenParamName.Append("end_phi");
        GenParamValue.Append(M_PI*2);

        GenParamName.Append("point_order");
        GenParamValue.Append("positive");

        GenParamName.Append("max_num_iterations");
        GenParamValue.Append(30);

        return mMetrologyModel.AddMetrologyObjectEllipseMeasure(Row, Column, Phi, Radius1, Radius2, MeasureLength1, MeasureLength2, MeasureSigma, MeasureThreshold, GenParamName, GenParamValue);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return 0;
    }
}

void HalconMeasureModel::clearMeasure(const QVariant& index)
{
    try
    {
        if (index.canConvert<qlonglong>())
        {
            HalconCpp::HTuple hIndex = index.toLongLong();
            mMetrologyModel.ClearMetrologyObject(hIndex);
        }
        else if (index.canConvert<QString>())
        {
            HalconCpp::HString hIndex = HalconCpp::HString::FromUtf8(index.toString().toUtf8().constData());
            mMetrologyModel.ClearMetrologyObject(hIndex);
        }
        else
        {
            // do nothing
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

void HalconMeasureModel::applyMeasure(const cv::Mat& mat) const
{
    try
    {
        if (!mat.empty() && 1 == mat.channels() && CV_8U == mat.depth())
        {
            HalconCpp::HImage hImage;
            hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
            mMetrologyModel.ApplyMetrologyModel(hImage);
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

qlonglong HalconMeasureModel::getNumInstances(const QVariant& index) const
{
    try
    {
        if (!index.canConvert<qlonglong>())
        {
            return 0;
        }

        qreal iNumInstances = mMetrologyModel.GetMetrologyObjectNumInstances(index.toLongLong());
        return qRound64(iNumInstances);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return 0;
    }
}

QVariantList HalconMeasureModel::getMeasureIndices() const
{
    QVariantList iIndices;
    try
    {
        HalconCpp::HTuple Indices = mMetrologyModel.GetMetrologyObjectIndices();
        iIndices.reserve(Indices.Length());
        for (Hlong nn = 0; nn < Indices.Length(); ++nn)
        {
            iIndices.push_back(Indices[nn].L());
        }

        return iIndices;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iIndices;
    }
}

QVariant HalconMeasureModel::getMeasureType(const QVariant &index) const
{
    try
    {
        HalconCpp::HTuple hObjectType = mMetrologyModel.GetMetrologyObjectParam(index.toLongLong(), "object_type");
        QString qObjType = QString::fromUtf8(hObjectType.ToString().ToUtf8());
        return qObjType;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QString();
    }
}

QVariantMap HalconMeasureModel::getAllBoxEdges(const QVariant& index) const
{
    try
    {
        HalconCpp::HXLDCont hBoxs;
        HalconCpp::HTuple hRows, hCols;
        HalconCpp::HString hTransition("all");
        if (index.canConvert<qlonglong>())
        {
            HalconCpp::HTuple hIndex = index.toLongLong();
            hBoxs = mMetrologyModel.GetMetrologyObjectMeasures(hIndex, hTransition, &hRows, &hCols);
        }
        else if (index.canConvert<QString>())
        {
            HalconCpp::HString hIndex = HalconCpp::HString::FromUtf8(index.toString().toUtf8().constData());
            hBoxs = mMetrologyModel.GetMetrologyObjectMeasures(hIndex, hTransition, &hRows, &hCols);
        }
        else
        {
            return QVariantMap();
        }

        QVector<QPointF> iEdges;
        iEdges.reserve(hRows.Length());
        for (Hlong nn = 0; nn < hRows.Length(); ++nn)
        {
            iEdges.emplaceBack(hCols[nn].D(), hRows[nn].D());
        }

        QVariantMap iResult;
        iResult[QStringLiteral("AllEdges")] = QVariant::fromValue(iEdges);
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

QVariantMap HalconMeasureModel::getMeasureResult(const QVariant& index, const QVariant& instance) const
{
    try
    {
        if (!index.canConvert<qlonglong>() || !instance.canConvert<qlonglong>())
        {
            return QVariantMap();
        }

        const qlonglong iIndex = index.toLongLong();
        const qlonglong iInstance = instance.toLongLong();

        QVariantMap iResult;
        HalconCpp::HTuple hScore = mMetrologyModel.GetMetrologyObjectResult(iIndex, iInstance, "result_type", "score");
        iResult[QStringLiteral("Score")] = hScore.D();

        HalconCpp::HTuple hRows = mMetrologyModel.GetMetrologyObjectResult(iIndex, iInstance, "used_edges", "row");
        HalconCpp::HTuple hCols = mMetrologyModel.GetMetrologyObjectResult(iIndex, iInstance, "used_edges", "column");
        HalconCpp::HTuple hAmplitudes = mMetrologyModel.GetMetrologyObjectResult(iIndex, iInstance, "used_edges", "amplitude");
        if (hRows.Length() > 0)
        {
            QVector<QPointF> iUsedEdges;
            QVector<qreal> iAmplitudes;
            for (Hlong nn = 0; nn < hRows.Length(); ++nn)
            {
                iUsedEdges.emplaceBack(hCols[nn].D(), hRows[nn].D());
                iAmplitudes.push_back(hAmplitudes[nn].D());
            }

            iResult[QStringLiteral("UsedEdges")] = QVariant::fromValue(iUsedEdges);
            iResult[QStringLiteral("Amplitudes")] = QVariant::fromValue(iAmplitudes);
        }
        else
        {
            return QVariantMap();
        }

        HalconCpp::HTuple hObjectType = mMetrologyModel.GetMetrologyObjectParam(iIndex, "object_type");
        QString qObjType = QString::fromUtf8(hObjectType.ToString().ToUtf8());
        // line circle ellipse rectangle
        if (QStringLiteral("\"line\"") == qObjType)
        {
            HalconCpp::HTuple hParameter = mMetrologyModel.GetMetrologyObjectResult(iIndex, iInstance, "result_type", "all_param");
            if (4 == hParameter.Length())
            {
                iResult[QStringLiteral("StartPoint")] = QPointF(hParameter[1].D(), hParameter[0].D());
                iResult[QStringLiteral("EndPoint")] = QPointF(hParameter[3].D(), hParameter[2].D());
            }
            else
            {
                return QVariantMap();
            }
        }
        else if (QStringLiteral("\"circle\"") == qObjType)
        {
            HalconCpp::HTuple hParameter = mMetrologyModel.GetMetrologyObjectResult(iIndex, iInstance, "result_type", "all_param");
            if (3 == hParameter.Length())
            {
                iResult[QStringLiteral("CenterPoint")] = QPointF(hParameter[1].D(), hParameter[0].D());
                iResult[QStringLiteral("Radius")] = hParameter[2].D();
            }
            else
            {
                return QVariantMap();
            }
        }
        else if (QStringLiteral("\"rectangle\"") == qObjType || QStringLiteral("\"ellipse\"") == qObjType)
        {
            HalconCpp::HTuple hParameter = mMetrologyModel.GetMetrologyObjectResult(iIndex, iInstance, "result_type", "all_param");
            if (5 == hParameter.Length())
            {
                iResult[QStringLiteral("CenterPoint")] = QPointF(hParameter[1].D(), hParameter[0].D());
                iResult[QStringLiteral("Angle")] = qRadiansToDegrees(hParameter[2].D());
                iResult[QStringLiteral("SemiMajorAxis")] = hParameter[3].D();
                iResult[QStringLiteral("SemiMinorAxis")] = hParameter[4].D();
            }
            else
            {
                return QVariantMap();
            }
        }
        else
        {
            return QVariantMap();
        }

        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

QVariantMap HalconMeasureModel::getPostResult(const QJsonObject& rawObj, const QString& progPath, const QString& procName) const
{
    try
    {
        HalconCpp::HDict hParams;
        if (rawObj.contains(QStringLiteral("Lines")) && rawObj.value(QStringLiteral("Lines")).isArray())
        {
            QJsonArray iLines = rawObj.value(QStringLiteral("Lines")).toArray();
            for (const auto &iLineRef : iLines)
            {
                QJsonObject iLine = iLineRef.toObject();
                const QString iName = iLine.value(QStringLiteral("Name")).toString();
                const double iStartX = iLine.value(QStringLiteral("StartX")).toDouble();
                const double iStartY = iLine.value(QStringLiteral("StartY")).toDouble();
                const double iEndX = iLine.value(QStringLiteral("EndX")).toDouble();
                const double iEndY = iLine.value(QStringLiteral("EndY")).toDouble();
                hParams.SetDictTuple(HalconCpp::HString::FromUtf8(iName.toUtf8()), HalconCpp::HTuple(iStartX).Append(iStartY).Append(iEndX).Append(iEndY));
            }
        }

        if (rawObj.contains(QStringLiteral("Rects")) && rawObj.value(QStringLiteral("Rects")).isArray())
        {
            QJsonArray iRects = rawObj.value(QStringLiteral("Rects")).toArray();
            for (const auto& iRectRef : iRects)
            {
                QJsonObject iRect = iRectRef.toObject();
                const QString iName = iRect.value(QStringLiteral("Name")).toString();
                const double iCX = iRect.value(QStringLiteral("CenterX")).toDouble();
                const double iCY = iRect.value(QStringLiteral("CenterY")).toDouble();
                const double iA = iRect.value(QStringLiteral("Angle")).toDouble();
                const double iLen1 = iRect.value(QStringLiteral("SemiMajorAxis")).toDouble();
                const double iLen2 = iRect.value(QStringLiteral("SemiMinorAxis")).toDouble();
                hParams.SetDictTuple(HalconCpp::HString::FromUtf8(iName.toUtf8()), HalconCpp::HTuple(iCX).Append(iCY).Append(iA).Append(iLen1).Append(iLen2));
            }
        }

        if (rawObj.contains(QStringLiteral("Circles")) && rawObj.value(QStringLiteral("Circles")).isArray())
        {
            QJsonArray iCircles = rawObj.value(QStringLiteral("Circles")).toArray();
            for (const auto& iCircleRef : iCircles)
            {
                QJsonObject iCircle = iCircleRef.toObject();
                const QString iName = iCircle.value(QStringLiteral("Name")).toString();
                const double iCX = iCircle.value(QStringLiteral("CenterX")).toDouble();
                const double iCY = iCircle.value(QStringLiteral("CenterY")).toDouble();
                const double iRadius = iCircle.value(QStringLiteral("Radius")).toDouble();
                hParams.SetDictTuple(HalconCpp::HString::FromUtf8(iName.toUtf8()), HalconCpp::HTuple(iCX).Append(iCY).Append(iRadius));
            }
        }

        if (rawObj.contains(QStringLiteral("Ellipses")) && rawObj.value(QStringLiteral("Ellipses")).isArray())
        {
            QJsonArray iEllipses = rawObj.value(QStringLiteral("Ellipses")).toArray();
            for (const auto& iEllipseRef : iEllipses)
            {
                QJsonObject iEllipse = iEllipseRef.toObject();
                const QString iName = iEllipse.value(QStringLiteral("Name")).toString();
                const double iCX = iEllipse.value(QStringLiteral("CenterX")).toDouble();
                const double iCY = iEllipse.value(QStringLiteral("CenterY")).toDouble();
                const double iA = iEllipse.value(QStringLiteral("Angle")).toDouble();
                const double iLen1 = iEllipse.value(QStringLiteral("SemiMajorAxis")).toDouble();
                const double iLen2 = iEllipse.value(QStringLiteral("SemiMinorAxis")).toDouble();
                hParams.SetDictTuple(HalconCpp::HString::FromUtf8(iName.toUtf8()), HalconCpp::HTuple(iCX).Append(iCY).Append(iA).Append(iLen1).Append(iLen2));
            }
        }

        HDevEngineCpp::HDevProgram hProgram;
        hProgram.LoadProgram(progPath.toStdWString().c_str());

        HDevEngineCpp::HDevProcedure hProc(hProgram, procName.toStdString().c_str());
        HDevEngineCpp::HDevProcedureCall hProcCall(hProc);
        hProcCall.SetInputCtrlParamTuple(1, hParams);
        hProcCall.Execute();

        QVariantMap iResults;
        iResults[QStringLiteral("ErrorId")] = 1;

        QVector<qreal> xList;
        QVector<qreal> yList;
        QVector<qreal> angleList;

        HalconCpp::HDict hResults(hProcCall.GetOutputCtrlParamTuple(1).H());
        HalconCpp::HTuple hKeys = hResults.GetDictParam("keys", HalconCpp::HTuple());
        for (Hlong ll = 0; ll < hKeys.Length(); ++ll)
        {
            HalconCpp::HString hKey = hKeys[ll].S();
            HalconCpp::HTuple hValue = hResults.GetDictTuple(hKey);
            QString iKey = QString::fromUtf8(hKey.ToUtf8());
            if (QStringLiteral("ErrorId") == iKey)
            {
                iResults[QStringLiteral("ErrorId")] = hValue.L();
                continue;
            }

            if (QStringLiteral("Row") == iKey)
            {
                for (Hlong ll = 0; ll < hValue.Length(); ++ll)
                {
                    yList.push_back(hValue[ll].D());
                }
                continue;
            }

            if (QStringLiteral("Column") == iKey)
            {
                for (Hlong ll = 0; ll < hValue.Length(); ++ll)
                {
                    xList.push_back(hValue[ll].D());
                }
                continue;
            }

            if (QStringLiteral("Angle") == iKey)
            {
                for (Hlong ll = 0; ll < hValue.Length(); ++ll)
                {
                    angleList.push_back(hValue[ll].D());
                }
                continue;
            }

            QString iType = QString::fromUtf8(hValue[0].S().ToUtf8());
            if (QStringLiteral("point") == iType)
            {
                iResults[iKey] = QPointF(hValue[1].D(), hValue[2].D());
            }
            else if (QStringLiteral("line") == iType)
            {
                iResults[iKey] = QLineF(hValue[1].D(), hValue[2].D(), hValue[3].D(), hValue[4].D());
            }
            else if (QStringLiteral("scalar") == iType)
            {
                iResults[iKey] = hValue[1].D();
            }
            else
            {
                qWarning() << QStringLiteral("Unknown result type");
            }
        }

        iResults[QStringLiteral("XList")] = QVariant::fromValue(xList);
        iResults[QStringLiteral("YList")] = QVariant::fromValue(yList);
        iResults[QStringLiteral("AngleList")] = QVariant::fromValue(angleList);

        return iResults;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        iResult[QStringLiteral("ErrorId")] = 1;
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        iResult[QStringLiteral("ErrorId")] = 1;
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}
