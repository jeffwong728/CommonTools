#ifndef HALCON_UTIL_H
#define HALCON_UTIL_H

#include <QtCore>
#include <halconcpp/HalconCpp.h>

class HalconUtil
{
public:
    static HalconCpp::HTuple toHTuple(const QVariant &var);
    static HalconCpp::HDict toHDict(const QVariantMap& params);
    static HalconCpp::HTuple getHParam(const QVariantMap & params, const QString &key, const QVariant &defVal);
};

#endif // HALCON_UTIL_H
