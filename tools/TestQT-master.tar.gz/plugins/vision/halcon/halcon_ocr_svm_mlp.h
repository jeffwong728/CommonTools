#ifndef HALCON_OCR_SVM_MLP_H
#define HALCON_OCR_SVM_MLP_H

#include <laser_x_ocr.h>
#include <halconcpp/HalconCpp.h>

class HalconOCRSvmMlp : public LaserXOCR
{
    Q_OBJECT
public:
    HalconOCRSvmMlp(const HalconCpp::HOCRSvm &svm, const HalconCpp::HOCRMlp &mlp);
    ~HalconOCRSvmMlp();

public:
    QByteArray getBlob() const override;
    QVariantMap getParams() const override;
    bool writeOCR(const QString& fileName) const override;
    QVariantMap trainOCR(const QVariantMap& params) override;
    QVariantMap doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const override;
    QVariantMap doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const override;

public:
    HalconCpp::HOCRSvm mSvm;
    HalconCpp::HOCRMlp mMlp;
};

#endif // HALCON_OCR_SVM_MLP_H
