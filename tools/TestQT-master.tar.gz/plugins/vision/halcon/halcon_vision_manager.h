#ifndef HALCON_VISION_MANAGER_H
#define HALCON_VISION_MANAGER_H

#include "halcon_vision_global.h"
#include <laser_x_image.h>
#include <laser_x_vision.h>
#include <QObject>
#include <memory>

class HalconVisionManager : public LaserXVisionManager
{
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LaserXVisionManagerInterfaceIID)
    Q_INTERFACES(LaserXVisionManager)
public:
    HalconVisionManager();
    ~HalconVisionManager();

public:
    LXImage readImage(const QString &fileName) const override;
    LXImage fromCVMat(const cv::Mat& mat, const bool deepCopy = true) const override;
    LXImage fromQImage(const QImage& image, const bool deepCopy = true) const override;

    LXRegion genRegion(const QJsonObject& object) const override;
    LXRegion genRectangle1(const QRectF& rect) const override;
    LXRegion genRectangle2(const QRectF& rect, const qreal phi) const override;
    LXRegion genCircle(const QPointF& center, const qreal radius) const override;
    LXRegion genRegionPolygonFilled(const QPolygonF& polygon) const override;
    LXRegion threshold(const cv::Mat& mat, const double minGray, const double maxGray) const override;
    LXNCCTemplate readNccTemplate(const QByteArray& blob) const override;
    LXNCCTemplate createNccTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const override;
    LXShapeTemplate readShapeTemplate(const QByteArray& blob) const override;
    LXShapeTemplate createShapeTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const override;
    LXRegionList inspectShapeTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const override;
    LXMeasureModel readMeasureModel(const QByteArray& blob) const override;
    LXMeasureModel createMeasureModel(const QVariantMap& params) const override;
    LXOCR createOCR(const QVariantMap& params) const override;
    LXOCR readOCR(const QByteArray& blob, const QVariantMap& params) const override;
    LXOCR readOCR(const QString& fileName, const QVariantMap& params) const override;
    LXTextModel createTextModelReader(const QVariantMap& params) const override;
    QVariantMap applyDeepOcr(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const override;
    QVariantMap applyDeepOcr(const LXImage& mat, const LXRegion& region, const QVariantMap& params) const override;
    QVariantMap vectorAngleToAffine(const QPointF& rOrigin, const qreal rAngle, const QPointF& aOrigin, const qreal aAngle) const override;
    bool saveImagePart(const cv::Mat& mat, const QString& fileName, const QRectF& rectPart) const override;
    LXImage rotateImage(const cv::Mat& mat, const qreal phi) const override;
    LXImage alignImage(const cv::Mat& mat, const QPointF& rOrigin, const qreal rAngle, const QPointF& aOrigin, const qreal aAngle) const override;
    QVariantMap doBlobAnalysis(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const override;
    QVariantMap segmentOCRSample(const QVariantMap& params) const override;
    QVariantMap appendOCRSample(const QVariantMap& params) const override;
    QVariantMap replaceOCRSamples(const QVariantMap& params) const override;
    QVariantMap readOCRCharacters(const QVariantMap& params) const override;
    QVariantMap packOCRSamples(const QVariantMap& params) const override;

private:
    QVariantMap segmentOCRSampleFull(const QVariantMap& params) const;
    QVariantMap segmentOCRSampleReduced(const QVariantMap& params) const;
    QVariantMap appendOCRSampleFull(const QVariantMap& params) const;
    QVariantMap appendOCRSampleReduced(const QVariantMap& params) const;
};

#endif // HALCON_VISION_MANAGER_H
