#ifndef HALCON_REGION_H
#define HALCON_REGION_H

#include <laser_x_region.h>
#include <halconcpp/HalconCpp.h>

class HalconRegion : public LaserXRegion
{
    Q_OBJECT
public:
    HalconRegion(const HalconCpp::HRegion &region);
    ~HalconRegion();

public:
    void writeRegion(const QString& fileName) const override;
    qlonglong area() const override;
    QPointF center() const override;
    QVariantMap ellipticAxis() const override;
    QImage toLabel(const QSize& size) const override;
    LXRegion connection() const override;
    LXRegion fillHoles() const override;
    LXRegion dilationCircle(const qreal radius) const override;
    LXRegion closingCircle(const qreal radius) const override;
    LXRegion closingRectangle1(const QSize& size) const override;
    LXRegion openingCircle(const qreal radius) const override;
    LXRegion openingRectangle1(const QSize& size) const override;
    QVector<QPolygonF> getPolygons(const qreal tolerance) const override;
    qlonglong countObj() const override;
    QVariantMap smallestRectangle2() const override;
    QVariantMap smallestCircle() const override;
    LXRegion selectRegion(const qlonglong index) const override;
    LXRegion selectArea(const qreal minArea, const qreal maxArea) const override;
    LXRegion selectCircularity(const qreal minCircularity, const qreal maxCircularity) const override;
    LXRegion selectOuterRadius(const qreal minOuterRadius, const qreal maxOuterRadius) const override;
    LXRegion selectRectangularity(const qreal minRectangularity, const qreal maxRectangularity) const override;
    LXRegion selectRect2SemiMajorLen(const qreal minSemiMajorLen, const qreal maxSemiMajorLen) const override;
    LXRegion selectRect2SemiMinorLen(const qreal minSemiMinorLen, const qreal maxSemiMinorLen) const override;

public:
    HalconCpp::HRegion mRegion;
};

#endif // HALCON_REGION_H
