#include "halcon_util.h"
#include "halcon_ocr_svm.h"
#include "halcon_image.h"
#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
#include <hdevengine/HDevEngineCpp.h>
extern void doDeleteLater(QObject* obj);

HalconOCRSvm::HalconOCRSvm(const HalconCpp::HOCRSvm& classifier)
    : LaserXOCR(nullptr)
    , mClassifier(classifier)
{
}

HalconOCRSvm::~HalconOCRSvm()
{
}

QByteArray HalconOCRSvm::getBlob() const
{
    try
    {
        HalconCpp::HSerializedItem hSerializedItem = mClassifier.SerializeOcrClassSvm();
        Hlong hSize = 0;
        void* hPointer = hSerializedItem.GetSerializedItemPtr(&hSize);

        QByteArray iByteArray(static_cast<char*>(hPointer), hSize);
        return iByteArray;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QByteArray();
    }
}

QVariantMap HalconOCRSvm::getParams() const
{
    QVariantMap iParams;
    iParams[QStringLiteral("OCRType")] = QStringLiteral("Svm");
    return iParams;
}

bool HalconOCRSvm::writeOCR(const QString& fileName) const
{
    try
    {
        if (!mClassifier.IsInitialized())
        {
            return false;
        }

        mClassifier.WriteOcrClassSvm(HalconCpp::HString::FromUtf8(fileName.toUtf8().constData()));
        return true;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return false;
    }
}

QVariantMap HalconOCRSvm::trainOCR(const QVariantMap& params)
{
    Q_UNUSED(params);
    QVariantMap iResult;
    const QString iErrorMsg = QStringLiteral("SVM OCR classifier can't be used alone");
    iResult[QStringLiteral("Success")] = false;
    iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
    qDebug() << iErrorMsg;
    return iResult;
}

QVariantMap HalconOCRSvm::doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    Q_UNUSED(mat);
    Q_UNUSED(cRegion);
    Q_UNUSED(params);
    QVariantMap iResult;
    const QString iErrorMsg = QStringLiteral("SVM OCR classifier can't be used alone");
    iResult[QStringLiteral("Success")] = false;
    iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
    qDebug() << iErrorMsg;
    return iResult;
}

QVariantMap HalconOCRSvm::doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    Q_UNUSED(mat);
    Q_UNUSED(cRegion);
    Q_UNUSED(params);
    QVariantMap iResult;
    const QString iErrorMsg = QStringLiteral("SVM OCR classifier can't be used alone");
    iResult[QStringLiteral("Success")] = false;
    iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
    qDebug() << iErrorMsg;
    return iResult;
}
