#ifndef HALCON_TEXT_MODEL_H
#define HALCON_TEXT_MODEL_H

#include <opencv2/opencv.hpp>
#include <laser_x_text_model.h>
#include <halconcpp/HalconCpp.h>

class HalconTextModel : public LaserXTextModel
{
    Q_OBJECT
public:
    HalconTextModel(const HalconCpp::HTextModel &textModel);
    ~HalconTextModel();

public:
    void setParams(const QVariantMap& params) const override;
    bool findText(const cv::Mat& mat, const LXRegion& region) override;
    bool findText(const LXImage& mat, const LXRegion& region) override;
    LXRegion getTextObject(const QVariantMap& params) override;
    QVariantMap getTextResult(const QVariantMap& params) override;
    void clearTextResult() override;

public:
    HalconCpp::HTextModel mTextModel;
    HalconCpp::HTextResult mTextResult;
};

#endif // HALCON_TEXT_MODEL_H
