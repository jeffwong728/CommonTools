#include "halcon_contour.h"
#include <QtCore>
#include <QtGui>
extern void doDeleteLater(QObject* obj);

HalconContour::HalconContour(const HalconCpp::HXLDCont& xldCont)
    : LaserXContour(nullptr)
    , mXLDCont(xldCont)
{
}

HalconContour::~HalconContour()
{
}

void HalconContour::writeContour(const QString& fileName) const
{
    try
    {
        return mXLDCont.WriteContourXldDxf(HalconCpp::HString::FromUtf8(fileName.toUtf8().constData()));
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}
