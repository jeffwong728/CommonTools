#include "halcon_util.h"
#include "halcon_ocr_svm_mlp.h"
#include "halcon_image.h"
#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
#include <hdevengine/HDevEngineCpp.h>
extern void doDeleteLater(QObject* obj);

HalconOCRSvmMlp::HalconOCRSvmMlp(const HalconCpp::HOCRSvm &svm, const HalconCpp::HOCRMlp &mlp)
    : LaserXOCR(nullptr)
    , mSvm(svm)
    , mMlp(mlp)
{
}

HalconOCRSvmMlp::~HalconOCRSvmMlp()
{
}

QByteArray HalconOCRSvmMlp::getBlob() const
{
    try
    {
        Hlong hSvmSize = 0;
        HalconCpp::HSerializedItem hSvmItem = mSvm.SerializeOcrClassSvm();
        void* hSvmPointer = hSvmItem.GetSerializedItemPtr(&hSvmSize);
        QByteArray iSvmBytes(static_cast<char*>(hSvmPointer), hSvmSize);

        Hlong hMlpSize = 0;
        HalconCpp::HSerializedItem hMlpItem = mMlp.SerializeOcrClassMlp();
        void* hMlpPointer = hMlpItem.GetSerializedItemPtr(&hMlpSize);
        QByteArray iMlpBytes(static_cast<char*>(hMlpPointer), hMlpSize);

        return iSvmBytes + iMlpBytes;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QByteArray();
    }
}

QVariantMap HalconOCRSvmMlp::getParams() const
{
    Hlong hSvmSize = 0;
    HalconCpp::HSerializedItem hSvmItem = mSvm.SerializeOcrClassSvm();
    hSvmItem.GetSerializedItemPtr(&hSvmSize);

    Hlong hMlpSize = 0;
    HalconCpp::HSerializedItem hMlpItem = mMlp.SerializeOcrClassMlp();
    hMlpItem.GetSerializedItemPtr(&hMlpSize);

    QVariantMap iParams;
    iParams[QStringLiteral("OCRType")] = QStringLiteral("SvmMlp");
    iParams[QStringLiteral("SvmSize")] = hSvmSize;
    iParams[QStringLiteral("MlpSize")] = hMlpSize;
    return iParams;
}

bool HalconOCRSvmMlp::writeOCR(const QString& fileName) const
{
    try
    {
        if (!mSvm.IsInitialized() || !mMlp.IsInitialized())
        {
            return false;
        }

        mSvm.WriteOcrClassSvm(HalconCpp::HString::FromUtf8((fileName + QStringLiteral(".osc")).toUtf8().constData()));
        mMlp.WriteOcrClassMlp(HalconCpp::HString::FromUtf8((fileName + QStringLiteral(".omc")).toUtf8().constData()));
        return true;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return false;
    }
}

QVariantMap HalconOCRSvmMlp::trainOCR(const QVariantMap& params)
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        if (!QFileInfo::exists(iTrainingFile))
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 not exists").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HalconCpp::HTuple hCharacters, hCharacterCount;
        const HalconCpp::HString hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
        HalconCpp::ReadOcrTrainfNames(hTrainingFile, &hCharacters, &hCharacterCount);

        const QVariantMap        iTrainParams       = params.value(QStringLiteral("TrainParams")).toMap();
        const Hlong              hWidthCharacter    = iTrainParams.value(QStringLiteral("WidthCharacter"), 8).toLongLong();
        const Hlong              hHeightCharacter   = iTrainParams.value(QStringLiteral("HeightCharacter"), 10).toLongLong();
        const HalconCpp::HTuple  hFeatures          = HalconUtil::getHParam(iTrainParams, QStringLiteral("Features"), QStringList() << QStringLiteral("default"));
        const Hlong              hNumHidden         = iTrainParams.value(QStringLiteral("NumHidden"), 80).toLongLong();
        const HalconCpp::HTuple  hPreprocessing     = HalconUtil::getHParam(iTrainParams, QStringLiteral("Preprocessing"), QStringLiteral("none"));
        const Hlong              hNumComponents     = iTrainParams.value(QStringLiteral("NumComponents"), 10).toLongLong();
        const HalconCpp::HTuple  hMaxIterations     = HalconUtil::toHTuple(iTrainParams.value(QStringLiteral("MaxIterations"), 200).toLongLong());
        const Hlong              hRandSeed          = iTrainParams.value(QStringLiteral("RandSeed"), 42).toLongLong();
        const HalconCpp::HTuple  hWeightTolerance   = HalconUtil::getHParam(iTrainParams, QStringLiteral("WeightTolerance"), 1.0);
        const HalconCpp::HTuple  hErrorTolerance    = HalconUtil::getHParam(iTrainParams, QStringLiteral("ErrorTolerance"), 0.01);
        const HalconCpp::HString hInterpolation     = HalconUtil::getHParam(iTrainParams, QStringLiteral("Interpolation"), QStringLiteral("constant"));
        const HalconCpp::HString hKernelType        = HalconUtil::getHParam(iTrainParams, QStringLiteral("KernelType"), QStringLiteral("rbf"));
        const double             hKernelParam       = iTrainParams.value(QStringLiteral("KernelParam"), 0.02).toDouble();
        const double             hNu                = iTrainParams.value(QStringLiteral("Nu"), 0.05).toDouble();
        const HalconCpp::HString hMode              = HalconUtil::getHParam(iTrainParams, QStringLiteral("Mode"), QStringLiteral("one-versus-one"));
        const double             hEpsilon           = iTrainParams.value(QStringLiteral("Epsilon"), 0.001).toDouble();
        const HalconCpp::HString hTrainMode         = HalconUtil::getHParam(iTrainParams, QStringLiteral("TrainMode"), QStringLiteral("default"));

        hCharacters = hCharacters.TupleSort().TupleUniq();
        mSvm.CreateOcrClassSvm(hWidthCharacter, hHeightCharacter, hInterpolation, hFeatures, hCharacters, hKernelType, hKernelParam, hNu, hMode, hPreprocessing, hNumComponents);
        mSvm.TrainfOcrClassSvm(hTrainingFile, hEpsilon, hTrainMode);

        HalconCpp::HTuple hErrorLog;
        mMlp.CreateOcrClassMlp(hWidthCharacter, hHeightCharacter, hInterpolation, hFeatures, hCharacters, hNumHidden, hPreprocessing, hNumComponents, hRandSeed);
        const qreal hError = mMlp.TrainfOcrClassMlp(hTrainingFile, hMaxIterations, hWeightTolerance, hErrorTolerance, &hErrorLog);

        QVector<qreal> iErrorLog;
        iErrorLog.reserve(hErrorLog.Length());
        for (Hlong ll = 0; ll < hErrorLog.Length(); ++ll)
        {
            iErrorLog.push_back(hErrorLog[ll].D());
        }

        iResult[QStringLiteral("Success")] = true;
        iResult[QStringLiteral("Error")] = hError;
        iResult[QStringLiteral("ErrorLog")] = QVariant::fromValue(iErrorLog);
        return iResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconOCRSvmMlp::doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    Q_UNUSED(mat);
    Q_UNUSED(cRegion);
    Q_UNUSED(params);
    QVariantMap iResult;
    const QString iErrorMsg = QStringLiteral("SVM OCR classifier can't be used alone");
    iResult[QStringLiteral("Success")] = false;
    iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
    qDebug() << iErrorMsg;
    return iResult;
}

QVariantMap HalconOCRSvmMlp::doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    try
    {
        QVariantMap rResult;
        QSharedPointer<HalconImage> spImg = mat.dynamicCast<HalconImage>();
        if (!spImg)
        {
            return rResult;
        }

        QSharedPointer<HalconRegion> hRegion = cRegion.dynamicCast<HalconRegion>();
        if (!hRegion)
        {
            return rResult;
        }

        if (hRegion->area() < 1)
        {
            qDebug() << QStringLiteral("Char box empty error");
            return rResult;
        }

        QString iProgPath = params.value(QStringLiteral("SegmentScriptPath")).toString();
        QString iProcName = params.value(QStringLiteral("SegmentProcedureName")).toString();
        if (!QFileInfo::exists(iProgPath))
        {
            qDebug() << QStringLiteral("Segment script %1 not exists").arg(iProgPath);
            return rResult;
        }

        bool iProcExists = false;
        HDevEngineCpp::HDevProgram hProgram;
        hProgram.LoadProgram(iProgPath.toStdWString().c_str());
        HalconCpp::HTuple hProcNames = hProgram.GetLocalProcedureNames();
        for (Hlong ll = 0; ll < hProcNames.Length(); ++ll)
        {
            QString iThisName = QString::fromUtf8(hProcNames[ll].S().ToUtf8());
            if (iThisName == iProcName)
            {
                iProcExists = true;
                break;
            }
        }

        if (!iProcExists)
        {
            qDebug() << QStringLiteral("Procedure %1 not exists in %2").arg(iProcName).arg(iProgPath);
            return rResult;
        }

        HDevEngineCpp::HDevProcedure hProc(hProgram, iProcName.toStdString().c_str());
        HDevEngineCpp::HDevProcedureCall hProcCall(hProc);

        HalconCpp::HDict hSegParams = HalconUtil::toHDict(params.value(QStringLiteral("SegmentParams")).toMap());
        HalconCpp::HDict hSelParams = HalconUtil::toHDict(params.value(QStringLiteral("SelectParams")).toMap());
        HalconCpp::HImage rImage = spImg->mImage.ReduceDomain(hRegion->mRegion);
        hProcCall.SetInputIconicParamObject(1, rImage);
        hProcCall.SetInputCtrlParamTuple(1, hSegParams);
        hProcCall.SetInputCtrlParamTuple(2, hSelParams);
        hProcCall.Execute();

        HalconCpp::HRegion hCharRegions = hProcCall.GetOutputIconicParamObject(1);
        if (!hCharRegions.IsInitialized())
        {
            return rResult;
        }

        HalconCpp::HTuple hRow1 = 0;
        HalconCpp::HTuple hColumn1 = 0;
        HalconCpp::HTuple hRow2 = 0;
        HalconCpp::HTuple hColumn2 = 0;
        hCharRegions.SmallestRectangle1(&hRow1, &hColumn1, &hRow2, &hColumn2);
        const Hlong iNumChars = hCharRegions.CountObj();

        HalconCpp::HTuple hConfidence;
        HalconCpp::HTuple hMlpClasses = mMlp.DoOcrMultiClassMlp(hCharRegions, rImage, &hConfidence);
        HalconCpp::HTuple hSvmClasses = mSvm.DoOcrMultiClassSvm(hCharRegions, rImage);
        if (hMlpClasses.Length() != iNumChars || hSvmClasses.Length() != iNumChars)
        {
            return rResult;
        }

        QStringList iCharacterClasses;
        QVector<qreal> iConfidences;
        QVector<QRectF> iCharacterRects;
        for (Hlong ll = 0; ll < hCharRegions.CountObj(); ++ll)
        {
            QString iMlpChar = QString::fromUtf8(hMlpClasses[ll].S().ToUtf8());
            QString iSvmChar = QString::fromUtf8(hSvmClasses[ll].S().ToUtf8());
            if (iMlpChar == iSvmChar)
            {
                iConfidences.push_back(hConfidence[ll].D());
            }
            else
            {
                iConfidences.push_back(0.0);
            }
            iCharacterClasses.push_back(iMlpChar);
            iCharacterRects.push_back(QRectF(hColumn1[ll].D() - 3, hRow1[ll].D() - 3, hColumn2[ll].D() - hColumn1[ll].D() + 6, hRow2[ll].D() - hRow1[ll].D() + 6));
        }

        rResult[QStringLiteral("CharacterClasses")] = iCharacterClasses;
        rResult[QStringLiteral("Confidences")] = QVariant::fromValue(iConfidences);
        rResult[QStringLiteral("CharacterRects")] = QVariant::fromValue(iCharacterRects);
        return rResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        qDebug() << QString::fromUtf8(e.Message());
        return QVariantMap();
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}
