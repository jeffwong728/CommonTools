#ifndef HALCON_SHAPE_TEMPLATE_H
#define HALCON_SHAPE_TEMPLATE_H

#include <opencv2/opencv.hpp>
#include <laser_x_shape_template.h>
#include <halconcpp/HalconCpp.h>

class HalconShapeTemplate : public LaserXShapeTemplate
{
    Q_OBJECT
public:
    HalconShapeTemplate(const HalconCpp::HShapeModel&model);
    ~HalconShapeTemplate();

public:
    QByteArray getBlob() const override;
    void writeShapeTemplate(const QString& fileName) const override;
    QVariantMap findTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const override;
    QVariantMap findTemplates(const std::vector<LXShapeTemplate>& templates, const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const override;

public:
    HalconCpp::HShapeModel mModel;
};

#endif // HALCON_SHAPE_TEMPLATE_H
