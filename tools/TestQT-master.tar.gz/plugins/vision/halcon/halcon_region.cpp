#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
extern void doDeleteLater(QObject* obj);

HalconRegion::HalconRegion(const HalconCpp::HRegion& region)
    : LaserXRegion(nullptr)
    , mRegion(region)
{
}

HalconRegion::~HalconRegion()
{
}

void HalconRegion::writeRegion(const QString& fileName) const
{
    try
    {
        return mRegion.WriteRegion(HalconCpp::HString::FromUtf8(fileName.toUtf8().constData()));
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

qlonglong HalconRegion::area() const
{
    try
    {
        double Row = 0, Column = 0;
        return mRegion.AreaCenter(&Row, &Column);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return 0;
    }
}

QPointF HalconRegion::center() const
{
    try
    {
        double iRow = 0, iColumn = 0;
        mRegion.AreaCenter(&iRow, &iColumn);
        return QPointF(iColumn, iRow);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QPointF();
    }
}

QVariantMap HalconRegion::ellipticAxis() const
{
    try
    {
        double iRb = 0, iPhi = 0;
        qreal iRa = mRegion.EllipticAxis(&iRb, &iPhi);
        QVariantMap iDict;
        iDict[QStringLiteral("Ra")]  = iRa;
        iDict[QStringLiteral("Rb")]  = iRb;
        iDict[QStringLiteral("Phi")] = iPhi;

        return iDict;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

QImage HalconRegion::toLabel(const QSize& size) const
{
    try
    {
        HalconCpp::HImage hImage = mRegion.RegionToLabel("byte", size.width(), size.height());

        Hlong Width = 0;
        Hlong Height = 0;
        HalconCpp::HString Type;
        void* dst = hImage.GetImagePointer1(&Type, &Width, &Height);
        QImage image(static_cast<uchar*>(dst), Width, Height, Width, QImage::Format_Indexed8);
        QImage iImage = image.copy();

        QList<QRgb> colors;
        colors.reserve(256);
        colors.push_back(0);
        const QRgb rgbs[3] = { 0xFFDAA520, 0xFF00FFFF, 0xFF7CFC00 };
        for (int i = 1; i < 256; ++i)
        {
            colors.push_back(rgbs[i % 3]);
        }
        iImage.setColorTable(colors);
        return iImage;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QImage();
    }
}

LXRegion HalconRegion::connection() const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.Connection();
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::fillHoles() const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.FillUp();
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::dilationCircle(const qreal radius) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.DilationCircle(radius);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::closingCircle(const qreal radius) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.ClosingCircle(radius);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::closingRectangle1(const QSize& size) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.ClosingRectangle1(size.width(), size.height());
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::openingCircle(const qreal radius) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.OpeningCircle(radius);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::openingRectangle1(const QSize& size) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.OpeningRectangle1(size.width(), size.height());
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

QVector<QPolygonF> HalconRegion::getPolygons(const qreal tolerance) const
{
    QVector<QPolygonF> iPolygons;
    try
    {
        if (!mRegion.IsInitialized())
        {
            return iPolygons;
        }

        const Hlong iNumRgns = mRegion.CountObj();
        for (int rr = 0; rr < iNumRgns; ++rr)
        {
            HalconCpp::HRegion hSubRgn = mRegion.SelectObj(rr + 1ll);
            Hlong hNumHoles = 0;
            Hlong hNumConnects = hSubRgn.ConnectAndHoles(&hNumHoles);
            if (1 == hNumConnects)
            {
                HalconCpp::HTuple hRows;
                HalconCpp::HTuple hColumns;
                hSubRgn.GetRegionPolygon(tolerance, &hRows, &hColumns);
                const Hlong hNumPoints = hRows.Length();
                iPolygons.emplace_back();
                iPolygons.back().reserve(hNumPoints);
                for (Hlong nn = 0; nn < hNumPoints; ++nn)
                {
                    iPolygons.back().emplace_back(hColumns[nn].D(), hRows[nn].D());
                }

                if (hNumHoles)
                {
                    HalconCpp::HRegion hFillRgn = hSubRgn.FillUp();
                    HalconCpp::HRegion hHoleRgn = hFillRgn.Difference(hSubRgn);

                    HalconRegion hLXRgn(hHoleRgn);
                    QVector<QPolygonF> iHolePlgs = hLXRgn.getPolygons(tolerance);
                    for (QPolygonF&iHolePlg : iHolePlgs)
                    {
                        std::reverse(iHolePlg.begin(), iHolePlg.end());
                    }
                    iPolygons.append(iHolePlgs);
                }
            }
            else if (hNumConnects > 1)
            {
                HalconCpp::HRegion hRgns = hSubRgn.Connection();
                HalconRegion hLXRgns(hRgns);
                QVector<QPolygonF> iPlgs = hLXRgns.getPolygons(tolerance);
                iPolygons.append(iPlgs);
            }
            else
            {
                qDebug() << QStringLiteral("Invalid region");
            }
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return iPolygons;
}

qlonglong HalconRegion::countObj() const
{
    try
    {
        return mRegion.CountObj();
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return 0;
    }
}

QVariantMap HalconRegion::smallestRectangle2() const
{
    try
    {
        double Row = 0;
        double Column = 0;
        double Phi = 0;
        double Length1 = 0;
        double Length2 = 0;
        mRegion.SmallestRectangle2(&Row, &Column, &Phi, &Length1, &Length2);

        QVariantMap iDict;
        iDict[QStringLiteral("CX")] = Column;
        iDict[QStringLiteral("CY")] = Row;
        iDict[QStringLiteral("Phi")] = Phi;
        iDict[QStringLiteral("SemiMajorLen")] = Length1;
        iDict[QStringLiteral("SemiMinorLen")] = Length2;

        return iDict;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

QVariantMap HalconRegion::smallestCircle() const
{
    try
    {
        double Row = 0;
        double Column = 0;
        double Radius = 0;
        mRegion.SmallestCircle(&Row, &Column, &Radius);

        QVariantMap iDict;
        iDict[QStringLiteral("CX")] = Column;
        iDict[QStringLiteral("CY")] = Row;
        iDict[QStringLiteral("Radius")] = Radius;

        return iDict;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

LXRegion HalconRegion::selectRegion(const qlonglong index) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.SelectObj(index+1);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::selectArea(const qreal minArea, const qreal maxArea) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.SelectShape("area", "and", minArea, maxArea);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::selectCircularity(const qreal minCircularity, const qreal maxCircularity) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.SelectShape("circularity", "and", minCircularity, maxCircularity);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::selectOuterRadius(const qreal minOuterRadius, const qreal maxOuterRadius) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.SelectShape("outer_radius", "and", minOuterRadius, maxOuterRadius);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::selectRectangularity(const qreal minRectangularity, const qreal maxRectangularity) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.SelectShape("rectangularity", "and", minRectangularity, maxRectangularity);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::selectRect2SemiMajorLen(const qreal minSemiMajorLen, const qreal maxSemiMajorLen) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.SelectShape("rect2_len1", "and", minSemiMajorLen, maxSemiMajorLen);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconRegion::selectRect2SemiMinorLen(const qreal minSemiMinorLen, const qreal maxSemiMinorLen) const
{
    try
    {
        HalconCpp::HRegion hRegion = mRegion.SelectShape("rect2_len2", "and", minSemiMinorLen, maxSemiMinorLen);
        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}
