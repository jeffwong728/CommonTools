#include "halcon_util.h"
#include <laser_x_util.h>

HalconCpp::HTuple HalconUtil::toHTuple(const QVariant &var)
{
    if (!var.isValid() || var.isNull())
    {
        return HalconCpp::HTuple();
    }

    if (var.type() == QVariant::Double)
    {
        return HalconCpp::HTuple(var.toDouble());
    }
    else if (var.type() == QVariant::LongLong)
    {
        return HalconCpp::HTuple(var.toLongLong());
    }
    else if (var.type() == QVariant::Int)
    {
        return HalconCpp::HTuple(var.toInt());
    }
    else if (var.type() == QVariant::String)
    {
        return HalconCpp::HTuple(var.toString().toStdString().c_str());
    }
    else if (var.type() == QVariant::StringList)
    {
        HalconCpp::HTuple hVar;
        const QStringList iVars = var.toStringList();
        for (const QString &iVar : iVars)
        {
            hVar.Append(iVar.toStdString().c_str());
        }
        return hVar;
    }
    else if (var.type() == QVariant::List)
    {
        HalconCpp::HTuple hVar;
        const QVariantList iVars = var.toList();
        for (const QVariant& iVar : iVars)
        {
            hVar.Append(HalconUtil::toHTuple(iVar));
        }
        return hVar;
    }
    else
    {
        qDebug() << QStringLiteral("Unknown variant type ") << QString::fromStdString(var.typeName());
        return HalconCpp::HTuple();
    }
}

HalconCpp::HDict HalconUtil::toHDict(const QVariantMap & params)
{
    HalconCpp::HDict hParams;
    for (const QString& iKey : params.keys())
    {
        hParams.SetDictTuple(HalconCpp::HString::FromUtf8(iKey.toUtf8()), toHTuple(params[iKey]));
    }

    return hParams;
}

HalconCpp::HTuple HalconUtil::getHParam(const QVariantMap& params, const QString& key, const QVariant& defVal)
{
    return HalconUtil::toHTuple(params.value(key, defVal));
}
