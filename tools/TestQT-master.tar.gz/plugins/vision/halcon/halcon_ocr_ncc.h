#ifndef HALCON_OCR_NCC_H
#define HALCON_OCR_NCC_H

#include <laser_x_ocr.h>
#include <halconcpp/HalconCpp.h>

class HalconOCRNCC : public LaserXOCR
{
    Q_OBJECT
public:
    HalconOCRNCC(const QStringList &chars, const HalconCpp::HOCRSvm& svm, const HalconCpp::HOCRMlp& mlp, const HalconCpp::HNCCModelArray &models);
    ~HalconOCRNCC();

public:
    QByteArray getBlob() const override;
    QVariantMap getParams() const override;
    bool writeOCR(const QString& fileName) const override;
    QVariantMap trainOCR(const QVariantMap& params) override;
    QVariantMap doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const override;
    QVariantMap doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const override;

public:
    QStringList mChars;
    HalconCpp::HOCRSvm mSvm;
    HalconCpp::HOCRMlp mMlp;
    HalconCpp::HNCCModelArray mModels;
};

#endif // HALCON_OCR_NCC_H
