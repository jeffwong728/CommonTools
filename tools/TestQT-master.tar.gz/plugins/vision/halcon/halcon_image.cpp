#include "halcon_image.h"
#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
extern void doDeleteLater(QObject* obj);

HalconImage::HalconImage(const HalconCpp::HImage& image)
    : LaserXImage(nullptr)
    , mImage(image)
{
}

HalconImage::~HalconImage()
{
}

QSize HalconImage::getSize() const
{
    try
    {
        Hlong Width = 0;
        Hlong Height = 0;
        mImage.GetImageSize(&Width, &Height);
        return QSize(static_cast<int>(Width), static_cast<int>(Height));
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QSize();
    }
}

void HalconImage::writeImage(const QString& format, const qlonglong fillColor, const QString& fileName) const
{
    try
    {
        HalconCpp::HString hFormat = HalconCpp::HString::FromUtf8(format.toUtf8().constData());
        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(fileName.toUtf8().constData());
        mImage.WriteImage(hFormat, fillColor, hFileName);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

LXImage HalconImage::reduceDomain(const LXRegion& region) const
{
    try
    {
        QSharedPointer<HalconRegion> hRegion = qSharedPointerDynamicCast<HalconRegion>(region);
        if (hRegion)
        {
            HalconCpp::HImage reducedImage = mImage.ReduceDomain(hRegion->mRegion);
            return LXImage(new HalconImage(reducedImage), doDeleteLater);
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return nullptr;
}

bool HalconImage::copyCVMat(const cv::Mat& mat)
{
    try
    {
        if (!mat.empty() && CV_8U == mat.depth())
        {
            if (1 == mat.channels())
            {
                QSize iSize = getSize();
                Hlong Width = iSize.width();
                Hlong Height = iSize.height();
                if (Width == mat.cols &&
                    Height == mat.rows &&
                    mImage.CountChannels().I() == mat.channels() &&
                    mImage.GetImageType() == HalconCpp::HTuple("byte"))
                {
                    HalconCpp::HString Type;
                    void* dst = mImage.GetImagePointer1(&Type, &Width, &Height);
                    std::memcpy(dst, mat.data, Width * Height);
                }
                else
                {
                    mImage.GenImage1("byte", mat.cols, mat.rows, mat.data);
                }

                return true;
            }
            else if (3 == mat.channels())
            {
                std::vector<cv::Mat> bgr(3);
                cv::split(mat, bgr);
                mImage.GenImage3("byte", mat.cols, mat.rows, bgr[2].data, bgr[1].data, bgr[0].data);
                return true;
            }
            else if (4 == mat.channels())
            {
                std::vector<cv::Mat> argb(4);
                cv::split(mat, argb);
                mImage.GenImage3("byte", mat.cols, mat.rows, argb[1].data, argb[2].data, argb[3].data);
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return false;
    }
}

bool HalconImage::refCVMat(const cv::Mat& mat)
{
    if (mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
    {
        return false;
    }

    mImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
    return true;
}

cv::Mat HalconImage::toCVMat() const
{
    try
    {
        if (mImage.GetImageType() != HalconCpp::HTuple("byte"))
        {
            return cv::Mat();
        }

        const int iChannels = mImage.CountChannels().I();
        if (1 == iChannels)
        {
            Hlong Width = 0;
            Hlong Height = 0;
            HalconCpp::HString Type;
            void* dst = mImage.GetImagePointer1(&Type, &Width, &Height);
            cv::Mat image(Height, Width, CV_8UC1, dst);
            return image.clone();
        }
        else if (3 == iChannels)
        {
            Hlong Width = 0;
            Hlong Height = 0;
            HalconCpp::HString Type;
            void* PointerRed = nullptr;
            void* PointerGreen = nullptr;
            void* PointerBlue = nullptr;
            mImage.GetImagePointer3(&PointerRed, &PointerGreen, &PointerBlue, &Type, &Width, &Height);
            if (PointerRed && PointerGreen && PointerBlue)
            {
                std::vector<cv::Mat> bgr(3);
                bgr[0] = cv::Mat(Height, Width, CV_8UC1, PointerRed);
                bgr[1] = cv::Mat(Height, Width, CV_8UC1, PointerGreen);
                bgr[2] = cv::Mat(Height, Width, CV_8UC1, PointerBlue);

                cv::Mat dst;
                cv::merge(bgr, dst);
                return dst;
            }
        }
        else
        {
            qWarning() << QStringLiteral("Can't convert image with %1 channels").arg(iChannels);
        }

        return cv::Mat();
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return cv::Mat();
    }
}
