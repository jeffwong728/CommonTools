#ifndef HALCON_NCC_TEMPLATE_H
#define HALCON_NCC_TEMPLATE_H

#include <opencv2/opencv.hpp>
#include <laser_x_ncc_template.h>
#include <halconcpp/HalconCpp.h>

class HalconNCCTemplate : public LaserXNCCTemplate
{
    Q_OBJECT
public:
    HalconNCCTemplate(const HalconCpp::HNCCModel &model);
    ~HalconNCCTemplate();

public:
    qreal getAngleStart() const override;
    qreal getAngleExtent() const override;
    qreal getAngleStep() const override;
    qlonglong getNumLevels() const override;
    bool getUsePolarity() const override;
    QByteArray getBlob() const override;
    void writeNCCTemplate(const QString& fileName) const override;
    QVariantMap findTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const override;

public:
    HalconCpp::HNCCModel mModel;
};

#endif // HALCON_NCC_TEMPLATE_H
