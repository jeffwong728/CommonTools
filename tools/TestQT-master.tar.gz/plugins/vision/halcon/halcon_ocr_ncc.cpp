#include "halcon_util.h"
#include "halcon_ocr_ncc.h"
#include "halcon_image.h"
#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
#include <hdevengine/HDevEngineCpp.h>
extern void doDeleteLater(QObject* obj);

HalconOCRNCC::HalconOCRNCC(const QStringList &chars, const HalconCpp::HNCCModelArray &models)
    : LaserXOCR(nullptr)
    , mChars(chars)
    , mModels(models)
{
}

HalconOCRNCC::~HalconOCRNCC()
{
}

QByteArray HalconOCRNCC::getBlob() const
{
    try
    {
        QByteArray iBlob;
        const Hlong hLen = mModels.Length();
        const HalconCpp::HNCCModel* hModels = mModels.Tools();
        for (Hlong ll = 0; ll < hLen; ++ll)
        {
            Hlong hSize = 0;
            HalconCpp::HSerializedItem hItem = hModels[ll].SerializeNccModel();
            void* hPointer = hItem.GetSerializedItemPtr(&hSize);
            QByteArray iBytes(static_cast<char*>(hPointer), hSize);
            iBlob += iBytes;
        }

        return iBlob;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QByteArray();
    }
}

QVariantMap HalconOCRNCC::getParams() const
{
    try
    {
        QVariantList iSizes;
        const Hlong hLen = mModels.Length();
        const HalconCpp::HNCCModel* hModels = mModels.Tools();
        for (Hlong ll = 0; ll < hLen; ++ll)
        {
            Hlong hSize = 0;
            HalconCpp::HSerializedItem hItem = hModels[ll].SerializeNccModel();
            hItem.GetSerializedItemPtr(&hSize);
            iSizes.append(hSize);
        }

        QVariantMap iParams;
        iParams[QStringLiteral("OCRType")] = QStringLiteral("Ncc");
        iParams[QStringLiteral("Chars")] = mChars;
        iParams[QStringLiteral("Sizes")] = iSizes;
        return iParams;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

bool HalconOCRNCC::writeOCR(const QString& fileName) const
{
    Q_UNUSED(fileName);
    return false;
}

QVariantMap HalconOCRNCC::trainOCR(const QVariantMap& params)
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        if (!QFileInfo::exists(iTrainingFile))
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 not exists").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HalconCpp::HImage hImages;
        const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
        const HalconCpp::HTuple hCharNames = hImages.ReadOcrTrainf(hTrainingFile);
        const HalconCpp::HImage hCharImages = hImages.FullDomain();
        if (hCharNames.Length() != hCharImages.CountObj() || !hCharNames.Length())
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 empty or damaged").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        const HalconCpp::HTuple hAngleStep = "auto";
        const HalconCpp::HTuple hNumLevels = params.value(QStringLiteral("NumLevels"), 0).toLongLong();
        const HalconCpp::HTuple hAngleStart = qDegreesToRadians(params.value(QStringLiteral("AngleStart"), 0.0).toReal());
        const HalconCpp::HTuple hAngleExtent = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0.0).toReal());
        const HalconCpp::HString hMetric = HalconCpp::HString::FromUtf8(params.value(QStringLiteral("Metric"), QStringLiteral("use_polarity")).toString().toUtf8());

        QStringList iChars;
        std::vector<HalconCpp::HNCCModel> iModels;
        const Hlong hNumChars = hCharNames.Length();
        for (Hlong ll = 0; ll < hNumChars; ++ll)
        {
            const QString iCharName = QString::fromUtf8(hCharNames[ll].S().ToUtf8());
            iChars.push_back(iCharName);

            HalconCpp::HImage hCharImage = hCharImages.SelectObj(ll + 1);
            HalconCpp::HNCCModel hModel(hCharImage, hNumLevels, hAngleStart, hAngleExtent, hAngleStep, hMetric);
            iModels.push_back(hModel);
        }

        mChars = iChars;
        mModels = HalconCpp::HNCCModelArray(iModels.data(), static_cast<Hlong>(iModels.size()));

        iResult[QStringLiteral("Success")] = true;
        iResult[QStringLiteral("Error")] = 0;
        iResult[QStringLiteral("ErrorLog")] = QVariantList();
        return iResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconOCRNCC::doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    Q_UNUSED(mat);
    Q_UNUSED(cRegion);
    Q_UNUSED(params);
    QVariantMap iResult;
    const QString iErrorMsg = QStringLiteral("SVM OCR classifier can't be used alone");
    iResult[QStringLiteral("Success")] = false;
    iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
    qDebug() << iErrorMsg;
    return iResult;
}

QVariantMap HalconOCRNCC::doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    try
    {
        QVariantMap rResult;
        QSharedPointer<HalconImage> spImg = mat.dynamicCast<HalconImage>();
        if (!spImg)
        {
            return rResult;
        }

        QSharedPointer<HalconRegion> hRegion = cRegion.dynamicCast<HalconRegion>();
        if (!hRegion)
        {
            return rResult;
        }

        if (hRegion->area() < 1)
        {
            qDebug() << QStringLiteral("Char box empty error");
            return rResult;
        }

        const HalconCpp::HTuple hAngleStart = qDegreesToRadians(params.value(QStringLiteral("AngleStart"), 0.0).toReal());
        const HalconCpp::HTuple hAngleExtent = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0.0).toReal());
        const HalconCpp::HTuple hMinScore = params.value(QStringLiteral("MinScore"), 0.9).toReal();
        const HalconCpp::HTuple hNumMatches = params.value(QStringLiteral("NumChars"), 0).toInt();
        const HalconCpp::HTuple hMaxOverlap = params.value(QStringLiteral("MaxOverlap"), 0.1).toReal();
        const HalconCpp::HString hSubPixel = "false";
        const HalconCpp::HTuple hNumLevels = 0;

        HalconCpp::HTuple hRow;
        HalconCpp::HTuple hColumn;
        HalconCpp::HTuple hAngle;
        HalconCpp::HTuple hScore;
        HalconCpp::HTuple hModel;
        HalconCpp::HImage rImage = spImg->mImage.ReduceDomain(hRegion->mRegion);
        HalconCpp::HNCCModel::FindNccModels(rImage, mModels, hAngleStart, hAngleExtent, hMinScore, hNumMatches,
            hMaxOverlap, hSubPixel, hNumLevels, &hRow, &hColumn, &hAngle, &hScore, &hModel);

        QStringList iCharacterClasses;
        QVector<qreal> iConfidences;
        QVector<QRectF> iCharacterRects;
        for (Hlong ll = 0; ll < hModel.Length(); ++ll)
        {
            const Hlong hCharIndex = hModel[ll].L();
            iCharacterClasses.push_back(mChars[hCharIndex]);
            iConfidences.push_back(hScore[ll].D());

            Hlong hRow1 = 0;
            Hlong hColumn1 = 0;
            Hlong hRow2 = 0;
            Hlong hColumn2 = 0;
            HalconCpp::HRegion hCharRegion = mModels.Tools()[hCharIndex].GetNccModelRegion();
            hCharRegion.SmallestRectangle1(&hRow1, &hColumn1, &hRow2, &hColumn2);
            iCharacterRects.push_back(QRectF(hColumn1 + hColumn[ll].D(), hRow1 + hRow[ll].D(), hColumn2 - hColumn1, hRow2 - hRow1));
        }

        rResult[QStringLiteral("CharacterClasses")] = iCharacterClasses;
        rResult[QStringLiteral("Confidences")] = QVariant::fromValue(iConfidences);
        rResult[QStringLiteral("CharacterRects")] = QVariant::fromValue(iCharacterRects);
        return rResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        qDebug() << QString::fromUtf8(e.Message());
        return QVariantMap();
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}
