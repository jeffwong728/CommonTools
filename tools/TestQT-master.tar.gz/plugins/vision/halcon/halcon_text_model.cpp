#include "halcon_text_model.h"
#include "halcon_image.h"
#include "halcon_region.h"
#include "halcon_util.h"
#include <QtCore>
#include <QtGui>
extern void doDeleteLater(QObject* obj);

HalconTextModel::HalconTextModel(const HalconCpp::HTextModel &textModel)
    : LaserXTextModel(nullptr)
    , mTextModel(textModel)
{
}

HalconTextModel::~HalconTextModel()
{
    mTextResult.ClearTextResult();
    mTextModel.ClearTextModel();
}

void HalconTextModel::setParams(const QVariantMap& params) const
{
    try
    {
        for (const QString &iKey : params.keys())
        {
            const QVariant iVar = params[iKey];
            mTextModel.SetTextModelParam(HalconCpp::HTuple(iKey.toStdWString().c_str()), HalconUtil::toHTuple(iVar));
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

bool HalconTextModel::findText(const cv::Mat& mat, const LXRegion& region)
{
    try
    {
        mTextResult.ClearTextResult();

        if (mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
        {
            return false;
        }

        HalconCpp::HImage hImage;
        HalconCpp::HImage rImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
        if (region)
        {
            QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
            rImage = hImage.ReduceDomain(hRegion->mRegion);
        }
        else
        {
            rImage = hImage;
        }

        mTextResult = mTextModel.FindText(rImage);
        return true;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return false;
    }
}

bool HalconTextModel::findText(const LXImage& mat, const LXRegion& region)
{
    try
    {
        mTextResult.ClearTextResult();
        QSharedPointer<HalconImage> spImg = mat.dynamicCast<HalconImage>();
        if (!spImg)
        {
            return false;
        }

        HalconCpp::HImage rImage;
        if (region)
        {
            QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
            rImage = spImg->mImage.ReduceDomain(hRegion->mRegion);
        }
        else
        {
            rImage = spImg->mImage;
        }

        mTextResult = mTextModel.FindText(rImage);
        return true;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return false;
    }
}

LXRegion HalconTextModel::getTextObject(const QVariantMap& params)
{
    Q_UNUSED(params);

    try
    {
        const HalconCpp::HString hResultName("all_lines");
        HalconCpp::HRegion hObj(mTextResult.GetTextObject(hResultName));
        return LXRegion(new HalconRegion(hObj), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

QVariantMap HalconTextModel::getTextResult(const QVariantMap& params)
{
    try
    {
        Q_UNUSED(params);
        QVariantMap rResult;
        HalconCpp::HTuple hNumLines = mTextResult.GetTextResult("num_lines");
        const Hlong iNumLines = hNumLines.L();
        rResult[QStringLiteral("NumLines")] = iNumLines;

        QStringList iClassLines;
        QVector<QVector<qreal>> iConfidenceLines;
        QVector<QVector<QRectF>> iRectLines;

        for (Hlong ll=0; ll < hNumLines; ++ll)
        {
            QString iClassLine;
            HalconCpp::HTuple hClassLine = mTextResult.GetTextResult(HalconCpp::HTuple().Append("class_line").Append(ll));
            for (Hlong nn = 0; nn < hClassLine.Length(); ++nn)
            {
                iClassLine.append(QString::fromUtf8(hClassLine[nn].operator HalconCpp::HString().ToUtf8()));
            }

            QVector<qreal> iConfidenceLine;
            HalconCpp::HTuple hConfidenceLine = mTextResult.GetTextResult(HalconCpp::HTuple().Append("confidence_line").Append(ll));
            for (Hlong nn = 0; nn < hConfidenceLine.Length(); ++nn)
            {
                iConfidenceLine.append(hConfidenceLine[nn].D());
            }

            HalconCpp::HTuple hRow1;
            HalconCpp::HTuple hColumn1;
            HalconCpp::HTuple hRow2;
            HalconCpp::HTuple hColumn2;
            QVector<QRectF> iRectLine;
            HalconCpp::HRegion hRgnLine(mTextResult.GetTextObject(HalconCpp::HTuple().Append("line").Append(ll)));
            hRgnLine.SmallestRectangle1(&hRow1, &hColumn1, &hRow2, &hColumn2);
            for (Hlong nn = 0; nn < hRow1.Length(); ++nn)
            {
                QRectF iRect(QPointF(hColumn1[nn].D(), hRow1[nn].D()), QPointF(hColumn2[nn].D(), hRow2[nn].D()));
                iRectLine.push_back(iRect);
            }

            iClassLines.push_back(iClassLine);
            iConfidenceLines.push_back(iConfidenceLine);
            iRectLines.push_back(iRectLine);
        }

        rResult[QStringLiteral("ClassLines")] = iClassLines;
        rResult[QStringLiteral("ConfidenceLines")] = QVariant::fromValue(iConfidenceLines);
        rResult[QStringLiteral("RectLines")] = QVariant::fromValue(iRectLines);

        return rResult;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

void HalconTextModel::clearTextResult()
{
    mTextResult.ClearTextResult();
}