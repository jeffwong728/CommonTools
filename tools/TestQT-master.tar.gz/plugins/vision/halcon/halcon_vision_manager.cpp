#include "halcon_util.h"
#include "halcon_image.h"
#include "halcon_region.h"
#include "halcon_ncc_template.h"
#include "halcon_shape_template.h"
#include "halcon_vision_manager.h"
#include "halcon_measure_model.h"
#include "halcon_text_model.h"
#include "halcon_ocr_mlp.h"
#include "halcon_ocr_svm.h"
#include "halcon_ocr_svm_mlp.h"
#include "halcon_ocr_ncc.h"
#include "halcon_ocr_shape.h"
#include <halconcpp/HalconCpp.h>
#include <hdevengine/HDevEngineCpp.h>
#include <QtCore>
#include <QtGui>
#include <QtMath>

void doDeleteLater(QObject* obj)
{
    obj->deleteLater();
}

namespace
{
    constexpr bool gEnableDlOcr = false;
    HalconCpp::HDlModelOcr gDlModelOcr;
}

HalconVisionManager::HalconVisionManager()
{
    try
    {
        HalconCpp::HSystem::SetSystem("no_object_result", "true");
        if (gEnableDlOcr)
        {
            QDir pluginsDir = QDir(QCoreApplication::applicationDirPath());
            pluginsDir.cd(QStringLiteral("plugins"));
            pluginsDir.cd(QStringLiteral("vision"));
            QString iOCRFileName = pluginsDir.absoluteFilePath(QStringLiteral("ocr.hdo"));
            gDlModelOcr.ReadDeepOcr(HalconCpp::HString::FromUtf8(iOCRFileName.toUtf8()));

            HalconCpp::HDlDevice hDlDevice;
            hDlDevice.QueryAvailableDlDevices("runtime", "cpu");
            gDlModelOcr.SetDeepOcrParam("device", hDlDevice);
        }

        QString iScriptsDir = QCoreApplication::applicationDirPath() + QDir::separator() + QStringLiteral("scripts");
        if (!QFileInfo::exists(iScriptsDir))
        {
            QDir(QCoreApplication::applicationDirPath()).mkdir(QStringLiteral("scripts"));
        }

        if (QFileInfo::exists(iScriptsDir))
        {
            HDevEngineCpp::HDevEngine().SetProcedurePath(iScriptsDir.toStdWString().c_str());
        }
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        qDebug() << QString::fromUtf8(e.Message());
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }
}

HalconVisionManager::~HalconVisionManager()
{
    gDlModelOcr.Clear();
}

LXImage HalconVisionManager::readImage(const QString &fileName) const
{
    try
    {
        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(fileName.toUtf8().constData());
        HalconCpp::HImage image(hFileName);
        return LXImage(new HalconImage(image), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXImage HalconVisionManager::fromCVMat(const cv::Mat& mat, const bool deepCopy) const
{
    HalconCpp::HImage image;
    LXImage lxImage = LXImage(new HalconImage(image), doDeleteLater);
    if (deepCopy && lxImage->copyCVMat(mat))
    {
        return lxImage;
    }
    else if (!deepCopy && lxImage->refCVMat(mat))
    {
        return lxImage;
    }
    else
    {
        return nullptr;
    }
}

LXImage HalconVisionManager::fromQImage(const QImage& image, const bool deepCopy) const
{
    if (!image.isNull())
    {
        if (QImage::Format_Grayscale8 == image.format())
        {
            cv::Mat mat(image.height(), image.width(), CV_8UC1, const_cast<QImage&>(image).bits());
            return HalconVisionManager::fromCVMat(mat, deepCopy);
        }
        else if (QImage::Format_RGB888 == image.format())
        {
            cv::Mat mat(image.height(), image.width(), CV_8UC3, const_cast<QImage&>(image).bits());
            return HalconVisionManager::fromCVMat(mat, deepCopy);
        }
        else if (QImage::Format_ARGB32 == image.format())
        {
            cv::Mat mat(image.height(), image.width(), CV_8UC4, const_cast<QImage&>(image).bits());
            return HalconVisionManager::fromCVMat(mat, deepCopy);
        }
        else
        {
            return nullptr;
        }
    }
    else
    {
        return nullptr;
    }
}

LXRegion HalconVisionManager::genRectangle1(const QRectF& rect) const
{
    try
    {
        const double hRow1 = rect.top();
        const double hColumn1 = rect.left();
        const double hRow2 = rect.bottom();
        const double hColumn2 = rect.right();
        HalconCpp::HRegion region(hRow1, hColumn1, hRow2, hColumn2);
        return LXRegion(new HalconRegion(region), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconVisionManager::genRegion(const QJsonObject& object) const
{
    QPainterPath iPath = LaserXVisionManager::getPath(object);
    if (iPath.isEmpty())
    {
        return nullptr;
    }
    else
    {
        try
        {
            const QRectF iRect = iPath.boundingRect();
            const QSize iSize(std::abs(iRect.right()) + 10, std::abs(iRect.bottom()) + 10);
            QImage iImage(iSize, QImage::Format_Grayscale8);
            iImage.fill(Qt::black);
            QPainter iPainter(&iImage);
            iPainter.setPen(Qt::NoPen);
            iPainter.setBrush(QBrush(Qt::lightGray));
            iPainter.drawPath(iPath);

            HalconCpp::HImage hImage;
            hImage.GenImage1Rect(const_cast<QImage&>(iImage).bits(), iImage.width(), iImage.height(), iImage.bytesPerLine(), 8, 8, "false", nullptr);
            HalconCpp::HRegion hRegion = hImage.Threshold(10, 255);

            return LXRegion(new HalconRegion(hRegion), doDeleteLater);
        }
        catch (const HalconCpp::HException& e)
        {
            qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
            return nullptr;
        }
    }
}

LXRegion HalconVisionManager::genRectangle2(const QRectF& rect, const qreal phi) const
{
    try
    {
        HalconCpp::HRegion region;
        region.GenRectangle2(rect.center().y(), rect.center().x(), phi, rect.width()/2, rect.height()/2);
        return LXRegion(new HalconRegion(region), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconVisionManager::genCircle(const QPointF& center, const qreal radius) const
{
    try
    {
        HalconCpp::HRegion region(center.y(), center.x(), radius);
        return LXRegion(new HalconRegion(region), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconVisionManager::genRegionPolygonFilled(const QPolygonF& polygon) const
{
    try
    {
        HalconCpp::HTuple Rows;
        HalconCpp::HTuple Columns;

        for (const QPointF& iPoint : polygon)
        {
            Rows.Append(iPoint.y());
            Columns.Append(iPoint.x());
        }

        HalconCpp::HRegion region;
        region.GenRegionPolygonFilled(Rows, Columns);
        return LXRegion(new HalconRegion(region), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegion HalconVisionManager::threshold(const cv::Mat& mat, const double minGray, const double maxGray) const
{
    if (!mat.empty() && 1 == mat.channels() && CV_8U == mat.depth())
    {
        HalconCpp::HImage hImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
        HalconCpp::HRegion hRegion = hImage.Threshold(minGray, maxGray);

        return LXRegion(new HalconRegion(hRegion), doDeleteLater);
    }
    else
    {
        return nullptr;
    }
}

LXNCCTemplate HalconVisionManager::readNccTemplate(const QByteArray& blob) const
{
    try
    {
        if (!blob.isEmpty())
        {
            HalconCpp::HSerializedItem hSerializedItem(const_cast<QByteArray &>(blob).data(), blob.size(), "true");
            HalconCpp::HNCCModel hModel;
            hModel.DeserializeNccModel(hSerializedItem);
            return LXNCCTemplate(new HalconNCCTemplate(hModel), doDeleteLater);
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
    }

    return nullptr;
}

LXNCCTemplate HalconVisionManager::createNccTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const
{
    try
    {
        QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
        if (!mat.empty() && 1 == mat.channels() && CV_8U == mat.depth() && hRegion)
        {
            HalconCpp::HImage hImage;
            hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
            HalconCpp::HImage rImage = hImage.ReduceDomain(hRegion->mRegion);

            const HalconCpp::HTuple hNumLevels = params[QStringLiteral("NumLevels")].toLongLong();
            const HalconCpp::HTuple hAngleStart = qDegreesToRadians(params.value(QStringLiteral("AngleStart"), 0.0).toReal());
            const HalconCpp::HTuple hAngleExtent = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0.0).toReal());
            const HalconCpp::HTuple hAngleStep = "auto";
            const HalconCpp::HString hMetric = HalconCpp::HString::FromUtf8(params.value(QStringLiteral("Metric"), QStringLiteral("use_polarity")).toString().toUtf8());

            HalconCpp::HNCCModel hModel(rImage, hNumLevels, hAngleStart, hAngleExtent, hAngleStep, hMetric);
            return LXNCCTemplate(new HalconNCCTemplate(hModel), doDeleteLater);
        }
        else
        {
            return nullptr;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXShapeTemplate HalconVisionManager::readShapeTemplate(const QByteArray& blob) const
{
    try
    {
        if (blob.isEmpty())
        {
            return nullptr;
        }

        HalconCpp::HSerializedItem hSerializedItem(const_cast<QByteArray&>(blob).data(), blob.size(), "true");
        HalconCpp::HShapeModel hModel;
        hModel.DeserializeShapeModel(hSerializedItem);
        return LXShapeTemplate(new HalconShapeTemplate(hModel), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXShapeTemplate HalconVisionManager::createShapeTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const
{
    try
    {
        QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
        if (!mat.empty() && 1 == mat.channels() && CV_8U == mat.depth() && hRegion)
        {
            HalconCpp::HImage hImage;
            hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
            HalconCpp::HImage rImage = hImage.ReduceDomain(hRegion->mRegion);

            const Hlong iNumLevels = params.value(QStringLiteral("NumLevels"), 0).toLongLong();
            const qreal iAngleStart = qDegreesToRadians(params.value(QStringLiteral("AngleStart"), 0).toReal());
            const qreal iAngleExtent = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0).toReal());
            const qreal iAngleStep = qDegreesToRadians(params.value(QStringLiteral("AngleStep"), 0).toReal());
            const qreal iLowerContrast = params.value(QStringLiteral("EdgeContrastLower"), 20).toReal();
            const qreal iUpperContrast = params.value(QStringLiteral("EdgeContrastUpper"), 30).toReal();
            const qreal iMinimumSize = params.value(QStringLiteral("EdgeMinSize"), 5).toReal();
            const qreal iMinContrast = params.value(QStringLiteral("MinContrast"), 15).toReal();
            const HalconCpp::HTuple hMetric = HalconCpp::HString::FromUtf8(params.value(QStringLiteral("Metric"), QStringLiteral("use_polarity")).toString().toUtf8());
            const HalconCpp::HTuple hOptimization = HalconCpp::HString::FromUtf8(params.value(QStringLiteral("Optimization"), QStringLiteral("auto")).toString().toUtf8());
            HalconCpp::HTuple hContrast;
            hContrast.Append(iLowerContrast).Append(iUpperContrast).Append(iMinimumSize);

            HalconCpp::HTuple hMinContrast = "auto";
            if (iMinContrast > 5)
            {
                hMinContrast = iMinContrast;
            }

            const HalconCpp::HTuple hNumLevels = iNumLevels;
            const HalconCpp::HTuple hAngleStep = iAngleStep;

            const QString iScaled = params.value(QStringLiteral("Scaled"), QStringLiteral("none")).toString();
            const qreal iScaleMin = params.value(QStringLiteral("ScaleMin"), 0.9).toReal();
            const qreal iScaleMax = params.value(QStringLiteral("ScaleMax"), 1.1).toReal();

            if (QStringLiteral("none") != iScaled)
            {
                const HalconCpp::HTuple iScaleStep = "auto";
                HalconCpp::HShapeModel hModel(rImage, hNumLevels, iAngleStart, iAngleExtent, hAngleStep, iScaleMin, iScaleMax, iScaleStep, hOptimization, hMetric, hContrast, hMinContrast);
                return LXShapeTemplate(new HalconShapeTemplate(hModel), doDeleteLater);
            }
            else
            {
                HalconCpp::HShapeModel hModel(rImage, hNumLevels, iAngleStart, iAngleExtent, hAngleStep, hOptimization, hMetric, hContrast, hMinContrast);
                return LXShapeTemplate(new HalconShapeTemplate(hModel), doDeleteLater);
            }
        }
        else
        {
            return nullptr;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXRegionList HalconVisionManager::inspectShapeTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const
{
    try
    {
        LXRegionList lxRgns;
        QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
        if (!mat.empty() && 1 == mat.channels() && CV_8U == mat.depth() && hRegion)
        {
            HalconCpp::HImage hImage;
            hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
            HalconCpp::HImage rImage = hImage.ReduceDomain(hRegion->mRegion);

            const Hlong iNumLevels = params.value(QStringLiteral("NumLevels"), 5).toLongLong();
            const qreal iLowerContrast = params.value(QStringLiteral("EdgeContrastLower"), 10).toReal();
            const qreal iUpperContrast = params.value(QStringLiteral("EdgeContrastUpper"), 20).toReal();
            const qreal iMinimumSize = params.value(QStringLiteral("EdgeMinSize"), 5).toReal();

            HalconCpp::HRegion hRegion;
            HalconCpp::HTuple hContrast;
            hContrast.Append(iLowerContrast).Append(iUpperContrast).Append(iMinimumSize);
            rImage.InspectShapeModel(&hRegion, iNumLevels, hContrast);

            Hlong hNumRgns = hRegion.CountObj();
            if (hNumRgns > 1)
            {
                for (Hlong rr = 0; rr < hNumRgns; ++rr)
                {
                    lxRgns.emplace_back(new HalconRegion(hRegion.SelectObj(rr+1)), doDeleteLater);
                }
            }
            else
            {
                lxRgns.emplace_back(new HalconRegion(hRegion), doDeleteLater);
            }
        }

        return lxRgns;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return LXRegionList();
    }
}

LXMeasureModel HalconVisionManager::readMeasureModel(const QByteArray& blob) const
{
    try
    {
        if (blob.isEmpty())
        {
            return nullptr;
        }

        HalconCpp::HSerializedItem hSerializedItem(const_cast<QByteArray&>(blob).data(), blob.size(), "true");
        HalconCpp::HMetrologyModel hModel;
        hModel.DeserializeMetrologyModel(hSerializedItem);
        return LXMeasureModel(new HalconMeasureModel(hModel), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXMeasureModel HalconVisionManager::createMeasureModel(const QVariantMap& params) const
{
    try
    {
        const Hlong Width = params[QStringLiteral("Width")].toLongLong();
        const Hlong Height = params[QStringLiteral("Height")].toLongLong();
        HalconCpp::HMetrologyModel hModel;
        hModel.CreateMetrologyModel();
        if (Width && Height)
        {
            hModel.SetMetrologyModelImageSize(Width, Height);
        }
        return LXMeasureModel(new HalconMeasureModel(hModel), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXOCR HalconVisionManager::createOCR(const QVariantMap& params) const
{
    try
    {
        QString iType = params.value(QStringLiteral("OCRType")).toString();
        if (QStringLiteral("Mlp") == iType)
        {
            HalconCpp::HOCRMlp hOCR;
            return LXOCR(new HalconOCRMlp(hOCR), doDeleteLater);
        }
        else if (QStringLiteral("Svm") == iType)
        {
            HalconCpp::HOCRSvm hOCR;
            return LXOCR(new HalconOCRSvm(hOCR), doDeleteLater);
        }
        else if (QStringLiteral("SvmMlp") == iType)
        {
            HalconCpp::HOCRSvm hSvm;
            HalconCpp::HOCRMlp hMlp;
            return LXOCR(new HalconOCRSvmMlp(hSvm, hMlp), doDeleteLater);
        }
        else if (QStringLiteral("Ncc") == iType)
        {
            QStringList iChars;
            HalconCpp::HOCRSvm hSvm;
            HalconCpp::HOCRMlp hMlp;
            HalconCpp::HNCCModelArray hModels;
            return LXOCR(new HalconOCRNCC(iChars, hSvm, hMlp, hModels), doDeleteLater);
        }
        else if (QStringLiteral("Shape") == iType)
        {
            QStringList iChars;
            HalconCpp::HShapeModelArray iModels;
            return LXOCR(new HalconOCRShape(iChars, iModels), doDeleteLater);
        }
        else
        {
            return nullptr;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXOCR HalconVisionManager::readOCR(const QByteArray& blob, const QVariantMap& params) const
{
    try
    {
        if (blob.isEmpty())
        {
            return nullptr;
        }

        QString iType = params.value(QStringLiteral("OCRType")).toString();
        if (QStringLiteral("Mlp") == iType)
        {
            HalconCpp::HOCRMlp hOCR;
            HalconCpp::HSerializedItem hItem(const_cast<char*>(blob.constData()), blob.size(), "true");
            hOCR.DeserializeOcrClassMlp(hItem);
            return LXOCR(new HalconOCRMlp(hOCR), doDeleteLater);
        }
        else if (QStringLiteral("Svm") == iType)
        {
            HalconCpp::HOCRSvm hOCR;
            HalconCpp::HSerializedItem hItem(const_cast<char*>(blob.constData()), blob.size(), "true");
            hOCR.DeserializeOcrClassSvm(hItem);
            return LXOCR(new HalconOCRSvm(hOCR), doDeleteLater);
        }
        else if (QStringLiteral("SvmMlp") == iType)
        {
            HalconCpp::HOCRSvm hSvm;
            HalconCpp::HOCRMlp hMlp;
            const Hlong iSvmSize = params.value(QStringLiteral("SvmSize")).toLongLong();
            const Hlong iMlpSize = params.value(QStringLiteral("MlpSize")).toLongLong();
            if (iSvmSize && iMlpSize && (iSvmSize + iMlpSize) == blob.size())
            {
                HalconCpp::HSerializedItem hSvmItem(const_cast<char*>(blob.constData()), iSvmSize, "true");
                HalconCpp::HSerializedItem hMlpItem(const_cast<char*>(blob.constData()) + iSvmSize, iMlpSize, "true");
                hSvm.DeserializeOcrClassSvm(hSvmItem);
                hMlp.DeserializeOcrClassMlp(hMlpItem);
                return LXOCR(new HalconOCRSvmMlp(hSvm, hMlp), doDeleteLater);
            }
            else
            {
                return nullptr;
            }
        }
        else if (QStringLiteral("Ncc") == iType)
        {
            qsizetype iTotalModelSize = 0;
            const QVariantList  iSizes      = params.value(QStringLiteral("Sizes")).toList();
            const QStringList   iChars      = params.value(QStringLiteral("Chars")).toStringList();
            const Hlong         iSvmSize    = params.value(QStringLiteral("SvmSize")).toLongLong();
            const Hlong         iMlpSize    = params.value(QStringLiteral("MlpSize")).toLongLong();

            if (iSizes.size() != iChars.size())
            {
                return nullptr;
            }

            for (const QVariant &iVar : iSizes)
            {
                const qlonglong iSize = iVar.toLongLong();
                iTotalModelSize += iSize;
            }

            const qsizetype iTotalSize = iTotalModelSize + iSvmSize + iMlpSize;
            if (iTotalSize != blob.size())
            {
                return nullptr;
            }

            Hlong hStartPos = 0;
            std::vector<HalconCpp::HNCCModel> iModels;
            for (const QVariant& iVar : iSizes)
            {
                HalconCpp::HNCCModel hModel;
                const qlonglong iSize = iVar.toLongLong();
                HalconCpp::HSerializedItem hItem(const_cast<char*>(blob.constData()) + hStartPos, iSize, "true");
                hModel.DeserializeNccModel(hItem);
                iModels.push_back(hModel);

                hStartPos += iSize;
            }

            HalconCpp::HOCRSvm hSvm;
            HalconCpp::HOCRMlp hMlp;
            if (iSvmSize && iMlpSize)
            {
                HalconCpp::HSerializedItem hSvmItem(const_cast<char*>(blob.constData()) + iTotalModelSize, iSvmSize, "true");
                HalconCpp::HSerializedItem hMlpItem(const_cast<char*>(blob.constData()) + iTotalModelSize + iSvmSize, iMlpSize, "true");
                hSvm.DeserializeOcrClassSvm(hSvmItem);
                hMlp.DeserializeOcrClassMlp(hMlpItem);
            }

            HalconCpp::HNCCModelArray hModels = HalconCpp::HNCCModelArray(iModels.data(), static_cast<Hlong>(iModels.size()));
            return LXOCR(new HalconOCRNCC(iChars, hSvm, hMlp, hModels), doDeleteLater);
        }
        else if (QStringLiteral("Shape") == iType)
        {
            qsizetype iTotalSize = 0;
            const QVariantList iSizes = params.value(QStringLiteral("Sizes")).toList();
            const QStringList  iChars = params.value(QStringLiteral("Chars")).toStringList();
            if (iSizes.size() != iChars.size())
            {
                return nullptr;
            }

            for (const QVariant& iVar : iSizes)
            {
                const qlonglong iSize = iVar.toLongLong();
                iTotalSize += iSize;
            }

            if (iTotalSize == blob.size())
            {
                Hlong hStartPos = 0;
                std::vector<HalconCpp::HShapeModel> iModels;
                for (const QVariant& iVar : iSizes)
                {
                    HalconCpp::HShapeModel hModel;
                    const qlonglong iSize = iVar.toLongLong();
                    HalconCpp::HSerializedItem hItem(const_cast<char*>(blob.constData()) + hStartPos, iSize, "true");
                    hModel.DeserializeShapeModel(hItem);
                    iModels.push_back(hModel);

                    hStartPos += iSize;
                }

                HalconCpp::HShapeModelArray hModels = HalconCpp::HShapeModelArray(iModels.data(), static_cast<Hlong>(iModels.size()));
                return LXOCR(new HalconOCRShape(iChars, hModels), doDeleteLater);
            }
            else
            {
                return nullptr;
            }
        }
        else
        {
            return nullptr;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXOCR HalconVisionManager::readOCR(const QString& fileName, const QVariantMap& params) const
{
    try
    {
        QString iType = params.value(QStringLiteral("OCRType")).toString();
        if (QStringLiteral("Mlp") == iType)
        {
            const HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(fileName.toUtf8());
            HalconCpp::HOCRMlp hOCRMlp(hFileName);
            return LXOCR(new HalconOCRMlp(hOCRMlp), doDeleteLater);
        }
        else if (QStringLiteral("Svm") == iType)
        {
            const HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(fileName.toUtf8());
            HalconCpp::HOCRSvm hOCRSvm(hFileName);
            return LXOCR(new HalconOCRSvm(hOCRSvm), doDeleteLater);
        }
        else if (QStringLiteral("SvmMlp") == iType)
        {
            const HalconCpp::HString hSvmFileName = HalconCpp::HString::FromUtf8((fileName + QStringLiteral(".osc")).toUtf8());
            const HalconCpp::HString hMlpFileName = HalconCpp::HString::FromUtf8((fileName + QStringLiteral(".omc")).toUtf8());
            HalconCpp::HOCRSvm hSvm(hSvmFileName);
            HalconCpp::HOCRMlp hMlp(hMlpFileName);
            return LXOCR(new HalconOCRSvmMlp(hSvm, hMlp), doDeleteLater);
        }
        else
        {
            return nullptr;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXTextModel HalconVisionManager::createTextModelReader(const QVariantMap& params) const
{
    try
    {
        const bool iAuto = params.value(QStringLiteral("Auto"), true).toBool();
        const QString iOCRClassifier = params.value(QStringLiteral("OCRClassifier")).toString();
        if (iOCRClassifier.isEmpty())
        {
            return nullptr;
        }

        if (!QFileInfo::exists(iOCRClassifier))
        {
            qDebug() << QStringLiteral("OCRClassifier %1 not exists").arg(iOCRClassifier);
            return nullptr;
        }

        if (!QFileInfo(iOCRClassifier).isFile())
        {
            qDebug() << QStringLiteral("OCRClassifier %1 not a file").arg(iOCRClassifier);
            return nullptr;
        }

        const HalconCpp::HString hMode = iAuto ? "auto" : "manual";
        const HalconCpp::HString hOCRClassifier = HalconCpp::HString::FromUtf8(iOCRClassifier.toUtf8().constData());

        HalconCpp::HTextModel hModel;
        hModel.CreateTextModelReader(hMode, hOCRClassifier);

        return LXTextModel(new HalconTextModel(hModel), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

QVariantMap HalconVisionManager::applyDeepOcr(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const
{
    try
    {
        Q_UNUSED(params);
        if (mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
        {
            return QVariantMap();
        }

        HalconCpp::HImage hImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
        return applyDeepOcr(LXImage(new HalconImage(hImage), doDeleteLater), region, params);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

QVariantMap HalconVisionManager::applyDeepOcr(const LXImage& mat, const LXRegion& region, const QVariantMap& params) const
{
    try
    {
        Q_UNUSED(params);
        QVariantMap rResult;
        if (!gDlModelOcr.IsInitialized())
        {
            return rResult;
        }

        QSharedPointer<HalconImage> spImg = mat.dynamicCast<HalconImage>();
        if (!spImg)
        {
            return rResult;
        }

        HalconCpp::HImage rImage;
        if (region)
        {
            Hlong Row1 = 0, Column1 = 0, Row2 = 0, Column2 = 0;
            QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
            hRegion->mRegion.SmallestRectangle1(&Row1, &Column1, &Row2, &Column2);
            rImage = spImg->mImage.CropPart(Row1, Column1, Column2 - Column1, Row2 - Row1);
        }
        else
        {
            rImage = spImg->mImage;
        }

        HalconCpp::HDictArray hResult = gDlModelOcr.ApplyDeepOcr(rImage, "recognition");
        if (hResult.Length())
        {
            HalconCpp::HDict hDict = hResult.Tools()[0];
            HalconCpp::HTuple hHaveWord = hDict.GetDictParam("key_exists", "word");
            if (hHaveWord.L())
            {
                HalconCpp::HTuple hWord = hDict.GetDictTuple("word");
                QString iWord = QString::fromUtf8(hWord.ToString().ToUtf8());
                if (iWord.size() > 1)
                {
                    iWord = iWord.mid(1, iWord.size() - 2);
                }
                rResult[QStringLiteral("Word")] = iWord;
            }
        }

        return rResult;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

QVariantMap HalconVisionManager::vectorAngleToAffine(const QPointF& rOrigin, const qreal rAngle, const QPointF& aOrigin, const qreal aAngle) const
{
    try
    {
        HalconCpp::HHomMat2D hMat;
        hMat.VectorAngleToRigid(rOrigin.y(), rOrigin.x(), qDegreesToRadians(rAngle), aOrigin.y(), aOrigin.x(), qDegreesToRadians(aAngle));

        double Sy = 1., Phi = 0., Theta = 0., Tx = 0., Ty = 0.;
        hMat.HomMat2dToAffinePar(&Sy, &Phi, &Theta, &Tx, &Ty);

        QVariantMap rMap;
        rMap[QStringLiteral("Row")] = Tx;
        rMap[QStringLiteral("Column")] = Ty;
        rMap[QStringLiteral("Angle")] = qRadiansToDegrees(Phi);
        return rMap;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        QVariantMap rMap;
        rMap[QStringLiteral("Row")] = 0.;
        rMap[QStringLiteral("Column")] = 0.;
        rMap[QStringLiteral("Angle")] = 0.;
        return rMap;
    }
}

bool HalconVisionManager::saveImagePart(const cv::Mat& mat, const QString& fileName, const QRectF& rectPart) const
{
    try
    {
        if (mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
        {
            return false;
        }

        HalconCpp::HImage hImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
        HalconCpp::HImage hPartImage = hImage.CropPart(qRound(rectPart.y()), qRound(rectPart.x()), qRound(rectPart.width()), qRound(rectPart.height()));

        const HalconCpp::HString hFormat("png");
        const Hlong hFillColor = 0;
        const HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(fileName.toUtf8());
        hPartImage.WriteImage(hFormat, hFillColor, hFileName);
        return true;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return false;
    }
}

LXImage HalconVisionManager::rotateImage(const cv::Mat& mat, const qreal phi) const
{
    try
    {
        if (mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
        {
            return nullptr;
        }

        HalconCpp::HImage hImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
        HalconCpp::HImage hRotatedImage = hImage.RotateImage(phi, "bilinear");

        return LXImage(new HalconImage(hRotatedImage), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

LXImage HalconVisionManager::alignImage(const cv::Mat& mat,
    const QPointF& rOrigin,
    const qreal rAngle,
    const QPointF& aOrigin,
    const qreal aAngle) const
{
    try
    {
        if (mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
        {
            return nullptr;
        }

        HalconCpp::HImage hImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);

        HalconCpp::HHomMat2D hMat;
        hMat.VectorAngleToRigid(rOrigin.y(), rOrigin.x(), qDegreesToRadians(rAngle), aOrigin.y(), aOrigin.x(), qDegreesToRadians(aAngle));
        HalconCpp::HHomMat2D rMat = hMat.HomMat2dInvert();

        HalconCpp::HImage aImage = rMat.AffineTransImage(hImage, "constant", "false");
        return LXImage(new HalconImage(aImage), doDeleteLater);
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return nullptr;
    }
}

QVariantMap HalconVisionManager::doBlobAnalysis(const cv::Mat& mat,
    const LXRegion& region,
    const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorId")] = 1;

        if (mat.empty() || 1 != mat.channels() || CV_8U != mat.depth())
        {
            const QString iErrorMsg = QStringLiteral("Image format invalid");
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HalconCpp::HImage hImage;
        HalconCpp::HImage rImage;
        hImage.GenImage1Rect(mat.data, mat.cols, mat.rows, mat.step, 8, 8, "false", nullptr);
        if (region)
        {
            QSharedPointer<HalconRegion> hRegion = region.dynamicCast<HalconRegion>();
            rImage = hImage.ReduceDomain(hRegion->mRegion);
        }
        else
        {
            rImage = hImage;
        }

        const QString blobShape = params.value(QStringLiteral("BlobShape")).toString();
        const QString progPath = params.value(QStringLiteral("ProgPath")).toString();
        const QString procName = params.value(QStringLiteral("ProcName")).toString();

        HDevEngineCpp::HDevProgram hProgram;
        hProgram.LoadProgram(progPath.toStdWString().c_str());

        HalconCpp::HDict hParams = HalconUtil::toHDict(params);
        HDevEngineCpp::HDevProcedure hProc(hProgram, procName.toStdString().c_str());
        HDevEngineCpp::HDevProcedureCall hProcCall(hProc);
        hProcCall.SetInputIconicParamObject(1, rImage);
        hProcCall.SetInputCtrlParamTuple(1, hParams);
        hProcCall.Execute();

        HalconCpp::HDict hResults(hProcCall.GetOutputCtrlParamTuple(1).H());
        iResult[QStringLiteral("ErrorId")] = hResults.GetDictTuple("ErrorId").L();

        HalconCpp::HRegion hRegions = hProcCall.GetOutputIconicParamObject(1);
        if (!hRegions.IsInitialized())
        {
            const QString iErrorMsg = QStringLiteral("Blob segment error");
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        if (QLatin1String("Circle") == blobShape)
        {
            HalconCpp::HTuple hRow          = hResults.GetDictTuple("Row");
            HalconCpp::HTuple hColumn       = hResults.GetDictTuple("Column");
            HalconCpp::HTuple hRefRow       = hResults.GetDictTuple("RefRow");
            HalconCpp::HTuple hRefColumn    = hResults.GetDictTuple("RefColumn");
            HalconCpp::HTuple hPhi          = hResults.GetDictTuple("Angle");
            HalconCpp::HTuple hRadius       = hResults.GetDictTuple("Radius");
            HalconCpp::HTuple hScore        = hResults.GetDictTuple("Score");

            QVector<qreal> xList;
            QVector<qreal> yList;
            QVector<qreal> xRefList;
            QVector<qreal> yRefList;
            QVector<qreal> angleList;
            QVector<qreal> radiusList;
            QVector<qreal> scoreList;
            Hlong hNumRegions = hRow.Length();
            xList.reserve(hNumRegions);
            yList.reserve(hNumRegions);
            xRefList.reserve(hNumRegions);
            yRefList.reserve(hNumRegions);
            radiusList.reserve(hNumRegions);
            scoreList.reserve(hNumRegions);
            for (Hlong ll = 0; ll < hNumRegions; ++ll)
            {
                xList.push_back(hColumn[ll].D());
                yList.push_back(hRow[ll].D());
                xRefList.push_back(hRefColumn[ll].D());
                yRefList.push_back(hRefRow[ll].D());
                angleList.push_back(hPhi[ll].D());
                radiusList.push_back(hRadius[ll].D());
                scoreList.push_back(hScore[ll].D());
            }

            iResult[QStringLiteral("XList")]        = QVariant::fromValue(xList);
            iResult[QStringLiteral("YList")]        = QVariant::fromValue(yList);
            iResult[QStringLiteral("RefXList")]     = QVariant::fromValue(xRefList);
            iResult[QStringLiteral("RefYList")]     = QVariant::fromValue(yRefList);
            iResult[QStringLiteral("AngleList")]    = QVariant::fromValue(angleList);
            iResult[QStringLiteral("RadiusList")]   = QVariant::fromValue(radiusList);
            iResult[QStringLiteral("ScoreList")]    = QVariant::fromValue(scoreList);
        }
        else
        {
            HalconCpp::HTuple hRow       = hResults.GetDictTuple("Row");
            HalconCpp::HTuple hColumn    = hResults.GetDictTuple("Column");
            HalconCpp::HTuple hRefRow    = hResults.GetDictTuple("RefRow");
            HalconCpp::HTuple hRefColumn = hResults.GetDictTuple("RefColumn");
            HalconCpp::HTuple hPhi       = hResults.GetDictTuple("Angle");
            HalconCpp::HTuple hLength1   = hResults.GetDictTuple("Length1");
            HalconCpp::HTuple hLength2   = hResults.GetDictTuple("Length2");
            HalconCpp::HTuple hScore     = hResults.GetDictTuple("Score");

            QVector<qreal> xList;
            QVector<qreal> yList;
            QVector<qreal> xRefList;
            QVector<qreal> yRefList;
            QVector<qreal> angleList;
            QVector<qreal> widthList;
            QVector<qreal> heightList;
            QVector<qreal> scoreList;
            Hlong hNumRegions = hRow.Length();
            xList.reserve(hNumRegions);
            yList.reserve(hNumRegions);
            xRefList.reserve(hNumRegions);
            yRefList.reserve(hNumRegions);
            angleList.reserve(hNumRegions);
            widthList.reserve(hNumRegions);
            heightList.reserve(hNumRegions);
            scoreList.reserve(hNumRegions);
            for (Hlong ll = 0; ll < hNumRegions; ++ll)
            {
                xList.push_back(hColumn[ll].D());
                yList.push_back(hRow[ll].D());
                xRefList.push_back(hRefColumn[ll].D());
                yRefList.push_back(hRefRow[ll].D());
                angleList.push_back(hPhi[ll].D());
                widthList.push_back(hLength1[ll].D());
                heightList.push_back(hLength2[ll].D());
                scoreList.push_back(hScore[ll].D());
            }

            iResult[QStringLiteral("XList")]        = QVariant::fromValue(xList);
            iResult[QStringLiteral("YList")]        = QVariant::fromValue(yList);
            iResult[QStringLiteral("RefXList")]     = QVariant::fromValue(xRefList);
            iResult[QStringLiteral("RefYList")]     = QVariant::fromValue(yRefList);
            iResult[QStringLiteral("AngleList")]    = QVariant::fromValue(angleList);
            iResult[QStringLiteral("WidthList")]    = QVariant::fromValue(widthList);
            iResult[QStringLiteral("HeightList")]   = QVariant::fromValue(heightList);
            iResult[QStringLiteral("ScoreList")]    = QVariant::fromValue(scoreList);
        }

        iResult[QStringLiteral("Success")] = true;
        return iResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        iResult[QStringLiteral("ErrorId")] = 1;
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        iResult[QStringLiteral("ErrorId")] = 1;
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::segmentOCRSampleFull(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        const QString iSampleFile = params.value(QStringLiteral("SampleFile")).toString();
        if (!QFileInfo::exists(iSampleFile))
        {
            const QString iErrorMsg = QStringLiteral("Character samples file %1 not exists").arg(iSampleFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QString iFileName = QFileInfo(iSampleFile).baseName();
        QStringList iHexs = iFileName.split(QChar(L'-'));
        if (iHexs.isEmpty())
        {
            const QString iErrorMsg = QStringLiteral("Sample file name \"%1\" format error").arg(iFileName);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        iHexs.resize(iHexs.size() - 1);
        QByteArray iBytes = QByteArray::fromHex(iHexs.join(QChar(L'\0')).toLatin1());
        QString iCharClasses = QString::fromUtf8(iBytes);
        HalconCpp::HString hClass = HalconCpp::HString(iCharClasses.toStdWString().c_str());

        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(iSampleFile.toUtf8().constData());
        HalconCpp::HImage hImage(hFileName);

        Hlong hWidth = 0;
        Hlong hHeight = 0;
        HalconCpp::HString hType;
        hImage.GetImageSize(&hWidth, &hHeight);

        HalconCpp::HWindow hWnd(0, 0, hWidth + 50, hHeight + 30, 0, "buffer", "");
        hWnd.SetWindowParam("flush", "false");
        hWnd.SetPart(0, 0, hHeight + 29, hWidth + 49);
        hWnd.DispImage(hImage);
        hWnd.SetDraw("fill");

        hWnd.SetColored(12);
        HalconCpp::HString hCoordSystem("window");
        HalconCpp::HTuple hGenParamName;
        HalconCpp::HTuple hGenParamValue;
        HalconCpp::HString hColor("blue");

        Hlong hRow1 = 0;
        Hlong hColumn1 = 0;
        Hlong hRow2 = 0;
        Hlong hColumn2 = 0;
        HalconCpp::HRegion hCharRegion = hImage.GetDomain();
        hCharRegion.SmallestRectangle1(&hRow1, &hColumn1, &hRow2, &hColumn2);
        hWnd.DispText(hClass, hCoordSystem, hRow2 + 3, (hColumn1 + hColumn2) / 2 - 5, hColor, hGenParamName, hGenParamValue);

        hWnd.FlushBuffer();
        HalconCpp::HImage hDumpImage = hWnd.DumpWindowImage();
        HalconCpp::HImage hSegImage = hDumpImage.InterleaveChannels("argb", "match", 255);
        void* pvData = hSegImage.GetImagePointer1(&hType, &hWidth, &hHeight);
        cv::Mat iSegImage(hHeight, hWidth / 4, CV_8UC4, pvData);

        iResult[QStringLiteral("Success")] = true;
        iResult[QStringLiteral("SegImage")] = QVariant::fromValue(iSegImage.clone());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::segmentOCRSampleShape(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        const QString iSampleFile = params.value(QStringLiteral("SampleFile")).toString();
        if (!QFileInfo::exists(iSampleFile))
        {
            const QString iErrorMsg = QStringLiteral("Character samples file %1 not exists").arg(iSampleFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QString iFileName = QFileInfo(iSampleFile).baseName();
        QStringList iHexs = iFileName.split(QChar(L'-'));
        if (iHexs.isEmpty())
        {
            const QString iErrorMsg = QStringLiteral("Sample file name \"%1\" format error").arg(iFileName);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        iHexs.resize(iHexs.size() - 1);
        QByteArray iBytes = QByteArray::fromHex(iHexs.join(QChar(L'\0')).toLatin1());
        QString iCharClasses = QString::fromUtf8(iBytes);
        HalconCpp::HString hClass = HalconCpp::HString(iCharClasses.toStdWString().c_str());

        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(iSampleFile.toUtf8().constData());
        HalconCpp::HImage hImage(hFileName);

        const Hlong iNumLevels = params.value(QStringLiteral("NumLevels"), 2).toLongLong();
        const qreal iLowerContrast = params.value(QStringLiteral("EdgeContrastLower"), 10).toReal();
        const qreal iUpperContrast = params.value(QStringLiteral("EdgeContrastUpper"), 20).toReal();
        const qreal iMinimumSize = params.value(QStringLiteral("EdgeMinSize"), 5).toReal();

        HalconCpp::HRegion hShapeRegion;
        HalconCpp::HTuple hContrast;
        hContrast.Append(iLowerContrast).Append(iUpperContrast).Append(iMinimumSize);
        hImage.InspectShapeModel(&hShapeRegion, 1, hContrast);

        Hlong hWidth = 0;
        Hlong hHeight = 0;
        HalconCpp::HString hType;
        hImage.GetImageSize(&hWidth, &hHeight);

        HalconCpp::HWindow hWnd(0, 0, hWidth + 50, hHeight + 30, 0, "buffer", "");
        hWnd.SetWindowParam("flush", "false");
        hWnd.SetPart(0, 0, hHeight + 29, hWidth + 49);
        hWnd.SetDraw("fill");
        hWnd.SetColor("green");
        hWnd.DispImage(hImage);
        hWnd.DispRegion(hShapeRegion);

        hWnd.SetColored(12);
        HalconCpp::HString hCoordSystem("window");
        HalconCpp::HTuple hGenParamName;
        HalconCpp::HTuple hGenParamValue;
        HalconCpp::HString hColor("blue");

        Hlong hRow1 = 0;
        Hlong hColumn1 = 0;
        Hlong hRow2 = 0;
        Hlong hColumn2 = 0;
        HalconCpp::HRegion hCharRegion = hImage.GetDomain();
        hCharRegion.SmallestRectangle1(&hRow1, &hColumn1, &hRow2, &hColumn2);
        hWnd.DispText(hClass, hCoordSystem, hRow2 + 3, (hColumn1 + hColumn2) / 2 - 5, hColor, hGenParamName, hGenParamValue);

        hWnd.FlushBuffer();
        HalconCpp::HImage hDumpImage = hWnd.DumpWindowImage();
        HalconCpp::HImage hSegImage = hDumpImage.InterleaveChannels("argb", "match", 255);
        void* pvData = hSegImage.GetImagePointer1(&hType, &hWidth, &hHeight);
        cv::Mat iSegImage(hHeight, hWidth / 4, CV_8UC4, pvData);

        iResult[QStringLiteral("Success")] = true;
        iResult[QStringLiteral("SegImage")] = QVariant::fromValue(iSegImage.clone());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::segmentOCRSampleReduced(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        const QString iSampleFile = params.value(QStringLiteral("SampleFile")).toString();
        if (!QFileInfo::exists(iSampleFile))
        {
            const QString iErrorMsg = QStringLiteral("Character samples file %1 not exists").arg(iSampleFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QString iProgPath = params.value(QStringLiteral("SegmentScriptPath")).toString();
        QString iProcName = params.value(QStringLiteral("SegmentProcedureName")).toString();
        if (!QFileInfo::exists(iProgPath))
        {
            const QString iErrorMsg = QStringLiteral("Segment script %1 not exists").arg(iProgPath);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        bool iProcExists = false;
        HDevEngineCpp::HDevProgram hProgram;
        hProgram.LoadProgram(iProgPath.toStdWString().c_str());
        HalconCpp::HTuple hProcNames = hProgram.GetLocalProcedureNames();
        for (Hlong ll = 0; ll < hProcNames.Length(); ++ll)
        {
            QString iThisName = QString::fromUtf8(hProcNames[ll].S().ToUtf8());
            if (iThisName == iProcName)
            {
                iProcExists = true;
                break;
            }
        }

        if (!iProcExists)
        {
            const QString iErrorMsg = QStringLiteral("Procedure %1 not exists in %2").arg(iProcName).arg(iProgPath);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HDevEngineCpp::HDevProcedure hProc(hProgram, iProcName.toStdString().c_str());
        HDevEngineCpp::HDevProcedureCall hProcCall(hProc);

        QString iFileName = QFileInfo(iSampleFile).baseName();
        QStringList iHexs = iFileName.split(QChar(L'-'));
        if (iHexs.isEmpty())
        {
            const QString iErrorMsg = QStringLiteral("Sample file name \"%1\" format error").arg(iFileName);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        iHexs.resize(iHexs.size() - 1);
        QByteArray iBytes = QByteArray::fromHex(iHexs.join(QChar(L'\0')).toLatin1());
        QString iCharClasses = QString::fromUtf8(iBytes);
        HalconCpp::HTuple hClasses;
        for (const auto iCharClass : iCharClasses)
        {
            HalconCpp::HString hClass = HalconCpp::HString(QString(1, iCharClass).toStdWString().c_str());
            hClasses.Append(hClass);
        }

        HalconCpp::HDict hSegParams = HalconUtil::toHDict(params.value(QStringLiteral("SegmentParams")).toMap());
        HalconCpp::HDict hSelParams = HalconUtil::toHDict(params.value(QStringLiteral("SelectParams")).toMap());
        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(iSampleFile.toUtf8().constData());
        HalconCpp::HImage hImage(hFileName);
        hProcCall.SetInputIconicParamObject(1, hImage);
        hProcCall.SetInputCtrlParamTuple(1, hSegParams);
        hProcCall.SetInputCtrlParamTuple(2, hSelParams);
        hProcCall.Execute();

        Hlong hWidth = 0;
        Hlong hHeight = 0;
        HalconCpp::HString hType;
        hImage.GetImageSize(&hWidth, &hHeight);

        HalconCpp::HWindow hWnd(0, 0, hWidth + 50, hHeight + 30, 0, "buffer", "");
        hWnd.SetWindowParam("flush", "false");
        hWnd.SetPart(0, 0, hHeight + 29, hWidth + 49);
        hWnd.DispImage(hImage);
        hWnd.SetDraw("fill");

        HalconCpp::HRegion hCharRegions = hProcCall.GetOutputIconicParamObject(1);
        if (hCharRegions.IsInitialized())
        {
            hWnd.SetColored(12);
            hWnd.DispObj(hCharRegions);
            HalconCpp::HString hCoordSystem("window");
            HalconCpp::HTuple hGenParamName;
            HalconCpp::HTuple hGenParamValue;
            if (hCharRegions.CountObj() == hClasses.Length())
            {
                HalconCpp::HString hColor("blue");
                for (Hlong cc = 0; cc < hClasses.Length(); ++cc)
                {
                    Hlong hRow1 = 0;
                    Hlong hColumn1 = 0;
                    Hlong hRow2 = 0;
                    Hlong hColumn2 = 0;
                    HalconCpp::HRegion hCharRegion = hCharRegions.SelectObj(cc + 1);
                    hCharRegion.SmallestRectangle1(&hRow1, &hColumn1, &hRow2, &hColumn2);
                    hWnd.DispText(hClasses[cc].S(), hCoordSystem, hRow2 + 3, (hColumn1 + hColumn2) / 2 - 5, hColor, hGenParamName, hGenParamValue);
                }
            }
            else
            {
                HalconCpp::HString hColor("red");
                hWnd.DispText(HalconCpp::HString("Error! Don't add!"), hCoordSystem, 1, 1, hColor, hGenParamName, hGenParamValue);
            }
        }

        hWnd.FlushBuffer();
        HalconCpp::HImage hDumpImage = hWnd.DumpWindowImage();
        HalconCpp::HImage hSegImage = hDumpImage.InterleaveChannels("argb", "match", 255);
        void* pvData = hSegImage.GetImagePointer1(&hType, &hWidth, &hHeight);
        cv::Mat iSegImage(hHeight, hWidth / 4, CV_8UC4, pvData);

        if (hCharRegions.IsInitialized() && hCharRegions.CountObj() == hClasses.Length())
        {
            iResult[QStringLiteral("Success")] = true;
            iResult[QStringLiteral("SegImage")] = QVariant::fromValue(iSegImage.clone());
            return iResult;
        }
        else
        {
            const QString iErrorMsg = QStringLiteral("Character segment error");
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            iResult[QStringLiteral("SegImage")] = QVariant::fromValue(iSegImage.clone());
            qDebug() << iErrorMsg;
            return iResult;
        }
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::segmentOCRSample(const QVariantMap& params) const
{
    const QString iMode = params.value(QStringLiteral("ClassifierType")).toString();
    if (QStringLiteral("Mlp") == iMode || QStringLiteral("Svm") == iMode || QStringLiteral("SvmMlp") == iMode)
    {
        return segmentOCRSampleReduced(params);
    }
    else if (QStringLiteral("Shape") == iMode)
    {
        return segmentOCRSampleShape(params);
    }
    else if (QStringLiteral("Ncc") == iMode)
    {
        return segmentOCRSampleFull(params);
    }
    else
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QStringLiteral("Unknown OCR type %1").arg(iMode);
        return iResult;
    }
}

QVariantMap HalconVisionManager::appendOCRSampleFull(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        const QString iSampleFile = params.value(QStringLiteral("SampleFile")).toString();
        if (!QFileInfo::exists(iSampleFile))
        {
            const QString iErrorMsg = QStringLiteral("Character samples file %1 not exists").arg(iSampleFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        QString iFileName = QFileInfo(iSampleFile).baseName();
        QStringList iHexs = iFileName.split(QChar(L'-'));
        if (iHexs.isEmpty())
        {
            const QString iErrorMsg = QStringLiteral("Sample file name \"%1\" format error").arg(iFileName);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        iHexs.resize(iHexs.size() - 1);
        QByteArray iBytes = QByteArray::fromHex(iHexs.join(QChar(L'\0')).toLatin1());
        QString iCharClasses = QString::fromUtf8(iBytes);

        HalconCpp::HTuple hClasses;
        HalconCpp::HString hClass = HalconCpp::HString(iCharClasses.toStdWString().c_str());
        hClasses.Append(hClass);

        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(iSampleFile.toUtf8().constData());
        HalconCpp::HImage hImage(hFileName);

        HalconCpp::HRegion hCharRegions = hImage.GetDomain();
        if (hCharRegions.IsInitialized() && hCharRegions.CountObj() == hClasses.Length())
        {
            const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
            HalconCpp::AppendOcrTrainf(hCharRegions, hImage, hClasses, hTrainingFile);
            iResult[QStringLiteral("Success")] = true;
            return iResult;
        }
        else
        {
            const QString iErrorMsg = QStringLiteral("Character segment error");
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::appendOCRSampleShape(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        const QString iSampleFile = params.value(QStringLiteral("SampleFile")).toString();
        if (!QFileInfo::exists(iSampleFile))
        {
            const QString iErrorMsg = QStringLiteral("Character samples file %1 not exists").arg(iSampleFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        QString iFileName = QFileInfo(iSampleFile).baseName();
        QStringList iHexs = iFileName.split(QChar(L'-'));
        if (iHexs.isEmpty())
        {
            const QString iErrorMsg = QStringLiteral("Sample file name \"%1\" format error").arg(iFileName);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        iHexs.resize(iHexs.size() - 1);
        QByteArray iBytes = QByteArray::fromHex(iHexs.join(QChar(L'\0')).toLatin1());
        QString iCharClasses = QString::fromUtf8(iBytes);

        HalconCpp::HTuple hClasses;
        HalconCpp::HString hClass = HalconCpp::HString(iCharClasses.toStdWString().c_str());
        hClasses.Append(hClass);

        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(iSampleFile.toUtf8().constData());
        HalconCpp::HImage hImage(hFileName);

        HalconCpp::HRegion hCharRegions = hImage.GetDomain();
        if (hCharRegions.IsInitialized() && hCharRegions.CountObj() == hClasses.Length())
        {
            const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
            HalconCpp::AppendOcrTrainf(hCharRegions, hImage, hClasses, hTrainingFile);
            iResult[QStringLiteral("Success")] = true;
            return iResult;
        }
        else
        {
            const QString iErrorMsg = QStringLiteral("Character segment error");
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::appendOCRSampleReduced(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        const QString iSampleFile = params.value(QStringLiteral("SampleFile")).toString();
        if (!QFileInfo::exists(iSampleFile))
        {
            const QString iErrorMsg = QStringLiteral("Character samples file %1 not exists").arg(iSampleFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        QString iProgPath = params.value(QStringLiteral("SegmentScriptPath")).toString();
        QString iProcName = params.value(QStringLiteral("SegmentProcedureName")).toString();
        if (!QFileInfo::exists(iProgPath))
        {
            const QString iErrorMsg = QStringLiteral("Segment script %1 not exists").arg(iProgPath);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        bool iProcExists = false;
        HDevEngineCpp::HDevProgram hProgram;
        hProgram.LoadProgram(iProgPath.toStdWString().c_str());
        HalconCpp::HTuple hProcNames = hProgram.GetLocalProcedureNames();
        for (Hlong ll = 0; ll < hProcNames.Length(); ++ll)
        {
            QString iThisName = QString::fromUtf8(hProcNames[ll].S().ToUtf8());
            if (iThisName == iProcName)
            {
                iProcExists = true;
                break;
            }
        }

        if (!iProcExists)
        {
            const QString iErrorMsg = QStringLiteral("Procedure %1 not exists in %2").arg(iProcName).arg(iProgPath);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HDevEngineCpp::HDevProcedure hProc(hProgram, iProcName.toStdString().c_str());
        HDevEngineCpp::HDevProcedureCall hProcCall(hProc);

        QString iFileName = QFileInfo(iSampleFile).baseName();
        QStringList iHexs = iFileName.split(QChar(L'-'));
        if (iHexs.isEmpty())
        {
            const QString iErrorMsg = QStringLiteral("Sample file name \"%1\" format error").arg(iFileName);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        iHexs.resize(iHexs.size() - 1);
        QByteArray iBytes = QByteArray::fromHex(iHexs.join(QChar(L'\0')).toLatin1());
        QString iCharClasses = QString::fromUtf8(iBytes);
        HalconCpp::HTuple hClasses;
        for (const auto iCharClass : iCharClasses)
        {
            HalconCpp::HString hClass = HalconCpp::HString(QString(1, iCharClass).toStdWString().c_str());
            hClasses.Append(hClass);
        }

        HalconCpp::HDict hSegParams = HalconUtil::toHDict(params.value(QStringLiteral("SegmentParams")).toMap());
        HalconCpp::HDict hSelParams = HalconUtil::toHDict(params.value(QStringLiteral("SelectParams")).toMap());
        HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(iSampleFile.toUtf8().constData());
        HalconCpp::HImage hImage(hFileName);
        hProcCall.SetInputIconicParamObject(1, hImage);
        hProcCall.SetInputCtrlParamTuple(1, hSegParams);
        hProcCall.SetInputCtrlParamTuple(2, hSelParams);
        hProcCall.Execute();

        HalconCpp::HRegion hCharRegions = hProcCall.GetOutputIconicParamObject(1);
        if (hCharRegions.IsInitialized() && hCharRegions.CountObj() == hClasses.Length())
        {
            const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
            HalconCpp::AppendOcrTrainf(hCharRegions, hImage, hClasses, hTrainingFile);
            iResult[QStringLiteral("Success")] = true;
            return iResult;
        }
        else
        {
            const QString iErrorMsg = QStringLiteral("Character segment error");
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::appendOCRSample(const QVariantMap& params) const
{
    const QString iMode = params.value(QStringLiteral("ClassifierType")).toString();
    if (QStringLiteral("Mlp") == iMode || QStringLiteral("Svm") == iMode || QStringLiteral("SvmMlp") == iMode)
    {
        return appendOCRSampleReduced(params);
    }
    else if (QStringLiteral("Shape") == iMode)
    {
        return appendOCRSampleShape(params);
    }
    else if (QStringLiteral("Ncc") == iMode)
    {
        return appendOCRSampleFull(params);
    }
    else
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QStringLiteral("Unknown OCR type %1").arg(iMode);
        return iResult;
    }
}

QVariantMap HalconVisionManager::replaceOCRSamples(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        QString iSamplesDir = params.value(QStringLiteral("SamplesDir")).toString();
        if (!QFileInfo::exists(iSamplesDir))
        {
            const QString iErrorMsg = QStringLiteral("Character samples directory %1 not exists").arg(iSamplesDir);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QElapsedTimer timer;
        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        timer.start();
        while (QFileInfo::exists(iTrainingFile) && !timer.hasExpired(2000))
        {
            QFile::remove(iTrainingFile);
            QThread::msleep(100);
        }

        if (QFileInfo::exists(iTrainingFile))
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 not removed").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QString iProgPath = params.value(QStringLiteral("SegmentScriptPath")).toString();
        QString iProcName = params.value(QStringLiteral("SegmentProcedureName")).toString();
        if (!QFileInfo::exists(iProgPath))
        {
            const QString iErrorMsg = QStringLiteral("Segment script %1 not exists").arg(iProgPath);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        bool iProcExists = false;
        HDevEngineCpp::HDevProgram hProgram;
        hProgram.LoadProgram(iProgPath.toStdWString().c_str());
        HalconCpp::HTuple hProcNames = hProgram.GetLocalProcedureNames();
        for (Hlong ll = 0; ll < hProcNames.Length(); ++ll)
        {
            QString iThisName = QString::fromUtf8(hProcNames[ll].S().ToUtf8());
            if (iThisName == iProcName)
            {
                iProcExists = true;
                break;
            }
        }

        if (!iProcExists)
        {
            const QString iErrorMsg = QStringLiteral("Procedure %1 not exists in %2").arg(iProcName).arg(iProgPath);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HDevEngineCpp::HDevProcedure hProc(hProgram, iProcName.toStdString().c_str());
        HDevEngineCpp::HDevProcedureCall hProcCall(hProc);

        QStringList filters;
        QStringList iSampleFiles;
        filters << QStringLiteral("*.bmp") << QStringLiteral("*.dib");
        filters << QStringLiteral("*.png") << QStringLiteral("*.jp2");
        filters << QStringLiteral("*.tiff") << QStringLiteral("*.tif");
        filters << QStringLiteral("*.jpg") << QStringLiteral("*.jpeg") << QStringLiteral("*.jpe");
        QDirIterator it(iSamplesDir, filters, QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext())
        {
            iSampleFiles.push_back(it.next());
        }

        if (iSampleFiles.empty())
        {
            const QString iErrorMsg = QStringLiteral("Character samples directory %1 empty").arg(iSamplesDir);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HalconCpp::HTuple hCharacters;
        const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
        for (const QString& iSampleFile : iSampleFiles)
        {
            QString iFileName = QFileInfo(iSampleFile).baseName();
            QStringList iHexs = iFileName.split(QChar(L'-'));
            if (iHexs.isEmpty())
            {
                continue;
            }

            iHexs.resize(iHexs.size() - 1);
            QByteArray iBytes = QByteArray::fromHex(iHexs.join(QChar(L'\0')).toLatin1());
            QString iCharClasses = QString::fromUtf8(iBytes);
            HalconCpp::HTuple hClasses;
            for (const auto iCharClass : iCharClasses)
            {
                HalconCpp::HString hClass = HalconCpp::HString(QString(1, iCharClass).toStdWString().c_str());
                hClasses.Append(hClass);
                hCharacters.Append(hClass);
            }

            HalconCpp::HDict hSegParams = HalconUtil::toHDict(params.value(QStringLiteral("SegmentParams")).toMap());
            HalconCpp::HDict hSelParams = HalconUtil::toHDict(params.value(QStringLiteral("SelectParams")).toMap());
            HalconCpp::HString hFileName = HalconCpp::HString::FromUtf8(iSampleFile.toUtf8().constData());
            HalconCpp::HImage hImage(hFileName);
            hProcCall.SetInputIconicParamObject(1, hImage);
            hProcCall.SetInputCtrlParamTuple(1, hSegParams);
            hProcCall.SetInputCtrlParamTuple(2, hSelParams);
            hProcCall.Execute();

            HalconCpp::HRegion hCharRegions = hProcCall.GetOutputIconicParamObject(1);
            if (hCharRegions.IsInitialized() && hCharRegions.CountObj() == hClasses.Length())
            {
                HalconCpp::AppendOcrTrainf(hCharRegions, hImage, hClasses, hTrainingFile);
            }
            else
            {
                const QString iErrorMsg = QStringLiteral("Character segment error in sample %1").arg(iSampleFile);
                iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
                qDebug() << iErrorMsg;
                return iResult;
            }
        }

        iResult[QStringLiteral("Success")] = true;
        return iResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::readOCRCharacters(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        if (!QFileInfo::exists(iTrainingFile))
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 not exists").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HalconCpp::HImage hImages;
        const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
        const HalconCpp::HTuple hCharNames = hImages.ReadOcrTrainf(hTrainingFile);
        const HalconCpp::HImage hCharImages = hImages.FullDomain();
        if (hCharNames.Length() != hCharImages.CountObj() || !hCharNames.Length())
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 empty or damaged").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QStringList iCharNames;
        std::map<QString, QVector<std::tuple<QImage, qlonglong>>> iCharNameImages;
        for (Hlong ll = 0; ll < hCharNames.Length(); ++ll)
        {
            Hlong Width = 0;
            Hlong Height = 0;
            HalconCpp::HString Type;
            void* dst = hCharImages.SelectObj(ll + 1).GetImagePointer1(&Type, &Width, &Height);
            QImage iCharImage(static_cast<uchar*>(dst), Width, Height, Width, QImage::Format_Grayscale8);

            const QString iCharName = QString::fromUtf8(hCharNames[ll].S().ToUtf8());
            iCharNameImages[iCharName].append(std::make_tuple(iCharImage.copy(), ll));
            iCharNames.push_back(iCharName);
        }

        QVariantMap rCharNameImages;
        for (const auto& iItem : iCharNameImages)
        {
            rCharNameImages.insert(iItem.first, QVariant::fromValue(iItem.second));
        }

        iResult[QStringLiteral("Success")] = true;
        iResult[QStringLiteral("CharNameImages")] = rCharNameImages;
        iResult[QStringLiteral("CharNames")] = iCharNames;
        iResult[QStringLiteral("CharImages")] = QVariant::fromValue(LXImage(new HalconImage(hImages), doDeleteLater));

        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconVisionManager::packOCRSamples(const QVariantMap& params) const
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        QElapsedTimer timer;
        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        timer.start();
        while (QFileInfo::exists(iTrainingFile) && !timer.hasExpired(2000))
        {
            QFile::remove(iTrainingFile);
            QThread::msleep(100);
        }

        if (QFileInfo::exists(iTrainingFile))
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 not removed").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        QStringList iCharNames = params.value(QStringLiteral("CharNames")).toStringList();
        LXImage lCharImages = params.value(QStringLiteral("CharImages")).value<LXImage>();
        QVector<int> iCharIndexs = params.value(QStringLiteral("CharIndexs")).value<QVector<int>>();
        QSharedPointer<HalconImage> hImages = lCharImages.dynamicCast<HalconImage>();
        if (!hImages)
        {
            const QString iErrorMsg = QStringLiteral("Invalid or empty image list");
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HalconCpp::HImage hCharImages = hImages->mImage;
        if (iCharNames.size() != hCharImages.CountObj() || iCharNames.empty())
        {
            const QString iErrorMsg = QStringLiteral("Invalid or empty image list");
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        std::sort(iCharIndexs.begin(), iCharIndexs.end());
        const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
        for (Hlong ll = 0; ll < iCharNames.size(); ++ll)
        {
            if (std::binary_search(iCharIndexs.begin(), iCharIndexs.end(), ll))
            {
                HalconCpp::HString hCharName = HalconCpp::HString::FromUtf8(iCharNames[ll].toUtf8());
                HalconCpp::HImage hCharImage = hCharImages.SelectObj(ll + 1);
                HalconCpp::HRegion hCharRegion = hCharImage.GetDomain();
                HalconCpp::AppendOcrTrainf(hCharRegion, hCharImage, hCharName, hTrainingFile);
            }
        }

        iResult[QStringLiteral("Success")] = true;
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}
