#include "halcon_util.h"
#include "halcon_ocr_shape.h"
#include "halcon_image.h"
#include "halcon_region.h"
#include <QtCore>
#include <QtGui>
#include <hdevengine/HDevEngineCpp.h>
extern void doDeleteLater(QObject* obj);

HalconOCRShape::HalconOCRShape(const QStringList &chars, const HalconCpp::HShapeModelArray &models)
    : LaserXOCR(nullptr)
    , mChars(chars)
    , mModels(models)
{
}

HalconOCRShape::~HalconOCRShape()
{
}

QByteArray HalconOCRShape::getBlob() const
{
    try
    {
        QByteArray iBlob;
        const Hlong hLen = mModels.Length();
        const HalconCpp::HShapeModel* hModels = mModels.Tools();
        for (Hlong ll = 0; ll < hLen; ++ll)
        {
            Hlong hSize = 0;
            HalconCpp::HSerializedItem hItem = hModels[ll].SerializeShapeModel();
            void* hPointer = hItem.GetSerializedItemPtr(&hSize);
            QByteArray iBytes(static_cast<char*>(hPointer), hSize);
            iBlob += iBytes;
        }

        return iBlob;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QByteArray();
    }
}

QVariantMap HalconOCRShape::getParams() const
{
    try
    {
        QVariantList iSizes;
        const Hlong hLen = mModels.Length();
        const HalconCpp::HShapeModel* hModels = mModels.Tools();
        for (Hlong ll = 0; ll < hLen; ++ll)
        {
            Hlong hSize = 0;
            HalconCpp::HSerializedItem hItem = hModels[ll].SerializeShapeModel();
            hItem.GetSerializedItemPtr(&hSize);
            iSizes.append(hSize);
        }

        QVariantMap iParams;
        iParams[QStringLiteral("OCRType")] = QStringLiteral("Shape");
        iParams[QStringLiteral("Chars")] = mChars;
        iParams[QStringLiteral("Sizes")] = iSizes;
        return iParams;
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}

bool HalconOCRShape::writeOCR(const QString& fileName) const
{
    Q_UNUSED(fileName);
    return false;
}

QVariantMap HalconOCRShape::trainOCR(const QVariantMap& params)
{
    try
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;

        QString iTrainingFile = params.value(QStringLiteral("TrainingFile")).toString();
        if (!QFileInfo::exists(iTrainingFile))
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 not exists").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }

        HalconCpp::HImage hImages;
        const HalconCpp::HTuple hTrainingFile = HalconCpp::HString::FromUtf8(iTrainingFile.toUtf8());
        const HalconCpp::HTuple hCharNames = hImages.ReadOcrTrainf(hTrainingFile);
        const HalconCpp::HImage hCharImages = hImages.FullDomain();
        if (hCharNames.Length() != hCharImages.CountObj() || !hCharNames.Length())
        {
            const QString iErrorMsg = QStringLiteral("Character training file %1 empty or damaged").arg(iTrainingFile);
            iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
            qDebug() << iErrorMsg;
            return iResult;
        }


        const HalconCpp::HTuple hNumLevels = params.value(QStringLiteral("NumLevels"), 0).toLongLong();
        const qreal hAngleExtent = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0.0).toReal());
        const qreal hAngleStart = -hAngleExtent / 2;
        const HalconCpp::HTuple hAngleStep = "auto";
        const HalconCpp::HString hMetric = HalconCpp::HString::FromUtf8(params.value(QStringLiteral("Metric"), QStringLiteral("ignore_local_polarity")).toString().toUtf8());
        const HalconCpp::HTuple hOptimization = HalconCpp::HString::FromUtf8(params.value(QStringLiteral("Optimization"), QStringLiteral("auto")).toString().toUtf8());

        const qreal iLowerContrast = params.value(QStringLiteral("EdgeContrastLower"), 15).toReal();
        const qreal iUpperContrast = params.value(QStringLiteral("EdgeContrastUpper"), 20).toReal();
        const qreal iMinimumSize = params.value(QStringLiteral("EdgeMinSize"), 5).toReal();
        const qreal iMinContrast = params.value(QStringLiteral("MinContrast"), 15).toReal();
        HalconCpp::HTuple hContrast; hContrast.Append(iLowerContrast).Append(iUpperContrast).Append(iMinimumSize);

        HalconCpp::HTuple hMinContrast = "auto";
        if (iMinContrast > 5)
        {
            hMinContrast = iMinContrast;
        }

        QStringList iChars;
        std::vector<HalconCpp::HShapeModel> iModels;
        const Hlong hNumChars = hCharNames.Length();
        for (Hlong ll = 0; ll < hNumChars; ++ll)
        {
            const QString iCharName = QString::fromUtf8(hCharNames[ll].S().ToUtf8());
            iChars.push_back(iCharName);

            HalconCpp::HImage hCharImage = hCharImages.SelectObj(ll + 1);
            HalconCpp::HShapeModel hModel(hCharImage, hNumLevels, hAngleStart, hAngleExtent, hAngleStep, hOptimization, hMetric, hContrast, hMinContrast);
            iModels.push_back(hModel);
        }

        mChars = iChars;
        mModels = HalconCpp::HShapeModelArray(iModels.data(), static_cast<Hlong>(iModels.size()));

        iResult[QStringLiteral("Success")] = true;
        iResult[QStringLiteral("Error")] = 0;
        iResult[QStringLiteral("ErrorLog")] = QVariantList();
        return iResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.Message());
        qDebug() << QString::fromUtf8(e.Message());
        return iResult;
    }
    catch (const HalconCpp::HException& e)
    {
        QVariantMap iResult;
        iResult[QStringLiteral("Success")] = false;
        iResult[QStringLiteral("ErrorMsg")] = QString::fromUtf8(e.ErrorMessage().ToUtf8());
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return iResult;
    }
}

QVariantMap HalconOCRShape::doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    Q_UNUSED(mat);
    Q_UNUSED(cRegion);
    Q_UNUSED(params);
    QVariantMap iResult;
    const QString iErrorMsg = QStringLiteral("SVM OCR classifier can't be used alone");
    iResult[QStringLiteral("Success")] = false;
    iResult[QStringLiteral("ErrorMsg")] = iErrorMsg;
    qDebug() << iErrorMsg;
    return iResult;
}

QVariantMap HalconOCRShape::doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const
{
    try
    {
        QVariantMap rResult;
        QSharedPointer<HalconImage> spImg = mat.dynamicCast<HalconImage>();
        if (!spImg)
        {
            return rResult;
        }

        QSharedPointer<HalconRegion> hRegion = cRegion.dynamicCast<HalconRegion>();
        if (!hRegion)
        {
            return rResult;
        }

        if (hRegion->area() < 1)
        {
            qDebug() << QStringLiteral("Char box empty error");
            return rResult;
        }

        const qreal hAngleExtent = qDegreesToRadians(params.value(QStringLiteral("AngleExtent"), 0.0).toReal());
        const qreal hAngleStart = -hAngleExtent / 2;
        const qreal hMinScore = params.value(QStringLiteral("MinScore"), 0.9).toReal();
        const Hlong hNumMatches = params.value(QStringLiteral("NumChars"), 0).toInt();
        const qreal hMaxOverlap = params.value(QStringLiteral("MaxOverlap"), 0.1).toReal();
        const qreal hGreediness = params.value(QStringLiteral("Greediness"), 0.9).toReal();
        const Hlong iMaxDeformation = params.value(QStringLiteral("MaxDeformation"), 0ll).toLongLong();
        const HalconCpp::HTuple hNumLevels = 0;

        HalconCpp::HTuple hSubPixel;
        hSubPixel.Append("least_squares").Append(HalconCpp::HString(QStringLiteral("max_deformation %1").arg(iMaxDeformation).toStdString().c_str()));

        HalconCpp::HTuple hRow;
        HalconCpp::HTuple hColumn;
        HalconCpp::HTuple hAngle;
        HalconCpp::HTuple hScore;
        HalconCpp::HTuple hModel;
        HalconCpp::HImage rImage = spImg->mImage.ReduceDomain(hRegion->mRegion);
        HalconCpp::HShapeModel::FindShapeModels(rImage, mModels, hAngleStart, hAngleExtent, hMinScore, hNumMatches,
            hMaxOverlap, hSubPixel, hNumLevels, hGreediness, &hRow, &hColumn, &hAngle, &hScore, &hModel);

        QStringList iCharacterClasses;
        QVector<qreal> iConfidences;
        QVector<QRectF> iCharacterRects;
        for (Hlong ll = 0; ll < hModel.Length(); ++ll)
        {
            const Hlong hCharIndex = hModel[ll].L();
            iCharacterClasses.push_back(mChars[hCharIndex]);
            iConfidences.push_back(hScore[ll].D());

            qreal hRow1 = 0;
            qreal hColumn1 = 0;
            qreal hRow2 = 0;
            qreal hColumn2 = 0;
            HalconCpp::HXLDCont hCharConts = mModels.Tools()[hCharIndex].GetShapeModelContours(1);
            const Hlong hNumConts = hCharConts.CountObj();
            if (hNumConts > 1)
            {
                QRectF iBox;
                for (Hlong cc = 0; cc < hNumConts; ++cc)
                {
                    hCharConts.SelectObj(cc + 1).SmallestRectangle1Xld(&hRow1, &hColumn1, &hRow2, &hColumn2);
                    iBox = iBox.united(QRectF(hColumn1 + hColumn[ll].D(), hRow1 + hRow[ll].D(), hColumn2 - hColumn1, hRow2 - hRow1));
                }
                iCharacterRects.push_back(iBox);
            }
            else
            {
                hCharConts.SmallestRectangle1Xld(&hRow1, &hColumn1, &hRow2, &hColumn2);
                iCharacterRects.push_back(QRectF(hColumn1 + hColumn[ll].D(), hRow1 + hRow[ll].D(), hColumn2 - hColumn1, hRow2 - hRow1));
            }
        }

        rResult[QStringLiteral("CharacterClasses")] = iCharacterClasses;
        rResult[QStringLiteral("Confidences")] = QVariant::fromValue(iConfidences);
        rResult[QStringLiteral("CharacterRects")] = QVariant::fromValue(iCharacterRects);
        return rResult;
    }
    catch (const HDevEngineCpp::HDevEngineException& e)
    {
        qDebug() << QString::fromUtf8(e.Message());
        return QVariantMap();
    }
    catch (const HalconCpp::HException& e)
    {
        qDebug() << QString::fromUtf8(e.ErrorMessage().ToUtf8());
        return QVariantMap();
    }
}
