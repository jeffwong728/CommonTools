#ifndef HALCON_CONTOUR_H
#define HALCON_CONTOUR_H

#include <laser_x_contour.h>
#include <halconcpp/HalconCpp.h>

class HalconContour : public LaserXContour
{
    Q_OBJECT
public:
    HalconContour(const HalconCpp::HXLDCont &xldCont);
    ~HalconContour();

public:
    void writeContour(const QString& fileName) const override;

public:
    HalconCpp::HXLDCont mXLDCont;
};

#endif // HALCON_CONTOUR_H
