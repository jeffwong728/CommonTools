#ifndef HALCON_IMAGE_H
#define HALCON_IMAGE_H

#include <laser_x_image.h>
#include <halconcpp/HalconCpp.h>

class HalconImage : public LaserXImage
{
    Q_OBJECT
public:
    HalconImage(const HalconCpp::HImage &image);
    ~HalconImage();

public:
    QSize getSize() const override;
    void writeImage(const QString& format, const qlonglong fillColor, const QString& fileName) const override;
    LXImage reduceDomain(const LXRegion& region) const override;
    bool copyCVMat(const cv::Mat& mat) override;
    bool refCVMat(const cv::Mat& mat) override;
    cv::Mat toCVMat() const override;

public:
    HalconCpp::HImage mImage;
};

#endif // HALCON_IMAGE_H
