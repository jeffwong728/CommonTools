#include "laser_x_file_camera.h"
#include <QtCore>

FileCamera::FileCamera(QObject* parent)
    : LaserXCamera(parent)
{//MT N/A
    mDescription = QStringLiteral("File");
}

FileCamera::FileCamera(QObject* parent, const QString& uuid)
    : LaserXCamera(parent, uuid)
{//MT N/A
    mDescription = QStringLiteral("File");
}

FileCamera::~FileCamera()
{//MT N/A
}

bool FileCamera::open(const QVariantMap& params)
{//MT N/A
    QVariant src = params[QStringLiteral("FileName")];
    if (!mClosed && src.toString() == mFileName)
    {
        return true;
    }

    QString iFileName = src.toString();
    if (QFileInfo::exists(iFileName) && QFileInfo(iFileName).isFile())
    {
        close();
        mFileName = iFileName;
        LaserXCamera::setParameters(params);
        mCVImage = cv::imread(mFileName.toStdString(), cv::IMREAD_UNCHANGED);

        QImageReader reader(mFileName);
        reader.setAutoTransform(true);
        mImage = reader.read();

        if (mCVImage.empty())
        {
            emit errorOccurred(ReadError);
            mClosed = true;
            return false;
        }
        else
        {
            mClosed = false;
            emit cameraOpened();
            return true;
        }
    }
    else
    {
        emit errorOccurred(DeviceNotFoundError);
        return false;
    }
}

bool FileCamera::close()
{//MT N/A
    if (!mClosed)
    {
        mClosed = true;
        mFileName.clear();
        emit cameraClosed();
    }
    return true;
}

cv::Mat FileCamera::snap(int msec)
{//MT N/A
    Q_UNUSED(msec);
    if (mClosed)
    {
        emit errorOccurred(NotOpenError);
    }
    return mCVImage;
}

QImage FileCamera::grab(int msec)
{//MT N/A
    Q_UNUSED(msec);
    if (mClosed)
    {
        emit errorOccurred(NotOpenError);
    }
    return mImage;
}

bool FileCamera::isOpened() const
{//MT N/A
    return !mClosed;
}

bool FileCamera::isLivable() const
{//MT N/A
    return false;
}

QVariantMap FileCamera::getParameters() const
{//MT N/A
    QVariantMap params = LaserXCamera::getParameters();
    params[QStringLiteral("FileName")] = mFileName;
    return params;
}

bool FileCamera::setParameters(const QVariantMap& params)
{//MT N/A
    return LaserXCamera::setParameters(params);
}

int FileCamera::getFPS() const
{//MT N/A
    return 0;
}
