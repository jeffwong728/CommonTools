#include "laser_x_file_camera.h"
#include "laser_x_file_camera_manager.h"
#include "addfilecamerapage.h"
#include "opencv2/opencv.hpp"
#include "configfilecamerapage.h"

FileCameraManager::FileCameraManager()
{
}

FileCameraManager::~FileCameraManager()
{
}

QString FileCameraManager::getTypeName()
{
    return QStringLiteral("ImageFileCamera");
}

QIcon FileCameraManager::getIcon() const
{
    return QIcon(QStringLiteral(":/icons/image.png"));
}

int FileCameraManager::getNumCameras()
{
    return static_cast<int>(mCameras.size());
}

QVector<LaserXCamera*> FileCameraManager::getCameras()
{
    QVector<LaserXCamera*> cams;
    cams.reserve(mCameras.size());
    for (auto &item : mCameras)
    {
        cams.push_back(item);
    }
    return cams;
}

LaserXCamera* FileCameraManager::createCamera(const QVariantMap& params)
{
    const QString iUUID = params[QStringLiteral("UUID")].toString();
    if (QUuid::fromString(iUUID).isNull())
    {
        FileCamera* cam = new FileCamera(this);
        emit cameraCreated(cam);
        return cam;
    }
    else
    {
        FileCamera* cam = new FileCamera(this, iUUID);
        emit cameraCreated(cam);
        return cam;
    }
}

bool FileCameraManager::addCamera(LaserXCamera* camera)
{
    FileCamera* cam = qobject_cast<FileCamera*>(camera);
    if (cam)
    {
        FileCamera* oldCam = mCameras[cam->getUUID()];
        if (oldCam)
        {
            if (oldCam != cam)
            {
                emit cameraAboutToDelete(oldCam);
                oldCam->deleteLater();
                mCameras[cam->getUUID()] = cam;
                emit cameraAdded(cam);
                return true;
            }
        }
        else
        {
            mCameras[cam->getUUID()] = cam;
            emit cameraAdded(cam);
            return true;
        }
    }

    return false;
}

void FileCameraManager::deleteCamera(LaserXCamera* camera)
{
    if (camera)
    {
        emit cameraAboutToDelete(camera);
        mCameras.remove(camera->getUUID());
        camera->deleteLater();
    }
}

LaserXAddCameraWidget* FileCameraManager::getAddWidget(QWidget* parent)
{
    return new AddFileCameraPage(parent);
}

LaserXConfigCameraWidget* FileCameraManager::getConfigWidget(QWidget* parent, LaserXCamera* camera)
{
    FileCamera* iCam = qobject_cast<FileCamera*>(camera);
    if (iCam)
    {
        return new ConfigFileCameraPage(parent, iCam);
    }
    else
    {
        return nullptr;
    }
}

