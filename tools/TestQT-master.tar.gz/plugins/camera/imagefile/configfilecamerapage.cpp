#include "configfilecamerapage.h"
#include "ui_configfilecamerapage.h"
#include "laser_x_file_camera.h"

ConfigFileCameraPage::ConfigFileCameraPage(QWidget *parent, FileCamera* camera) :
    LaserXConfigCameraWidget(parent),
    ui(new Ui::ConfigFileCameraPage), mCamera(camera)
{
    ui->setupUi(this);
}

ConfigFileCameraPage::~ConfigFileCameraPage()
{
    delete ui;
}

void ConfigFileCameraPage::initialize(const QVariantMap& params)
{
    ui->lineEditName->setText(params[QStringLiteral("Name")].toString());
    ui->lineEditDescription->setText(params[QStringLiteral("Description")].toString());
    ui->lineEditPath->setText(params[QStringLiteral("FileName")].toString());
}

QVariantMap ConfigFileCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = ui->lineEditName->text();
    params[QStringLiteral("Description")] = ui->lineEditDescription->text();
    params[QStringLiteral("FileName")] = ui->lineEditPath->text();
    return params;
}

void ConfigFileCameraPage::on_lineEditName_returnPressed()
{
    mCamera->setName(ui->lineEditName->text());
    emit parametersChanged(getParameters());
}

void ConfigFileCameraPage::on_lineEditDescription_returnPressed()
{
    mCamera->setDescription(ui->lineEditDescription->text());
    emit parametersChanged(getParameters());
}
