#ifndef LASER_X_FILE_CAMERA_MANAGER_H
#define LASER_X_FILE_CAMERA_MANAGER_H

#include "laser_x_file_camera_global.h"
#include <laser_x_camera.h>
#include <QObject>
#include <memory>
class FileCamera;

class FileCameraManager : public LaserXCameraManager {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LaserXCameraManagerInterfaceIID)
    Q_INTERFACES(LaserXCameraManager)
public:
    FileCameraManager();
    ~FileCameraManager();

public:
    QString getTypeName() override;
    QIcon getIcon() const override;
    int getNumCameras() override;
    QVector<LaserXCamera*> getCameras() override;
    LaserXCamera* createCamera(const QVariantMap& params) override;
    bool addCamera(LaserXCamera* camera) override;
    void deleteCamera(LaserXCamera* camera) override;
    LaserXAddCameraWidget* getAddWidget(QWidget* parent) override;
    LaserXConfigCameraWidget* getConfigWidget(QWidget* parent, LaserXCamera* camera) override;

private:
    QMap<QString, FileCamera*> mCameras;
};

#endif // LASER_X_FILE_CAMERA_MANAGER_H
