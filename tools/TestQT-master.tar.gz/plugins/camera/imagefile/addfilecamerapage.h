#ifndef ADDFILECAMERAPAGE_H
#define ADDFILECAMERAPAGE_H

#include <QWidget>
#include <laser_x_camera.h>

namespace Ui {
class AddFileCameraPage;
}

class AddFileCameraPage : public LaserXAddCameraWidget
{
    Q_OBJECT

public:
    explicit AddFileCameraPage(QWidget *parent);
    ~AddFileCameraPage();

public:
    QVariantMap getParameters() const override;

private slots:
    void on_pushButtonLoad_clicked();

private:
    Ui::AddFileCameraPage *ui;
};

#endif // ADDFILECAMERAPAGE_H
