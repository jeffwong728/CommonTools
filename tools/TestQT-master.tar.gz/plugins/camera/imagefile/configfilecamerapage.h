#ifndef CONFIGFILECAMERAPAGE_H
#define CONFIGFILECAMERAPAGE_H

#include <QToolBox>
#include <laser_x_camera.h>
class FileCamera;

namespace Ui {
class ConfigFileCameraPage;
}

class ConfigFileCameraPage : public LaserXConfigCameraWidget
{
    Q_OBJECT

public:
    explicit ConfigFileCameraPage(QWidget *parent, FileCamera* camera);
    ~ConfigFileCameraPage();

public:
    void initialize(const QVariantMap& params) override;
    QVariantMap getParameters() const override;

private slots:
    void on_lineEditName_returnPressed();
    void on_lineEditDescription_returnPressed();

private:
    Ui::ConfigFileCameraPage *ui;
    FileCamera* mCamera = nullptr;
};

#endif // CONFIGFILECAMERAPAGE_H
