#include "addfilecamerapage.h"
#include "ui_addfilecamerapage.h"
#include <QtWidgets>

AddFileCameraPage::AddFileCameraPage(QWidget *parent) :
    LaserXAddCameraWidget(parent),
    ui(new Ui::AddFileCameraPage)
{
    ui->setupUi(this);
}

AddFileCameraPage::~AddFileCameraPage()
{
    delete ui;
}

void AddFileCameraPage::on_pushButtonLoad_clicked()
{
    QString filter(tr("Images(*.png *.jpg *.tiff *.tif *.bmp *.dib)"));
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open Image File"), QStringLiteral(""), filter);

    if (!filePath.isEmpty() && filePath != ui->lineEditFilePath->text())
    {
        ui->lineEditFilePath->setText(filePath);
        emit parametersChanged(getParameters());
    }
}

QVariantMap AddFileCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("FileName")] = ui->lineEditFilePath->text();
    return params;
}
