#ifndef ADD_BASLER_CAMERA_PAGE_H
#define ADD_BASLER_CAMERA_PAGE_H

#include <QWidget>
#include <laser_x_camera.h>
#include <pylon/PylonIncludes.h>
class BaslerCameraManager;

namespace Ui {
class AddBaslerCameraPage;
}

class AddBaslerCameraPage : public LaserXAddCameraWidget
{
    Q_OBJECT

public:
    explicit AddBaslerCameraPage(QWidget *parent, BaslerCameraManager* camManager);
    ~AddBaslerCameraPage();

public:
    QVariantMap getParameters() const override;

private slots:
    void on_comboBoxDevice_currentIndexChanged(int index);

private:
    Ui::AddBaslerCameraPage *ui;
    BaslerCameraManager* const mCameraManager;
    Pylon::DeviceInfoList_t mDevices;
};

#endif // ADD_BASLER_CAMERA_PAGE_H
