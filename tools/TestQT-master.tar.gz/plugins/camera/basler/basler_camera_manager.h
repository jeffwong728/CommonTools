#ifndef BASLER_CAMERA_MANAGER_H
#define BASLER_CAMERA_MANAGER_H

#include <laser_x_camera.h>
#include <QObject>
#include <memory>
class BaslerCamera;

class BaslerCameraManager : public LaserXCameraManager {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LaserXCameraManagerInterfaceIID)
    Q_INTERFACES(LaserXCameraManager)
public:
    BaslerCameraManager();
    ~BaslerCameraManager();

public:
    bool initialize() override;
    bool terminate() override;
    QString getTypeName() override;
    QIcon getIcon() const override;
    int getNumCameras() override;
    QVector<LaserXCamera*> getCameras() override;
    LaserXCamera* createCamera(const QVariantMap& params) override;
    LaserXCamera* findCamera(const QVariantMap& params) const override;
    bool addCamera(LaserXCamera* camera) override;
    void deleteCamera(LaserXCamera* camera) override;
    LaserXAddCameraWidget* getAddWidget(QWidget* parent) override;
    LaserXConfigCameraWidget* getConfigWidget(QWidget* parent, LaserXCamera* camera) override;

private:
    QMap<QString, BaslerCamera*> mCameras;
};

#endif // BASLER_CAMERA_MANAGER_H
