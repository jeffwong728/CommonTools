#include "basler_camera.h"
#include "basler_camera_manager.h"
#include "addbaslercamerapage.h"
#include "configbaslercamerapage.h"
#include <opencv2/opencv.hpp>
#include <QDebug>

BaslerCameraManager::BaslerCameraManager()
{
}

BaslerCameraManager::~BaslerCameraManager()
{
}

bool BaslerCameraManager::initialize()
{
    Pylon::PylonInitialize();
    return true;
}

bool BaslerCameraManager::terminate()
{
    Pylon::PylonTerminate();
    return true;
}

QString BaslerCameraManager::getTypeName()
{
    return QStringLiteral("BaslerPylonCamera");
}

QIcon BaslerCameraManager::getIcon() const
{
    return QIcon(QStringLiteral(":/icons/video.png"));
}

int BaslerCameraManager::getNumCameras()
{
    return static_cast<int>(mCameras.size());
}

QVector<LaserXCamera*> BaslerCameraManager::getCameras()
{
    QVector<LaserXCamera*> cams;
    cams.reserve(mCameras.size());
    for (auto& item : mCameras)
    {
        cams.push_back(item);
    }
    return cams;
}

LaserXCamera* BaslerCameraManager::createCamera(const QVariantMap& params)
{
    const QString iUUID = params[QStringLiteral("UUID")].toString();
    if (QUuid::fromString(iUUID).isNull())
    {
        BaslerCamera* cam = new BaslerCamera(this);
        emit cameraCreated(cam);
        return cam;
    }
    else
    {
        BaslerCamera* cam = new BaslerCamera(this, iUUID);
        emit cameraCreated(cam);
        return cam;
    }
}

LaserXCamera* BaslerCameraManager::findCamera(const QVariantMap& params) const
{
    const QString iDevId = params[QStringLiteral("DeviceID")].toString();
    for (const auto &camItem : mCameras)
    {
        if (camItem->deviceID() == iDevId)
        {
            return camItem;
        }
    }

    return nullptr;
}

bool BaslerCameraManager::addCamera(LaserXCamera* camera)
{
    BaslerCamera* cam = qobject_cast<BaslerCamera*>(camera);
    if (cam)
    {
        BaslerCamera* oldCam = mCameras[cam->getUUID()];
        if (oldCam)
        {
            if (oldCam != cam)
            {
                emit cameraAboutToDelete(oldCam);
                oldCam->deleteLater();
                mCameras[cam->getUUID()] = cam;
                emit cameraAdded(cam);
                return true;
            }
        }
        else
        {
            mCameras[cam->getUUID()] = cam;
            emit cameraAdded(cam);
            return true;
        }
    }

    return false;
}

void BaslerCameraManager::deleteCamera(LaserXCamera* camera)
{
    if (camera)
    {
        emit cameraAboutToDelete(camera);
        mCameras.remove(camera->getUUID());
        camera->deleteLater();
    }
}

LaserXAddCameraWidget* BaslerCameraManager::getAddWidget(QWidget* parent)
{
    return new AddBaslerCameraPage(parent, this);
}

LaserXConfigCameraWidget* BaslerCameraManager::getConfigWidget(QWidget* parent, LaserXCamera* camera)
{
    BaslerCamera* iCam = qobject_cast<BaslerCamera*>(camera);
    if (iCam)
    {
        return new ConfigBaslerCameraPage(parent, iCam);
    }
    else
    {
        return nullptr;
    }
}

