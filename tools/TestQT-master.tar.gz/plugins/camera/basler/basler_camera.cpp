#include "basler_camera.h"
#include <QtCore>
#include <QtConcurrent>

inline bool BaslerEQValue(const qreal v0, const qreal v1)
{
    return std::abs(v0-v1) < 0.001;
}

BaslerCamera::BaslerCamera(QObject* parent)
    : BaslerCamera(parent, QUuid::createUuid().toString())
{//MT N/A
    mDescription = QStringLiteral("BaslerCamera");
}

BaslerCamera::BaslerCamera(QObject* parent, const QString& uuid)
    : LaserXCamera(parent, uuid)
{//MT N/A
    mDescription = QStringLiteral("BaslerCamera");
}

BaslerCamera::~BaslerCamera()
{//MT N/A
    close();
}

bool BaslerCamera::open(const QVariantMap& params)
{//MT N/A
    try
    {
        LaserXCamera::setParameters(params);
        QString iDeviceID = params[QStringLiteral("DeviceID")].toString();
        if (mCamera.IsOpen() && iDeviceID == mDeviceID)
        {
            return true;
        }

        close();

        Pylon::DeviceInfoList_t iDevices;
        Pylon::CTlFactory& TlFactory = Pylon::CTlFactory::GetInstance();
        TlFactory.EnumerateDevices(iDevices);
        qDebug() << QStringLiteral("Basler camera manager found %1 devices").arg(iDevices.size());

        for (const Pylon::CDeviceInfo& iDevInfo : iDevices)
        {
            QString thisDevId = QString::fromLatin1(iDevInfo.GetSerialNumber().c_str());
            if (thisDevId == iDeviceID)
            {
                Pylon::IPylonDevice* pDevice = Pylon::CTlFactory::GetInstance().CreateDevice(iDevInfo.GetFullName());
                if (!pDevice)
                {
                    emit errorOccurred(OpenError);
                    return false;
                }

                mCamera.Attach(pDevice, Pylon::Cleanup_Delete);
                mCamera.Open();

                if (mCamera.IsOpen() && initCamera())
                {
                    mCamera.StartGrabbing();
                    mDeviceID = iDeviceID;
                    emit cameraOpened();
                    return true;
                }
                else
                {
                    close();
                    emit errorOccurred(WriteParameterError);
                    return false;
                }
            }
        }

        return false;
    }
    catch (const Pylon::GenericException& e)
    {
        close();
        emit errorOccurredEx(OpenError, QString::fromLatin1(e.GetDescription()));
        qDebug() << QStringLiteral("Basler camera manager open device exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool BaslerCamera::close()
{//MT
    try
    {
        if (mCamera.IsOpen())
        {
            mCamera.StopGrabbing();
            mCamera.Close();
            mCamera.DestroyDevice();
            emit cameraClosed();
        }

        return true;
    }
    catch (const Pylon::GenericException& e)
    {
        emit errorOccurredEx(UnknownError, QString::fromLatin1(e.GetDescription()));
        qDebug() << QStringLiteral("Basler camera manager close device exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

cv::Mat BaslerCamera::snap(int msec)
{//MT
    bool bOK = trigger(true);
    if (bOK)
    {
        return grabImage(true, msec);
    }
    else
    {
        return mImage;
    }
}

QImage BaslerCamera::grab(int msec)
{//MT
    if (trigger(true))
    {
        return snapImage(true, msec);
    }
    else
    {
        return QImage();
    }
}

bool BaslerCamera::startContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (!mContinuousGrabbing)
    {
        mContinuousGrabbing = true;
        mLiveFuture = QtConcurrent::run(BaslerCamera::liveMe, this);
    }

    return true;
}

bool BaslerCamera::stopContinuousGrab()
{//
    QWriteLocker iLocker(&mLocker);
    if (mContinuousGrabbing)
    {
        mContinuousGrabbing = false;
        mLiveFuture.waitForFinished();
    }
    return true;
}

bool BaslerCamera::toggleContinuousGrab()
{//MT
    if (mContinuousGrabbing)
    {
        return stopContinuousGrab();
    }
    else
    {
        return startContinuousGrab();
    }
}

bool BaslerCamera::isOpened() const
{//MT
    try
    {
        return mCamera.IsOpen();
    }
    catch (const Pylon::GenericException& e)
    {
        Q_UNUSED(e);
        return false;
    }
}

bool BaslerCamera::isLivable() const
{//MT
    return true;
}

bool BaslerCamera::setParameters(const QVariantMap& params)
{//MT
    LaserXCamera::setParameters(params);
    BaslerCamera::setGrabParams(params);
    return true;
}

QVariantMap BaslerCamera::getParameters() const
{//MT N/A
    QVariantMap params = LaserXCamera::getParameters();
    params[QStringLiteral("DeviceID")] = mDeviceID;
    if (isOpened())
    {
        params[QStringLiteral("TriggerDelay")] = readTriggerDelay();
        params[QStringLiteral("ExposureTime")] = readExposureTime();
        params[QStringLiteral("Gain")] = readGain();
        params[QStringLiteral("GammaEnable")] = readGammaEnable();
        params[QStringLiteral("Gamma")] = readGamma();
        params[QStringLiteral("Sharpness")] = readSharpness();
    }
    return params;
}

void BaslerCamera::setGrabParams(const QVariantMap& params)
{//MT
    QWriteLocker iLocker(&mLocker);
    if (params.contains(QStringLiteral("Gain")))
    {
        qreal iGain = params.value(QStringLiteral("Gain")).toReal();
        writeGain(iGain);
    }

    if (params.contains(QStringLiteral("ExposureTime")))
    {
        qreal iExposureTime = params.value(QStringLiteral("ExposureTime")).toReal();
        writeExposureTime(iExposureTime);
    }
}

QVariantMap BaslerCamera::getGrabParams() const
{//MT N/A
    QVariantMap params;
    if (isOpened())
    {
        params[QStringLiteral("ExposureTime")] = readExposureTime();
        params[QStringLiteral("Gain")] = readGain();
    }
    return params;
}

int BaslerCamera::getFPS() const
{//MT
    return 10;
}

void BaslerCamera::startGrab()
{//MT
    try
    {
        if (mCamera.IsOpen())
        {
            mCamera.StartGrabbing();
        }
    }
    catch (const Pylon::GenericException& e)
    {
        emit errorOccurredEx(UnknownError, QString::fromLatin1(e.GetDescription()));
        qDebug() << QStringLiteral("Basler camera start grabbing exception: %1").arg(QString::fromLatin1(e.what()));
    }
}

void BaslerCamera::stopGrab()
{//MT
    try
    {
        if (mCamera.IsOpen())
        {
            mCamera.StopGrabbing();
        }
    }
    catch (const Pylon::GenericException& e)
    {
        emit errorOccurredEx(UnknownError, QString::fromLatin1(e.GetDescription()));
        qDebug() << QStringLiteral("Basler camera stop grabbing exception: %1").arg(QString::fromLatin1(e.what()));
    }
}

bool BaslerCamera::trigger(bool emitError)
{//MT
    try
    {
        if (!mCamera.IsOpen())
        {
            if (emitError) emit errorOccurred(NotOpenError);
            return false;
        }

        QWriteLocker iLocker(&mLocker);
        mCamera.TriggerSoftware.Execute();
        return true;
    }
    catch (const Pylon::GenericException& e)
    {
        if (emitError)
        {
            emit errorOccurredEx(UnknownError, QString::fromLatin1(e.GetDescription()));
            qDebug() << QStringLiteral("Basler camera software trigger exception: %1").arg(QString::fromLatin1(e.what()));
        }
        return false;
    }
}

cv::Mat BaslerCamera::grabImage(bool emitError, int msec)
{//MT
    try
    {
        if (!mCamera.IsOpen())
        {
            if (emitError) emit errorOccurred(NotOpenError);
        }
        else
        {
            Pylon::CGrabResultPtr ptrGrabResult;
            mCamera.RetrieveResult(msec ? msec : 1000, ptrGrabResult, Pylon::TimeoutHandling_ThrowException);
            if (ptrGrabResult->GrabSucceeded())
            {
                QWriteLocker iLocker(&mLocker);
                if (!mImage.empty() &&
                    mImage.rows == ptrGrabResult->GetHeight() &&
                    mImage.cols == ptrGrabResult->GetWidth() &&
                    CV_8UC1 == mImage.type())
                {
                    std::memcpy(mImage.data, ptrGrabResult->GetBuffer(), mImage.total());
                }
                else
                {
                    mImage = cv::Mat(ptrGrabResult->GetHeight(), ptrGrabResult->GetWidth(), CV_8UC1, ptrGrabResult->GetBuffer()).clone();
                }
            }
            else
            {
                if (emitError) emit errorOccurred(ReadError);
            }
        }
    }
    catch (const Pylon::GenericException& e)
    {
        if (emitError)
        {
            emit errorOccurredEx(ReadError, QString::fromLatin1(e.GetDescription()));
            qDebug() << QStringLiteral("Basler camera grab image exception: %1").arg(QString::fromLatin1(e.what()));
        }
    }

    return mImage;
}

QImage BaslerCamera::snapImage(bool emitError, int msec)
{//MT
    try
    {
        if (!mCamera.IsOpen())
        {
            if (emitError) emit errorOccurred(NotOpenError);
        }
        else
        {
            Pylon::CGrabResultPtr ptrGrabResult;
            mCamera.RetrieveResult(msec ? msec : 1000, ptrGrabResult, Pylon::TimeoutHandling_ThrowException);
            if (ptrGrabResult->GrabSucceeded())
            {
                QImage iImage(static_cast<uchar*>(ptrGrabResult->GetBuffer()), ptrGrabResult->GetWidth(), ptrGrabResult->GetHeight(), QImage::Format_Grayscale8);
                return iImage.copy();
            }
            else
            {
                if (emitError) emit errorOccurred(ReadError);
            }
        }
    }
    catch (const Pylon::GenericException& e)
    {
        if (emitError)
        {
            emit errorOccurredEx(ReadError, QString::fromLatin1(e.GetDescription()));
            qDebug() << QStringLiteral("Basler camera grab image exception: %1").arg(QString::fromLatin1(e.what()));
        }
    }

    return QImage();
}

qreal BaslerCamera::readExposureTime() const
{//MT N/A
    try
    {
        if (mCamera.ExposureTimeRaw.IsReadable())
        {
            return mCamera.ExposureTimeRaw.GetValue();
        }
        else if (mCamera.ExposureTime.IsReadable())
        {
            return mCamera.ExposureTime.GetValue();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read ExposureTime exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readExposureTimeMin() const
{//MT N/A
    try
    {
        if (mCamera.ExposureTimeRaw.IsReadable())
        {
            return mCamera.ExposureTimeRaw.GetMin();
        }
        else if (mCamera.ExposureTime.IsReadable())
        {
            return mCamera.ExposureTime.GetMin();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read ExposureTimeMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readExposureTimeMax() const
{//MT N/A
    try
    {
        if (mCamera.ExposureTimeRaw.IsReadable())
        {
            return mCamera.ExposureTimeRaw.GetMax();
        }
        else if (mCamera.ExposureTime.IsReadable())
        {
            return mCamera.ExposureTime.GetMax();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read ExposureTimeMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readExposureTimeInc() const
{//MT N/A
    try
    {
        if (mCamera.ExposureTimeRaw.IsReadable())
        {
            return mCamera.ExposureTimeRaw.GetInc();
        }
        else if (mCamera.ExposureTime.IsReadable())
        {
            return mCamera.ExposureTime.GetInc();
        }
        else
        {
            return 1;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read ExposureTimeInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 1;
    }
}

qreal BaslerCamera::readGain() const
{//MT N/A
    try
    {
        if (mCamera.GainRaw.IsReadable())
        {
            return mCamera.GainRaw.GetValue();
        }
        else if (mCamera.Gain.IsReadable())
        {
            return mCamera.Gain.GetValue();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read Gain exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readGainMin() const
{//MT N/A
    try
    {
        if (mCamera.GainRaw.IsReadable())
        {
            return mCamera.GainRaw.GetMin();
        }
        else if (mCamera.Gain.IsReadable())
        {
            return mCamera.Gain.GetMin();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read GainMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readGainMax() const
{//MT N/A
    try
    {
        if (mCamera.GainRaw.IsReadable())
        {
            return mCamera.GainRaw.GetMax();
        }
        else if (mCamera.Gain.IsReadable())
        {
            return mCamera.Gain.GetMax();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read GainMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readGainInc() const
{//MT N/A
    try
    {
        if (mCamera.GainRaw.IsReadable())
        {
            return mCamera.GainRaw.GetInc();
        }
        else if (mCamera.Gain.IsReadable())
        {
            return mCamera.Gain.GetInc();
        }
        else
        {
            return 0.1;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read GainInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 0.1;
    }
}

bool BaslerCamera::readGammaEnable() const
{//MT N/A
    try
    {
        if (mCamera.GammaEnable.IsReadable())
        {
            return mCamera.GammaEnable.GetValue();
        }
        else
        {
            return false;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read GammaEnable exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readGamma() const
{//MT N/A
    try
    {
        if (mCamera.Gamma.IsReadable())
        {
            return mCamera.Gamma.GetValue();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read Gamma exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readGammaMin() const
{//MT N/A
    try
    {
        if (mCamera.Gamma.IsReadable())
        {
            return mCamera.Gamma.GetMin();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read GammaMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readGammaMax() const
{//MT N/A
    try
    {
        if (mCamera.Gamma.IsReadable())
        {
            return mCamera.Gamma.GetMax();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read GammaMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readGammaInc() const
{//MT N/A
    try
    {
        if (mCamera.Gamma.IsReadable())
        {
            return mCamera.Gamma.GetInc();
        }
        else
        {
            return 0.1;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read GammaInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 0.1;
    }
}

qreal BaslerCamera::readTriggerDelay() const
{//MT N/A
    try
    {
        if (mCamera.TriggerDelay.IsReadable())
        {
            return mCamera.TriggerDelay.GetValue();
        }
        else if (mCamera.TriggerDelayAbs.IsReadable())
        {
            return mCamera.TriggerDelayAbs.GetValue();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read TriggerDelay exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readTriggerDelayMin() const
{//MT N/A
    try
    {
        if (mCamera.TriggerDelay.IsReadable())
        {
            return mCamera.TriggerDelay.GetMin();
        }
        else if (mCamera.TriggerDelayAbs.IsReadable())
        {
            return mCamera.TriggerDelayAbs.GetMin();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read TriggerDelayMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readTriggerDelayMax() const
{//MT N/A
    try
    {
        if (mCamera.TriggerDelay.IsReadable())
        {
            return mCamera.TriggerDelay.GetMax();
        }
        else if (mCamera.TriggerDelayAbs.IsReadable())
        {
            return mCamera.TriggerDelayAbs.GetMax();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read TriggerDelayMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readTriggerDelayInc() const
{//MT N/A
    try
    {
        if (mCamera.TriggerDelay.IsReadable())
        {
            return mCamera.TriggerDelay.GetInc();
        }
        else if (mCamera.TriggerDelayAbs.IsReadable())
        {
            return mCamera.TriggerDelayAbs.GetInc();
        }
        else
        {
            return 1;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read TriggerDelayInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 1;
    }
}

qreal BaslerCamera::readSharpness() const
{//MT N/A
    try
    {
        if (mCamera.SharpnessEnhancement.IsReadable())
        {
            return mCamera.SharpnessEnhancement.GetValue();
        }
        else if (mCamera.SharpnessEnhancementAbs.IsReadable())
        {
            return mCamera.SharpnessEnhancementAbs.GetValue();
        }
        else
        {
            return 0.f;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read Sharpness exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readSharpnessMin() const
{//MT N/A
    try
    {
        if (mCamera.SharpnessEnhancement.IsReadable())
        {
            return mCamera.SharpnessEnhancement.GetMin();
        }
        else if (mCamera.SharpnessEnhancementAbs.IsReadable())
        {
            return mCamera.SharpnessEnhancementAbs.GetMin();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read SharpnessMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readSharpnessMax() const
{//MT N/A
    try
    {
        if (mCamera.SharpnessEnhancement.IsReadable())
        {
            return mCamera.SharpnessEnhancement.GetMax();
        }
        else if (mCamera.SharpnessEnhancementAbs.IsReadable())
        {
            return mCamera.SharpnessEnhancementAbs.GetMax();
        }
        else
        {
            return 0;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read SharpnessMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal BaslerCamera::readSharpnessInc() const
{//MT N/A
    try
    {
        if (mCamera.SharpnessEnhancement.IsReadable())
        {
            return mCamera.SharpnessEnhancement.GetInc();
        }
        else if (mCamera.SharpnessEnhancementAbs.IsReadable())
        {
            return mCamera.SharpnessEnhancementAbs.GetInc();
        }
        else
        {
            return 1;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera read SharpnessInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 1;
    }
}

bool BaslerCamera::readSharpnessEnable() const
{//MT N/A
    return false;
}

bool BaslerCamera::writeExposureTime(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readExposureTime();
        if (BaslerEQValue(oValue, nValue))
        {
            return true;
        }

        if (mCamera.ExposureTimeRaw.IsWritable())
        {
            mCamera.ExposureTimeRaw.SetValue(nValue);
            emit parameterChanged(QStringLiteral("ExposureTime"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else if (mCamera.ExposureTime.IsWritable())
        {
            mCamera.ExposureTime.SetValue(nValue);
            emit parameterChanged(QStringLiteral("ExposureTime"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera write ExposureTime exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool BaslerCamera::writeGain(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readGain();
        if (BaslerEQValue(oValue, nValue))
        {
            return true;
        }

        if (mCamera.GainRaw.IsWritable())
        {
            mCamera.GainRaw.SetValue(nValue);
            emit parameterChanged(QStringLiteral("Gain"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else if (mCamera.Gain.IsWritable())
        {
            mCamera.Gain.SetValue(nValue);
            emit parameterChanged(QStringLiteral("Gain"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera write Gain exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool BaslerCamera::writeGammaEnable(const bool nValue)
{//MT N/A
    try
    {
        const bool oValue = readGammaEnable();
        if (oValue == nValue)
        {
            return true;
        }

        if (mCamera.GammaEnable.IsWritable())
        {
            mCamera.GammaEnable.SetValue(nValue);
            emit parameterChanged(QStringLiteral("GammaEnable"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera write GammaEnable exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool BaslerCamera::writeGamma(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readGamma();
        if (BaslerEQValue(oValue, nValue))
        {
            return true;
        }

        if (mCamera.Gamma.IsWritable())
        {
            mCamera.Gamma.SetValue(nValue);
            emit parameterChanged(QStringLiteral("Gamma"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera write Gamma exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool BaslerCamera::writeTriggerDelay(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readTriggerDelay();
        if (BaslerEQValue(oValue, nValue))
        {
            return true;
        }

        if (mCamera.TriggerDelay.IsWritable())
        {
            mCamera.TriggerDelay.SetValue(nValue);
            emit parameterChanged(QStringLiteral("TriggerDelay"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else if (mCamera.TriggerDelayAbs.IsWritable())
        {
            mCamera.TriggerDelayAbs.SetValue(nValue);
            emit parameterChanged(QStringLiteral("TriggerDelay"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera write TriggerDelay exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool BaslerCamera::writeSharpness(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readSharpness();
        if (BaslerEQValue(oValue, nValue))
        {
            return true;
        }

        if (mCamera.SharpnessEnhancement.IsWritable())
        {
            mCamera.SharpnessEnhancement.SetValue(nValue);
            emit parameterChanged(QStringLiteral("SharpnessEnhancement"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else if (mCamera.SharpnessEnhancementAbs.IsWritable())
        {
            mCamera.SharpnessEnhancementAbs.SetValue(nValue);
            emit parameterChanged(QStringLiteral("SharpnessEnhancement"), QVariant(oValue), QVariant(nValue));
            return true;
        }
        else
        {
            return false;
        }
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera write Sharpness exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool BaslerCamera::writeSharpnessEnable(const bool nValue)
{//MT N/A
    return false;
}

bool BaslerCamera::initCamera()
{//MT N/A
    try
    {
        if (!mCamera.PixelFormat.CanSetValue(Basler_UniversalCameraParams::PixelFormat_Mono8))
        {
            return false;
        }

        mCamera.OffsetX.TrySetToMinimum();
        mCamera.OffsetY.TrySetToMinimum();

        mCamera.Width.TrySetToMaximum();
        mCamera.Height.TrySetToMaximum();
        mCamera.PixelFormat.TrySetValue(Basler_UniversalCameraParams::PixelFormat_Mono8);
        mCamera.GainAuto.TrySetValue(Basler_UniversalCameraParams::GainAuto_Off);
        mCamera.ExposureAuto.TrySetValue(Basler_UniversalCameraParams::ExposureAuto_Off);
        mCamera.TriggerMode.TrySetValue(Basler_UniversalCameraParams::TriggerMode_On);
        mCamera.TriggerSource.TrySetValue(Basler_UniversalCameraParams::TriggerSource_Software);
        mCamera.AcquisitionMode.TrySetValue(Basler_UniversalCameraParams::AcquisitionMode_Continuous);
        mDescription = QString::fromLatin1(mCamera.GetDeviceInfo().GetFriendlyName().c_str());

        return true;
    }
    catch (const Pylon::GenericException& e)
    {
        qDebug() << QStringLiteral("Basler camera initialization exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

void BaslerCamera::liveMe(BaslerCamera* cam)
{//MT
    while (cam->mContinuousGrabbing)
    {
        if (cam->trigger(false))
        {
            cv::Mat iImage = cam->grabImage(false);
            QVariantMap infos;
            emit cam->imageReady(iImage, infos);
        }
    }
}
