#include "addbaslercamerapage.h"
#include "ui_addbaslercamerapage.h"
#include "basler_camera_manager.h"

AddBaslerCameraPage::AddBaslerCameraPage(QWidget *parent, BaslerCameraManager* camManager)
    : LaserXAddCameraWidget(parent)
    , ui(new Ui::AddBaslerCameraPage)
    , mCameraManager(camManager)
{
    ui->setupUi(this);

    try
    {
        Pylon::CTlFactory& TlFactory = Pylon::CTlFactory::GetInstance();
        TlFactory.EnumerateDevices(mDevices);
        qDebug() << QStringLiteral("Basler camera manager found %1 devices").arg(mDevices.size());
    }
    catch (const Pylon::GenericException& e)
    {
        mDevices.clear();
        qDebug() << QStringLiteral("Basler camera manager enumerate devices exception: %1").arg(QString::fromLatin1(e.what()));
    }

    int iDevIndex = 0;
    for (const Pylon::CDeviceInfo &iDev : mDevices)
    {
        QVariantMap params;
        params[QStringLiteral("DeviceID")] = QString::fromLatin1(iDev.GetSerialNumber().c_str());
        if (!mCameraManager->findCamera(params))
        {
            ui->comboBoxDevice->addItem(QString::fromLatin1(iDev.GetFriendlyName().c_str()), iDevIndex);
        }
        iDevIndex += 1;
    }
}

AddBaslerCameraPage::~AddBaslerCameraPage()
{
    delete ui;
}


void AddBaslerCameraPage::on_comboBoxDevice_currentIndexChanged(int index)
{
    if (index >= 0 && index < ui->comboBoxDevice->count())
    {
        const int iDevIndex = ui->comboBoxDevice->itemData(index).toInt();
        const Pylon::CDeviceInfo& iDevInfo = mDevices.at(iDevIndex);

        ui->lineEditDeviceID->setText(QString::fromLatin1(iDevInfo.GetSerialNumber().c_str()));
        ui->lineEditVendorName->setText(QString::fromLatin1(iDevInfo.GetVendorName().c_str()));
        ui->lineEditModelName->setText(QString::fromLatin1(iDevInfo.GetModelName().c_str()));
        ui->lineEditDeviceVersion->setText(QString::fromLatin1(iDevInfo.GetDeviceVersion().c_str()));
        ui->lineEditUserDefinedName->setText(QString::fromLatin1(iDevInfo.GetUserDefinedName().c_str()));
        ui->lineEditFullName->setText(QString::fromLatin1(iDevInfo.GetFullName().c_str()));

        emit parametersChanged(getParameters());
    }
}

QVariantMap AddBaslerCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("DeviceID")] = ui->lineEditDeviceID->text();
    return params;
}
