#include "addvideocamerapage.h"
#include "ui_addvideocamerapage.h"

AddVideoCameraPage::AddVideoCameraPage(QWidget *parent) :
    LaserXAddCameraWidget(parent),
    ui(new Ui::AddVideoCameraPage)
{
    ui->setupUi(this);
}

AddVideoCameraPage::~AddVideoCameraPage()
{
    delete ui;
}

void AddVideoCameraPage::on_pushButtonLoad_clicked()
{
    QString filter(tr("Videos(*.mp4 *.avi)"));
    QString filePath = QFileDialog::getOpenFileName(this, tr("Open Video File"), QStringLiteral(""), filter);

    if (!filePath.isEmpty() && filePath != ui->lineEditVideoPath->text())
    {
        ui->lineEditVideoPath->setText(filePath);
        emit parametersChanged(getParameters());
    }
}

QVariantMap AddVideoCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("FileName")] = ui->lineEditVideoPath->text();
    return params;
}
