#include "laser_x_video_camera.h"
#include "laser_x_video_camera_manager.h"
#include "addvideocamerapage.h"
#include "opencv2/opencv.hpp"
#include "configvideocamerapage.h"

VideoCameraManager::VideoCameraManager()
{
}

VideoCameraManager::~VideoCameraManager()
{
}

QString VideoCameraManager::getTypeName()
{
    return QStringLiteral("VideoFileCamera");
}

QIcon VideoCameraManager::getIcon() const
{
    return QIcon(QStringLiteral(":/icons/film.png"));
}

int VideoCameraManager::getNumCameras()
{
    return static_cast<int>(mCameras.size());
}

QVector<LaserXCamera*> VideoCameraManager::getCameras()
{
    QVector<LaserXCamera*> cams;
    cams.reserve(mCameras.size());
    for (auto& item : mCameras)
    {
        cams.push_back(item);
    }
    return cams;
}

LaserXCamera* VideoCameraManager::createCamera(const QVariantMap& params)
{
    const QString iUUID = params[QStringLiteral("UUID")].toString();
    if (QUuid::fromString(iUUID).isNull())
    {
        VideoCamera* cam = new VideoCamera(this);
        emit cameraCreated(cam);
        return cam;
    }
    else
    {
        VideoCamera* cam = new VideoCamera(this, iUUID);
        emit cameraCreated(cam);
        return cam;
    }
}

bool VideoCameraManager::addCamera(LaserXCamera* camera)
{
    VideoCamera* cam = qobject_cast<VideoCamera*>(camera);
    if (cam)
    {
        VideoCamera* oldCam = mCameras[cam->getUUID()];
        if (oldCam)
        {
            if (oldCam != cam)
            {
                emit cameraAboutToDelete(oldCam);
                oldCam->deleteLater();
                mCameras[cam->getUUID()] = cam;
                emit cameraAdded(cam);
                return true;
            }
        }
        else
        {
            mCameras[cam->getUUID()] = cam;
            emit cameraAdded(cam);
            return true;
        }
    }

    return false;
}

void VideoCameraManager::deleteCamera(LaserXCamera* camera)
{
    if (camera)
    {
        emit cameraAboutToDelete(camera);
        mCameras.remove(camera->getUUID());
        camera->deleteLater();
    }
}

LaserXAddCameraWidget* VideoCameraManager::getAddWidget(QWidget* parent)
{
    return new AddVideoCameraPage(parent);
}

LaserXConfigCameraWidget* VideoCameraManager::getConfigWidget(QWidget* parent, LaserXCamera* camera)
{
    VideoCamera* iCam = qobject_cast<VideoCamera*>(camera);
    if (iCam)
    {
        return new ConfigVideoCameraPage(parent, iCam);
    }
    else
    {
        return nullptr;
    }
}
