#ifndef CONFIGVIDEOCAMERAPAGE_H
#define CONFIGVIDEOCAMERAPAGE_H

#include <QToolBox>
#include <laser_x_camera.h>
class VideoCamera;

namespace Ui {
class ConfigVideoCameraPage;
}

class ConfigVideoCameraPage : public LaserXConfigCameraWidget
{
    Q_OBJECT

public:
    explicit ConfigVideoCameraPage(QWidget *parent, VideoCamera* camera);
    ~ConfigVideoCameraPage();

public:
    void initialize(const QVariantMap& params) override;
    QVariantMap getParameters() const override;

private slots:
    void on_lineEditName_returnPressed();
    void on_lineEditDescription_returnPressed();

private:
    Ui::ConfigVideoCameraPage *ui;
    VideoCamera* mCamera = nullptr;
};

#endif // CONFIGVIDEOCAMERAPAGE_H
