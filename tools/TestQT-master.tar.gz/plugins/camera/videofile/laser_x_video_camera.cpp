#include "laser_x_video_camera.h"
#include <QtCore>

VideoCamera::VideoCamera(QObject* parent)
    : LaserXCamera(parent)
{//MT N/A
    mDescription = QStringLiteral("Video");
    connect(&mLiveTimer, &QTimer::timeout, this, &VideoCamera::onLiveTimeout);
}

VideoCamera::~VideoCamera()
{//MT N/A
}

VideoCamera::VideoCamera(QObject* parent, const QString& uuid)
    : LaserXCamera(parent, uuid)
{//MT N/A
    mDescription = QStringLiteral("Video");
    connect(&mLiveTimer, &QTimer::timeout, this, &VideoCamera::onLiveTimeout);
}

bool VideoCamera::open(const QVariantMap& params)
{//MT N/A
    QVariant src = params[QStringLiteral("FileName")];
    QString iFileName = src.toString();
    if (mVideoCapture.isOpened() && iFileName == mFileName)
    {
        return true;
    }

    if (QFileInfo::exists(iFileName) && QFileInfo(iFileName).isFile())
    {
        close();
        mFileName = iFileName;
        LaserXCamera::setParameters(params);
        bool bOk = mVideoCapture.open(mFileName.toStdString());
        if (bOk)
        {
            emit cameraOpened();
        }
        else
        {
            emit errorOccurred(OpenError);
        }
        return bOk;
    }
    else
    {
        emit errorOccurred(DeviceNotFoundError);
        return false;
    }
}

bool VideoCamera::close()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (mVideoCapture.isOpened())
    {
        mVideoCapture.release();
        emit cameraClosed();
    }
    return true;
}

cv::Mat VideoCamera::snap(int msec)
{//MT
    Q_UNUSED(msec);
    QWriteLocker iLocker(&mLocker);
    if (!mVideoCapture.isOpened())
    {
        emit errorOccurred(NotOpenError);
        return cv::Mat();
    }
    else
    {
        mVideoCapture >> mCVImage;
        if (mCVImage.empty())
        {
            mVideoCapture.set(cv::CAP_PROP_POS_FRAMES, 0);
            mVideoCapture >> mCVImage;
        }
        return mCVImage;
    }
}

QImage VideoCamera::grab(int msec)
{//MT
    Q_UNUSED(msec);
    QWriteLocker iLocker(&mLocker);
    if (!mVideoCapture.isOpened())
    {
        emit errorOccurred(NotOpenError);
        return QImage();
    }
    else
    {
        mVideoCapture >> mCVImage;
        if (mCVImage.empty())
        {
            mVideoCapture.set(cv::CAP_PROP_POS_FRAMES, 0);
            mVideoCapture >> mCVImage;
        }

        if (mCVImage.empty())
        {
            return QImage();
        }

        switch (mCVImage.type())
        {
        case CV_8UC1:
        {
            QImage image(mCVImage.data, mCVImage.cols, mCVImage.rows, mCVImage.step, QImage::Format_Grayscale8);
            return image.copy();
        }

        case CV_8UC3:
        {
            QImage image(mCVImage.data, mCVImage.cols, mCVImage.rows, mCVImage.step, QImage::Format_RGB888);
            return image.rgbSwapped();
        }
        break;

        case CV_8UC4:
        {
            QImage image(mCVImage.data, mCVImage.cols, mCVImage.rows, mCVImage.step, QImage::Format_ARGB32);
            return image.copy();
        }
        break;

        default:
            return QImage();
        }

        return QImage();
    }
}

bool VideoCamera::isOpened() const
{//MT N/A
    return mVideoCapture.isOpened();
}

bool VideoCamera::isLivable() const
{//MT N/A
    return true;
}

QVariantMap VideoCamera::getParameters() const
{//MT N/A
    QVariantMap params = LaserXCamera::getParameters();
    params[QStringLiteral("FileName")] = mFileName;
    return params;
}

int VideoCamera::getFPS() const
{//MT N/A
    if (mVideoCapture.isOpened())
    {
        return static_cast<int>(mVideoCapture.get(cv::CAP_PROP_FPS));
    }
    else
    {
        return LaserXCamera::getFPS();
    }
}

bool VideoCamera::startContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (!mContinuousGrabbing)
    {
        mContinuousGrabbing = true;
        QMetaObject::invokeMethod(this, "startMyTimer");
    }

    return true;
}

bool VideoCamera::stopContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (mContinuousGrabbing)
    {
        mContinuousGrabbing = false;
        QMetaObject::invokeMethod(this, "stopMyTimer");
    }

    return true;
}

bool VideoCamera::toggleContinuousGrab()
{//MT
    if (mContinuousGrabbing)
    {
        return stopContinuousGrab();
    }
    else
    {
        return startContinuousGrab();
    }
}

void VideoCamera::onLiveTimeout()
{
    if (mContinuousGrabbing)
    {
        cv::Mat iImage = snap();
        QVariantMap infos;
        emit imageReady(iImage, infos);
    }
}

void VideoCamera::startMyTimer()
{
    if (!mLiveTimer.isActive())
    {
        const int fps = getFPS();
        mLiveTimer.start(fps ? (1000 / fps) : 50);
    }
}

void VideoCamera::stopMyTimer()
{
    if (mLiveTimer.isActive())
    {
        mLiveTimer.stop();
    }
}
