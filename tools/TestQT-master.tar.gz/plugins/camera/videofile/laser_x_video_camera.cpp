#include "laser_x_video_camera.h"
#include <QtCore>

VideoCamera::VideoCamera(QObject* parent)
    : LaserXCamera(parent)
{//MT N/A
    mDescription = QStringLiteral("Video");
}

VideoCamera::~VideoCamera()
{//MT N/A
}

VideoCamera::VideoCamera(QObject* parent, const QString& uuid)
    : LaserXCamera(parent, uuid)
{//MT N/A
    mDescription = QStringLiteral("Video");
}

bool VideoCamera::open(const QVariantMap& params)
{//MT N/A
    QVariant src = params[QStringLiteral("FileName")];
    QString iFileName = src.toString();
    if (mVideoCapture.isOpened() && iFileName == mFileName)
    {
        return true;
    }

    if (QFileInfo::exists(iFileName) && QFileInfo(iFileName).isFile())
    {
        close();
        mFileName = iFileName;
        LaserXCamera::setParameters(params);
        bool bOk = mVideoCapture.open(mFileName.toStdString());
        if (bOk)
        {
            emit cameraOpened();
        }
        else
        {
            emit errorOccurred(OpenError);
        }
        return bOk;
    }
    else
    {
        emit errorOccurred(DeviceNotFoundError);
        return false;
    }
}

bool VideoCamera::close()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (mVideoCapture.isOpened())
    {
        mVideoCapture.release();
        emit cameraClosed();
    }
    return true;
}

cv::Mat VideoCamera::snap(int msec)
{//MT
    Q_UNUSED(msec);
    QWriteLocker iLocker(&mLocker);
    if (!mVideoCapture.isOpened())
    {
        emit errorOccurred(NotOpenError);
        return cv::Mat();
    }
    else
    {
        mVideoCapture >> mCVImage;
        if (mCVImage.empty())
        {
            mVideoCapture.set(cv::CAP_PROP_POS_FRAMES, 0);
            mVideoCapture >> mCVImage;
        }
        return mCVImage;
    }
}

cv::Mat VideoCamera::tryLiveGrab(int msec)
{//MT
    Q_UNUSED(msec);
    if (!mLocker.tryLockForWrite())
    {
        return cv::Mat();
    }

    if (!mVideoCapture.isOpened())
    {
        mLocker.unlock();
        return cv::Mat();
    }
    else
    {
        mVideoCapture >> mCVImage;
        if (mCVImage.empty())
        {
            mVideoCapture.set(cv::CAP_PROP_POS_FRAMES, 0);
            mVideoCapture >> mCVImage;
        }

        mLocker.unlock();
        return mCVImage;
    }
}

bool VideoCamera::isOpened() const
{//MT N/A
    return mVideoCapture.isOpened();
}

bool VideoCamera::isLivable() const
{//MT N/A
    return true;
}

QVariantMap VideoCamera::getParameters() const
{//MT N/A
    QVariantMap params = LaserXCamera::getParameters();
    params[QStringLiteral("FileName")] = mFileName;
    return params;
}

int VideoCamera::getFPS() const
{//MT N/A
    if (mVideoCapture.isOpened())
    {
        return static_cast<int>(mVideoCapture.get(cv::CAP_PROP_FPS));
    }
    else
    {
        return LaserXCamera::getFPS();
    }
}
