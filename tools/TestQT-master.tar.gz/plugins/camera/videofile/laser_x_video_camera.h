#ifndef LASER_X_VIDEO_CAMERA_H
#define LASER_X_VIDEO_CAMERA_H

#include "opencv2/opencv.hpp"
#include <laser_x_camera.h>

class VideoCamera : public LaserXCamera
{
    Q_OBJECT
public:
    VideoCamera(QObject* parent);
    VideoCamera(QObject* parent, const QString& uuid);
    ~VideoCamera();

public:
    bool open(const QVariantMap& params) override;
    bool close() override;
    cv::Mat snap(int msec = 0) override;
    cv::Mat tryLiveGrab(int msec = 0) override;
    bool isOpened() const override;
    bool isLivable() const override;
    QVariantMap getParameters() const override;
    int getFPS() const override;

private:
    QString mFileName;
    cv::VideoCapture mVideoCapture;
    cv::Mat mCVImage;
};

#endif // LASER_X_VIDEO_CAMERA_H
