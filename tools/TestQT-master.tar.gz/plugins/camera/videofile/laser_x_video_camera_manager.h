#ifndef LASER_X_FILE_CAMERA_MANAGER_H
#define LASER_X_FILE_CAMERA_MANAGER_H

#include "laser_x_video_camera_global.h"
#include <laser_x_camera.h>
#include <QObject>
#include <memory>
class VideoCamera;

class VideoCameraManager : public LaserXCameraManager {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LaserXCameraManagerInterfaceIID)
    Q_INTERFACES(LaserXCameraManager)
public:
    VideoCameraManager();
    ~VideoCameraManager();

public:
    QString getTypeName() override;
    QIcon getIcon() const override;
    int getNumCameras() override;
    QVector<LaserXCamera*> getCameras() override;
    LaserXCamera* createCamera(const QVariantMap& params) override;
    LaserXAddCameraWidget* getAddWidget(QWidget* parent) override;
    bool addCamera(LaserXCamera* camera) override;
    void deleteCamera(LaserXCamera* camera) override;
    LaserXConfigCameraWidget* getConfigWidget(QWidget* parent, LaserXCamera* camera) override;

private:
    QMap<QString, VideoCamera*> mCameras;
};

#endif // LASER_X_FILE_CAMERA_MANAGER_H
