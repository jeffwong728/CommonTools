#ifndef ADDVIDEOCAMERAPAGE_H
#define ADDVIDEOCAMERAPAGE_H

#include <QWidget>
#include <laser_x_camera.h>

namespace Ui {
class AddVideoCameraPage;
}

class AddVideoCameraPage : public LaserXAddCameraWidget
{
    Q_OBJECT

public:
    explicit AddVideoCameraPage(QWidget *parent);
    ~AddVideoCameraPage();

public:
    QVariantMap getParameters() const override;

private slots:
    void on_pushButtonLoad_clicked();

private:
    Ui::AddVideoCameraPage *ui;
};

#endif // ADDVIDEOCAMERAPAGE_H
