#include "configvideocamerapage.h"
#include "ui_configvideocamerapage.h"
#include "laser_x_video_camera.h"

ConfigVideoCameraPage::ConfigVideoCameraPage(QWidget *parent, VideoCamera* camera) :
    LaserXConfigCameraWidget(parent),
    ui(new Ui::ConfigVideoCameraPage), mCamera(camera)
{
    ui->setupUi(this);
}

ConfigVideoCameraPage::~ConfigVideoCameraPage()
{
    delete ui;
}

void ConfigVideoCameraPage::initialize(const QVariantMap& params)
{
    ui->lineEditName->setText(params[QStringLiteral("Name")].toString());
    ui->lineEditDescription->setText(params[QStringLiteral("Description")].toString());
    ui->lineEditPath->setText(params[QStringLiteral("FileName")].toString());
}

QVariantMap ConfigVideoCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = ui->lineEditName->text();
    params[QStringLiteral("Description")] = ui->lineEditDescription->text();
    params[QStringLiteral("FileName")] = ui->lineEditPath->text();
    return params;
}

void ConfigVideoCameraPage::on_lineEditName_returnPressed()
{
    mCamera->setName(ui->lineEditName->text());
    emit parametersChanged(getParameters());
}

void ConfigVideoCameraPage::on_lineEditDescription_returnPressed()
{
    mCamera->setDescription(ui->lineEditDescription->text());
    emit parametersChanged(getParameters());
}
