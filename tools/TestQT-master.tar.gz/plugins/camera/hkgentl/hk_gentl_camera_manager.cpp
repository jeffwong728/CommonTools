#include "hk_gentl_camera.h"
#include "hk_gentl_camera_manager.h"
#include "addhkgentlcamerapage.h"
#include "confighikgentlcamerapage.h"
#include <opencv2/opencv.hpp>
#include <MvCameraControl.h>
#include <QDebug>

HKGenTLCameraManager::HKGenTLCameraManager()
{
}

HKGenTLCameraManager::~HKGenTLCameraManager()
{
}

QString HKGenTLCameraManager::getTypeName()
{
    return QStringLiteral("HikRoboticsGenTLCamera");
}

QIcon HKGenTLCameraManager::getIcon() const
{
    return QIcon(QStringLiteral(":/icons/video.png"));
}

int HKGenTLCameraManager::getNumCameras()
{
    return static_cast<int>(mCameras.size());
}

QVector<LaserXCamera*> HKGenTLCameraManager::getCameras()
{
    QVector<LaserXCamera*> cams;
    cams.reserve(mCameras.size());
    for (auto& item : mCameras)
    {
        cams.push_back(item);
    }
    return cams;
}

LaserXCamera* HKGenTLCameraManager::createCamera(const QVariantMap& params)
{
    const QString iUUID = params[QStringLiteral("UUID")].toString();
    if (QUuid::fromString(iUUID).isNull())
    {
        HKGenTLCamera* cam = new HKGenTLCamera(this);
        emit cameraCreated(cam);
        return cam;
    }
    else
    {
        HKGenTLCamera* cam = new HKGenTLCamera(this, iUUID);
        emit cameraCreated(cam);
        return cam;
    }
}

LaserXCamera* HKGenTLCameraManager::findCamera(const QVariantMap& params) const
{
    const QString iDevId = params[QStringLiteral("DeviceID")].toString();
    for (const auto &camItem : mCameras)
    {
        if (camItem->deviceID() == iDevId)
        {
            return camItem;
        }
    }

    return nullptr;
}

bool HKGenTLCameraManager::addCamera(LaserXCamera* camera)
{
    HKGenTLCamera* cam = qobject_cast<HKGenTLCamera*>(camera);
    if (cam)
    {
        HKGenTLCamera* oldCam = mCameras[cam->getUUID()];
        if (oldCam)
        {
            if (oldCam != cam)
            {
                emit cameraAboutToDelete(oldCam);
                oldCam->deleteLater();
                mCameras[cam->getUUID()] = cam;
                emit cameraAdded(cam);
                return true;
            }
        }
        else
        {
            mCameras[cam->getUUID()] = cam;
            emit cameraAdded(cam);
            return true;
        }
    }

    return false;
}

void HKGenTLCameraManager::deleteCamera(LaserXCamera* camera)
{
    if (camera)
    {
        emit cameraAboutToDelete(camera);
        mCameras.remove(camera->getUUID());
        camera->deleteLater();
    }
}

LaserXAddCameraWidget* HKGenTLCameraManager::getAddWidget(QWidget* parent)
{
    return new AddHKGenTLCameraPage(parent, this);
}

LaserXConfigCameraWidget* HKGenTLCameraManager::getConfigWidget(QWidget* parent, LaserXCamera* camera)
{
    HKGenTLCamera* iCam = qobject_cast<HKGenTLCamera*>(camera);
    if (iCam)
    {
        return new ConfigHikGenTLCameraPage(parent, iCam);
    }
    else
    {
        return nullptr;
    }
}
