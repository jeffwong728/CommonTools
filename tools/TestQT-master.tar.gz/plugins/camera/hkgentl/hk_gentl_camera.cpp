#include "hk_gentl_camera.h"
#include "hk_gentl_camera_manager.h"
#include <QtCore>
#include <QtConcurrent>
#include <QMutexLocker>
#pragma warning( push )
#pragma warning( disable : 26812 )

inline bool HikEQValue(const float v0, const float v1)
{
    return std::abs(v0 - v1) < 0.001;
}

HKGenTLCamera::HKGenTLCamera(QObject* parent)
    : HKGenTLCamera(parent, QUuid::createUuid().toString())
{//MT N/A
    mManager = qobject_cast<HKGenTLCameraManager *>(parent);
    if (!mManager)
    {
        throw std::invalid_argument("The parent of HKGenTLCamera must be HKGenTLCameraManager");
    }
    mDescription = QStringLiteral("Hik Camera");
}

HKGenTLCamera::HKGenTLCamera(QObject* parent, const QString& uuid)
    : LaserXCamera(parent, uuid)
{//MT N/A
    mManager = qobject_cast<HKGenTLCameraManager*>(parent);
    if (!mManager)
    {
        throw std::invalid_argument("The parent of HKGenTLCamera must be HKGenTLCameraManager");
    }
    mDescription = QStringLiteral("Hik Camera");
}

HKGenTLCamera::~HKGenTLCamera()
{//MT N/A
    close();
}

bool HKGenTLCamera::open(const QVariantMap& params)
{//MT N/A
    LaserXCamera::setParameters(params);
    QString iDeviceID = params[QStringLiteral("DeviceID")].toString();
    if (mDevHandle && iDeviceID == mDeviceID)
    {
        return true;
    }

    QDir pluginsDir = QDir(QCoreApplication::applicationDirPath());
    pluginsDir.cd(QStringLiteral("plugins"));
    pluginsDir.cd(QStringLiteral("cameras"));
    QStringList nameFilters;
    nameFilters << QStringLiteral("MvProducerGEV.cti");
    const auto entryList = pluginsDir.entryList(nameFilters, QDir::Files | QDir::NoDotAndDotDot);
    MV_GENTL_IF_INFO_LIST iIFList;
    if (!entryList.empty())
    {
        const std::string strGenTLPath = entryList.at(0).toStdString();
        std::memset(&iIFList, 0, sizeof(iIFList));

        int iRet = MV_CC_EnumInterfacesByGenTL(&iIFList, strGenTLPath.c_str());
        if (MV_OK == iRet && iIFList.nInterfaceNum)
        {
            for (unsigned int ii = 0; ii < iIFList.nInterfaceNum; ++ii)
            {
                MV_GENTL_IF_INFO* pstIFInfo = iIFList.pIFInfo[ii];
                MV_GENTL_DEV_INFO_LIST stDevList;
                std::memset(&stDevList, 0, sizeof(stDevList));

                int iRet = MV_CC_EnumDevicesByGenTL(pstIFInfo, &stDevList);
                if (MV_OK == iRet && stDevList.nDeviceNum)
                {
                    for (unsigned int jj = 0; jj < stDevList.nDeviceNum; ++jj)
                    {
                        const MV_GENTL_DEV_INFO* pstDeviceInfo = stDevList.pDeviceInfo[jj];
                        QString thisDevId = QString::fromLatin1(&pstDeviceInfo->chDeviceID[0]);
                        if (thisDevId == iDeviceID)
                        {
                            close();

                            int nRet = MV_CC_CreateHandleByGenTL(&mDevHandle, pstDeviceInfo);
                            if (MV_OK == nRet)
                            {
                                nRet = MV_CC_OpenDevice(mDevHandle);
                                if (MV_OK == nRet && initCamera())
                                {
                                    startGrab();
                                    mDeviceID = iDeviceID;
                                    emit cameraOpened();
                                    return true;
                                }
                                else if (MV_E_ACCESS_DENIED == nRet)
                                {
                                    MV_CC_DestroyHandle(mDevHandle);

                                    mDevHandle = nullptr;
                                    emit errorOccurred(AccessDeniedError);
                                    return false;
                                }
                                else
                                {
                                    MV_CC_DestroyHandle(mDevHandle);
                                    mDevHandle = nullptr;
                                }
                            }

                            emit errorOccurred(OpenError);
                            return false;
                        }
                    }
                }
            }
        }
    }

    emit errorOccurred(DeviceNotFoundError);
    return false;
}

bool HKGenTLCamera::close()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (mDevHandle)
    {
        MV_CC_StopGrabbing(mDevHandle);
        MV_CC_CloseDevice(mDevHandle);
        MV_CC_DestroyHandle(mDevHandle);
        mDevHandle = nullptr;
        emit cameraClosed();
    }

    return true;
}

cv::Mat HKGenTLCamera::snap(int msec)
{//MT
    QWriteLocker iLocker(&mLocker);
    if (trigger(true))
    {
        return grabImage(true, msec);
    }
    else
    {
        return mImage;
    }
}

QImage HKGenTLCamera::grab(int msec)
{//MT
    QWriteLocker iLocker(&mLocker);
    if (trigger(true))
    {
        return snapImage(true, msec);
    }
    else
    {
        return QImage();
    }
}

void HKGenTLCamera::imageConsumed()
{//MT
    mManager->mPending -= 1;
    if (mManager->mPending < 0)
    {
        mManager->mPending = 0;
    }
}

bool HKGenTLCamera::startContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (!mContinuousGrabbing)
    {
        mContinuousGrabbing = true;
        mManager->mNumLiving += 1;
        mLiveFuture = QtConcurrent::run(HKGenTLCamera::liveMe, this);
    }

    return true;
}

bool HKGenTLCamera::stopContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (mContinuousGrabbing)
    {
        mContinuousGrabbing = false;
        mLiveFuture.waitForFinished();
        mManager->mNumLiving -= 1;
        mManager->mPending = 0;
    }
    return true;
}

bool HKGenTLCamera::toggleContinuousGrab()
{//MT
    if (mContinuousGrabbing)
    {
        return stopContinuousGrab();
    }
    else
    {
        return startContinuousGrab();
    }
}

bool HKGenTLCamera::isOpened() const
{//MT N/A
    return mDevHandle;
}

bool HKGenTLCamera::isLivable() const
{//MT N/A
    return true;
}

bool HKGenTLCamera::setParameters(const QVariantMap& params)
{//MT N/A
    LaserXCamera::setParameters(params);
    HKGenTLCamera::setGrabParams(params);
    return true;
}

QVariantMap HKGenTLCamera::getParameters() const
{//MT N/A
    QVariantMap params = LaserXCamera::getParameters();
    params[QStringLiteral("DeviceID")] = mDeviceID;
    if (isOpened())
    {
        params[QStringLiteral("TriggerDelay")] = readTriggerDelay();
        params[QStringLiteral("ExposureTime")] = readExposureTime();
        params[QStringLiteral("Gain")] = readGain();
        params[QStringLiteral("GammaEnable")] = readGammaEnable();
        params[QStringLiteral("Gamma")] = readGamma();
        params[QStringLiteral("Sharpness")] = readSharpness();
    }
    return params;
}

void HKGenTLCamera::setGrabParams(const QVariantMap& params)
{//MT
    QWriteLocker iLocker(&mLocker);
    if (params.contains(QStringLiteral("Gain")))
    {
        qreal iGain = params.value(QStringLiteral("Gain")).toReal();
        writeGain(iGain);
    }

    if (params.contains(QStringLiteral("ExposureTime")))
    {
        qreal iExposureTime = params.value(QStringLiteral("ExposureTime")).toReal();
        writeExposureTime(iExposureTime);
    }
}

QVariantMap HKGenTLCamera::getGrabParams() const
{//MT N/A
    QVariantMap params;
    if (isOpened())
    {
        params[QStringLiteral("ExposureTime")] = readExposureTime();
        params[QStringLiteral("Gain")] = readGain();
    }
    return params;
}

int HKGenTLCamera::getFPS() const
{//MT N/A
    return 10;
}

void HKGenTLCamera::startGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    int nRet = MV_CC_StartGrabbing(mDevHandle);
    if (MV_OK != nRet)
    {
        emit errorOccurred(ReadError);
    }
}

void HKGenTLCamera::stopGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    int nRet = MV_CC_StopGrabbing(mDevHandle);
    if (MV_OK != nRet)
    {
        emit errorOccurred(ReadError);
    }
}

bool HKGenTLCamera::trigger(bool emitError)
{//MT N/A
    if (!mDevHandle)
    {
        if (emitError) emit errorOccurred(NotOpenError);
        return false;
    }
    else
    {
        int nRet = MV_CC_SetCommandValue(mDevHandle, "TriggerSoftware");
        if (MV_OK != nRet)
        {
            if (emitError) emit errorOccurred(TriggerError);
            return false;
        }
        else
        {
            return true;
        }
    }
}

cv::Mat HKGenTLCamera::grabImage(bool emitError, int msec)
{//MT N/A
    if (!isOpened())
    {
        if (emitError) emit errorOccurred(NotOpenError);
    }
    else
    {
        MV_FRAME_OUT stImageInfo;
        std::memset(&stImageInfo, 0, sizeof(stImageInfo));

        int nRet = MV_CC_GetImageBuffer(mDevHandle, &stImageInfo, msec ? msec : 1000);
        if (nRet == MV_OK)
        {
            if (stImageInfo.stFrameInfo.enPixelType == PixelType_Gvsp_Mono8)
            {
                if (!mImage.empty() &&
                    mImage.rows == stImageInfo.stFrameInfo.nHeight &&
                    mImage.cols == stImageInfo.stFrameInfo.nWidth &&
                    CV_8UC1 == mImage.type())
                {
                    std::memcpy(mImage.data, stImageInfo.pBufAddr, mImage.total());
                }
                else
                {
                    mImage = cv::Mat(stImageInfo.stFrameInfo.nHeight, stImageInfo.stFrameInfo.nWidth, CV_8UC1, stImageInfo.pBufAddr).clone();
                }
            }
            else
            {
                mImage = cv::Mat();
            }

            MV_CC_FreeImageBuffer(mDevHandle, &stImageInfo);
        }
        else
        {
            if (emitError) emit errorOccurred(ReadError);
        }
    }

    return mImage;
}

QImage HKGenTLCamera::snapImage(bool emitError, int msec)
{//MT N/A
    QImage rImage;
    if (!isOpened())
    {
        if (emitError) emit errorOccurred(NotOpenError);
    }
    else
    {
        MV_FRAME_OUT stImageInfo;
        std::memset(&stImageInfo, 0, sizeof(stImageInfo));

        int nRet = MV_CC_GetImageBuffer(mDevHandle, &stImageInfo, msec ? msec : 1000);
        if (nRet == MV_OK)
        {
            if (stImageInfo.stFrameInfo.enPixelType == PixelType_Gvsp_Mono8)
            {
                QImage iImage(static_cast<uchar*>(stImageInfo.pBufAddr), stImageInfo.stFrameInfo.nWidth, stImageInfo.stFrameInfo.nHeight, QImage::Format_Grayscale8);
                rImage = iImage.copy();
            }

            MV_CC_FreeImageBuffer(mDevHandle, &stImageInfo);
        }
        else
        {
            if (emitError) emit errorOccurred(ReadError);
        }
    }

    return rImage;
}

MV_CAM_TRIGGER_MODE HKGenTLCamera::readTriggerMode() const
{//MT N/A
    MVCC_ENUMVALUE stEnumValue = { 0 };

    int nRet = MV_CC_GetEnumValue(mDevHandle, "TriggerMode", &stEnumValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read TriggerMode error"));
        return MV_TRIGGER_MODE_OFF;
    }
    else
    {
        return static_cast<MV_CAM_TRIGGER_MODE>(stEnumValue.nCurValue);
    }
}

MV_CAM_TRIGGER_SOURCE HKGenTLCamera::readTriggerSource() const
{//MT N/A
    MVCC_ENUMVALUE stEnumValue = { 0 };

    int nRet = MV_CC_GetEnumValue(mDevHandle, "TriggerSource", &stEnumValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read TriggerSource error"));
        return MV_TRIGGER_SOURCE_SOFTWARE;
    }
    else
    {
        return static_cast<MV_CAM_TRIGGER_SOURCE>(stEnumValue.nCurValue);
    }
}

MV_CAM_ACQUISITION_MODE HKGenTLCamera::readAcquisitionMode() const
{//MT N/A
    MVCC_ENUMVALUE stEnumValue = { 0 };

    int nRet = MV_CC_GetEnumValue(mDevHandle, "AcquisitionMode", &stEnumValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read AcquisitionMode error"));
        return MV_ACQ_MODE_SINGLE;
    }
    else
    {
        return static_cast<MV_CAM_ACQUISITION_MODE>(stEnumValue.nCurValue);
    }
}

MV_CAM_EXPOSURE_MODE HKGenTLCamera::readExposureMode() const
{//MT N/A
    MVCC_ENUMVALUE stEnumValue = { 0 };

    int nRet = MV_CC_GetEnumValue(mDevHandle, "ExposureMode", &stEnumValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read ExposureMode error"));
        return MV_EXPOSURE_MODE_TIMED;
    }
    else
    {
        return static_cast<MV_CAM_EXPOSURE_MODE>(stEnumValue.nCurValue);
    }
}

MV_CAM_EXPOSURE_AUTO_MODE HKGenTLCamera::readExposureAuto() const
{//MT N/A
    MVCC_ENUMVALUE stEnumValue = { 0 };

    int nRet = MV_CC_GetEnumValue(mDevHandle, "ExposureAuto", &stEnumValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read ExposureAuto error"));
        return MV_EXPOSURE_AUTO_MODE_OFF;
    }
    else
    {
        return static_cast<MV_CAM_EXPOSURE_AUTO_MODE>(stEnumValue.nCurValue);
    }
}

float HKGenTLCamera::readExposureTime() const
{//MT N/A
    MVCC_FLOATVALUE stFloatValue = { 0 };

    int nRet = MV_CC_GetFloatValue(mDevHandle, "ExposureTime", &stFloatValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read ExposureTime error"));
        return 0;
    }
    else
    {
        return stFloatValue.fCurValue;
    }
}

MV_CAM_GAIN_MODE HKGenTLCamera::readGainAuto() const
{//MT N/A
    MVCC_ENUMVALUE stEnumValue = { 0 };

    int nRet = MV_CC_GetEnumValue(mDevHandle, "GainAuto", &stEnumValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read GainAuto error"));
        return MV_GAIN_MODE_OFF;
    }
    else
    {
        return static_cast<MV_CAM_GAIN_MODE>(stEnumValue.nCurValue);
    }
}

float HKGenTLCamera::readGain() const
{//MT N/A
    MVCC_FLOATVALUE stFloatValue = { 0 };

    int nRet = MV_CC_GetFloatValue(mDevHandle, "Gain", &stFloatValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read Gain error"));
        return 0;
    }
    else
    {
        return stFloatValue.fCurValue;
    }
}

bool HKGenTLCamera::readGammaEnable() const
{//MT N/A
    bool bValue = false;

    int nRet = MV_CC_GetBoolValue(mDevHandle, "GammaEnable", &bValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read GammaEnable error"));
        return false;
    }
    else
    {
        return bValue;
    }
}

float HKGenTLCamera::readGamma() const
{//MT N/A
    MVCC_FLOATVALUE stFloatValue = { 0 };

    int nRet = MV_CC_GetFloatValue(mDevHandle, "Gamma", &stFloatValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read Gamma error"));
        return 0;
    }
    else
    {
        return stFloatValue.fCurValue;
    }
}

float HKGenTLCamera::readTriggerDelay() const
{//MT N/A
    MVCC_FLOATVALUE stValue = { 0 };

    int nRet = MV_CC_GetFloatValue(mDevHandle, "TriggerDelay", &stValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read TriggerDelay error"));
        return 0;
    }
    else
    {
        return stValue.fCurValue;
    }
}

int HKGenTLCamera::readSharpness() const
{//MT N/A
    MVCC_INTVALUE_EX stValue = { 0 };

    int nRet = MV_CC_GetIntValueEx(mDevHandle, "Sharpness", &stValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read Sharpness error"));
        return 0;
    }
    else
    {
        return static_cast<int>(stValue.nCurValue);
    }
}

bool HKGenTLCamera::readSharpnessEnable() const
{//MT N/A
    bool bValue = false;

    int nRet = MV_CC_GetBoolValue(mDevHandle, "SharpnessEnable", &bValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read SharpnessEnable error"));
        return false;
    }
    else
    {
        return bValue;
    }
}

int HKGenTLCamera::readWidthMax() const
{//MT N/A
    MVCC_INTVALUE_EX stValue = { 0 };
    int nRet = MV_CC_GetIntValueEx(mDevHandle, "WidthMax", &stValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read WidthMax error"));
        return 0;
    }
    else
    {
        return static_cast<int>(stValue.nCurValue);
    }
}

int HKGenTLCamera::readHeightMax() const
{//MT N/A
    MVCC_INTVALUE_EX stValue = { 0 };
    int nRet = MV_CC_GetIntValueEx(mDevHandle, "HeightMax", &stValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(ReadParameterError, QStringLiteral("Read HeightMax error"));
        return 0;
    }
    else
    {
        return static_cast<int>(stValue.nCurValue);
    }
}

bool HKGenTLCamera::writeTriggerMode(MV_CAM_TRIGGER_MODE nValue)
{//MT N/A
    const auto oValue = readTriggerMode();
    if (oValue == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetEnumValue(mDevHandle, "TriggerMode", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write TriggerMode to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("TriggerMode"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

bool HKGenTLCamera::writeTriggerSource(MV_CAM_TRIGGER_SOURCE nValue)
{//MT N/A
    const auto oValue = readTriggerSource();
    if (oValue == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetEnumValue(mDevHandle, "TriggerSource", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write TriggerSource to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("TriggerSource"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

bool HKGenTLCamera::writeAcquisitionMode(MV_CAM_ACQUISITION_MODE nValue)
{//MT N/A
    const auto oValue = readAcquisitionMode();
    if (oValue == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetEnumValue(mDevHandle, "AcquisitionMode", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write AcquisitionMode to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("AcquisitionMode"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

bool HKGenTLCamera::writeExposureMode(MV_CAM_EXPOSURE_MODE nValue)
{//MT N/A
    const auto oValue = readExposureMode();
    if (oValue == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetEnumValue(mDevHandle, "ExposureMode", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write ExposureMode to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("ExposureMode"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

bool HKGenTLCamera::writeExposureAuto(MV_CAM_EXPOSURE_AUTO_MODE nValue)
{//MT N/A
    const auto oValue = readExposureAuto();
    if (oValue == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetEnumValue(mDevHandle, "ExposureAuto", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write ExposureAuto to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("ExposureAuto"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

bool HKGenTLCamera::writeExposureTime(const float nValue)
{//MT N/A
    if (HikEQValue(mExposureTime, nValue))
    {
        return true;
    }

    int nRet = MV_CC_SetFloatValue(mDevHandle, "ExposureTime", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write ExposureTime to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("ExposureTime"), QVariant(mExposureTime), QVariant(nValue));
        mExposureTime = nValue;
        return true;
    }
}

bool HKGenTLCamera::writeGainAuto(MV_CAM_GAIN_MODE nValue)
{//MT N/A
    const auto oValue = readGainAuto();
    if (oValue == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetEnumValue(mDevHandle, "GainAuto", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write GainAuto to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("GainAuto"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

bool HKGenTLCamera::writeGain(const float nValue)
{//MT N/A
    if (HikEQValue(mGain, nValue))
    {
        return true;
    }

    int nRet = MV_CC_SetFloatValue(mDevHandle, "Gain", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write Gain to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("Gain"), QVariant(mGain), QVariant(nValue));
        mGain = nValue;
        return true;
    }
}

bool HKGenTLCamera::writeGammaEnable(const bool nValue)
{//MT N/A
    if (mGammaEnable == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetBoolValue(mDevHandle, "GammaEnable", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write GammaEnable to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("GammaEnable"), QVariant(mGammaEnable), QVariant(nValue));
        mGammaEnable = nValue;
        return true;
    }
}

bool HKGenTLCamera::writeGamma(const float nValue)
{//MT N/A
    if (HikEQValue(mGamma, nValue))
    {
        return true;
    }

    int nRet = MV_CC_SetFloatValue(mDevHandle, "Gamma", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write Gamma to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("Gamma"), QVariant(mGamma), QVariant(nValue));
        mGamma = nValue;
        return true;
    }
}

bool HKGenTLCamera::writeTriggerDelay(const float nValue)
{//MT N/A
    const auto oValue = readTriggerDelay();
    if (HikEQValue(oValue, nValue))
    {
        return true;
    }

    int nRet = MV_CC_SetFloatValue(mDevHandle, "TriggerDelay", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write TriggerDelay to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("TriggerDelay"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

bool HKGenTLCamera::writeSharpness(const int nValue)
{//MT N/A
    const auto oValue = readSharpness();
    if (oValue == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetIntValueEx(mDevHandle, "Sharpness", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write Sharpness to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("Sharpness"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

bool HKGenTLCamera::writeSharpnessEnable(const bool nValue)
{//MT N/A
    const auto oValue = readSharpnessEnable();
    if (oValue == nValue)
    {
        return true;
    }

    int nRet = MV_CC_SetBoolValue(mDevHandle, "SharpnessEnable", nValue);
    if (MV_OK != nRet)
    {
        emit errorOccurredEx(WriteParameterError, QStringLiteral("Write SharpnessEnable to %1 error").arg(nValue));
        return false;
    }
    else
    {
        emit parameterChanged(QStringLiteral("SharpnessEnable"), QVariant(oValue), QVariant(nValue));
        return true;
    }
}

void HKGenTLCamera::installImageCallBack()
{//MT N/A
    int nRet = MV_CC_RegisterImageCallBackEx(mDevHandle, &HKGenTLCamera::imageCallBackEx, this);
    if (MV_OK != nRet)
    {
        emit errorOccurred(WriteParameterError);
    }
}

void HKGenTLCamera::uninstallImageCallBack()
{//MT N/A
    int nRet = MV_CC_RegisterImageCallBackEx(mDevHandle, nullptr, this);
    if (MV_OK != nRet)
    {
        emit errorOccurred(UnknownError);
    }
}

void HKGenTLCamera::installExceptionCallBack()
{//MT N/A
    int nRet = MV_CC_RegisterExceptionCallBack(mDevHandle, &HKGenTLCamera::exceptionCallBack, this);
    if (MV_OK != nRet)
    {
        if (MV_E_SUPPORT == nRet)
        {
            qDebug() << QStringLiteral("UnsupportedOperationError");
        }
        else
        {
            qDebug() << QStringLiteral("Error code: ") << nRet;
        }
    }
}

bool HKGenTLCamera::initCamera()
{//MT N/A
    writeTriggerMode(MV_TRIGGER_MODE_ON);
    writeTriggerSource(MV_TRIGGER_SOURCE_SOFTWARE);
    writeAcquisitionMode(MV_ACQ_MODE_CONTINUOUS);
    writeExposureMode(MV_EXPOSURE_MODE_TIMED);
    writeExposureAuto(MV_EXPOSURE_AUTO_MODE_OFF);
    writeGainAuto(MV_GAIN_MODE_OFF);
    writeSharpnessEnable(true);
    installExceptionCallBack();

    mGain = readGain();
    mExposureTime = readExposureTime();
    mGamma = readGamma();
    mGammaEnable = readGammaEnable();
    mWidthMax = readWidthMax();
    mHeightMax = readHeightMax();

    return true;
}

void HKGenTLCamera::liveMe(HKGenTLCamera* cam)
{//MT
    while (cam->mContinuousGrabbing)
    {
        QThread::msleep(cam->mManager->getLivingDelay());
        if (cam->mManager->mPending > 0)
        {
            continue;
        }

        if (!cam->mLocker.tryLockForWrite())
        {
            continue;
        }

        if (cam->trigger(false))
        {
            QVariantMap infos;
            cv::Mat iImage = cam->grabImage(false, 500);
            emit cam->imageReady(iImage, infos);
            cam->mManager->mPending += 1;
        }

        cam->mLocker.unlock();
    }
}

void __stdcall HKGenTLCamera::imageCallBackEx(unsigned char* pData, MV_FRAME_OUT_INFO_EX* pFrameInfo, void* pUser)
{
    HKGenTLCamera* self = static_cast<HKGenTLCamera*>(pUser);
    if (pData && pFrameInfo && pFrameInfo->enPixelType == PixelType_Gvsp_Mono8)
    {
        QVariantMap infos;
        infos[QStringLiteral("FrameNum")] = pFrameInfo->nFrameNum;
        infos[QStringLiteral("Gain")] = pFrameInfo->fGain;
        infos[QStringLiteral("ExposureTime")] = pFrameInfo->fExposureTime;

        cv::Mat iImage;
        emit self->imageReady(iImage, infos);
    }
}

void __stdcall HKGenTLCamera::exceptionCallBack(unsigned int nMsgType, void* pUser)
{
    HKGenTLCamera* self = static_cast<HKGenTLCamera*>(pUser);
    if (self) {
        self->close();
    }
}

#pragma warning( pop )
