#ifndef HK_GENTL_CAMERA_H
#define HK_GENTL_CAMERA_H

#include "opencv2/opencv.hpp"
#include <QElapsedTimer>
#include <laser_x_camera.h>
#include <MvCameraControl.h>
class HKGenTLCameraManager;

class HKGenTLCamera : public LaserXCamera
{
    Q_OBJECT
    friend class ConfigHikGenTLCameraPage;
public:
    HKGenTLCamera(QObject* parent);
    HKGenTLCamera(QObject* parent, const QString& uuid);
    ~HKGenTLCamera();

public:
    bool open(const QVariantMap& params) override;
    bool close() override;
    cv::Mat snap(int msec = 0) override;
    cv::Mat tryLiveGrab(int msec = 0) override;
    bool isOpened() const override;
    bool isLivable() const override;
    bool setParameters(const QVariantMap& params) override;
    QVariantMap getParameters() const override;
    void setGrabParams(const QVariantMap& params) override;
    QVariantMap getGrabParams() const override;
    QString getPerProjectParams() const override;
    void setPerProjectParams(const QString& perProjParams) override;
    int getFPS() const override;

public:
    QString deviceID() const { return mDeviceID; }
    bool setWidth(const int nValue);
    bool setHeight(const int nValue);

private:
    void startGrab();
    void stopGrab();
    bool trigger(bool emitError);
    cv::Mat grabImage(bool emitError, int msec = 0);
    QImage snapImage(bool emitError, int msec = 0);

    MV_CAM_TRIGGER_MODE readTriggerMode() const;
    MV_CAM_TRIGGER_SOURCE readTriggerSource() const;
    MV_CAM_ACQUISITION_MODE readAcquisitionMode() const;
    MV_CAM_EXPOSURE_MODE readExposureMode() const;
    MV_CAM_EXPOSURE_AUTO_MODE readExposureAuto() const;
    float readExposureTime() const;
    MV_CAM_GAIN_MODE readGainAuto() const;
    float readGain() const;
    bool readGammaEnable() const;
    float readGamma() const;
    float readTriggerDelay() const;
    int readSharpness() const;
    bool readSharpnessEnable() const;
    int readWidthMax() const;
    int readHeightMax() const;
    int readWidth() const;
    int readHeight() const;

    bool writeTriggerMode(MV_CAM_TRIGGER_MODE nValue);
    bool writeTriggerSource(MV_CAM_TRIGGER_SOURCE nValue);
    bool writeAcquisitionMode(MV_CAM_ACQUISITION_MODE nValue);
    bool writeExposureMode(MV_CAM_EXPOSURE_MODE nValue);
    bool writeExposureAuto(MV_CAM_EXPOSURE_AUTO_MODE nValue);
    bool writeExposureTime(const float nValue);
    bool writeGainAuto(MV_CAM_GAIN_MODE nValue);
    bool writeGain(const float nValue);
    bool writeGammaEnable(const bool nValue);
    bool writeGamma(const float nValue);
    bool writeTriggerDelay(const float nValue);
    bool writeSharpness(const int nValue);
    bool writeSharpnessEnable(const bool nValue);
    bool writeWidth(const int nValue);
    bool writeHeight(const int nValue);

    void installImageCallBack();
    void uninstallImageCallBack();
    void installExceptionCallBack();

    bool initCamera(const int iWidth, const int iHeight);

private:
    static void __stdcall imageCallBackEx(unsigned char* pData, MV_FRAME_OUT_INFO_EX* pFrameInfo, void* pUser);
    static void __stdcall exceptionCallBack(unsigned int nMsgType, void* pUser);

private:
    void* mDevHandle = nullptr;
    QString mDeviceID;
    cv::Mat mImage;
    QFuture<void> mLiveFuture;
    float mNumFrames = 0;
    HKGenTLCameraManager* mManager = nullptr;

private:
    float mGain = 0.f;
    float mExposureTime = 0.f;
    float mGamma = 0.f;
    bool  mGammaEnable = false;
    int mROIWidth = 0;
    int mROIHeight = 0;
    int mWidthMax = 0;
    int mHeightMax = 0;
};

#endif // HK_GENTL_CAMERA_H
