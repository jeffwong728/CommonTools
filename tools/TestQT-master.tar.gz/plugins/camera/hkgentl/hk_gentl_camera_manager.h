#ifndef HK_GENTL_CAMERA_MANAGER_H
#define HK_GENTL_CAMERA_MANAGER_H

#include "hk_gentl_camera_global.h"
#include <laser_x_camera.h>
#include <QObject>
#include <memory>
class HKGenTLCamera;

class HKGenTLCameraManager : public LaserXCameraManager {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LaserXCameraManagerInterfaceIID)
    Q_INTERFACES(LaserXCameraManager)
public:
    HKGenTLCameraManager();
    ~HKGenTLCameraManager();

public:
    QString getTypeName() override;
    QIcon getIcon() const override;
    int getNumCameras() override;
    QVector<LaserXCamera*> getCameras() override;
    LaserXCamera* createCamera(const QVariantMap& params) override;
    LaserXCamera* findCamera(const QVariantMap& params) const override;
    bool addCamera(LaserXCamera* camera) override;
    void deleteCamera(LaserXCamera* camera) override;
    LaserXAddCameraWidget* getAddWidget(QWidget* parent) override;
    LaserXConfigCameraWidget* getConfigWidget(QWidget* parent, LaserXCamera* camera) override;
    int getLivingDelay() const;

public:
    qint8 mNumLiving = 0;
    QAtomicInt mPending;

private:
    QMap<QString, HKGenTLCamera*> mCameras;
};

#endif // HK_GENTL_CAMERA_MANAGER_H
