#ifndef ADDHKGENTLCAMERAPAGE_H
#define ADDHKGENTLCAMERAPAGE_H

#include <QWidget>
#include <laser_x_camera.h>
#include <MvCameraControl.h>
class HKGenTLCameraManager;

namespace Ui {
class AddHKGenTLCameraPage;
}

class AddHKGenTLCameraPage : public LaserXAddCameraWidget
{
    Q_OBJECT

public:
    explicit AddHKGenTLCameraPage(QWidget *parent, HKGenTLCameraManager* camManager);
    ~AddHKGenTLCameraPage();

public:
    QVariantMap getParameters() const override;

private slots:
    void on_comboBoxInterface_currentIndexChanged(int index);
    void on_comboBoxDevice_currentIndexChanged(int index);

private:
    Ui::AddHKGenTLCameraPage *ui;
    MV_GENTL_IF_INFO_LIST mIFList;
    std::vector<MV_GENTL_DEV_INFO_LIST> mDevList;
    HKGenTLCameraManager* const mCameraManager;
};

#endif // ADDHKGENTLCAMERAPAGE_H
