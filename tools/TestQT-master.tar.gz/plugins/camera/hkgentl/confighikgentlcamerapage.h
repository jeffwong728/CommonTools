#ifndef CONFIGHIKGENTLCAMERAPAGE_H
#define CONFIGHIKGENTLCAMERAPAGE_H

#include <QToolBox>
#include <laser_x_camera.h>
class HKGenTLCamera;

namespace Ui {
class ConfigHikGenTLCameraPage;
}

class ConfigHikGenTLCameraPage : public LaserXConfigCameraWidget
{
    Q_OBJECT

public:
    explicit ConfigHikGenTLCameraPage(QWidget *parent, HKGenTLCamera* camera);
    ~ConfigHikGenTLCameraPage();

public:
    void initialize(const QVariantMap& params) override;
    QVariantMap getParameters() const override;

private slots:
    void on_lineEditName_returnPressed();
    void on_lineEditDescription_returnPressed();
    void on_lineEditExposureTime_returnPressed();
    void on_lineEditTriggerDelay_returnPressed();
    void on_lineEditGain_returnPressed();
    void on_spinBoxSharpness_valueChanged(int arg1);
    void on_spinBoxBlackLevel_valueChanged(int arg1);
    void on_checkBoxGammaEnable_toggled(bool checked);
    void on_lineEditGamma_returnPressed();

private:
    Ui::ConfigHikGenTLCameraPage *ui;
    HKGenTLCamera* mCamera = nullptr;
};

#endif // CONFIGHIKGENTLCAMERAPAGE_H
