#include "confighikgentlcamerapage.h"
#include "hk_gentl_camera.h"
#include <MvCameraControl.h>

ConfigHikGenTLCameraPage::ConfigHikGenTLCameraPage(QWidget *parent, HKGenTLCamera* camera) :
    LaserXConfigCameraWidget(parent), mCamera(camera)
{
    setupUi(this);
    checkBoxGammaEnable->setVisible(false);
    lineEditGamma->setVisible(false);
    lineEditTriggerDelay->setVisible(false);
    spinBoxSharpness->setVisible(false);
    spinBoxBlackLevel->setVisible(false);
    labelGammaEnable->setVisible(false);
    labelGamma->setVisible(false);
    labelTriggerDelay->setVisible(false);
    labelSharpness->setVisible(false);
    labelBlackLevel->setVisible(false);

    lineEditWidth->setText(QString::number(mCamera->readWidth()));
    lineEditHeight->setText(QString::number(mCamera->readHeight()));
    lineEditWidth->setValidator(new QIntValidator(32, mCamera->readWidthMax(), this));
    lineEditHeight->setValidator(new QIntValidator(32, mCamera->readHeightMax(), this));
    lineEditWidth->setToolTip(tr("Range: %1..%2").arg(32).arg(mCamera->readWidthMax()));
    lineEditHeight->setToolTip(tr("Range: %1..%2").arg(32).arg(mCamera->readHeightMax()));
}

ConfigHikGenTLCameraPage::~ConfigHikGenTLCameraPage()
{
}

void ConfigHikGenTLCameraPage::initialize(const QVariantMap& params)
{
    lineEditName->setText(params[QStringLiteral("Name")].toString());
    lineEditDescription->setText(params[QStringLiteral("Description")].toString());
    lineEditExposureTime->setText(QStringLiteral("%1").arg(params[QStringLiteral("ExposureTime")].toFloat()));
    lineEditGain->setText(QStringLiteral("%1").arg(params[QStringLiteral("Gain")].toFloat()));
    checkBoxGammaEnable->setChecked(params[QStringLiteral("GammaEnable")].toBool());
    lineEditGamma->setText(QStringLiteral("%1").arg(params[QStringLiteral("Gamma")].toFloat()));
    lineEditTriggerDelay->setText(QStringLiteral("%1").arg(params[QStringLiteral("TriggerDelay")].toFloat()));
    spinBoxSharpness->setValue(params[QStringLiteral("Sharpness")].toInt());
    lineEditGamma->setEnabled(checkBoxGammaEnable->isChecked());

    if (params.value(QStringLiteral("DisableSize")).toBool())
    {
        lineEditWidth->setEnabled(false);
        lineEditHeight->setEnabled(false);
    }
}

QVariantMap ConfigHikGenTLCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = lineEditName->text();
    params[QStringLiteral("Description")] = lineEditDescription->text();
    params[QStringLiteral("ExposureTime")] = lineEditExposureTime->text().toFloat();
    params[QStringLiteral("Gain")] = lineEditGain->text().toFloat();
    params[QStringLiteral("GammaEnable")] = checkBoxGammaEnable->isChecked();
    params[QStringLiteral("Gamma")] = lineEditGamma->text().toFloat();
    params[QStringLiteral("TriggerDelay")] = lineEditTriggerDelay->text().toFloat();
    params[QStringLiteral("Sharpness")] = spinBoxSharpness->value();
    return params;
}

void ConfigHikGenTLCameraPage::on_lineEditName_returnPressed()
{
    mCamera->setName(lineEditName->text());
    emit parametersChanged(getParameters());
}

void ConfigHikGenTLCameraPage::on_lineEditDescription_returnPressed()
{
    mCamera->setDescription(lineEditDescription->text());
    emit parametersChanged(getParameters());
}

void ConfigHikGenTLCameraPage::on_lineEditExposureTime_returnPressed()
{
    bool ok = false;
    float nValue = lineEditExposureTime->text().toFloat(&ok);
    if (ok && mCamera->writeExposureTime(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_lineEditTriggerDelay_returnPressed()
{
    bool ok = false;
    float nValue = lineEditTriggerDelay->text().toFloat(&ok);
    if (ok && mCamera->writeTriggerDelay(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_lineEditGain_returnPressed()
{
    bool ok = false;
    float nValue = lineEditGain->text().toFloat(&ok);
    if (ok && mCamera->writeGain(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_spinBoxSharpness_valueChanged(int arg1)
{
    int nValue = spinBoxSharpness->value();
    if (mCamera->writeSharpness(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_lineEditWidth_returnPressed()
{
    int nValue = lineEditWidth->text().toInt();
    QApplication::setOverrideCursor(Qt::WaitCursor);
    const bool iLive = mCamera->isContinuousGrab();
    mCamera->stopContinuousGrab();
    mCamera->stopGrab();
    const bool iOk = mCamera->writeWidth(nValue);
    mCamera->startGrab();
    if (iLive)
    {
        mCamera->startContinuousGrab();
    }

    if (mCamera->setWidth(nValue) && iOk)
    {
        emit parametersChanged(getParameters());
    }
    QApplication::restoreOverrideCursor();
}

void ConfigHikGenTLCameraPage::on_lineEditHeight_returnPressed()
{
    int nValue = lineEditHeight->text().toInt();
    QApplication::setOverrideCursor(Qt::WaitCursor);
    const bool iLive = mCamera->isContinuousGrab();
    mCamera->stopContinuousGrab();
    mCamera->stopGrab();
    const bool iOk = mCamera->writeHeight(nValue);
    mCamera->startGrab();
    if (iLive)
    {
        mCamera->startContinuousGrab();
    }

    if (mCamera->setHeight(nValue) && iOk)
    {
        emit parametersChanged(getParameters());
    }
    QApplication::restoreOverrideCursor();
}

void ConfigHikGenTLCameraPage::on_spinBoxBlackLevel_valueChanged(int arg1)
{
    emit parametersChanged(getParameters());
}

void ConfigHikGenTLCameraPage::on_checkBoxGammaEnable_toggled(bool checked)
{
    lineEditGamma->setEnabled(checkBoxGammaEnable->isChecked());
    if (mCamera->writeGammaEnable(checked))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_lineEditGamma_returnPressed()
{
    bool ok = false;
    float nValue = lineEditGamma->text().toFloat(&ok);
    if (ok && mCamera->writeGamma(nValue))
    {
        emit parametersChanged(getParameters());
    }
}
