#include "confighikgentlcamerapage.h"
#include "ui_confighikgentlcamerapage.h"
#include "hk_gentl_camera.h"
#include <MvCameraControl.h>

ConfigHikGenTLCameraPage::ConfigHikGenTLCameraPage(QWidget *parent, HKGenTLCamera* camera) :
    LaserXConfigCameraWidget(parent),
    ui(new Ui::ConfigHikGenTLCameraPage), mCamera(camera)
{
    ui->setupUi(this);
}

ConfigHikGenTLCameraPage::~ConfigHikGenTLCameraPage()
{
    delete ui;
}

void ConfigHikGenTLCameraPage::initialize(const QVariantMap& params)
{
    ui->lineEditName->setText(params[QStringLiteral("Name")].toString());
    ui->lineEditDescription->setText(params[QStringLiteral("Description")].toString());
    ui->lineEditExposureTime->setText(QStringLiteral("%1").arg(params[QStringLiteral("ExposureTime")].toFloat()));
    ui->lineEditGain->setText(QStringLiteral("%1").arg(params[QStringLiteral("Gain")].toFloat()));
    ui->checkBoxGammaEnable->setChecked(params[QStringLiteral("GammaEnable")].toBool());
    ui->lineEditGamma->setText(QStringLiteral("%1").arg(params[QStringLiteral("Gamma")].toFloat()));
    ui->lineEditTriggerDelay->setText(QStringLiteral("%1").arg(params[QStringLiteral("TriggerDelay")].toFloat()));
    ui->spinBoxSharpness->setValue(params[QStringLiteral("Sharpness")].toInt());
    ui->lineEditGamma->setEnabled(ui->checkBoxGammaEnable->isChecked());
}

QVariantMap ConfigHikGenTLCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = ui->lineEditName->text();
    params[QStringLiteral("Description")] = ui->lineEditDescription->text();
    params[QStringLiteral("ExposureTime")] = ui->lineEditExposureTime->text().toFloat();
    params[QStringLiteral("Gain")] = ui->lineEditGain->text().toFloat();
    params[QStringLiteral("GammaEnable")] = ui->checkBoxGammaEnable->isChecked();
    params[QStringLiteral("Gamma")] = ui->lineEditGamma->text().toFloat();
    params[QStringLiteral("TriggerDelay")] = ui->lineEditTriggerDelay->text().toFloat();
    params[QStringLiteral("Sharpness")] = ui->spinBoxSharpness->value();
    return params;
}

void ConfigHikGenTLCameraPage::on_lineEditName_returnPressed()
{
    mCamera->setName(ui->lineEditName->text());
    emit parametersChanged(getParameters());
}

void ConfigHikGenTLCameraPage::on_lineEditDescription_returnPressed()
{
    mCamera->setDescription(ui->lineEditDescription->text());
    emit parametersChanged(getParameters());
}

void ConfigHikGenTLCameraPage::on_lineEditExposureTime_returnPressed()
{
    bool ok = false;
    float nValue = ui->lineEditExposureTime->text().toFloat(&ok);
    if (ok && mCamera->writeExposureTime(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_lineEditTriggerDelay_returnPressed()
{
    bool ok = false;
    float nValue = ui->lineEditTriggerDelay->text().toFloat(&ok);
    if (ok && mCamera->writeTriggerDelay(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_lineEditGain_returnPressed()
{
    bool ok = false;
    float nValue = ui->lineEditGain->text().toFloat(&ok);
    if (ok && mCamera->writeGain(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_spinBoxSharpness_valueChanged(int arg1)
{
    int nValue = ui->spinBoxSharpness->value();
    if (mCamera->writeSharpness(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_spinBoxBlackLevel_valueChanged(int arg1)
{
    emit parametersChanged(getParameters());
}

void ConfigHikGenTLCameraPage::on_checkBoxGammaEnable_toggled(bool checked)
{
    ui->lineEditGamma->setEnabled(ui->checkBoxGammaEnable->isChecked());
    if (mCamera->writeGammaEnable(checked))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigHikGenTLCameraPage::on_lineEditGamma_returnPressed()
{
    bool ok = false;
    float nValue = ui->lineEditGamma->text().toFloat(&ok);
    if (ok && mCamera->writeGamma(nValue))
    {
        emit parametersChanged(getParameters());
    }
}
