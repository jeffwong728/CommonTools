#include "addhkgentlcamerapage.h"
#include "ui_addhkgentlcamerapage.h"
#include "hk_gentl_camera_manager.h"

AddHKGenTLCameraPage::AddHKGenTLCameraPage(QWidget *parent, HKGenTLCameraManager* camManager)
    : LaserXAddCameraWidget(parent)
    , ui(new Ui::AddHKGenTLCameraPage)
    , mIFList{ 0, {0} }
    , mCameraManager(camManager)
{
    ui->setupUi(this);

    QDir pluginsDir = QDir(QCoreApplication::applicationDirPath());
    pluginsDir.cd(QStringLiteral("plugins"));
    pluginsDir.cd(QStringLiteral("cameras"));
    QStringList nameFilters;
    nameFilters << QStringLiteral("MvProducerGEV.cti");
    const auto entryList = pluginsDir.entryList(nameFilters, QDir::Files | QDir::NoDotAndDotDot);
    if (!entryList.empty())
    {
        const std::string strGenTLPath = entryList.at(0).toStdString();
        std::memset(&mIFList, 0, sizeof(mIFList));
        int iRet = MV_CC_EnumInterfacesByGenTL(&mIFList, strGenTLPath.c_str());
        if (MV_OK == iRet && mIFList.nInterfaceNum)
        {
            mDevList.resize(mIFList.nInterfaceNum);
            for (unsigned int ii = 0; ii < mIFList.nInterfaceNum; ++ii)
            {
                const MV_GENTL_IF_INFO* pstIFInfo = mIFList.pIFInfo[ii];
                const QString iType = QString::fromLatin1(&pstIFInfo->chTLType[0]);
                const QString iID = QString::fromLatin1(&pstIFInfo->chInterfaceID[0]);
                const QString iName = QString::fromLatin1(&pstIFInfo->chDisplayName[0]);
                const QString iIF = QStringLiteral("Interface[%1]: %2 %3 (%4) (%5)").arg(ii).arg(iType).arg(iID).arg(iName).arg(pstIFInfo->nCtiIndex);
                ui->comboBoxInterface->addItem(iIF);
            }
        }
    }
}

AddHKGenTLCameraPage::~AddHKGenTLCameraPage()
{
    delete ui;
}

void AddHKGenTLCameraPage::on_comboBoxInterface_currentIndexChanged(int index)
{
    ui->comboBoxDevice->clear();
    if (index >= 0 && index < ui->comboBoxInterface->count())
    {
        MV_GENTL_DEV_INFO_LIST &stDevList = mDevList[index];
        std::memset(&stDevList, 0, sizeof(stDevList));

        int iRet = MV_CC_EnumDevicesByGenTL(mIFList.pIFInfo[index], &stDevList);
        if (MV_OK == iRet && stDevList.nDeviceNum)
        {
            for (unsigned int ii = 0; ii < stDevList.nDeviceNum; ++ii)
            {
                const MV_GENTL_DEV_INFO* pstDeviceInfo = stDevList.pDeviceInfo[ii];
                const QString iDevId = QString::fromLatin1(&pstDeviceInfo->chVendorName[0]);
                QVariantMap params;
                params[QStringLiteral("DeviceID")] = QString::fromLatin1(&pstDeviceInfo->chDeviceID[0]);
                if (!mCameraManager->findCamera(params))
                {
                    const QString iVendorName = QString::fromLatin1(&pstDeviceInfo->chVendorName[0]);
                    const QString iUserDefinedName = QString::fromLatin1(&pstDeviceInfo->chUserDefinedName[0]);
                    const QString iModelName = QString::fromLatin1(&pstDeviceInfo->chModelName[0]);
                    const QString iSerialNumber = QString::fromLatin1(&pstDeviceInfo->chSerialNumber[0]);
                    const QString iDev = QStringLiteral("Device[%1]: %2 (%3) %4 %5").arg(ii).arg(iVendorName).arg(iUserDefinedName).arg(iModelName).arg(iSerialNumber);
                    ui->comboBoxDevice->addItem(iDev, ii);
                }
            }
        }
    }
}


void AddHKGenTLCameraPage::on_comboBoxDevice_currentIndexChanged(int index)
{
    if (index >= 0 && index < ui->comboBoxDevice->count())
    {
        const int iDevIndex = ui->comboBoxDevice->itemData(index).toInt();
        const MV_GENTL_DEV_INFO *stDevList = mDevList[ui->comboBoxInterface->currentIndex()].pDeviceInfo[iDevIndex];
        ui->lineEditInterfaceID->setText(QString::fromLatin1(&stDevList->chInterfaceID[0]));
        ui->lineEditDeviceID->setText(QString::fromLatin1(&stDevList->chDeviceID[0]));
        ui->lineEditVendorName->setText(QString::fromLatin1(&stDevList->chVendorName[0]));
        ui->lineEditModelName->setText(QString::fromLatin1(&stDevList->chModelName[0]));
        ui->lineEditTLType->setText(QString::fromLatin1(&stDevList->chTLType[0]));
        ui->lineEditDisplayName->setText(QString::fromLatin1(&stDevList->chDisplayName[0]));
        ui->lineEditUserDefinedName->setText(QString::fromLatin1(&stDevList->chUserDefinedName[0]));
        ui->lineEditSerialNumber->setText(QString::fromLatin1(&stDevList->chSerialNumber[0]));
        ui->lineEditDeviceVersion->setText(QString::fromLatin1(&stDevList->chDeviceVersion[0]));
        emit parametersChanged(getParameters());
    }
}

QVariantMap AddHKGenTLCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("DeviceID")] = ui->lineEditDeviceID->text();
    return params;
}
