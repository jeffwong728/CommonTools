#include "laser_x_folder_camera.h"
#include <QtCore>

FolderCamera::FolderCamera(QObject* parent)
    : LaserXCamera(parent)
{//MT N/A
    mDescription = QStringLiteral("Folder");
    connect(&mLiveTimer, &QTimer::timeout, this, &FolderCamera::onLiveTimeout);
}

FolderCamera::FolderCamera(QObject* parent, const QString& uuid)
    : LaserXCamera(parent, uuid)
{//MT N/A
    mDescription = QStringLiteral("Folder");
    connect(&mLiveTimer, &QTimer::timeout, this, &FolderCamera::onLiveTimeout);
}

FolderCamera::~FolderCamera()
{//MT N/A
}

bool FolderCamera::open(const QVariantMap& params)
{//MT N/A
    QVariant src = params[QStringLiteral("FolderName")];
    if (!mClosed && src == mFolderName)
    {
        return true;
    }

    QString iFolderName = src.toString();
    if (QFileInfo::exists(iFolderName) && QFileInfo(iFolderName).isDir())
    {
        close();
        mFolderName = iFolderName;
        LaserXCamera::setParameters(params);
        QStringList filters;
        filters << QStringLiteral("*.bmp") << QStringLiteral("*.dib");
        filters << QStringLiteral("*.png") << QStringLiteral("*.jp2");
        filters << QStringLiteral("*.tiff") << QStringLiteral("*.tif");
        filters << QStringLiteral("*.jpg") << QStringLiteral("*.jpeg") << QStringLiteral("*.jpe");
        QDirIterator it(iFolderName, filters, QDir::Files, QDirIterator::Subdirectories);
        while (it.hasNext())
        {
            mFileNames.push_back(it.next());
            mCVFileNames.push_back(mFileNames.back().toStdString());
        }

        if (mFileNames.empty())
        {
            emit errorOccurred(OpenError);
            mClosed = true;
            return false;
        }
        else
        {
            mClosed = false;
            emit cameraOpened();
            return true;
        }
    }
    else
    {
        emit errorOccurred(DeviceNotFoundError);
        return false;
    }
}

bool FolderCamera::close()
{//MT
    if (!mClosed)
    {
        QWriteLocker iLocker(&mLocker);
        mClosed = true;
        mFilePos = 0;
        mFolderName.clear();
        mFileNames.clear();
        mCVFileNames.clear();
        emit cameraClosed();
    }
    return true;
}

cv::Mat FolderCamera::snap(int msec)
{//MT
    QWriteLocker iLocker(&mLocker);
    if (mClosed)
    {
        emit errorOccurred(NotOpenError);
    }
    else if (mCVFileNames.empty())
    {
        emit errorOccurred(DeviceNotFoundError);
    }
    else
    {
        if (mFilePos >= static_cast<int>(mCVFileNames.size()))
        {
            mFilePos = 0;
        }
        mCVImage = cv::imread(mCVFileNames[mFilePos++], cv::IMREAD_UNCHANGED);
    }

    return mCVImage;
}

QImage FolderCamera::grab(int msec)
{
    QWriteLocker iLocker(&mLocker);
    if (mClosed)
    {
        emit errorOccurred(NotOpenError);
    }
    else if (mFileNames.empty())
    {
        emit errorOccurred(DeviceNotFoundError);
    }
    else
    {
        if (mFilePos >= static_cast<int>(mFileNames.size()))
        {
            mFilePos = 0;
        }
        QImageReader reader(mFileNames[mFilePos++]);
        reader.setAutoTransform(true);
        mImage = reader.read();
    }

    return mImage;
}

bool FolderCamera::isOpened() const
{//MT N/A
    return !mClosed;
}

bool FolderCamera::isLivable() const
{//MT N/A
    return true;
}

QVariantMap FolderCamera::getParameters() const
{//MT N/A
    QVariantMap params = LaserXCamera::getParameters();
    params[QStringLiteral("FolderName")] = mFolderName;
    return params;
}

int FolderCamera::getFPS() const
{//MT N/A
    return 1;
}

bool FolderCamera::startContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (!mContinuousGrabbing)
    {
        mContinuousGrabbing = true;
        QMetaObject::invokeMethod(this, "startMyTimer");
    }

    return true;
}

bool FolderCamera::stopContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (mContinuousGrabbing)
    {
        mContinuousGrabbing = false;
        QMetaObject::invokeMethod(this, "stopMyTimer");
    }

    return true;
}

bool FolderCamera::toggleContinuousGrab()
{//MT
    if (mContinuousGrabbing)
    {
        return stopContinuousGrab();
    }
    else
    {
        return startContinuousGrab();
    }
}

void FolderCamera::onLiveTimeout()
{//MT
    if (mContinuousGrabbing)
    {
        cv::Mat iImage = snap();
        QVariantMap infos;
        emit imageReady(iImage, infos);
    }
}

void FolderCamera::startMyTimer()
{
    if (!mLiveTimer.isActive())
    {
        const int fps = getFPS();
        mLiveTimer.start(fps ? (1000 / fps) : 50);
    }
}

void FolderCamera::stopMyTimer()
{
    if (mLiveTimer.isActive())
    {
        mLiveTimer.stop();
    }
}
