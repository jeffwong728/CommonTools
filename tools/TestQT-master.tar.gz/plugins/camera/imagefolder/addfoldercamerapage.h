#ifndef ADDFOLDERCAMERAPAGE_H
#define ADDFOLDERCAMERAPAGE_H

#include <QWidget>
#include <laser_x_camera.h>

namespace Ui {
class AddFolderCameraPage;
}

class AddFolderCameraPage : public LaserXAddCameraWidget
{
    Q_OBJECT

public:
    explicit AddFolderCameraPage(QWidget *parent);
    ~AddFolderCameraPage();

public:
    QVariantMap getParameters() const override;

private slots:
    void on_pushButtonLoad_clicked();

private:
    Ui::AddFolderCameraPage *ui;
};

#endif // ADDFOLDERCAMERAPAGE_H
