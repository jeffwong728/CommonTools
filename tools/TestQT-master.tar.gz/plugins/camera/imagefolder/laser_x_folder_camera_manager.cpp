#include "laser_x_folder_camera.h"
#include "laser_x_folder_camera_manager.h"
#include "addfoldercamerapage.h"
#include "opencv2/opencv.hpp"
#include "configfoldercamerapage.h"

FolderCameraManager::FolderCameraManager()
{
}

FolderCameraManager::~FolderCameraManager()
{
}

QString FolderCameraManager::getTypeName()
{
    return QStringLiteral("ImageFolderCamera");
}

QIcon FolderCameraManager::getIcon() const
{
    return QIcon(QStringLiteral(":/icons/folder_image.png"));
}

int FolderCameraManager::getNumCameras()
{
    return static_cast<int>(mCameras.size());
}

QVector<LaserXCamera*> FolderCameraManager::getCameras()
{
    QVector<LaserXCamera*> cams;
    cams.reserve(mCameras.size());
    for (auto& item : mCameras)
    {
        cams.push_back(item);
    }
    return cams;
}

LaserXCamera* FolderCameraManager::createCamera(const QVariantMap& params)
{
    const QString iUUID = params[QStringLiteral("UUID")].toString();
    if (QUuid::fromString(iUUID).isNull())
    {
        FolderCamera* cam = new FolderCamera(this);
        emit cameraCreated(cam);
        return cam;
    }
    else
    {
        FolderCamera* cam = new FolderCamera(this, iUUID);
        emit cameraCreated(cam);
        return cam;
    }
}

bool FolderCameraManager::addCamera(LaserXCamera* camera)
{
    FolderCamera* cam = qobject_cast<FolderCamera*>(camera);
    if (cam)
    {
        FolderCamera* oldCam = mCameras[cam->getUUID()];
        if (oldCam)
        {
            if (oldCam != cam)
            {
                emit cameraAboutToDelete(oldCam);
                oldCam->deleteLater();
                mCameras[cam->getUUID()] = cam;
                emit cameraAdded(cam);
                return true;
            }
        }
        else
        {
            mCameras[cam->getUUID()] = cam;
            emit cameraAdded(cam);
            return true;
        }
    }

    return false;
}

void FolderCameraManager::deleteCamera(LaserXCamera* camera)
{
    if (camera)
    {
        emit cameraAboutToDelete(camera);
        mCameras.remove(camera->getUUID());
        camera->deleteLater();
    }
}

LaserXAddCameraWidget* FolderCameraManager::getAddWidget(QWidget* parent)
{
    return new AddFolderCameraPage(parent);
}

LaserXConfigCameraWidget* FolderCameraManager::getConfigWidget(QWidget* parent, LaserXCamera* camera)
{
    FolderCamera* iCam = qobject_cast<FolderCamera*>(camera);
    if (iCam)
    {
        return new ConfigFolderCameraPage(parent, iCam);
    }
    else
    {
        return nullptr;
    }
}
