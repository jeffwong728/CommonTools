#ifndef LASER_X_FOLDER_CAMERA_MANAGER_H
#define LASER_X_FOLDER_CAMERA_MANAGER_H

#include "laser_x_folder_camera_global.h"
#include <laser_x_camera.h>
#include <QObject>
#include <memory>
class FolderCamera;

class FolderCameraManager : public LaserXCameraManager {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LaserXCameraManagerInterfaceIID)
    Q_INTERFACES(LaserXCameraManager)
public:
    FolderCameraManager();
    ~FolderCameraManager();

public:
    QString getTypeName() override;
    QIcon getIcon() const override;
    int getNumCameras() override;
    QVector<LaserXCamera*> getCameras() override;
    LaserXCamera* createCamera(const QVariantMap& params) override;
    bool addCamera(LaserXCamera* camera) override;
    void deleteCamera(LaserXCamera* camera) override;
    LaserXAddCameraWidget* getAddWidget(QWidget* parent) override;
    LaserXConfigCameraWidget* getConfigWidget(QWidget* parent, LaserXCamera* camera) override;

private:
    QMap<QString, FolderCamera*> mCameras;
};

#endif // LASER_X_FOLDER_CAMERA_MANAGER_H
