#include "configfoldercamerapage.h"
#include "ui_configfoldercamerapage.h"
#include "laser_x_folder_camera.h"

ConfigFolderCameraPage::ConfigFolderCameraPage(QWidget *parent, FolderCamera* camera) :
    LaserXConfigCameraWidget(parent),
    ui(new Ui::ConfigFolderCameraPage), mCamera(camera)
{
    ui->setupUi(this);
}

ConfigFolderCameraPage::~ConfigFolderCameraPage()
{
    delete ui;
}

void ConfigFolderCameraPage::initialize(const QVariantMap& params)
{
    ui->lineEditName->setText(params[QStringLiteral("Name")].toString());
    ui->lineEditDescription->setText(params[QStringLiteral("Description")].toString());
    ui->lineEditPath->setText(params[QStringLiteral("FolderName")].toString());
}

QVariantMap ConfigFolderCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = ui->lineEditName->text();
    params[QStringLiteral("Description")] = ui->lineEditDescription->text();
    params[QStringLiteral("FolderName")] = ui->lineEditPath->text();
    return params;
}

void ConfigFolderCameraPage::on_lineEditName_returnPressed()
{
    mCamera->setName(ui->lineEditName->text());
    emit parametersChanged(getParameters());
}

void ConfigFolderCameraPage::on_lineEditDescription_returnPressed()
{
    mCamera->setDescription(ui->lineEditDescription->text());
    emit parametersChanged(getParameters());
}
