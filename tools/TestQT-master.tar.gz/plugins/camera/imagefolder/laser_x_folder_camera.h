#ifndef LASER_X_FOLDER_CAMERA_H
#define LASER_X_FOLDER_CAMERA_H

#include <QTimer>
#include <opencv2/opencv.hpp>
#include <laser_x_camera.h>

class FolderCamera : public LaserXCamera {
    Q_OBJECT
public:
    FolderCamera(QObject* parent);
    FolderCamera(QObject* parent, const QString& uuid);
    ~FolderCamera();

public:
    bool open(const QVariantMap& params) override;
    bool close() override;
    cv::Mat snap(int msec = 0) override;
    QImage grab(int msec = 0) override;
    bool isOpened() const override;
    bool isLivable() const override;
    QVariantMap getParameters() const override;
    int getFPS() const override;
    bool startContinuousGrab() override;
    bool stopContinuousGrab() override;
    bool toggleContinuousGrab() override;

private:
    void onLiveTimeout();

private slots:
    void startMyTimer();
    void stopMyTimer();

private:
    QString mFolderName;
    std::vector<QString> mFileNames;
    std::vector<cv::String> mCVFileNames;
    cv::Mat mCVImage;
    QImage mImage;
    QTimer mLiveTimer;
    int mFilePos = 0;
    bool mClosed = true;
};

#endif // LASER_X_FOLDER_CAMERA_H
