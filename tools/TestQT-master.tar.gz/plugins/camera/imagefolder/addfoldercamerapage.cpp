#include "addfoldercamerapage.h"
#include "ui_addfoldercamerapage.h"

AddFolderCameraPage::AddFolderCameraPage(QWidget *parent) :
    LaserXAddCameraWidget(parent),
    ui(new Ui::AddFolderCameraPage)
{
    ui->setupUi(this);
}

AddFolderCameraPage::~AddFolderCameraPage()
{
    delete ui;
}

void AddFolderCameraPage::on_pushButtonLoad_clicked()
{
    QString folderPath = QFileDialog::getExistingDirectory(this, tr("Open Image Folder"));
    if (!folderPath.isEmpty() && folderPath != ui->lineEditFolderPath->text())
    {
        ui->lineEditFolderPath->setText(folderPath);
        emit parametersChanged(getParameters());
    }
}

QVariantMap AddFolderCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("FolderName")] = ui->lineEditFolderPath->text();
    return params;
}
