#ifndef CONFIGFOLDERCAMERAPAGE_H
#define CONFIGFOLDERCAMERAPAGE_H

#include <QToolBox>
#include <laser_x_camera.h>
class FolderCamera;

namespace Ui {
class ConfigFolderCameraPage;
}

class ConfigFolderCameraPage : public LaserXConfigCameraWidget
{
    Q_OBJECT

public:
    explicit ConfigFolderCameraPage(QWidget *parent, FolderCamera* camera);
    ~ConfigFolderCameraPage();

public:
    void initialize(const QVariantMap& params) override;
    QVariantMap getParameters() const override;

private slots:
    void on_lineEditName_returnPressed();
    void on_lineEditDescription_returnPressed();

private:
    Ui::ConfigFolderCameraPage *ui;
    FolderCamera* mCamera = nullptr;
};

#endif // CONFIGFOLDERCAMERAPAGE_H
