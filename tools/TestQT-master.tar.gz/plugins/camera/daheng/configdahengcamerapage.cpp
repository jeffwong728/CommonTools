#include "configdahengcamerapage.h"
#include "ui_configdahengcamerapage.h"
#include "daheng_camera.h"

ConfigDahengCameraPage::ConfigDahengCameraPage(QWidget *parent, DahengCamera* camera) :
    LaserXConfigCameraWidget(parent),
    ui(new Ui::ConfigDahengCameraPage), mCamera(camera)
{
    ui->setupUi(this);
}

ConfigDahengCameraPage::~ConfigDahengCameraPage()
{
    delete ui;
}

void ConfigDahengCameraPage::initialize(const QVariantMap& params)
{
    ui->spinBoxExposureTime->setMinimum(qRound(mCamera->readExposureTimeMin()));
    ui->spinBoxExposureTime->setMaximum(qRound(mCamera->readExposureTimeMax()));
    ui->spinBoxExposureTime->setSingleStep(qRound(mCamera->readExposureTimeInc()));
    ui->spinBoxExposureTime->setToolTip(tr("Range: %1..%2").arg(qRound(mCamera->readExposureTimeMin())).arg(qRound(mCamera->readExposureTimeMax())));

    ui->doubleSpinBoxGain->setMinimum(mCamera->readGainMin());
    ui->doubleSpinBoxGain->setMaximum(mCamera->readGainMax());
    ui->doubleSpinBoxGain->setSingleStep(mCamera->readGainInc());
    ui->doubleSpinBoxGain->setToolTip(tr("Range: %1..%2").arg(mCamera->readGainMin()).arg(mCamera->readGainMax()));

    ui->doubleSpinBoxGamma->setMinimum(mCamera->readGammaMin());
    ui->doubleSpinBoxGamma->setMaximum(mCamera->readGammaMax());
    ui->doubleSpinBoxGamma->setSingleStep(mCamera->readGammaInc());
    ui->doubleSpinBoxGamma->setToolTip(tr("Range: %1..%2").arg(mCamera->readGammaMin()).arg(mCamera->readGammaMax()));

    ui->spinBoxTriggerDelay->setMinimum(qRound(mCamera->readTriggerDelayMin()));
    ui->spinBoxTriggerDelay->setMaximum(qRound(mCamera->readTriggerDelayMax()));
    ui->spinBoxTriggerDelay->setSingleStep(qRound(mCamera->readTriggerDelayInc()));
    ui->spinBoxTriggerDelay->setToolTip(tr("Range: %1..%2").arg(qRound(mCamera->readTriggerDelayMin())).arg(qRound(mCamera->readTriggerDelayMax())));

    ui->spinBoxSharpness->setMinimum(qRound(mCamera->readSharpnessMin()));
    ui->spinBoxSharpness->setMaximum(qRound(mCamera->readSharpnessMax()));
    ui->spinBoxSharpness->setSingleStep(qRound(mCamera->readSharpnessInc()));
    ui->spinBoxSharpness->setToolTip(tr("Range: %1..%2").arg(qRound(mCamera->readSharpnessMin())).arg(qRound(mCamera->readSharpnessMax())));

    ui->lineEditName->setText(params[QStringLiteral("Name")].toString());
    ui->lineEditDescription->setText(params[QStringLiteral("Description")].toString());
    ui->spinBoxExposureTime->setValue(qRound(params[QStringLiteral("ExposureTime")].toReal()));
    ui->doubleSpinBoxGain->setValue(params[QStringLiteral("Gain")].toReal());
    ui->checkBoxGammaEnable->setChecked(params[QStringLiteral("GammaEnable")].toBool());
    ui->doubleSpinBoxGamma->setValue(params[QStringLiteral("Gamma")].toReal());
    ui->spinBoxTriggerDelay->setValue(qRound(params[QStringLiteral("TriggerDelay")].toReal()));
    ui->spinBoxSharpness->setValue(qRound(params[QStringLiteral("Sharpness")].toReal()));
    ui->doubleSpinBoxGamma->setEnabled(ui->checkBoxGammaEnable->isChecked());

    mInitialized = true;
}

QVariantMap ConfigDahengCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = ui->lineEditName->text();
    params[QStringLiteral("Description")] = ui->lineEditDescription->text();
    params[QStringLiteral("ExposureTime")] = ui->spinBoxExposureTime->value();
    params[QStringLiteral("Gain")] = ui->doubleSpinBoxGain->value();
    params[QStringLiteral("GammaEnable")] = ui->checkBoxGammaEnable->isChecked();
    params[QStringLiteral("Gamma")] = ui->doubleSpinBoxGamma->value();
    params[QStringLiteral("TriggerDelay")] = ui->spinBoxTriggerDelay->value();
    params[QStringLiteral("Sharpness")] = ui->spinBoxSharpness->value();
    return params;
}

void ConfigDahengCameraPage::on_lineEditName_returnPressed()
{
    mCamera->setName(ui->lineEditName->text());
    emit parametersChanged(getParameters());
}

void ConfigDahengCameraPage::on_lineEditDescription_returnPressed()
{
    mCamera->setDescription(ui->lineEditDescription->text());
    emit parametersChanged(getParameters());
}

void ConfigDahengCameraPage::on_spinBoxExposureTime_valueChanged(int nValue)
{
    if (mInitialized && mCamera->writeExposureTime(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigDahengCameraPage::on_spinBoxTriggerDelay_valueChanged(int nValue)
{
    if (mInitialized && mCamera->writeTriggerDelay(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigDahengCameraPage::on_doubleSpinBoxGain_valueChanged(double nValue)
{
    if (mInitialized && mCamera->writeGain(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigDahengCameraPage::on_spinBoxSharpness_valueChanged(int nValue)
{
    if (mInitialized && mCamera->writeSharpness(nValue))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigDahengCameraPage::on_checkBoxGammaEnable_toggled(bool checked)
{
    ui->doubleSpinBoxGamma->setEnabled(checked);
    if (mInitialized && mCamera->writeGammaEnable(checked))
    {
        emit parametersChanged(getParameters());
    }
}

void ConfigDahengCameraPage::on_doubleSpinBoxGamma_valueChanged(double nValue)
{
    if (mInitialized && ui->checkBoxGammaEnable->isChecked() && mCamera->writeGamma(nValue))
    {
        emit parametersChanged(getParameters());
    }
}
