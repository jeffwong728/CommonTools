#include "daheng_camera.h"
#include "daheng_camera_manager.h"
#include "adddahengcamerapage.h"
#include "configdahengcamerapage.h"
#include <opencv2/opencv.hpp>
#include <QDebug>

DahengCameraManager::DahengCameraManager()
    : mPending(0)
{
}

DahengCameraManager::~DahengCameraManager()
{
}

bool DahengCameraManager::initialize()
{
    try
    {
        IGXFactory::GetInstance().Init();
        return true;
    }
    catch (CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Initialize Daheng Camera Error: %1(%2)").arg(QString::fromLocal8Bit(e.what())).arg(e.GetErrorCode());
        return false;
    }
}

bool DahengCameraManager::terminate()
{
    try
    {
        IGXFactory::GetInstance().Uninit();
        return true;
    }
    catch (CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Terminate Daheng Camera Error: %1(%2)").arg(QString::fromLocal8Bit(e.what())).arg(e.GetErrorCode());
        return false;
    }
}

QString DahengCameraManager::getTypeName()
{
    return QStringLiteral("DahengGalaxyCamera");
}

QIcon DahengCameraManager::getIcon() const
{
    return QIcon(QStringLiteral(":/icons/video.png"));
}

int DahengCameraManager::getNumCameras()
{
    return static_cast<int>(mCameras.size());
}

QVector<LaserXCamera*> DahengCameraManager::getCameras()
{
    QVector<LaserXCamera*> cams;
    cams.reserve(mCameras.size());
    for (auto& item : mCameras)
    {
        cams.push_back(item);
    }
    return cams;
}

LaserXCamera* DahengCameraManager::createCamera(const QVariantMap& params)
{
    const QString iUUID = params[QStringLiteral("UUID")].toString();
    if (QUuid::fromString(iUUID).isNull())
    {
        DahengCamera* cam = new DahengCamera(this);
        emit cameraCreated(cam);
        return cam;
    }
    else
    {
        DahengCamera* cam = new DahengCamera(this, iUUID);
        emit cameraCreated(cam);
        return cam;
    }
}

LaserXCamera* DahengCameraManager::findCamera(const QVariantMap& params) const
{
    const QString iDevId = params[QStringLiteral("DeviceID")].toString();
    for (const auto &camItem : mCameras)
    {
        if (camItem->deviceID() == iDevId)
        {
            return camItem;
        }
    }

    return nullptr;
}

bool DahengCameraManager::addCamera(LaserXCamera* camera)
{
    DahengCamera* cam = qobject_cast<DahengCamera*>(camera);
    if (cam)
    {
        DahengCamera* oldCam = mCameras[cam->getUUID()];
        if (oldCam)
        {
            if (oldCam != cam)
            {
                emit cameraAboutToDelete(oldCam);
                oldCam->deleteLater();
                mCameras[cam->getUUID()] = cam;
                emit cameraAdded(cam);
                return true;
            }
        }
        else
        {
            mCameras[cam->getUUID()] = cam;
            emit cameraAdded(cam);
            return true;
        }
    }

    return false;
}

void DahengCameraManager::deleteCamera(LaserXCamera* camera)
{
    if (camera)
    {
        emit cameraAboutToDelete(camera);
        mCameras.remove(camera->getUUID());
        camera->deleteLater();
    }
}

LaserXAddCameraWidget* DahengCameraManager::getAddWidget(QWidget* parent)
{
    return new AddDahengCameraPage(parent, this);
}

LaserXConfigCameraWidget* DahengCameraManager::getConfigWidget(QWidget* parent, LaserXCamera* camera)
{
    DahengCamera* iCam = qobject_cast<DahengCamera*>(camera);
    if (iCam)
    {
        return new ConfigDahengCameraPage(parent, iCam);
    }
    else
    {
        return nullptr;
    }
}

int DahengCameraManager::getLivingDelay() const
{
    return mNumLiving < 0 ? 0 : mNumLiving * 50;
}
