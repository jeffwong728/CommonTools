#ifndef CONFIG_DAHENG_CAMERAPAGE_H
#define CONFIG_DAHENG_CAMERAPAGE_H

#include <QToolBox>
#include <laser_x_camera.h>
class DahengCamera;

namespace Ui {
class ConfigDahengCameraPage;
}

class ConfigDahengCameraPage : public LaserXConfigCameraWidget
{
    Q_OBJECT

public:
    explicit ConfigDahengCameraPage(QWidget *parent, DahengCamera* camera);
    ~ConfigDahengCameraPage();

public:
    void initialize(const QVariantMap& params) override;
    QVariantMap getParameters() const override;

private slots:
    void on_lineEditName_returnPressed();
    void on_lineEditDescription_returnPressed();
    void on_spinBoxExposureTime_valueChanged(int nValue);
    void on_spinBoxTriggerDelay_valueChanged(int nValue);
    void on_doubleSpinBoxGain_valueChanged(double nValue);
    void on_spinBoxSharpness_valueChanged(int nValue);
    void on_checkBoxGammaEnable_toggled(bool checked);
    void on_doubleSpinBoxGamma_valueChanged(double nValue);

private:
    Ui::ConfigDahengCameraPage*ui;
    DahengCamera* mCamera = nullptr;
    bool mInitialized = false;
};

#endif // CONFIG_DAHENG_CAMERAPAGE_H
