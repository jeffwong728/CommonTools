#include "daheng_camera.h"
#include "daheng_camera_manager.h"
#include <QtCore>
#include <QtConcurrent>

inline bool DahengEQValue(const qreal v0, const qreal v1)
{
    return std::abs(v0-v1) < 0.001;
}

DahengCamera::DahengCamera(QObject* parent)
    : DahengCamera(parent, QUuid::createUuid().toString())
{//MT N/A
    mDescription = QStringLiteral("DahengCamera");
    mManager = qobject_cast<DahengCameraManager*>(parent);
    if (!mManager)
    {
        throw std::invalid_argument("The parent of DahengCamera must be DahengCameraManager");
    }
}

DahengCamera::DahengCamera(QObject* parent, const QString& uuid)
    : LaserXCamera(parent, uuid)
{//MT N/A
    mDescription = QStringLiteral("DahengCamera");
    mManager = qobject_cast<DahengCameraManager*>(parent);
    if (!mManager)
    {
        throw std::invalid_argument("The parent of DahengCamera must be DahengCameraManager");
    }
}

DahengCamera::~DahengCamera()
{//MT N/A
    close();
}

bool DahengCamera::open(const QVariantMap& params)
{//MT N/A
    try
    {
        LaserXCamera::setParameters(params);
        QString iDeviceID = params[QStringLiteral("DeviceID")].toString();
        if (!mCamera.IsNull() && iDeviceID == mDeviceID)
        {
            return true;
        }

        close();

        GxIAPICPP::gxdeviceinfo_vector iDevices;
        IGXFactory::GetInstance().UpdateDeviceList(1000, iDevices);
        qDebug() << QStringLiteral("Daheng camera manager found %1 devices").arg(iDevices.size());

        for (const CGXDeviceInfo& iDevInfo : iDevices)
        {
            QString thisDevId = QString::fromLatin1(iDevInfo.GetSN().c_str());
            if (thisDevId == iDeviceID)
            {
                mCamera = IGXFactory::GetInstance().OpenDeviceBySN(iDevInfo.GetSN(), GX_ACCESS_EXCLUSIVE);
                if (mCamera.IsNull())
                {
                    emit errorOccurred(OpenError);
                    return false;
                }

                mFeatureControl = mCamera->GetRemoteFeatureControl();
                uint32_t nStreamCount = mCamera->GetStreamCount();
                if (nStreamCount < 1)
                {
                    mCamera->Close();
                    emit errorOccurred(OpenError);
                    return false;
                }

                mStream = mCamera->OpenStream(0);
                mStreamFeatureControl = mCamera->GetFeatureControl();
                if (mCamera.IsNull() || mStreamFeatureControl.IsNull())
                {
                    mCamera->Close();
                    emit errorOccurred(OpenError);
                    return false;
                }

                if (initCamera())
                {
                    mStream->StartGrab();
                    mFeatureControl->GetCommandFeature("AcquisitionStart")->Execute();
                    mDeviceID = iDeviceID;
                    emit cameraOpened();
                    return true;
                }
                else
                {
                    close();
                    emit errorOccurred(WriteParameterError);
                    return false;
                }
            }
        }

        return false;
    }
    catch (const CGalaxyException& e)
    {
        close();
        emit errorOccurredEx(OpenError, QString::fromLatin1(e.what()));
        qDebug() << QStringLiteral("Daheng camera manager open device exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool DahengCamera::close()
{//MT
    try
    {
        QWriteLocker iLocker(&mLocker);
        if (!mFeatureControl.IsNull())
        {
            mFeatureControl->GetCommandFeature("AcquisitionStop")->Execute();
        }

        if (!mStream.IsNull())
        {
            mStream->StopGrab();
            mStream->Close();
        }

        if (!mCamera.IsNull())
        {
            mCamera->Close();
        }

        emit cameraClosed();
        return true;
    }
    catch (const CGalaxyException& e)
    {
        emit errorOccurredEx(UnknownError, QString::fromLatin1(e.what()));
        qDebug() << QStringLiteral("Daheng camera manager close device exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

cv::Mat DahengCamera::snap(int msec)
{//MT
    QWriteLocker iLocker(&mLocker);
    if (trigger(true))
    {
        return grabImage(true, msec);
    }
    else
    {
        return mImage;
    }
}

QImage DahengCamera::grab(int msec)
{//MT
    QWriteLocker iLocker(&mLocker);
    if (trigger(true))
    {
        return snapImage(true, msec);
    }
    else
    {
        return QImage();
    }
}

void DahengCamera::imageConsumed()
{//MT
    mManager->mPending -= 1;
    if (mManager->mPending < 0)
    {
        mManager->mPending = 0;
    }
}

bool DahengCamera::startContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (!mContinuousGrabbing)
    {
        mContinuousGrabbing = true;
        mManager->mNumLiving += 1;
        mLiveFuture = QtConcurrent::run(DahengCamera::liveMe, this);
    }

    return true;
}

bool DahengCamera::stopContinuousGrab()
{//MT
    QWriteLocker iLocker(&mLocker);
    if (mContinuousGrabbing)
    {
        mContinuousGrabbing = false;
        mLiveFuture.waitForFinished();
        mManager->mNumLiving -= 1;
        mManager->mPending = 0;
    }
    return true;
}

bool DahengCamera::toggleContinuousGrab()
{//MT
    if (mContinuousGrabbing)
    {
        return stopContinuousGrab();
    }
    else
    {
        return startContinuousGrab();
    }
}

bool DahengCamera::isOpened() const
{//MT
    try
    {
        QReadLocker iLocker(const_cast<QReadWriteLock*>(&mLocker));
        return !mCamera.IsNull() && !mStream.IsNull() && !mFeatureControl.IsNull() && !mStreamFeatureControl.IsNull();
    }
    catch (const CGalaxyException& e)
    {
        Q_UNUSED(e);
        return false;
    }
}

bool DahengCamera::isLivable() const
{//MT N/A
    return true;
}

bool DahengCamera::setParameters(const QVariantMap& params)
{//MT
    LaserXCamera::setParameters(params);
    DahengCamera::setGrabParams(params);
    return true;
}

QVariantMap DahengCamera::getParameters() const
{//MT N/A
    QVariantMap params = LaserXCamera::getParameters();
    params[QStringLiteral("DeviceID")] = mDeviceID;
    if (isOpened())
    {
        params[QStringLiteral("TriggerDelay")] = readTriggerDelay();
        params[QStringLiteral("ExposureTime")] = readExposureTime();
        params[QStringLiteral("Gain")] = readGain();
        params[QStringLiteral("GammaEnable")] = readGammaEnable();
        params[QStringLiteral("Gamma")] = readGamma();
        params[QStringLiteral("Sharpness")] = readSharpness();
    }
    return params;
}

void DahengCamera::setGrabParams(const QVariantMap& params)
{//MT
    QWriteLocker iLocker(&mLocker);
    if (params.contains(QStringLiteral("Gain")))
    {
        qreal iGain = params.value(QStringLiteral("Gain")).toReal();
        writeGain(iGain);
    }

    if (params.contains(QStringLiteral("ExposureTime")))
    {
        qreal iExposureTime = params.value(QStringLiteral("ExposureTime")).toReal();
        writeExposureTime(iExposureTime);
    }
}

QVariantMap DahengCamera::getGrabParams() const
{//MT N/A
    QVariantMap params;
    if (isOpened())
    {
        params[QStringLiteral("ExposureTime")] = readExposureTime();
        params[QStringLiteral("Gain")] = readGain();
    }
    return params;
}

int DahengCamera::getFPS() const
{//MT N/A
    return 10;
}

void DahengCamera::startGrab()
{//MT
    try
    {
        QWriteLocker iLocker(&mLocker);
        if (!mStream.IsNull())
        {
            mStream->StartGrab();
        }

        if (!mFeatureControl.IsNull())
        {
            mFeatureControl->GetCommandFeature("AcquisitionStart")->Execute();
        }
    }
    catch (const CGalaxyException& e)
    {
        emit errorOccurredEx(UnknownError, QString::fromLatin1(e.what()));
        qDebug() << QStringLiteral("Daheng camera start grabbing exception: %1").arg(QString::fromLatin1(e.what()));
    }
}

void DahengCamera::stopGrab()
{//MT
    try
    {
        if (!mFeatureControl.IsNull())
        {
            QWriteLocker iLocker(&mLocker);
            mFeatureControl->GetCommandFeature("AcquisitionStop")->Execute();
        }
    }
    catch (const CGalaxyException& e)
    {
        emit errorOccurredEx(UnknownError, QString::fromLatin1(e.what()));
        qDebug() << QStringLiteral("Daheng camera stop grabbing exception: %1").arg(QString::fromLatin1(e.what()));
    }
}

bool DahengCamera::trigger(bool emitError)
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            if (emitError) emit errorOccurred(NotOpenError);
            return false;
        }

        mFeatureControl->GetCommandFeature("TriggerSoftware")->Execute();
        return true;
    }
    catch (const CGalaxyException& e)
    {
        if (emitError)
        {
            emit errorOccurredEx(UnknownError, QString::fromLatin1(e.what()));
            qDebug() << QStringLiteral("Daheng camera software trigger exception: %1").arg(QString::fromLatin1(e.what()));
        }
        return false;
    }
}

cv::Mat DahengCamera::grabImage(bool emitError, int msec)
{//MT N/A
    try
    {
        if (mStream.IsNull())
        {
            if (emitError) emit errorOccurred(NotOpenError);
        }
        else
        {
            CImageDataPointer spImage = mStream->GetImage(msec ? msec : 1000);
            if (!spImage.IsNull() && GX_PIXEL_FORMAT_MONO8 == spImage->GetPixelFormat())
            {
                if (!mImage.empty() &&
                    mImage.rows == spImage->GetHeight() &&
                    mImage.cols == spImage->GetWidth() &&
                    CV_8UC1 == mImage.type())
                {
                    std::memcpy(mImage.data, spImage->GetBuffer(), mImage.total());
                }
                else
                {
                    mImage = cv::Mat(spImage->GetHeight(), spImage->GetWidth(), CV_8UC1, spImage->GetBuffer()).clone();
                }
            }
            else
            {
                if (emitError) emit errorOccurred(ReadError);
            }
        }
    }
    catch (const CGalaxyException& e)
    {
        if (emitError)
        {
            emit errorOccurredEx(ReadError, QString::fromLatin1(e.what()));
            qDebug() << QStringLiteral("Daheng camera grab image exception: %1").arg(QString::fromLatin1(e.what()));
        }
    }

    return mImage;
}

QImage DahengCamera::snapImage(bool emitError, int msec)
{//MT N/A
    try
    {
        if (mStream.IsNull())
        {
            if (emitError) emit errorOccurred(NotOpenError);
        }
        else
        {
            CImageDataPointer spImage = mStream->GetImage(msec ? msec : 1000);
            if (!spImage.IsNull() && GX_PIXEL_FORMAT_MONO8 == spImage->GetPixelFormat())
            {
                QImage iImage(static_cast<uchar*>(spImage->GetBuffer()), spImage->GetWidth(), spImage->GetHeight(), QImage::Format_Grayscale8);
                return iImage.copy();
            }
            else
            {
                if (emitError) emit errorOccurred(ReadError);
            }
        }
    }
    catch (const CGalaxyException& e)
    {
        if (emitError)
        {
            emit errorOccurredEx(ReadError, QString::fromLatin1(e.what()));
            qDebug() << QStringLiteral("Daheng camera grab image exception: %1").arg(QString::fromLatin1(e.what()));
        }
    }

    return QImage();
}

qreal DahengCamera::readExposureTime() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("ExposureTime")->GetValue();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read ExposureTime exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readExposureTimeMin() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("ExposureTime")->GetMin();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read ExposureTimeMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readExposureTimeMax() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("ExposureTime")->GetMax();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read ExposureTimeMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readExposureTimeInc() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            const qreal iVal = mFeatureControl->GetFloatFeature("ExposureTime")->GetInc();
            return iVal > 0 ? iVal : 100;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read ExposureTimeInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 1;
    }
}

qreal DahengCamera::readGain() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Gain")->GetValue();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read Gain exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readGainMin() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Gain")->GetMin();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read GainMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readGainMax() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Gain")->GetMax();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read GainMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readGainInc() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0.;
        }
        else
        {
            const qreal iVal = mFeatureControl->GetFloatFeature("Gain")->GetInc();
            return iVal > 0 ? iVal : 1.;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read GainInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 0.;
    }
}

bool DahengCamera::readGammaEnable() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return false;
        }
        else
        {
            return mFeatureControl->GetBoolFeature("GammaEnable")->GetValue();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read GammaEnable exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

qreal DahengCamera::readGamma() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull() || !mFeatureControl->IsImplemented("Gamma"))
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Gamma")->GetValue();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read Gamma exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readGammaMin() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull() || !mFeatureControl->IsImplemented("Gamma"))
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Gamma")->GetMin();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read GammaMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readGammaMax() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull() || !mFeatureControl->IsImplemented("Gamma"))
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Gamma")->GetMax();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read GammaMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readGammaInc() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull() || !mFeatureControl->IsImplemented("Gamma"))
        {
            return 0.1;
        }
        else
        {
            const qreal iVal = mFeatureControl->GetFloatFeature("Gamma")->GetInc();
            return iVal > 0 ? iVal : 0.1;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read GammaInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 0.1;
    }
}

qreal DahengCamera::readTriggerDelay() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("TriggerDelay")->GetValue();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read TriggerDelay exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readTriggerDelayMin() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("TriggerDelay")->GetMin();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read TriggerDelayMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readTriggerDelayMax() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("TriggerDelay")->GetMax();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read TriggerDelayMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readTriggerDelayInc() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            const qreal iVal = mFeatureControl->GetFloatFeature("TriggerDelay")->GetInc();
            return iVal > 0 ? iVal : 100;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read TriggerDelayInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readSharpness() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Sharpness")->GetValue();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read Sharpness exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readSharpnessMin() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Sharpness")->GetMin();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read SharpnessMin exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readSharpnessMax() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 0;
        }
        else
        {
            return mFeatureControl->GetFloatFeature("Sharpness")->GetMax();
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read SharpnessMax exception: %1").arg(QString::fromLatin1(e.what()));
        return 0;
    }
}

qreal DahengCamera::readSharpnessInc() const
{//MT N/A
    try
    {
        if (mFeatureControl.IsNull())
        {
            return 1;
        }
        else
        {
            const qreal iVal = mFeatureControl->GetFloatFeature("Sharpness")->GetInc();
            return iVal > 0 ? iVal : 1;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera read SharpnessInc exception: %1").arg(QString::fromLatin1(e.what()));
        return 1;
    }
}

bool DahengCamera::readSharpnessEnable() const
{//MT N/A
    return false;
}

bool DahengCamera::writeExposureTime(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readExposureTime();
        if (DahengEQValue(oValue, nValue))
        {
            return true;
        }

        if (mFeatureControl.IsNull())
        {
            return false;
        }
        else
        {
            mFeatureControl->GetFloatFeature("ExposureTime")->SetValue(nValue);
            emit parameterChanged(QStringLiteral("ExposureTime"), QVariant(oValue), QVariant(nValue));
            return true;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera write ExposureTime exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool DahengCamera::writeGain(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readGain();
        if (DahengEQValue(oValue, nValue))
        {
            return true;
        }

        if (mFeatureControl.IsNull())
        {
            return false;
        }
        else
        {
            mFeatureControl->GetFloatFeature("Gain")->SetValue(nValue);
            emit parameterChanged(QStringLiteral("Gain"), QVariant(oValue), QVariant(nValue));
            return true;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera write Gain exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool DahengCamera::writeGammaEnable(const bool nValue)
{//MT N/A
    try
    {
        const bool oValue = readGammaEnable();
        if (oValue == nValue)
        {
            return true;
        }

        if (mFeatureControl.IsNull())
        {
            return false;
        }
        else
        {
            mFeatureControl->GetBoolFeature("GammaEnable")->SetValue(nValue);
            emit parameterChanged(QStringLiteral("GammaEnable"), QVariant(oValue), QVariant(nValue));
            return true;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera write GammaEnable exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool DahengCamera::writeGamma(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readGamma();
        if (DahengEQValue(oValue, nValue))
        {
            return true;
        }

        if (mFeatureControl.IsNull())
        {
            return false;
        }
        else
        {
            mFeatureControl->GetFloatFeature("Gamma")->SetValue(nValue);
            emit parameterChanged(QStringLiteral("Gamma"), QVariant(oValue), QVariant(nValue));
            return true;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera write Gamma exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool DahengCamera::writeTriggerDelay(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readTriggerDelay();
        if (DahengEQValue(oValue, nValue))
        {
            return true;
        }

        if (mFeatureControl.IsNull())
        {
            return false;
        }
        else
        {
            mFeatureControl->GetFloatFeature("TriggerDelay")->SetValue(nValue);
            emit parameterChanged(QStringLiteral("TriggerDelay"), QVariant(oValue), QVariant(nValue));
            return true;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera write TriggerDelay exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool DahengCamera::writeSharpness(const qreal nValue)
{//MT N/A
    try
    {
        const qreal oValue = readSharpness();
        if (DahengEQValue(oValue, nValue))
        {
            return true;
        }

        if (mFeatureControl.IsNull())
        {
            return false;
        }
        else
        {
            mFeatureControl->GetFloatFeature("Sharpness")->SetValue(nValue);
            emit parameterChanged(QStringLiteral("Sharpness"), QVariant(oValue), QVariant(nValue));
            return true;
        }
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera write Sharpness exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

bool DahengCamera::writeSharpnessEnable(const bool nValue)
{//MT N/A
    return false;
}

bool DahengCamera::initCamera()
{
    try
    {
        if (!mCamera.IsNull() && !mFeatureControl.IsNull() && !mStream.IsNull())
        {
            GX_DEVICE_CLASS_LIST objDeviceClass = mCamera->GetDeviceInfo().GetDeviceClass();
            if (GX_DEVICE_CLASS_GEV == objDeviceClass)
            {
                if (mFeatureControl->IsImplemented("GevSCPSPacketSize"))
                {
                    int nPacketSize = mStream->GetOptimalPacketSize();
                    mFeatureControl->GetIntFeature("GevSCPSPacketSize")->SetValue(nPacketSize);
                }
            }
        }

        if (!mFeatureControl.IsNull())
        {
            mFeatureControl->GetEnumFeature("AcquisitionMode")->SetValue("Continuous");
            mFeatureControl->GetEnumFeature("TriggerMode")->SetValue("On");
            mFeatureControl->GetEnumFeature("TriggerSource")->SetValue("Software");
            mFeatureControl->GetEnumFeature("GainAuto")->SetValue("Off");
            mFeatureControl->GetEnumFeature("ExposureAuto")->SetValue("Off");
            mFeatureControl->GetEnumFeature("PixelFormat")->SetValue("Mono8");
        }

        if (!mStreamFeatureControl.IsNull() && mStreamFeatureControl->IsImplemented("StreamBufferHandlingMode"))
        {
            mStreamFeatureControl->GetEnumFeature("StreamBufferHandlingMode")->SetValue("OldestFirst");
        }

        if (!mCamera.IsNull())
        {
            mDescription = QString::fromLatin1(mCamera->GetDeviceInfo().GetDisplayName().c_str());
        }

        return true;
    }
    catch (const CGalaxyException& e)
    {
        qDebug() << QStringLiteral("Daheng camera initialization exception: %1").arg(QString::fromLatin1(e.what()));
        return false;
    }
}

void DahengCamera::liveMe(DahengCamera* cam)
{//MT
    while (cam->mContinuousGrabbing)
    {
        QThread::msleep(cam->mManager->getLivingDelay());
        if (cam->mManager->mPending > 0)
        {
            continue;
        }

        if (!cam->mLocker.tryLockForWrite())
        {
            continue;
        }

        if (cam->trigger(false))
        {
            cv::Mat iImage = cam->grabImage(false);
            QVariantMap infos;
            emit cam->imageReady(iImage, infos);
            cam->mManager->mPending += 1;
        }

        cam->mLocker.unlock();
    }
}
