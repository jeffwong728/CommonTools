#ifndef DAHENG_CAMERA_H
#define DAHENG_CAMERA_H

#include "opencv2/opencv.hpp"
#include <QElapsedTimer>
#include <laser_x_camera.h>
#include <GalaxyException.h>
#include <GalaxyIncludes.h>
class DahengCameraManager;

class DahengCamera : public LaserXCamera
{
    Q_OBJECT
    friend class ConfigDahengCameraPage;
public:
    DahengCamera(QObject* parent);
    DahengCamera(QObject* parent, const QString& uuid);
    ~DahengCamera();

public:
    bool open(const QVariantMap& params) override;
    bool close() override;
    cv::Mat snap(int msec = 0) override;
    QImage grab(int msec = 0) override;
    void imageConsumed() override;
    bool startContinuousGrab() override;
    bool stopContinuousGrab() override;
    bool toggleContinuousGrab() override;
    bool isOpened() const override;
    bool isLivable() const override;
    bool setParameters(const QVariantMap& params) override;
    QVariantMap getParameters() const override;
    void setGrabParams(const QVariantMap& params) override;
    QVariantMap getGrabParams() const override;
    int getFPS() const override;

public:
    QString deviceID() const { return mDeviceID; }

private:
    void startGrab();
    void stopGrab();
    bool trigger(bool emitError);
    cv::Mat grabImage(bool emitError, int msec = 0);
    QImage snapImage(bool emitError, int msec = 0);

    qreal readExposureTime() const;
    qreal readExposureTimeMin() const;
    qreal readExposureTimeMax() const;
    qreal readExposureTimeInc() const;

    qreal readGain() const;
    qreal readGainMin() const;
    qreal readGainMax() const;
    qreal readGainInc() const;

    bool readGammaEnable() const;

    qreal readGamma() const;
    qreal readGammaMin() const;
    qreal readGammaMax() const;
    qreal readGammaInc() const;

    qreal readTriggerDelay() const;
    qreal readTriggerDelayMin() const;
    qreal readTriggerDelayMax() const;
    qreal readTriggerDelayInc() const;

    qreal readSharpness() const;
    qreal readSharpnessMin() const;
    qreal readSharpnessMax() const;
    qreal readSharpnessInc() const;

    bool readSharpnessEnable() const;

    bool writeExposureTime(const qreal nValue);
    bool writeGain(const qreal nValue);
    bool writeGammaEnable(const bool nValue);
    bool writeGamma(const qreal nValue);
    bool writeTriggerDelay(const qreal nValue);
    bool writeSharpness(const qreal nValue);
    bool writeSharpnessEnable(const bool nValue);

    bool initCamera();

private:
    static void liveMe(DahengCamera*cam);

private:
    cv::Mat mImage;
    QString mDeviceID;
    CGXDevicePointer mCamera;
    CGXStreamPointer mStream;
    mutable CGXFeatureControlPointer mFeatureControl;
    mutable CGXFeatureControlPointer mStreamFeatureControl;
    QFuture<void> mLiveFuture;
    DahengCameraManager* mManager = nullptr;
};

#endif // DAHENG_CAMERA_H
