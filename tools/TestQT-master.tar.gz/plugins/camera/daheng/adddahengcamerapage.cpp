#include "adddahengcamerapage.h"
#include "ui_adddahengcamerapage.h"
#include "daheng_camera_manager.h"

AddDahengCameraPage::AddDahengCameraPage(QWidget *parent, DahengCameraManager* camManager)
    : LaserXAddCameraWidget(parent)
    , ui(new Ui::AddDahengCameraPage)
    , mCameraManager(camManager)
{
    ui->setupUi(this);

    try
    {
        IGXFactory::GetInstance().UpdateDeviceList(1000, mDevices);
        qDebug() << QStringLiteral("Daheng camera manager found %1 devices").arg(mDevices.size());
    }
    catch (const CGalaxyException& e)
    {
        mDevices.clear();
        qDebug() << QStringLiteral("Daheng camera manager enumerate devices exception: %1").arg(QString::fromLatin1(e.what()));
    }

    int iDevIndex = 0;
    for (const CGXDeviceInfo &iDev : mDevices)
    {
        QVariantMap params;
        params[QStringLiteral("DeviceID")] = QString::fromLatin1(iDev.GetSN().c_str());
        if (!mCameraManager->findCamera(params))
        {
            ui->comboBoxDevice->addItem(QString::fromLatin1(iDev.GetDisplayName().c_str()), iDevIndex);
        }
        iDevIndex += 1;
    }
}

AddDahengCameraPage::~AddDahengCameraPage()
{
    delete ui;
}


void AddDahengCameraPage::on_comboBoxDevice_currentIndexChanged(int index)
{
    if (index >= 0 && index < ui->comboBoxDevice->count())
    {
        const int iDevIndex = ui->comboBoxDevice->itemData(index).toInt();
        const CGXDeviceInfo& iDevInfo = mDevices.at(iDevIndex);

        ui->lineEditDeviceID->setText(QString::fromLatin1(iDevInfo.GetSN().c_str()));
        ui->lineEditVendorName->setText(QString::fromLatin1(iDevInfo.GetVendorName().c_str()));
        ui->lineEditModelName->setText(QString::fromLatin1(iDevInfo.GetModelName().c_str()));
        ui->lineEditDeviceVersion->setText(QString::fromLatin1(iDevInfo.GetIP().c_str()));
        ui->lineEditUserDefinedName->setText(QString::fromLatin1(iDevInfo.GetUserID().c_str()));
        ui->lineEditFullName->setText(QString::fromLatin1(iDevInfo.GetModelName().c_str()));

        emit parametersChanged(getParameters());
    }
}

QVariantMap AddDahengCameraPage::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("DeviceID")] = ui->lineEditDeviceID->text();
    return params;
}
