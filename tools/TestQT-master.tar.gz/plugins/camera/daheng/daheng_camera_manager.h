#ifndef DAHENG_CAMERA_MANAGER_H
#define DAHENG_CAMERA_MANAGER_H

#include <laser_x_camera.h>
#include <QObject>
#include <memory>
class DahengCamera;

class DahengCameraManager : public LaserXCameraManager {
    Q_OBJECT
    Q_PLUGIN_METADATA(IID LaserXCameraManagerInterfaceIID)
    Q_INTERFACES(LaserXCameraManager)
public:
    DahengCameraManager();
    ~DahengCameraManager();

public:
    bool initialize() override;
    bool terminate() override;
    QString getTypeName() override;
    QIcon getIcon() const override;
    int getNumCameras() override;
    QVector<LaserXCamera*> getCameras() override;
    LaserXCamera* createCamera(const QVariantMap& params) override;
    LaserXCamera* findCamera(const QVariantMap& params) const override;
    bool addCamera(LaserXCamera* camera) override;
    void deleteCamera(LaserXCamera* camera) override;
    LaserXAddCameraWidget* getAddWidget(QWidget* parent) override;
    LaserXConfigCameraWidget* getConfigWidget(QWidget* parent, LaserXCamera* camera) override;

private:
    QMap<QString, DahengCamera*> mCameras;
};

#endif // DAHENG_CAMERA_MANAGER_H
