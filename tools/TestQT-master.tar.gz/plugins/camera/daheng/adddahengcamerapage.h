#ifndef ADD_DAHENG_CAMERA_PAGE_H
#define ADD_DAHENG_CAMERA_PAGE_H

#include <QWidget>
#include <laser_x_camera.h>
#include <GalaxyException.h>
#include <GalaxyIncludes.h>
class DahengCameraManager;

namespace Ui {
class AddDahengCameraPage;
}

class AddDahengCameraPage : public LaserXAddCameraWidget
{
    Q_OBJECT

public:
    explicit AddDahengCameraPage(QWidget *parent, DahengCameraManager* camManager);
    ~AddDahengCameraPage();

public:
    QVariantMap getParameters() const override;

private slots:
    void on_comboBoxDevice_currentIndexChanged(int index);

private:
    Ui::AddDahengCameraPage *ui;
    DahengCameraManager* const mCameraManager;
    GxIAPICPP::gxdeviceinfo_vector mDevices;
};

#endif // ADD_DAHENG_CAMERA_PAGE_H
