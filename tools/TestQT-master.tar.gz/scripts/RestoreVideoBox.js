let errorId = gApp.restoreVideoBox();

let reply = new Object();
reply.CommandName   = gCommandName;
reply.CommandSN     = gCommandSN;
reply.ProjectName   = gProjectName;
reply.ErrorId       = errorId;
reply.ErrorMsg      = gApp.getErrorMsg(errorId);
reply.Success       = !errorId;

let rMsg = JSON.stringify(reply);
rMsg += "\n"
gIO.write(rMsg)
