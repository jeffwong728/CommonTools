#include "jsapp.h"
#include "jsiodevice.h"
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>
#include <database/settingdb.h>
#include <database/projectdb.h>
#include <ui/runpage.h>
#include <ui/mainframe.h>
#include <ui/flowchart/flowview.h>

JSApp::JSApp(QJSEngine* jsEngine, QObject *parent)
    : mJSEngine(jsEngine), QObject(parent)
{
}

QJSValue JSApp::findSerialPort(const QString &name)
{
    LaserXSerialPort* iSerialPort = gDeviceManager->findSerialPortByName(name);
    if (iSerialPort && mJSEngine)
    {
        JSIODevice* iIO = new JSIODevice(iSerialPort, nullptr);
        QJSValue jsIO = mJSEngine->newQObject(iIO);
        mJSEngine->setObjectOwnership(iIO, QJSEngine::JavaScriptOwnership);
        return jsIO;
    }
    else
    {
        return QJSValue(QJSValue::NullValue);
    }
}

QJSValue JSApp::switchProject(const QString& newProjName)
{
    if (gMainFrame->mProjectEditing)
    {
        gRunPage->logError(QStringLiteral("Can't switch project when editing"));
        return kImageProcessError_ProjectEditing;
    }

    SettingDB settingDB;
    QStringList allProjNames = settingDB.getProjectNames();
    qsizetype iProjIndex = allProjNames.indexOf(newProjName);
    if (-1 == iProjIndex)
    {
        gRunPage->logError(QStringLiteral("Project %1 not exists").arg(newProjName));
        return kImageProcessError_ProjectNotExists;
    }

    QString newProjPath = settingDB.getProjectPath(newProjName);
    if (!QFileInfo::exists(newProjPath))
    {
        gRunPage->logError(QStringLiteral("Project %1 not valid").arg(newProjName));
        return kImageProcessError_ProjectInvalid;
    }

    QString oldProjPath = QAppHelper::getSetting<QString>(gAppProjPath);
    if (oldProjPath != newProjPath)
    {
        gFlowView->cleanProject();
        QAppHelper::setSetting(gAppProjPath, newProjPath);
        gFlowView->loadProject();
        QAppHelper::setTemporarySetting(gAppProjTemp, false);
        gMainFrame->mStatusLabels[MainFrame::CurrentProject]->setText(newProjName);
    }
    else
    {
        qWarning() << QStringLiteral("Project %1 already current").arg(newProjName);
    }

    return kImageProcessError_NoError;
}

QJSValue JSApp::restoreVideoBox()
{
    gRunPage->restoreVideoBox();
    return kImageProcessError_NoError;
}

QJSValue JSApp::startProcessCommand()
{
    gMainFrame->startProcess();
    return kImageProcessError_NoError;
}

QJSValue JSApp::stopProcessCommand()
{
    gMainFrame->stopProcess();
    return kImageProcessError_NoError;
}

QJSValue JSApp::getErrorMsg(const int errorId)
{
    return gGetErrorMsg(errorId);
}
