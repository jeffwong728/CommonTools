#include "pyregion.h"
#include <laser_x_region.h>

PyRegion::PyRegion(const LXRegion &region)
    : mRegion(region)
{
}

qreal PyRegion::Area() const
{
    return mRegion->area();
}

std::tuple<double, double> PyRegion::Center() const
{
    QPointF iCenter = mRegion->center();
    return std::make_tuple<double, double>(iCenter.x(), iCenter.y());
}

pybind11::object PyRegion::Connection() const
{
    LXRegion iRgn = mRegion->connection();
    if (iRgn)
    {
        PyRegion pyRgn(iRgn);
        return pybind11::cast(pyRgn);
    }
    else
    {
        return pybind11::none();
    }
}

pybind11::object PyRegion::ClosingCircle(const qreal radius) const
{
    LXRegion iRgn = mRegion->closingCircle(radius);
    if (iRgn)
    {
        PyRegion pyRgn(iRgn);
        return pybind11::cast(pyRgn);
    }
    else
    {
        return pybind11::none();
    }
}

pybind11::object PyRegion::ClosingRectangle1(const qreal width, const qreal height) const
{
    LXRegion iRgn = mRegion->closingRectangle1(QSize(qRound(width), qRound(height)));
    if (iRgn)
    {
        PyRegion pyRgn(iRgn);
        return pybind11::cast(pyRgn);
    }
    else
    {
        return pybind11::none();
    }
}

pybind11::object PyRegion::OpeningCircle(const qreal radius) const
{
    LXRegion iRgn = mRegion->openingCircle(radius);
    if (iRgn)
    {
        PyRegion pyRgn(iRgn);
        return pybind11::cast(pyRgn);
    }
    else
    {
        return pybind11::none();
    }
}

pybind11::object PyRegion::OpeningRectangle1(const qreal width, const qreal height) const
{
    LXRegion iRgn = mRegion->openingRectangle1(QSize(qRound(width), qRound(height)));
    if (iRgn)
    {
        PyRegion pyRgn(iRgn);
        return pybind11::cast(pyRgn);
    }
    else
    {
        return pybind11::none();
    }
}

pybind11::object PyRegion::FillHoles() const
{
    LXRegion iRgn = mRegion->fillHoles();
    if (iRgn)
    {
        PyRegion pyRgn(iRgn);
        return pybind11::cast(pyRgn);
    }
    else
    {
        return pybind11::none();
    }
}

pybind11::object PyRegion::EllipticAxis() const
{
    QVariantMap iParams = mRegion->ellipticAxis();
    std::unordered_map<std::string, double> iDict;
    iDict["Ra"] = iParams[QStringLiteral("Ra")].toReal();
    iDict["Rb"] = iParams[QStringLiteral("Rb")].toReal();
    iDict["Phi"] = iParams[QStringLiteral("Phi")].toReal();
    return pybind11::cast(iDict);
}

void PyExportRegion(pybind11::module_& m)
{
    auto c = pybind11::class_<PyRegion>(m, "Region");
    c.def("Area", &PyRegion::Area, "Return area of region");
    c.def("Connection", &PyRegion::Connection, "Compute connected components of a region");
    c.def("FillHoles", &PyRegion::FillHoles, "Fill up holes in regions");
    c.def("EllipticAxis", &PyRegion::EllipticAxis, "Calculate the parameters of the equivalent ellipse");
    c.def("ClosingCircle", &PyRegion::ClosingCircle, "Close a region with a circular structuring element");
    c.def("ClosingRectangle1", &PyRegion::ClosingRectangle1, "Close a region with a rectangular structuring element");
    c.def("OpeningCircle", &PyRegion::OpeningCircle, "Open a region with a circular structuring element");
    c.def("OpeningRectangle1", &PyRegion::OpeningRectangle1, "Open a region with a rectangular structuring element");
}
