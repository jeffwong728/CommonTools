#ifndef SCRIPTING_PYMAIN_H
#define SCRIPTING_PYMAIN_H
#include <string>

extern std::string InitializePython();
extern void FinalizePython();
extern void PyClearOutput();
extern std::string PyGetOutput();
extern std::pair<std::string, bool> PyRunFile(const std::string& strFullPath);
extern std::pair<std::string, bool> PyRunStrings(const std::string& strCmd);

#endif //SCRIPTING_PYMAIN_H
