#ifndef SCRIPTING_PY_TEXTBOX_H
#define SCRIPTING_PY_TEXTBOX_H

#include <pybind11/embed.h>
#include <pybind11/stl.h>
#include <pybind11/cast.h>
#include <pybind11/numpy.h>
#include <QtWidgets>

struct PyTextBox
{
    explicit PyTextBox(QWidget *textBox);
    virtual ~PyTextBox() = default;
    pybind11::object GetText();
    void AppendText(const std::wstring &text);
    QWidget *mTextBox = nullptr;
};

#endif //SCRIPTING_PY_TEXTBOX_H
