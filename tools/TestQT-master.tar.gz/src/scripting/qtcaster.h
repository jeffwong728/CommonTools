#ifndef SCRIPTING_QT_CASTER_H
#define SCRIPTING_QT_CASTER_H

#include <pybind11/embed.h>
#include <pybind11/stl.h>
#include <pybind11/cast.h>
#include <pybind11/numpy.h>

enum class MvlabPyType
{
    kMVPT_REGION = 0,
    kMVPT_CONTOUR = 1,
    kMVPT_GUARD = 2
};

#endif //SCRIPTING_QT_CASTER_H
