#include "pytextbox.h"

PyTextBox::PyTextBox(QWidget* textBox)
    : mTextBox(textBox)
{
}

pybind11::object PyTextBox::GetText()
{
    if (mTextBox)
    {
        QPlainTextEdit* textBox = qobject_cast<QPlainTextEdit*>(mTextBox);
        if (textBox)
        {
            pybind11::cast(textBox->toPlainText().toStdWString());
        }
        else
        {
            QTextEdit* textEdit = qobject_cast<QTextEdit*>(mTextBox);
            if (textEdit)
            {
                pybind11::cast(textEdit->toPlainText().toStdWString());
            }
        }
    }

    return pybind11::none();
}

void PyTextBox::AppendText(const std::wstring &text)
{
    if (mTextBox)
    {
        QPlainTextEdit* textBox = qobject_cast<QPlainTextEdit*>(mTextBox);
        if (textBox)
        {
            textBox->appendPlainText(QString::fromStdWString(text));
        }
        else
        {
            QTextEdit* textEdit = qobject_cast<QTextEdit*>(mTextBox);
            if (textEdit)
            {
                textEdit->append(QString::fromStdWString(text));
            }
        }
    }
}

void PyExportTextBox(pybind11::module_& m)
{
    auto c = pybind11::class_<PyTextBox>(m, "TextBox");
    c.def("GetText", &PyTextBox::GetText);
    c.def("AppendText", &PyTextBox::AppendText);
}
