#include <pybind11/embed.h>
#include <pybind11/stl.h>

extern void PyExportRunPage(pybind11::module_& m);
extern void PyExportCanvas(pybind11::module_& m);
extern void PyExportTextBox(pybind11::module_& m);
extern void PyExportRegion(pybind11::module_& m);
extern void PyQuitApp();
extern pybind11::object PyGetRunPage();

PYBIND11_EMBEDDED_MODULE(laserx, m)
{
    PyExportRunPage(m);
    PyExportCanvas(m);
    PyExportTextBox(m);
    PyExportRegion(m);
    m.def("Quit", PyQuitApp);
    m.def("GetRunPage", PyGetRunPage);
}

std::string InitializePython()
{
    try {
        //PyImport_AppendInittab("laserx", &PyInit_laserx);
        pybind11::initialize_interpreter();
        pybind11::object mainModule = pybind11::module_::import("__main__");
        pybind11::object mainNamespace = mainModule.attr("__dict__");
        pybind11::exec("import sys", mainNamespace);
        pybind11::exec("import io", mainNamespace);
        pybind11::exec("laserx_output = io.StringIO()", mainNamespace);
        pybind11::exec("sys.stdout = laserx_output", mainNamespace);
        return std::string();
    }
    catch (pybind11::error_already_set& e)
    {
        return std::string(e.what());
    }
}

void FinalizePython()
{
    //PyImport_AppendInittab("laserx", &PyInit_laserx);
    pybind11::finalize_interpreter();
}

void PyClearOutput()
{
    pybind11::object mainModule = pybind11::module_::import("__main__");
    pybind11::object mainNamespace = mainModule.attr("__dict__");
    pybind11::exec("laserx_output = io.StringIO()", mainNamespace);
    pybind11::exec("sys.stdout = laserx_output", mainNamespace);
}

std::string PyGetOutput()
{
    pybind11::object mainModule = pybind11::module_::import("__main__");
    pybind11::object mainNamespace = mainModule.attr("__dict__");
    pybind11::exec("laserxOut = laserx_output.getvalue()", mainNamespace);
    std::string stdOut = pybind11::cast<std::string>(mainNamespace["laserxOut"]);
    return stdOut;
}

std::pair<std::string, bool> PyRunFile(const std::string& strFullPath)
{
    try
    {
        pybind11::object mainModule = pybind11::module_::import("__main__");
        pybind11::object mainNamespace = mainModule.attr("__dict__");
        PyClearOutput();
        pybind11::eval_file(strFullPath.c_str(), mainNamespace);
        return std::make_pair(PyGetOutput(), true);
    }
    catch (const pybind11::error_already_set& e)
    {
        return std::make_pair(std::string(e.what()), false);
    }
}

std::pair<std::string, bool> PyRunStrings(const std::string& strCmd)
{
    try
    {
        pybind11::object mainModule = pybind11::module_::import("__main__");
        pybind11::object mainNamespace = mainModule.attr("__dict__");
        PyClearOutput();
        pybind11::object resultObj = pybind11::eval<pybind11::eval_statements>(strCmd.c_str(), mainNamespace);
        const auto resultTypeStr = pybind11::str(resultObj.get_type()).cast<std::string>();
        const auto noneTypeStr = pybind11::str(pybind11::none().get_type()).cast<std::string>();
        if (resultTypeStr != noneTypeStr)
        {
            return std::make_pair(pybind11::str(resultObj).cast<std::string>(), true);
        }
        else
        {
            return std::make_pair(PyGetOutput(), true);
        }
    }
    catch (const pybind11::error_already_set& e)
    {
        return std::make_pair(std::string(e.what()), false);
    }
}
