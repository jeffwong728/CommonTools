#include "pyrunpage.h"
#include "pycanvas.h"
#include "pytextbox.h"
#include <ui/runpage.h>
#include <ui/mainframe.h>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QtWidgets>
#include <laser_x_canvas.h>


PyRunPage::PyRunPage(RunPage *runPage)
    : mRunPage(runPage)
{
}

pybind11::object PyRunPage::FindCanvas(const std::wstring &objectName)
{
    if (mRunPage)
    {
        QString qObjectName = QString::fromStdWString(objectName);
        LaserXCanvas* view = mRunPage->findChild<LaserXCanvas*>(qObjectName);
        if (view)
        {
            PyCanvas scene(view);
            return pybind11::cast(scene);
        }
    }
    return pybind11::none();
}

pybind11::object PyRunPage::FindTextBox(const std::wstring& objectName)
{
    if (mRunPage)
    {
        QString qObjectName = QString::fromStdWString(objectName);
        QPlainTextEdit* textBox = mRunPage->findChild<QPlainTextEdit*>(qObjectName);
        if (textBox)
        {
            PyTextBox pyTextBox(textBox);
            return pybind11::cast(pyTextBox);
        }
        else
        {
            QTextEdit* textEdit = mRunPage->findChild<QTextEdit*>(qObjectName);
            if (textEdit)
            {
                PyTextBox pyTextBox(textBox);
                return pybind11::cast(pyTextBox);
            }
        }
    }
    return pybind11::none();
}

pybind11::object PyGetRunPage()
{
    MainFrame* mainFrame = nullptr;
    QWidgetList topWidgets = qApp->topLevelWidgets();
    for (QWidget* topWidget : topWidgets)
    {
        mainFrame = qobject_cast<MainFrame*>(topWidget);
        if (mainFrame)
        {
            break;
        }
    }

    if (mainFrame)
    {
        PyRunPage pyRunPage(mainFrame->mRunPage);
        return pybind11::cast(pyRunPage);
    }

    return pybind11::none();
}

void PyQuitApp()
{
    qApp->quit();
}

void PyExportRunPage(pybind11::module_& m)
{
    auto c = pybind11::class_<PyRunPage>(m, "RunPage");
    c.def("FindCanvas", &PyRunPage::FindCanvas);
    c.def("FindTextBox", &PyRunPage::FindTextBox);
}
