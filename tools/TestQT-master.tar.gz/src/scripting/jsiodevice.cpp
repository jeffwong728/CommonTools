#include "jsiodevice.h"

JSIODevice::JSIODevice(QIODevice* ioDevice, QObject *parent)
    : mIODevice(ioDevice), QObject(parent)
{
}

QJSValue JSIODevice::write(const QString &msg)
{
    if (mIODevice)
    {
        mIODevice->write(msg.toUtf8());
        return true;
    }
    else
    {
        return false;
    }
}
