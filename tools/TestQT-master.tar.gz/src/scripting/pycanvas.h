#ifndef SCRIPTING_PY_GRAPHICS_SCENE_H
#define SCRIPTING_PY_GRAPHICS_SCENE_H

#include <pybind11/embed.h>
#include <pybind11/stl.h>
#include <pybind11/cast.h>
#include <pybind11/numpy.h>
#include <QtWidgets>
class LaserXCanvas;
class PyRegion;

struct PyCanvas
{
    explicit PyCanvas(LaserXCanvas* canvas);
    virtual ~PyCanvas() = default;
    void SetColor(const std::string& color);
    void SetColor(const uint8_t red, const uint8_t green, const uint8_t blue);
    void SetColor(const uint8_t red, const uint8_t green, const uint8_t blue, const uint8_t alpha);
    void SetColored(const int numColors);
    void SetLineWidth(const int width);
    void AddRect(qreal x, qreal y, qreal w, qreal h);
    void AddArrow(qreal cx, qreal cy, qreal phi, qreal headSize);
    void DispObj(const PyRegion& obj);
    void DispObjs(const std::vector<PyRegion>& objs);
    void EraseAll();
    pybind11::object Threshold(const double minGray, const double maxGray) const;
    LaserXCanvas *mCanvas = nullptr;
    QColor mColor;
    int mLineWidth = 1;
    int mNumColors = 16;
};

#endif //SCRIPTING_PY_GRAPHICS_SCENE_H
