#ifndef SCRIPTING_JS_APP_H
#define SCRIPTING_JS_APP_H

#include <QtCore>
#include <QJSEngine>

class JSApp : public QObject
{
    Q_OBJECT

public:
    JSApp(QJSEngine* jsEngine, QObject *parent);
    
public:
    Q_INVOKABLE QJSValue findSerialPort(const QString& name);
    Q_INVOKABLE QJSValue switchProject(const QString &newProjName);
    Q_INVOKABLE QJSValue getErrorMsg(const int errorId);

private:
    QJSEngine* mJSEngine = nullptr;
};

#endif //SCRIPTING_JS_APP_H
