#ifndef SCRIPTING_PY_RUN_PAGE_H
#define SCRIPTING_PY_RUN_PAGE_H

#include <pybind11/embed.h>
#include <pybind11/stl.h>
#include <pybind11/cast.h>
#include <pybind11/numpy.h>
#include <QtWidgets>
#include <string>
class RunPage;

struct PyRunPage
{
    explicit PyRunPage(RunPage *runPage);
    virtual ~PyRunPage() = default;
    pybind11::object FindCanvas(const std::wstring& objectName);
    pybind11::object FindTextBox(const std::wstring &objectName);
    RunPage *mRunPage = nullptr;
};

#endif //SCRIPTING_PY_RUN_PAGE_H
