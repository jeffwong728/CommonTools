#ifndef SCRIPTING_JS_IO_DEVICE_H
#define SCRIPTING_JS_IO_DEVICE_H

#include <QtCore>
#include <QJSEngine>

class JSIODevice : public QObject
{
    Q_OBJECT

public:
    JSIODevice(QIODevice* ioDevice, QObject *parent);
    
public:
    Q_INVOKABLE QJSValue write(const QString &msg);

public:
    QIODevice* mIODevice = nullptr;
};

#endif //SCRIPTING_JS_IO_DEVICE_H
