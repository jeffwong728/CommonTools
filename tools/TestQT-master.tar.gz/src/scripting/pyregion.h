#ifndef SCRIPTING_PY_REGION_H
#define SCRIPTING_PY_REGION_H

#include <pybind11/embed.h>
#include <pybind11/stl.h>
#include <pybind11/cast.h>
#include <pybind11/numpy.h>
#include <QtCore>
#include <laser_x_vision_global.h>

struct PyRegion
{
    explicit PyRegion(const LXRegion &region);
    virtual ~PyRegion() = default;
    qreal Area() const;
    std::tuple<double, double> Center() const;
    pybind11::object Connection() const;
    pybind11::object ClosingCircle(const qreal radius) const;
    pybind11::object ClosingRectangle1(const qreal width, const qreal height) const;
    pybind11::object OpeningCircle(const qreal radius) const;
    pybind11::object OpeningRectangle1(const qreal width, const qreal height) const;
    pybind11::object FillHoles() const;
    pybind11::object EllipticAxis() const;
    const LXRegion mRegion;
};

#endif //SCRIPTING_PY_REGION_H
