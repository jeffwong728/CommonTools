#include "pycanvas.h"
#include "pyregion.h"
#include <cmndef.h>
#include <laser_x_vision.h>
#include <laser_x_canvas.h>
#pragma warning( push )
#pragma warning( disable : 4819 4003 )
#include <2geom/circle.h>
#include <2geom/pathvector.h>
#include <2geom/path-sink.h>
#pragma warning( pop )

PyCanvas::PyCanvas(LaserXCanvas* canvas)
    : mCanvas(canvas)
{
}

void PyCanvas::SetColor(const std::string& color)
{
    mColor.setNamedColor(QString::fromStdString(color));
    if (!mColor.isValid())
    {
        throw std::invalid_argument(std::string("Invalid color string: ") + color);
    }
}

void PyCanvas::SetColor(const uint8_t red, const uint8_t green, const uint8_t blue)
{
    mColor.setRgb(red, green, blue);
}

void PyCanvas::SetColor(const uint8_t red, const uint8_t green, const uint8_t blue, const uint8_t alpha)
{
    mColor.setRgb(red, green, blue, alpha);
}

void PyCanvas::SetColored(const int numColors)
{
    if (numColors > 0)
    {
        mNumColors = numColors;
    }
}

void PyCanvas::SetLineWidth(const int width)
{
    if (width < 1)
    {
        throw std::invalid_argument("width >= 1.0");
    }
    else
    {
        mLineWidth = width;
    }
}

void PyCanvas::AddRect(qreal x, qreal y, qreal w, qreal h)
{
    if (mCanvas)
    {
        QPen pen(mColor);
        pen.setCosmetic(true);
        pen.setWidth(mLineWidth);
        QGraphicsRectItem* iItem = new QGraphicsRectItem(x, y, w, h);
        iItem->setPen(pen);
        mCanvas->addTemporaryItem(iItem);
    }
}

void PyCanvas::AddArrow(qreal cx, qreal cy, qreal phi, qreal headSize)
{
    if (headSize < 3 || headSize > 15)
    {
        throw std::invalid_argument(std::string("Invalid head_size ") + std::to_string(headSize));
    }

    if (mCanvas)
    {
        Geom::Coord arrowLen = 20.;
        Geom::Point sPt(cx, cy);
        Geom::Point ePt = sPt + Geom::Point::polar(Geom::rad_from_deg(phi), arrowLen);

        Geom::Point arrowBase = Geom::lerp(headSize / arrowLen, ePt, sPt);
        Geom::Point tPt = arrowBase + Geom::rot90(ePt - arrowBase);
        Geom::Point rPt = Geom::lerp(0.618, tPt, arrowBase);
        Geom::Point lPt = Geom::lerp(2, rPt, arrowBase);

        QPainterPath iPath;
        iPath.moveTo(QPointF(ePt.x(), ePt.y()));
        iPath.lineTo(QPointF(rPt.x(), rPt.y()));
        iPath.lineTo(QPointF(lPt.x(), lPt.y()));
        iPath.closeSubpath();
        iPath.moveTo(QPointF(sPt.x(), sPt.y()));
        iPath.lineTo(QPointF(ePt.x(), ePt.y()));
        iPath.closeSubpath();

        QPen pen(mColor);
        pen.setCosmetic(true);
        pen.setWidth(1);
        QBrush brush(mColor);

        QGraphicsPathItem* iItem = new QGraphicsPathItem(iPath);
        iItem->setPen(pen);
        iItem->setBrush(brush);
        mCanvas->addTemporaryItem(iItem);
    }
}

void PyCanvas::DispObj(const PyRegion& obj)
{
    if (mCanvas)
    {
        QPainterPath iPath;
        QPen pen(mColor);
        pen.setCosmetic(true);
        pen.setWidth(1);
        QBrush brush(mColor);
        QVector<QPolygonF> iPlgs = obj.mRegion->getPolygons(1.5);
        for (QPolygonF& iPlg : iPlgs)
        {
            iPath.addPolygon(iPlg);
        }

        QGraphicsPathItem* iItem = new QGraphicsPathItem(iPath);
        iItem->setPen(pen);
        iItem->setBrush(brush);
        mCanvas->addTemporaryItem(iItem);
    }
}

void PyCanvas::DispObjs(const std::vector<PyRegion>& objs)
{
    if (mCanvas)
    {

    }
}

void PyCanvas::EraseAll()
{
    if (mCanvas)
    {
        mCanvas->clearAllTemporaryItems();
    }
}

pybind11::object PyCanvas::Threshold(const double minGray, const double maxGray) const
{
    if (mCanvas)
    {
        cv::Mat iMat = mCanvas->mat();
        LXRegion lxRgn = gVision->threshold(iMat, minGray, maxGray);
        if (lxRgn)
        {
            PyRegion pyRgn(lxRgn);
            return pybind11::cast(pyRgn);
        }
    }

    return pybind11::none();
}

void PyExportCanvas(pybind11::module_& m)
{
    auto c = pybind11::class_<PyCanvas>(m, "Canvas");
    c.def("SetColor", pybind11::overload_cast<const std::string&>(&PyCanvas::SetColor), "Set output color by color name", pybind11::arg("color"));
    c.def("SetColor", pybind11::overload_cast<const uint8_t, const uint8_t, const uint8_t>(&PyCanvas::SetColor), "Set output color in RGB format", pybind11::arg("red"), pybind11::arg("green"), pybind11::arg("blue"));
    c.def("SetColor", pybind11::overload_cast<const uint8_t, const uint8_t, const uint8_t, const uint8_t>(&PyCanvas::SetColor), "Set output color in RGBA format", pybind11::arg("red"), pybind11::arg("green"), pybind11::arg("blue"), pybind11::arg("alpha"));
    c.def("SetLineWidth", &PyCanvas::SetLineWidth, "Define the line width for region contour output", pybind11::arg("width"));
    c.def("DispObj", pybind11::overload_cast<const PyRegion&>(&PyCanvas::DispObj), "Display a region or regions", pybind11::arg("obj"));
    c.def("EraseAll", &PyCanvas::EraseAll, "Erase all displayables inside canvas display area");
    c.def("AddRect", &PyCanvas::AddRect, "Add a rectangle item to canvas");
    c.def("Threshold", &PyCanvas::Threshold, "Segment current image using global threshold in canvas");
}
