#ifndef COMMON_DEFINE_H
#define COMMON_DEFINE_H
#include <QtCore>
#include <laser_x_util.h>
class MainFrame;
class RunPage;
class LaserXDeviceManager;
class QUndoGroup;
class QUndoStack;
class LaserXVisionManager;
class ImageResourceManager;
class FlowView;
class LoggingDB;

constexpr int kMessageID_Ready = 0;
constexpr int kMessageID_Switch_To_English = 1;
constexpr int kMessageID_Switch_To_Chinese = 2;

constexpr int kImageProcessError_NoError = 0;
constexpr int kImageProcessError_General = 1;
constexpr int kImageProcessError_CameraDisconnected = 2;
constexpr int kImageProcessError_NoCamera = 3;
constexpr int kImageProcessError_NoCanvas = 4;
constexpr int kImageProcessError_NoDie = 5;
constexpr int kImageProcessError_BadDie = 6;
constexpr int kImageProcessError_MultiDie = 7;
constexpr int kImageProcessError_GrabConflict = 8;
constexpr int kImageProcessError_Stopped = 9;
constexpr int kImageProcessError_ProjectEditing = 1001;
constexpr int kImageProcessError_ProjectNotExists = 1002;
constexpr int kImageProcessError_ProjectInvalid = 1003;

extern const QString gUILanguage;
extern const QString gUITheme;
extern const QString gAppImageFolder;
extern const QString gAppUndoLimit;
extern const QString gAppProjsDir;
extern const QString gAppOCRDir;
extern const QString gAppScriptsDir;
extern const QString gAppProjPath;
extern const QString gAppSettingPath;
extern const QString gAppCommandProcessControl;
extern const QString gUIImageCross;
extern const QString gUIImageXYAxis;
extern const QString gUIFlowXYAxis;
extern const QString gUIRunTimeFile;
extern const QString gUIImageProcess;
extern const QString gAppProjTemp;
extern const QString gAppLogDir;
extern const QString gAppMainUIAnchor;
extern const QString gAppMainUIWidth;
extern const QString gAppCameraPlugins;

extern const QString gTypeIOTrigger;
extern const QString gTypeSerialTrigger;
extern const QString gTypeNetworkTrigger;
extern const QString gTypeSoftTrigger;
extern const QString gTypeTimerTrigger;
extern const QString gTypeImageLive;
extern const QString gTypeImageGrabber;
extern const QString gTypeNCCTemplate;
extern const QString gTypeShapeTemplate;
extern const QString gTypeMultiShapeTemplate;
extern const QString gTypeRectTemplate;
extern const QString gTypeCircleTemplate;
extern const QString gTypeBlobFinder;
extern const QString gTypeGeomMeasure;
extern const QString gTypeCompoundProcess;
extern const QString gTypeGeneralOCR;
extern const QString gTypePretrainedOCR;
extern const QString gTypeCustomOCR;
extern const QString gTypeNccOCR;
extern const QString gTypeJSImageProcess;

constexpr int gkPrivilegeOperator = 1;
constexpr int gkPrivilegeEngineer = 2;
constexpr int gkPrivilegeAdministrator = 3;
constexpr int gkPrivilegeDeveloper = 4;

constexpr int gkAsyncImageProcess = 1;

extern MainFrame *gMainFrame;
extern RunPage *gRunPage;
extern LaserXDeviceManager *gDeviceManager;
extern QUndoGroup* gUndoGroup;
extern QUndoStack *gUndoStack;
extern LaserXVisionManager* gVision;
extern ImageResourceManager* gImageManager;
extern FlowView* gFlowView;
extern LoggingDB* gLogging;

extern QString gGetErrorMsg(const int errId);

#endif // COMMON_DEFINE_H
