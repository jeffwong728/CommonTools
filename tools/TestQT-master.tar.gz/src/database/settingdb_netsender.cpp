#include "settingdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <laser_x_net_sender.h>
#include <laser_x_devicemanager.h>

bool SettingDB::addNetSender(const LaserXNetSender* netSender)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO netSenders (UUID, Params) VALUES (?, ?)")))
    {
        qCritical() << QStringLiteral("Add into netSenders in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, netSender->uuid());
    query.bindValue(1, netSender->getJson());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into netSenders in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::deleteNetSender(const LaserXNetSender* netSender)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM netSenders WHERE UUID = '%1'; ").arg(netSender->uuid())))
    {
        qCritical() << QStringLiteral("Delete from netSenders in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::updateNetSender(const LaserXNetSender* netSender)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE netSenders SET Params = '%1' WHERE UUID = '%2';").arg(netSender->getJson(), netSender->uuid())))
    {
        qCritical() << QStringLiteral("Update netSenders in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

void SettingDB::loadAllNetSender(LaserXDeviceManager* deviceManager)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT UUID, Params FROM netSenders;")))
    {
        qCritical() << QStringLiteral("Search net senders in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return;
    }

    while (query.next())
    {
        QString uuid = query.value(0).toString();
        QString params = query.value(1).toString();

        LaserXNetSender* netSender = deviceManager->newNetSender(uuid);
        netSender->setJson(params);
        deviceManager->addNetSender(netSender);
        netSender->connectWithWait();
    }
}

bool SettingDB::createNetSenderTable(QSqlQuery& query)
{
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS netSenders (Id INTEGER PRIMARY KEY, UUID TEXT NOT NULL UNIQUE, Params TEXT);")))
    {
        qCritical() << QStringLiteral("Open netSenders in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }
    else
    {
        return true;
    }
}
