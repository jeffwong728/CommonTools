#include "settingdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

bool SettingDB::addNetListener(const LaserXNetListener* netListener)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO netListeners (UUID, Params) VALUES (?, ?)")))
    {
        qCritical() << QStringLiteral("Add into netListeners in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, netListener->uuid());
    query.bindValue(1, netListener->getJson());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into netListeners in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::deleteNetListener(const LaserXNetListener* netListener)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM netListeners WHERE UUID = '%1'; ").arg(netListener->uuid())))
    {
        qCritical() << QStringLiteral("Delete from netListeners in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::updateNetListener(const LaserXNetListener* netListener)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE netListeners SET Params = '%1' WHERE UUID = '%2';").arg(netListener->getJson(), netListener->uuid())))
    {
        qCritical() << QStringLiteral("Update netListeners in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

void SettingDB::loadAllNetListener(LaserXDeviceManager* deviceManager)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT UUID, Params FROM netListeners;")))
    {
        qCritical() << QStringLiteral("Search net listeners in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return;
    }

    while (query.next())
    {
        QString uuid = query.value(0).toString();
        QString params = query.value(1).toString();

        LaserXNetListener* netListener = deviceManager->newNetListener(uuid);
        netListener->setJson(params);
        deviceManager->addNetListener(netListener);
        netListener->startListen();
    }
}

bool SettingDB::createNetListenerTable(QSqlQuery& query)
{
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS netListeners (Id INTEGER PRIMARY KEY, UUID TEXT NOT NULL UNIQUE, Params TEXT);")))
    {
        qCritical() << QStringLiteral("Open netListeners in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }
    else
    {
        return true;
    }
}
