#ifndef DATA_PROJECT_LIST_DB_H
#define DATA_PROJECT_LIST_DB_H
#include <QtCore>
class QSqlQuery;
class LaserXSerialPort;
class LaserXDeviceManager;
class LaserXNetSender;
class LaserXNetListener;
class LaserXLEDController;
class LaserXLensController;

class SettingDB
{
public:
    SettingDB();
    ~SettingDB();

public:
    QStringList getProjectNames();
    bool isProjectExist(const QString &projName);
    bool addProject(const QString& projName, const QString& projFilePath);
    bool deleteProject(const QString& projName);
    QString getProjectPath(const QString& projName);
    bool updateProject(const QString& oldProjName, const QString& newProjName, const QString& newProjFilePath);

    bool isUserExist(const QString& userName, const QString& userGroup);
    bool addUser(const QString& userName, const QString& userGroup, const QByteArray &data);
    QByteArray getUserData(const QString& userName, const QString& userGroup);

    bool addSerialPort(const QString& portName, const QString& uuid, const QString& paramsData);
    bool deleteSerialPort(const QString& uuid);
    bool updateSerialPort(const QString& uuid, const QString& paramsData);
    void loadAllSerialPort(LaserXDeviceManager*deviceManager);

    bool addNetListener(const LaserXNetListener *netListener);
    bool deleteNetListener(const LaserXNetListener* netListener);
    bool updateNetListener(const LaserXNetListener* netListener);
    void loadAllNetListener(LaserXDeviceManager* deviceManager);

    bool addNetSender(const LaserXNetSender* netSender);
    bool deleteNetSender(const LaserXNetSender* netSender);
    bool updateNetSender(const LaserXNetSender* netSender);
    void loadAllNetSender(LaserXDeviceManager* deviceManager);

    bool addCamera(const QString& uuid, const QString& pluginType, const QVariantMap &params);
    bool deleteCamera(const QString& uuid);
    bool updateCamera(const QString& uuid, const QString& paramsData);
    void loadAllCameras(LaserXDeviceManager* deviceManager);

    bool addLightSource(const LaserXLEDController* lightSource);
    bool deleteLightSource(const LaserXLEDController* lightSource);
    bool updateLightSource(const LaserXLEDController* lightSource);
    void loadAllLightSource(LaserXDeviceManager* deviceManager);

    bool addLensController(const LaserXLensController* lens);
    bool deleteLensController(const LaserXLensController* lens);
    bool updateLensController(const LaserXLensController* lens);
    void loadAllLensController(LaserXDeviceManager* deviceManager);

    bool setSetting(const QString& name, const int value);
    bool setSetting(const QString& name, const QString &value);
    template<typename T> T getSetting(const QString& name, const T& defaultValue);

private:
    bool open();
    bool close();
    void setSettingFilePath();
    bool createCameraTable(QSqlQuery& query);
    bool createSerialPortTable(QSqlQuery& query);
    bool createNetListenerTable(QSqlQuery& query);
    bool createNetSenderTable(QSqlQuery& query);
    bool createLightSourceTable(QSqlQuery& query);
    bool createLensControllerTable(QSqlQuery& query);

private:
    const QString mConnectionName;
    const QString mSettingFilePath;

private:
    Q_DISABLE_COPY_MOVE(SettingDB)
};

#endif // DATA_PROJECT_LIST_DB_H
