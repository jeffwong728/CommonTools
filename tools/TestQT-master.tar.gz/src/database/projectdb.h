#ifndef DATA_PROJECT_DB_H
#define DATA_PROJECT_DB_H
#include <QtCore>
#include <opencv2/opencv.hpp>
class LXProcedureItem;
class LinkerItem;

class ProjectDB
{
public:
    ProjectDB(const QString& projFilePath);
    ~ProjectDB();

public:
    bool isValid() const;

private:
    bool open();
    bool close();

public:
    qint64 addProcedure(const LXProcedureItem *procItem);
    QVector<LXProcedureItem*> loadProcedures();
    bool updateName(const LXProcedureItem* procItem);
    bool updateGeomData(const LXProcedureItem* procItem);
    bool updateJsonData(const LXProcedureItem* procItem);
    bool updateBinData(const LXProcedureItem* procItem);
    bool updateImageData(const LXProcedureItem* procItem);
    bool deleteProcedure(const LXProcedureItem* procItem);
    QString queryJsonData(const LXProcedureItem* procItem);

    qint64 addLinker(const LinkerItem* linkerItem);
    bool updateData(const LinkerItem* linkerItem);
    bool deleteLinker(const LinkerItem* linkerItem);
    QVector<LinkerItem*> loadLinkers(const QVector<LXProcedureItem*> &procs);

    bool addImage(const QString& uuid, const QString& name, const cv::Mat& mat);
    bool deleteImage(const QString &uuid);
    void loadImages();

private:
    const QString mConnectionName;
    const QString mProjFilePath;

private:
    Q_DISABLE_COPY_MOVE(ProjectDB)
};

#endif // DATA_PROJECT_DB_H
