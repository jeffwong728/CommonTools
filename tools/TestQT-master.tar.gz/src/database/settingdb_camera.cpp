#include "settingdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/runpage.h>
#include <laser_x_camera.h>
#include <laser_x_devicemanager.h>

bool SettingDB::addCamera(const QString& uuid, const QString& pluginType, const QVariantMap& params)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO cameras (UUID, PluginType, Params) VALUES (?, ?, ?)")))
    {
        qCritical() << QStringLiteral("Add into cameras in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, uuid);
    query.bindValue(1, pluginType);

    QJsonDocument doc = QJsonDocument::fromVariant(params);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    QString jsonParams = QString::fromUtf8(buffer);
    query.bindValue(2, jsonParams);

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into cameras in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::deleteCamera(const QString& uuid)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM cameras WHERE UUID = '%1'; ").arg(uuid)))
    {
        qCritical() << QStringLiteral("Delete from cameras in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::updateCamera(const QString& uuid, const QString& paramsData)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE cameras SET Params = '%1' WHERE UUID = '%2';").arg(paramsData, uuid)))
    {
        qCritical() << QStringLiteral("Update cameras in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

void SettingDB::loadAllCameras(LaserXDeviceManager* deviceManager)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT UUID, PluginType, Params FROM cameras;")))
    {
        qCritical() << QStringLiteral("Search cameras in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
    }

    while (query.next())
    {
        QString uuid = query.value(0).toString();
        QString typeName = query.value(1).toString();
        QString paramsJson = query.value(2).toString();
        LaserXCameraManager* camManager = deviceManager->getCameraManager(typeName);
        if (camManager)
        {
            QJsonParseError jsonError;
            QByteArray jsonData = paramsJson.toUtf8();
            QJsonDocument doc = QJsonDocument::fromJson(jsonData, &jsonError);
            QVariantMap params = doc.toVariant().toMap();
            LaserXCamera* cam = camManager->createCamera(params);
            if (cam)
            {
                cam->open(params);
                cam->setParameters(params);
                camManager->addCamera(cam);
            }
        }
        else
        {
            gRunPage->logError(QStringLiteral("Camera Plugin %1 not loaded").arg(typeName));
        }
        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
    }
}

bool SettingDB::createCameraTable(QSqlQuery& query)
{
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS cameras (Id INTEGER PRIMARY KEY, UUID TEXT NOT NULL UNIQUE, PluginType TEXT NOT NULL, Params TEXT);")))
    {
        qCritical() << QStringLiteral("Open cameras in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }
    else
    {
        return true;
    }
}
