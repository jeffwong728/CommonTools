#include "loggingdb.h"
#include <QtGui>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>

LoggingDB::LoggingDB(const QString& logFilePath)
    : mConnectionName(QStringLiteral("LXLoggingConnection"))
    , mLogFilePath(logFilePath)
{
    open();
}

LoggingDB::~LoggingDB()
{
    close();
}

bool LoggingDB::open()
{
    if (QSqlDatabase::contains(mConnectionName))
    {
        qWarning() << QStringLiteral("Connection to logging file %1 already established!!!").arg(mLogFilePath);
        return true;
    }

    mDB = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), mConnectionName);
    mDB.setDatabaseName(mLogFilePath);
    if (!mDB.open())
    {
        qCritical() << QStringLiteral("Open logging file %1 failed. (%2)").arg(mLogFilePath, mDB.lastError().text());
        return false;
    }

    QSqlQuery query(mDB);
    if (!createPositionTable(query))
    {
        return false;
    }

    return true;
}

bool LoggingDB::close()
{
    if (!QSqlDatabase::contains(mConnectionName))
    {
        qWarning() << QStringLiteral("Connection to logging file %1 already closed!!!").arg(mLogFilePath);
        return true;
    }

    if (mDB.isOpen())
    {
        mDB.close();
    }

    mDB = QSqlDatabase();
    QSqlDatabase::removeDatabase(mConnectionName);
    return true;
}

bool LoggingDB::createPositionTable(QSqlQuery& query)
{
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS positions (Id INTEGER PRIMARY KEY, Name TEXT, CenterX REAL, CenterY REAL, Angle REAL, Score REAL, Success INTEGER, TimeStamp TEXT, Image BLOB);")))
    {
        qCritical() << QStringLiteral("Open positions in logging file %1 failed. (%2)").arg(mLogFilePath, query.lastError().text());
        return false;
    }

    if (!query.exec(QStringLiteral("CREATE VIEW IF NOT EXISTS pure_positions AS SELECT Id, Name, CenterX, CenterY, Angle, Score, Success, TimeStamp FROM positions;")))
    {
        qCritical() << QStringLiteral("Open positions in logging file %1 failed. (%2)").arg(mLogFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool LoggingDB::isOpened() const
{
    return mDB.isOpen();
}

bool LoggingDB::addPosition(const QString& name, const QJsonObject& rObj)
{
    if (!mDB.isOpen())
    {
        qCritical() << QStringLiteral("Logging file %1 is not open.").arg(mLogFilePath);
        return false;
    }

    QSqlQuery query(mDB);
    if (!query.prepare(QStringLiteral("INSERT INTO positions (Name, CenterX, CenterY, Angle, Score, Success, TimeStamp) VALUES (?, ?, ?, ?, ?, ?, datetime('now','localtime'))")))
    {
        qCritical() << QStringLiteral("Add into positions in logging file %1 failed. (%2)").arg(mLogFilePath, query.lastError().text());
        return false;
    }

    QJsonArray xList = rObj[QLatin1String("CenterXList")].toArray();
    QJsonArray yList = rObj[QLatin1String("CenterYList")].toArray();
    QJsonArray aList = rObj[QLatin1String("AngleList")].toArray();
    QJsonArray sList = rObj[QLatin1String("ScoreList")].toArray();

    query.bindValue(0, name);
    query.bindValue(1, xList.empty() ? 0.0 : xList[0].toDouble());
    query.bindValue(2, yList.empty() ? 0.0 : yList[0].toDouble());
    query.bindValue(3, aList.empty() ? 0.0 : aList[0].toDouble());
    query.bindValue(4, sList.empty() ? 0.0 : sList[0].toDouble());
    query.bindValue(5, rObj[QLatin1String("Success")].toBool());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into positions in logging file %1 failed. (%2)").arg(mLogFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool LoggingDB::addPosition(const QString& name, const QJsonObject& rObj, const cv::Mat& mat)
{
    if (!mDB.isOpen())
    {
        qCritical() << QStringLiteral("Logging file %1 is not open.").arg(mLogFilePath);
        return false;
    }

    QSqlQuery query(mDB);
    if (!query.prepare(QStringLiteral("INSERT INTO positions (Name, CenterX, CenterY, Angle, Score, Success, TimeStamp, Image) VALUES (?, ?, ?, ?, ?, ?, datetime('now','localtime'), ?)")))
    {
        qCritical() << QStringLiteral("Add into positions in logging file %1 failed. (%2)").arg(mLogFilePath, query.lastError().text());
        return false;
    }

    QByteArray data;
    QBuffer buffer(&data);
    buffer.open(QIODevice::WriteOnly);
    QImage image = QUIHelper::fromCVMat(mat);
    image.save(&buffer, "PNG");

    QJsonArray xList = rObj[QLatin1String("CenterXList")].toArray();
    QJsonArray yList = rObj[QLatin1String("CenterYList")].toArray();
    QJsonArray aList = rObj[QLatin1String("AngleList")].toArray();
    QJsonArray sList = rObj[QLatin1String("ScoreList")].toArray();

    query.bindValue(0, name);
    query.bindValue(1, xList.empty() ? 0.0 : xList[0].toDouble());
    query.bindValue(2, yList.empty() ? 0.0 : yList[0].toDouble());
    query.bindValue(3, aList.empty() ? 0.0 : aList[0].toDouble());
    query.bindValue(4, sList.empty() ? 0.0 : sList[0].toDouble());
    query.bindValue(5, rObj[QLatin1String("Success")].toBool());
    query.bindValue(6, data);

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into positions in logging file %1 failed. (%2)").arg(mLogFilePath, query.lastError().text());
        return false;
    }

    return true;
}
