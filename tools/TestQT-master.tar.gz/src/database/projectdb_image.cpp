#include "projectdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <manager/image_resource_manager.h>

bool ProjectDB::addCameraPerProjectData(const QString& uuid, const QString& data)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO cameras (UUID, Data) VALUES (?, ?)")))
    {
        qCritical() << QStringLiteral("Add camera into project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, uuid);
    query.bindValue(1, data);

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add camera into project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::updateCameraPerProjectData(const QString& uuid, const QString& data)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("UPDATE cameras SET Data = ? WHERE UUID = ?;")))
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, data);
    query.bindValue(1, uuid);

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::deleteCameraPerProjectData(const QString& uuid)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM cameras WHERE UUID = '%1'; ").arg(uuid)))
    {
        qCritical() << QStringLiteral("Delete camera from project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

QString ProjectDB::queryCameraPerProjectData(const QString& uuid)
{
    QString camProjData;
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return camProjData;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Data FROM cameras WHERE UUID = '%1';").arg(uuid)))
    {
        qCritical() << QStringLiteral("Search cameras in project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return camProjData;
    }

    if (query.next())
    {
        camProjData = query.value(0).toString();
    }

    return camProjData;
}
