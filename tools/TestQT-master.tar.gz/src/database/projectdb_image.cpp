#include "projectdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <manager/image_resource_manager.h>

bool ProjectDB::addImage(const QString& uuid, const QString& name, const cv::Mat& mat)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO images (Name, UUID, Data) VALUES (?, ?, ?)")))
    {
        qCritical() << QStringLiteral("Add image into project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    QByteArray data;
    QBuffer buffer(&data);
    buffer.open(QIODevice::WriteOnly);
    QImage image = QUIHelper::fromCVMat(mat);
    image.save(&buffer, "PNG");

    query.bindValue(0, name);
    query.bindValue(1, uuid);
    query.bindValue(2, data);

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add image into project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::deleteImage(const QString& uuid)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM images WHERE UUID = '%1'; ").arg(uuid)))
    {
        qCritical() << QStringLiteral("Delete image from project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

void ProjectDB::loadImages()
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Name, UUID, Data FROM images;")))
    {
        qCritical() << QStringLiteral("Query images in file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
    }

    while (query.next())
    {
        QString name = query.value(0).toString();
        QString uuid = query.value(1).toString();
        QByteArray data = query.value(2).toByteArray();

        QImage image;
        if (image.loadFromData(data, "PNG"))
        {
            cv::Mat mat = QUIHelper::toCVMat(image).clone();
            gImageManager->addImage(uuid, name, mat);
        }
    }
}
