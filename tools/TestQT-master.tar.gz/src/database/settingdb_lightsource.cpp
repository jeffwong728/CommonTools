#include "settingdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <laser_x_led_controller.h>
#include <laser_x_devicemanager.h>

bool SettingDB::addLightSource(const LaserXLEDController* lightSource)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO lightSources (Type, UUID, NumChannels, Params) VALUES (?, ?, ?, ?)")))
    {
        qCritical() << QStringLiteral("Add into lightSources in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, lightSource->type());
    query.bindValue(1, lightSource->uuid());
    query.bindValue(2, lightSource->numChannels());
    query.bindValue(3, lightSource->getJson());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into lightSources in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::deleteLightSource(const LaserXLEDController* lightSource)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM lightSources WHERE UUID = '%1'; ").arg(lightSource->uuid())))
    {
        qCritical() << QStringLiteral("Delete from lightSources in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::updateLightSource(const LaserXLEDController* lightSource)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE lightSources SET Params = '%1' WHERE UUID = '%2';").arg(lightSource->getJson(), lightSource->uuid())))
    {
        qCritical() << QStringLiteral("Update lightSources in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

void SettingDB::loadAllLightSource(LaserXDeviceManager* deviceManager)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Type, UUID, NumChannels, Params FROM lightSources;")))
    {
        qCritical() << QStringLiteral("Search light sources in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return;
    }

    while (query.next())
    {
        const QString type = query.value(0).toString();
        const QString uuid = query.value(1).toString();
        const qlonglong numChannels = query.value(2).toLongLong();
        const QString params = query.value(3).toString();

        LaserXLEDController* lightSource = deviceManager->newLEDController(type, numChannels, uuid);
        lightSource->setJson(params);
        deviceManager->addLEDController(lightSource);
    }
}

bool SettingDB::createLightSourceTable(QSqlQuery& query)
{
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS lightSources (Id INTEGER PRIMARY KEY, Type TEXT NOT NULL, UUID TEXT NOT NULL UNIQUE, NumChannels INTEGER NOT NULL, Params TEXT);")))
    {
        qCritical() << QStringLiteral("Open lightSources in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }
    else
    {
        return true;
    }
}
