#include "settingdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <laser_x_serialport.h>
#include <laser_x_devicemanager.h>

bool SettingDB::addSerialPort(const QString& portName, const QString& uuid, const QString& paramsData)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO serialPorts (PortName, UUID, Params) VALUES (?, ?, ?)")))
    {
        qCritical() << QStringLiteral("Add into serialPorts in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, portName);
    query.bindValue(1, uuid);
    query.bindValue(2, paramsData);

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into serialPorts in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::deleteSerialPort(const QString& uuid)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM serialPorts WHERE UUID = '%1'; ").arg(uuid)))
    {
        qCritical() << QStringLiteral("Delete from serialPorts in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::updateSerialPort(const QString& uuid, const QString& paramsData)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE serialPorts SET Params = '%1' WHERE UUID = '%2';").arg(paramsData, uuid)))
    {
        qCritical() << QStringLiteral("Update serialPorts in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

void SettingDB::loadAllSerialPort(LaserXDeviceManager* deviceManager)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT PortName, UUID, Params FROM serialPorts;")))
    {
        qCritical() << QStringLiteral("Search serial ports in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return;
    }

    while (query.next())
    {
        QString portName = query.value(0).toString();
        QString uuid = query.value(1).toString();
        QString params = query.value(2).toString();

        LaserXSerialPort *comPort = deviceManager->newSerialPort(uuid);
        comPort->setPortName(portName);
        comPort->setParameters(params);
        comPort->open(QSerialPort::ReadWrite);
        deviceManager->addSerialPort(comPort);
    }
}

bool SettingDB::createSerialPortTable(QSqlQuery& query)
{
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS serialPorts (Id INTEGER PRIMARY KEY, PortName TEXT NOT NULL UNIQUE, UUID TEXT NOT NULL UNIQUE, Params TEXT);")))
    {
        qCritical() << QStringLiteral("Open serialPorts in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }
    else
    {
        return true;
    }
}
