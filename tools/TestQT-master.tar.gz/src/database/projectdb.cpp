#include "projectdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <ui/flowchart/procedure/linkeritem.h>
#include <procedure/lxprocedure.h>

ProjectDB::ProjectDB(const QString& projFilePath)
    : mConnectionName(QStringLiteral("LXProjectConnection"))
    , mProjFilePath(projFilePath)
{
    open();
}

ProjectDB::~ProjectDB()
{
    close();
}

bool ProjectDB::isValid() const
{
    if (QSqlDatabase::contains(mConnectionName))
    {
        QSqlDatabase db = QSqlDatabase::database(mConnectionName, false);
        return db.isValid() && db.isOpen();
    }

    return false;
}

bool ProjectDB::open()
{
    if (QSqlDatabase::contains(mConnectionName))
    {
        qWarning() << QStringLiteral("Connection to %1 already established!!!").arg(mProjFilePath);
        return true;
    }

    QSqlDatabase db = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), mConnectionName);
    db.setDatabaseName(mProjFilePath);
    if (!db.open())
    {
        qCritical() << QStringLiteral("Open project file %1 failed (%2)").arg(mProjFilePath, db.lastError().text());
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS procedures (Id INTEGER PRIMARY KEY, Name TEXT, Type TEXT NOT NULL, UUID TEXT NOT NULL UNIQUE, GeomData TEXT NOT NULL, JsonData TEXT, BinData BLOB, ImageData BLOB);")))
    {
        qCritical() << QStringLiteral("Open project file %1 failed (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS linkers (Id INTEGER PRIMARY KEY, UUID TEXT NOT NULL UNIQUE, Data TEXT NOT NULL);")))
    {
        qCritical() << QStringLiteral("Open project file %1 failed (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS cameras (Id INTEGER PRIMARY KEY, UUID TEXT NOT NULL UNIQUE, Data BLOB NOT NULL);")))
    {
        qCritical() << QStringLiteral("Open project file %1 failed (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::close()
{
    if (!QSqlDatabase::contains(mConnectionName))
    {
        qWarning() << QStringLiteral("Connection to %1 already closed!!!").arg(mProjFilePath);
        return true;
    }

    {
        QSqlDatabase db = QSqlDatabase::database(mConnectionName, false);
        if (db.isOpen())
        {
            db.close();
        }
    }

    QSqlDatabase::removeDatabase(mConnectionName);
    return true;
}

qint64 ProjectDB::addProcedure(const LXProcedureItem* procItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return 0;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO procedures (Name, Type, UUID, GeomData, JsonData, BinData, ImageData) VALUES (?, ?, ?, ?, ?, ?, ?);")))
    {
        qCritical() << QStringLiteral("Insert into project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return 0;
    }

    query.bindValue(0, procItem->getName());
    query.bindValue(1, procItem->getType());
    query.bindValue(2, procItem->getUUID());
    query.bindValue(3, procItem->getJson());
    query.bindValue(4, procItem->getLXProcedure() ? procItem->getLXProcedure()->getJson() : QString());
    query.bindValue(5, procItem->getLXProcedure() ? procItem->getLXProcedure()->getBlob() : QByteArray());
    query.bindValue(6, procItem->getLXProcedure() ? procItem->getLXProcedure()->getImageData() : QByteArray());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Insert into project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return 0;
    }

    return query.lastInsertId().toLongLong();
}

QVector<LXProcedureItem*> ProjectDB::loadProcedures()
{
    QVector<LXProcedureItem*> iProcs;
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return iProcs;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Id, Name, Type, UUID, GeomData, JsonData, BinData, ImageData FROM procedures;")))
    {
        qCritical() << QStringLiteral("Search procedures in file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return iProcs;
    }

    while (query.next())
    {
        qlonglong id = query.value(0).toLongLong();
        QString name = query.value(1).toString();
        QString type = query.value(2).toString();
        QString uuid = query.value(3).toString();
        QString data = query.value(4).toString();
        QString jsonData = query.value(5).toString();
        QByteArray blobData = query.value(6).toByteArray();
        QByteArray imageData = query.value(7).toByteArray();

        LXProcedureItem* item = new LXProcedureItem(name, type, uuid, data, jsonData, blobData, imageData);
        item->setId(id);
        iProcs.push_back(item);
    }

    return iProcs;
}

bool ProjectDB::updateName(const LXProcedureItem* procItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("UPDATE procedures SET Name = ? WHERE UUID = ?;")))
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, procItem->getName());
    query.bindValue(1, procItem->getUUID());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::updateGeomData(const LXProcedureItem* procItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("UPDATE procedures SET GeomData = ? WHERE UUID = ?;")))
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, procItem->getJson());
    query.bindValue(1, procItem->getUUID());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::updateJsonData(const LXProcedureItem* procItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("UPDATE procedures SET JsonData = ? WHERE UUID = ?;")))
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, procItem->getLXProcedure()->getJson());
    query.bindValue(1, procItem->getUUID());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::updateBinData(const LXProcedureItem* procItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("UPDATE procedures SET BinData = ? WHERE UUID = ?;")))
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, procItem->getLXProcedure()->getBlob());
    query.bindValue(1, procItem->getUUID());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::updateImageData(const LXProcedureItem* procItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("UPDATE procedures SET ImageData = ? WHERE UUID = ?;")))
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, procItem->getLXProcedure()->getImageData());
    query.bindValue(1, procItem->getUUID());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::deleteProcedure(const LXProcedureItem* procItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM procedures WHERE UUID = '%1';").arg(procItem->getUUID())))
    {
        qCritical() << QStringLiteral("Delete from project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

QString ProjectDB::queryJsonData(const LXProcedureItem* procItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return QString();
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT JsonData FROM procedures WHERE UUID = '%1';").arg(procItem->getUUID())))
    {
        qCritical() << QStringLiteral("Search procedures in file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return QString();
    }

    if (query.next())
    {
        return query.value(0).toString();
    }
    else
    {
        return QString();
    }
}

qint64 ProjectDB::addLinker(const LinkerItem* linkerItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return 0;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO linkers (UUID, Data) VALUES (?, ?);")))
    {
        qCritical() << QStringLiteral("Insert into project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return 0;
    }

    query.bindValue(0, linkerItem->getUUID());
    query.bindValue(1, linkerItem->getJson());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Insert into project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return 0;
    }

    return query.lastInsertId().toLongLong();
}

bool ProjectDB::updateData(const LinkerItem* linkerItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("UPDATE linkers SET Data = ? WHERE UUID = ?;")))
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, linkerItem->getJson());
    query.bindValue(1, linkerItem->getUUID());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Update project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool ProjectDB::deleteLinker(const LinkerItem* linkerItem)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM linkers WHERE UUID = '%1'; ").arg(linkerItem->getUUID())))
    {
        qCritical() << QStringLiteral("Delete from project file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return false;
    }

    return true;
}

QVector<LinkerItem*> ProjectDB::loadLinkers(const QVector<LXProcedureItem*>& procs)
{
    QVector<LinkerItem*> iLinkers;
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Project file %1 is not open.").arg(mProjFilePath);
        return iLinkers;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Id, UUID, Data FROM linkers;")))
    {
        qCritical() << QStringLiteral("Search linkers in file %1 failed. (%2)").arg(mProjFilePath, query.lastError().text());
        return iLinkers;
    }

    while (query.next())
    {
        qlonglong id = query.value(0).toLongLong();
        QString uuid = query.value(1).toString();
        QString data = query.value(2).toString();

        LinkerItem* item = LinkerItem::loadLinker(procs, uuid, data);
        if (item)
        {
            item->setId(id);
            iLinkers.push_back(item);
        }
    }

    return iLinkers;
}
