#include "settingdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/runpage.h>
#include <laser_x_motion.h>
#include <laser_x_devicemanager.h>

bool SettingDB::addMotionDevice(const QString& uuid, const QString& pluginType, const QVariantMap& params)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO MotionDevices (UUID, PluginType, Params) VALUES (?, ?, ?)")))
    {
        qCritical() << QStringLiteral("Add into MotionDevices in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, uuid);
    query.bindValue(1, pluginType);

    QJsonDocument doc = QJsonDocument::fromVariant(params);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    QString jsonParams = QString::fromUtf8(buffer);
    query.bindValue(2, jsonParams);

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into MotionDevices in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::deleteMotionDevice(const QString& uuid)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM MotionDevices WHERE UUID = '%1'; ").arg(uuid)))
    {
        qCritical() << QStringLiteral("Delete from MotionDevices in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::updateMotionDevice(const QString& uuid, const QString& paramsData)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE MotionDevices SET Params = '%1' WHERE UUID = '%2';").arg(paramsData, uuid)))
    {
        qCritical() << QStringLiteral("Update MotionDevices in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

void SettingDB::loadAllMotionDevices(LaserXDeviceManager* deviceManager)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT UUID, PluginType, Params FROM MotionDevices;")))
    {
        qCritical() << QStringLiteral("Search MotionDevices in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
    }

    while (query.next())
    {
        QString uuid = query.value(0).toString();
        QString typeName = query.value(1).toString();
        QString paramsJson = query.value(2).toString();
        LaserXMotionManager* manager = deviceManager->findMotionManager(typeName);
        if (manager)
        {
            QJsonParseError jsonError;
            QByteArray jsonData = paramsJson.toUtf8();
            QJsonDocument doc = QJsonDocument::fromJson(jsonData, &jsonError);
            QVariantMap params = doc.toVariant().toMap();
            LaserXMotionDevice* dev = manager->createMotionDevice(params);
            if (dev)
            {
                dev->open(params);
                dev->setParameters(params);
                dev->setEnabledAll(true);
                manager->addMotionDevice(dev);
            }
        }
        else
        {
            gRunPage->logError(QStringLiteral("Motion Plugin %1 not loaded").arg(typeName));
        }
        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
    }
}

bool SettingDB::createMotionDeviceTable(QSqlQuery& query)
{
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS MotionDevices (Id INTEGER PRIMARY KEY, UUID TEXT NOT NULL UNIQUE, PluginType TEXT NOT NULL, Params TEXT);")))
    {
        qCritical() << QStringLiteral("Open MotionDevices in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }
    else
    {
        return true;
    }
}
