#include "settingdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <laser_x_lens_controller.h>
#include <laser_x_devicemanager.h>

bool SettingDB::addLensController(const LaserXLensController* lens)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO lensControllers (Type, UUID, Params) VALUES (?, ?, ?)")))
    {
        qCritical() << QStringLiteral("Add into lensControllers in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, lens->type());
    query.bindValue(1, lens->uuid());
    query.bindValue(2, lens->getJson());

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add into lensControllers in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::deleteLensController(const LaserXLensController* lens)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM lensControllers WHERE UUID = '%1'; ").arg(lens->uuid())))
    {
        qCritical() << QStringLiteral("Delete from lensControllers in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::updateLensController(const LaserXLensController* lens)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE lensControllers SET Params = '%1' WHERE UUID = '%2';").arg(lens->getJson(), lens->uuid())))
    {
        qCritical() << QStringLiteral("Update lensControllers in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

void SettingDB::loadAllLensController(LaserXDeviceManager* deviceManager)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Type, UUID, Params FROM lensControllers;")))
    {
        qCritical() << QStringLiteral("Search lens controller in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return;
    }

    while (query.next())
    {
        const QString type = query.value(0).toString();
        const QString uuid = query.value(1).toString();
        const QString params = query.value(2).toString();

        LaserXLensController* iLens = deviceManager->newLensController(type, uuid);
        iLens->setJson(params);
        deviceManager->addLensController(iLens);
    }
}

bool SettingDB::createLensControllerTable(QSqlQuery& query)
{
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS lensControllers (Id INTEGER PRIMARY KEY, Type TEXT NOT NULL, UUID TEXT NOT NULL UNIQUE, Params TEXT);")))
    {
        qCritical() << QStringLiteral("Open lensControllers in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }
    else
    {
        return true;
    }
}
