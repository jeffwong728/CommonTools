#ifndef DATA_LOGGING_DB_H
#define DATA_LOGGING_DB_H
#include <QtCore>
#include <QtSql>
#include <opencv2/opencv.hpp>
class QSqlQuery;

class LoggingDB
{
public:
    LoggingDB(const QString& logFilePath);
    ~LoggingDB();

public:
    bool isOpened() const;
    bool addPosition(const QString& name, const QJsonObject& rObj);
    bool addPosition(const QString &name, const QJsonObject &rObj, const cv::Mat& mat);

    QVariantList getValues(const QString& name, const QJsonObject& rObj) const;
    QVariantList getValues(const QString& name, const QJsonObject& rObj, const cv::Mat& mat) const;
    bool addPosition(const QVariantList vals);

private:
    bool open();
    bool close();
    bool createPositionTable(QSqlQuery& query);

private:
    const QString mLogFilePath;
    const QString mConnectionName;
    QSqlDatabase mDB;

private:
    Q_DISABLE_COPY_MOVE(LoggingDB)
};

#endif // DATA_LOGGING_DB_H
