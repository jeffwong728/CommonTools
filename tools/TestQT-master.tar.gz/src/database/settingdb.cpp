#include "settingdb.h"
#include <QtGui>
#include <QtSql>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>

SettingDB::SettingDB()
    : mConnectionName(QStringLiteral("LXProjectListConnection"))
    , mSettingFilePath()
{
    setSettingFilePath();
    open();
}

SettingDB::~SettingDB()
{
    close();
}

void SettingDB::setSettingFilePath()
{
    const_cast<QString &>(mSettingFilePath) = QAppHelper::getSetting<QString>(gAppSettingPath);
}

bool SettingDB::open()
{
    if (QSqlDatabase::contains(mConnectionName))
    {
        qWarning() << QStringLiteral("Connection to setting file %1 already established!!!").arg(mSettingFilePath);
        return true;
    }

    QSqlDatabase db = QSqlDatabase::addDatabase(QStringLiteral("QSQLITE"), mConnectionName);
    db.setDatabaseName(mSettingFilePath);
    if (!db.open())
    {
        qCritical() << QStringLiteral("Open setting file %1 failed. (%2)").arg(mSettingFilePath, db.lastError().text());
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS projects (Id INTEGER PRIMARY KEY, Name TEXT NOT NULL UNIQUE, Path TEXT NOT NULL);")))
    {
        qCritical() << QStringLiteral("Open projects in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS settings (Id INTEGER PRIMARY KEY, Name TEXT NOT NULL UNIQUE, Val);")))
    {
        qCritical() << QStringLiteral("Open settings in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    if (!query.exec(QStringLiteral("CREATE TABLE IF NOT EXISTS users (Id INTEGER PRIMARY KEY, Name TEXT, Privilege TEXT, Data BLOB NOT NULL, UNIQUE(Name, Privilege));")))
    {
        qCritical() << QStringLiteral("Open users in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    createSerialPortTable(query);
    createCameraTable(query);
    createNetListenerTable(query);
    createNetSenderTable(query);
    createLightSourceTable(query);
    createMotionDeviceTable(query);

    return true;
}

bool SettingDB::close()
{
    if (!QSqlDatabase::contains(mConnectionName))
    {
        qWarning() << QStringLiteral("Connection to setting file %1 already closed!!!").arg(mSettingFilePath);
        return true;
    }

    {
        QSqlDatabase db = QSqlDatabase::database(mConnectionName, false);
        if (db.isOpen())
        {
            db.close();
        }
    }

    QSqlDatabase::removeDatabase(mConnectionName);
    return true;
}

QStringList SettingDB::getProjectNames()
{
    QStringList projList;
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return projList;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Name FROM projects;")))
    {
        qCritical() << QStringLiteral("Search projects in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return projList;
    }

    while (query.next())
    {
        projList.push_back(query.value(0).toString());
    }

    return projList;
}

bool SettingDB::isProjectExist(const QString& projName)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Name FROM projects WHERE Name = '%1';").arg(projName)))
    {
        qCritical() << QStringLiteral("Search projects in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return query.next();
}

bool SettingDB::addProject(const QString& projName, const QString& projFilePath)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("INSERT INTO projects (Name, Path) VALUES ('%1', '%2');").arg(projName, projFilePath)))
    {
        qCritical() << QStringLiteral("Insert into projects in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::deleteProject(const QString& projName)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("DELETE FROM projects WHERE Name = '%1'; ").arg(projName)))
    {
        qCritical() << QStringLiteral("Delete from projects in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

QString SettingDB::getProjectPath(const QString& projName)
{
    QString projPath;
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return projPath;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Path FROM projects WHERE Name = '%1';").arg(projName)))
    {
        qCritical() << QStringLiteral("Search projects in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return projPath;
    }

    if (query.next())
    {
        projPath = query.value(0).toString();
    }

    return projPath;
}

bool SettingDB::updateProject(const QString& oldProjName, const QString& newProjName, const QString& newProjFilePath)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE projects SET Name = '%1', Path = '%2' WHERE Name = '%3';").arg(newProjName, newProjFilePath, oldProjName)))
    {
        qCritical() << QStringLiteral("Update projects in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

bool SettingDB::isUserExist(const QString& userName, const QString& userGroup)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Name FROM users WHERE Name = '%1' AND Privilege = '%2';").arg(userName, userGroup)))
    {
        qCritical() << QStringLiteral("Search user in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return query.next();
}

bool SettingDB::addUser(const QString& userName, const QString& userGroup, const QByteArray& data)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.prepare(QStringLiteral("INSERT INTO users (Name, Privilege, Data) VALUES (?, ?, ?)")))
    {
        qCritical() << QStringLiteral("Add user into users in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    query.bindValue(0, userName);
    query.bindValue(1, userGroup);
    query.bindValue(2, data);

    if (!query.exec())
    {
        qCritical() << QStringLiteral("Add user into users in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    return true;
}

QByteArray SettingDB::getUserData(const QString& userName, const QString& userGroup)
{
    QByteArray data;
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return data;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Data FROM users WHERE Name = '%1' AND Privilege = '%2';").arg(userName, userGroup)))
    {
        qCritical() << QStringLiteral("Search user in setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return data;
    }

    if (query.next())
    {
        data = query.value(0).toByteArray();
    }

    return data;
}

bool SettingDB::setSetting(const QString& name, const int value)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE settings SET Val = %1 WHERE Name = '%2';").arg(value).arg(name)))
    {
        qCritical() << QStringLiteral("Update setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    if (!query.numRowsAffected())
    {
        if (!query.exec(QStringLiteral("INSERT INTO settings (Name, Val) VALUES ('%1', %2);").arg(name).arg(value)))
        {
            qCritical() << QStringLiteral("Update setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
            return false;
        }
    }

    return true;
}

bool SettingDB::setSetting(const QString& name, const QString& value)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return false;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("UPDATE settings SET Val = '%2' WHERE Name = '%1';").arg(name, value)))
    {
        qCritical() << QStringLiteral("Update setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return false;
    }

    if (!query.numRowsAffected())
    {
        if (!query.exec(QStringLiteral("INSERT INTO settings (Name, Val) VALUES ('%1', '%2');").arg(name, value)))
        {
            qCritical() << QStringLiteral("Update setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
            return false;
        }
    }

    return true;
}

template <>
QString SettingDB::getSetting<QString>(const QString& name, const QString& defaultValue)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return defaultValue;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Val FROM settings WHERE Name = '%1';").arg(name)))
    {
        qCritical() << QStringLiteral("Search setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return defaultValue;
    }

    if (query.next())
    {
        return query.value(0).toString();
    }
    else
    {
        return defaultValue;
    }
}

template <>
int SettingDB::getSetting<int>(const QString& name, const int& defaultValue)
{
    QSqlDatabase db = QSqlDatabase::database(mConnectionName, true);
    if (!db.isOpen())
    {
        qCritical() << QStringLiteral("Setting file %1 is not open.").arg(mSettingFilePath);
        return defaultValue;
    }

    QSqlQuery query(db);
    if (!query.exec(QStringLiteral("SELECT Val FROM settings WHERE Name = '%1';").arg(name)))
    {
        qCritical() << QStringLiteral("Search setting file %1 failed. (%2)").arg(mSettingFilePath, query.lastError().text());
        return defaultValue;
    }

    if (query.next())
    {
        return query.value(0).toInt();
    }
    else
    {
        return defaultValue;
    }
}
