#include <QApplication>
#include <QStyleFactory>
#include <QFile>
#include <QTextStream>
#include <QTranslator>
#include <QMessageBox>
#include <QDir>
#include <cmndef.h>
#include <ui/mainframe.h>
#include <ui/dialog/account/logindialog.h>
#include <manager/image_resource_manager.h>
#include <util/quihelper.h>
#include <util/qapphelper.h>
#include <database/loggingdb.h>
#include <laser_x_vision.h>
#include <laser_x_devicemanager.h>
#include <opencv2/opencv.hpp>

class LaserXCamera;
class LaserXCanvas;
class QAbstractButton;
class QIODevice;
Q_DECLARE_OPAQUE_POINTER(LaserXCamera*)
Q_DECLARE_OPAQUE_POINTER(LaserXCanvas*)
Q_DECLARE_OPAQUE_POINTER(QAbstractButton*)
Q_DECLARE_OPAQUE_POINTER(QIODevice*)

MainFrame* gMainFrame = nullptr;
RunPage* gRunPage = nullptr;
LaserXDeviceManager* gDeviceManager = nullptr;
QUndoGroup* gUndoGroup = nullptr;
QUndoStack* gUndoStack = nullptr;
LaserXVisionManager* gVision = nullptr;
ImageResourceManager* gImageManager = nullptr;
FlowView* gFlowView = nullptr;
LoggingDB* gLogging = nullptr;

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);

    if (!QAppHelper::loadSetting())
    {
        return 0;
    }

    QString loggingPath = QAppHelper::getSetting<QString>(gAppLogDir) + QDir::separator() + QStringLiteral("logging.db");
    LoggingDB iLoggingDB(loggingPath);
    gLogging = &iLoggingDB;
    if (!iLoggingDB.isOpened())
    {
        QMessageBox msgBox;
        msgBox.setIcon(QMessageBox::Critical);
        msgBox.setText(QObject::tr("The application can't open logging file."));
        msgBox.exec();
        return 0;
    }

    QDir pluginsDir = QDir(QCoreApplication::applicationDirPath());
    pluginsDir.cd(QStringLiteral("plugins"));
    pluginsDir.cd(QStringLiteral("vision"));

    QPluginLoader loader(pluginsDir.absoluteFilePath(QStringLiteral("halconvision")));
    gVision = qobject_cast<LaserXVisionManager*>(loader.instance());
    if (!gVision)
    {
        QMessageBox msgBox;
        msgBox.setIcon(QMessageBox::Critical);
        msgBox.setText(QObject::tr("The application can't load vision plugin."));
        msgBox.exec();
        return 0;
    }

    QSystemSemaphore semaphore(QStringLiteral("{1F52EFFE-4C8B-4C1D-BC92-821B8D669E30}"), 1); 
    semaphore.acquire();

    QSharedMemory sharedMemory(QStringLiteral("{10A0DE3B-6B34-4F29-8A31-5EEE0D48AB3E}"));
    bool is_running = true;
    if (sharedMemory.attach())
    {
        is_running = true;
    }
    else
    {
        sharedMemory.create(1);
        is_running = false;
    }
    semaphore.release();

    if (is_running)
    {
        QMessageBox msgBox;
        msgBox.setIcon(QMessageBox::Warning);
        msgBox.setText(QObject::tr("The application is already running.\nAllowed to run only one instance of the application."));
        msgBox.exec();
        return 0;
    }

    QCoreApplication::setOrganizationName(QStringLiteral("Laser X"));
    QCoreApplication::setOrganizationDomain(QStringLiteral("http://www.laserx.net/"));
    QCoreApplication::setApplicationName(QStringLiteral("LaserXImage"));
    QCoreApplication::setApplicationVersion(QStringLiteral("1.0.0"));
    qSetMessagePattern(QStringLiteral("%{type} %{file}(%{line}): %{message}"));

    QCommandLineParser parser;
    parser.setApplicationDescription(QStringLiteral("LaserXImage"));
    parser.addHelpOption();
    parser.addVersionOption();

    QCommandLineOption userOption(QStringList() << QStringLiteral("u") << QStringLiteral("username"), QStringLiteral(""), QStringLiteral("username"));
    QCommandLineOption passOption(QStringList() << QStringLiteral("p") << QStringLiteral("password"), QStringLiteral(""), QStringLiteral("password"));
    QCommandLineOption groupOption(QStringList() << QStringLiteral("g") << QStringLiteral("group"), QStringLiteral(""), QStringLiteral("group"));
    parser.addOption(userOption);
    parser.addOption(passOption);
    parser.addOption(groupOption);
    parser.process(app);

    QString userName = parser.value(userOption);
    QString password = parser.value(passOption);
    QString groupName = parser.value(groupOption);

    userName = QStringLiteral("laserx");
    password = QStringLiteral("laserx");
    groupName = QStringLiteral("Administrator");

    QAppHelper::installCrashHandler();
    QUIHelper::iniIcons();
    QUIHelper::iniPixmaps();

    AppInit appini;
    qApp->installEventFilter(&appini);
    qRegisterMetaType<cv::Mat>();
    qRegisterMetaType<LaserXCamera*>();
    qRegisterMetaType<LaserXCanvas*>();
    qRegisterMetaType<QAbstractButton*>();
    qRegisterMetaType<QIODevice*>();

    ImageResourceManager imageManager;
    gImageManager = &imageManager;

    LaserXDeviceManager deviceManager(qApp);
    deviceManager.loadCameraPlugins(QAppHelper::getSetting<QString>(gAppCameraPlugins));
    gDeviceManager = &deviceManager;
    MainFrame w(userName, password, groupName, &deviceManager);
    QRect iRect = app.screens()[0]->availableGeometry();
    const int iW = QAppHelper::getSetting<int>(gAppMainUIWidth);
    if (QStringLiteral("right") == QAppHelper::getSetting<QString>(gAppMainUIAnchor))
    {
        w.setGeometry(QRect(iRect.width() - iW, 0, iW, iRect.height()));
    }
    else
    {
        w.setGeometry(QRect(0, 0, iW, iRect.height()));
    }
    w.showNormal();
    const auto ir = app.exec();
    loader.unload();

    QAppHelper::saveSetting();
    QAppHelper::uninstallCrashHandler();

    return ir;
}
