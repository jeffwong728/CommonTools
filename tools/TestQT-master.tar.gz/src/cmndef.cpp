#include "cmndef.h"

const QString gUILanguage               = QStringLiteral("UILanguage");
const QString gUITheme                  = QStringLiteral("UITheme");
const QString gAppImageFolder           = QStringLiteral("AppImageFolder");
const QString gAppUndoLimit             = QStringLiteral("AppUndoLimit");
const QString gAppProjsDir              = QStringLiteral("AppProjsDir");
const QString gAppOCRDir                = QStringLiteral("AppOCRDir");
const QString gAppScriptsDir            = QStringLiteral("AppScriptsDir");
const QString gAppProjPath              = QStringLiteral("AppProjPath");
const QString gAppSettingPath           = QStringLiteral("AppSettingPath");
const QString gAppCommandProcessControl = QStringLiteral("AppCommandProcessControl");
const QString gUIImageCross             = QStringLiteral("UIShowImageViewCenterCross");
const QString gUIImageXYAxis            = QStringLiteral("UIShowImageViewXYAxis");
const QString gUIFlowXYAxis             = QStringLiteral("UIShowFlowViewXYAxis");
const QString gUIRunTimeFile            = QStringLiteral("UIRunTimeUIFile");
const QString gUIImageProcess           = QStringLiteral("UIImageProcess");
const QString gAppProjTemp              = QStringLiteral("AppProjTemp");
const QString gAppLogDir                = QStringLiteral("AppLogDir");
const QString gAppMainUIAnchor          = QStringLiteral("AppMainUIAnchor");
const QString gAppMainUIWidth           = QStringLiteral("AppMainUIWidth");
const QString gAppCameraPlugins         = QStringLiteral("AppCameraPlugins");

const QString gTypeIOTrigger            = QStringLiteral("IOTrigger");
const QString gTypeSerialTrigger        = QStringLiteral("SerialTrigger");
const QString gTypeNetworkTrigger       = QStringLiteral("NetworkTrigger");
const QString gTypeSoftTrigger          = QStringLiteral("SoftTrigger");
const QString gTypeTimerTrigger         = QStringLiteral("TimerTrigger");
const QString gTypeImageLive            = QStringLiteral("ImageLive");
const QString gTypeImageGrabber         = QStringLiteral("ImageGrabber");
const QString gTypeNCCTemplate          = QStringLiteral("GrayTemplate");
const QString gTypeShapeTemplate        = QStringLiteral("ShapeTemplate");
const QString gTypeMultiShapeTemplate   = QStringLiteral("MultiShapeTemplate");
const QString gTypeRectTemplate         = QStringLiteral("RectTemplate");
const QString gTypeCircleTemplate       = QStringLiteral("CircleTemplate");
const QString gTypeBlobFinder           = QStringLiteral("BlobFinder");
const QString gTypeGeomMeasure          = QStringLiteral("GeomMeasure");
const QString gTypeCompoundProcess      = QStringLiteral("CompoundProcess");
const QString gTypeGeneralOCR           = QStringLiteral("GeneralOCR");
const QString gTypePretrainedOCR        = QStringLiteral("PretrainedOCR");
const QString gTypeCustomOCR            = QStringLiteral("CustomOCRFont");
const QString gTypeNccOCR               = QStringLiteral("GrayOCRFont");
const QString gTypeJSImageProcess       = QStringLiteral("JSImageProcess");

QString gGetErrorMsg(const int errId)
{
    switch (errId)
    {
    case kImageProcessError_NoError: return QStringLiteral("No error");
    case kImageProcessError_General: return QStringLiteral("General image process error");
    case kImageProcessError_CameraDisconnected: return QStringLiteral("Camera disconnected");
    case kImageProcessError_NoCamera: return QStringLiteral("No bound camera");
    case kImageProcessError_NoCanvas: return QStringLiteral("No bound canvas");
    case kImageProcessError_NoDie: return QStringLiteral("No die found");
    case kImageProcessError_BadDie: return QStringLiteral("Bad die found");
    case kImageProcessError_MultiDie: return QStringLiteral("Multiple dies found");
    case kImageProcessError_GrabConflict: return QStringLiteral("Camera is in continuous grab mode");
    case kImageProcessError_Stopped: return QStringLiteral("Image process stopped");
    case kImageProcessError_ProjectEditing: return QStringLiteral("Can't switch project when editing");
    case kImageProcessError_ProjectNotExists: return QStringLiteral("Project not exists");
    case kImageProcessError_ProjectInvalid: return QStringLiteral("Project not valid");
    default: return QStringLiteral("Unknown error");
    }
}
