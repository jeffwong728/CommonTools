#ifndef TRIGGER_PROCESSOR_H
#define TRIGGER_PROCESSOR_H
#include "triggerparams.h"
#include <QtCore>
#include <procedure/lxprocedure.h>
#include <laser_x_vision.h>
class QTcpSocket;

class TriggerProcessor : public LXProcedure, public TriggerParams
{
    Q_OBJECT

public:
    explicit TriggerProcessor();

public:
    void getJson(QJsonObject &rootObj) const;
    void setJson(const QJsonObject& jsonObj);
    void copyDataTo(TriggerProcessor*other) const;

public:
    virtual void onButtonCommand();
    virtual void processIODeviceCommand(QIODevice* ioDev, QJsonObject &cmdObj);
    void onSerialPortCommand(const QJsonDocument& cmdDoc);
    void onNetClientCommand();
    void onNetServerCommand(QTcpSocket* connection, const QJsonDocument& cmdDoc);

public:
    void disconnectExistingTriggerSources() override;
    void connectToTriggerSources() override;

signals:
    void processCompleted();

protected:
    qlonglong mCommandSN = 0;
};

#endif // TRIGGER_PROCESSOR_H
