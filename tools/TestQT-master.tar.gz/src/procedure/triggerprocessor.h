#ifndef TRIGGER_PROCESSOR_H
#define TRIGGER_PROCESSOR_H
#include "triggerparams.h"
#include <QtCore>
#include <procedure/lxprocedure.h>
#include <laser_x_vision.h>
class QTcpSocket;
class QGraphicsItem;
class LaserXCamera;

class TriggerProcessor : public LXProcedure, public TriggerParams
{
    Q_OBJECT

public:
    explicit TriggerProcessor();

public:
    void getJson(QJsonObject &rootObj) const;
    void setJson(const QJsonObject& jsonObj);
    void copyDataTo(TriggerProcessor*other) const;

public:
    virtual void onButtonCommand();
    virtual void processIODeviceCommand(QIODevice* ioDev, QJsonObject &cmdObj);
    void onSerialPortCommand(const QJsonDocument& cmdDoc);
    void onNetClientCommand();
    void onNetServerCommand(QTcpSocket* connection, const QJsonDocument& cmdDoc);

public:
    void disconnectExistingTriggerSources() override;
    void connectToTriggerSources() override;

public:
    void postLogError(const QString& msg);
    void postImage(LaserXCanvas* cav, const QString name, const cv::Mat mat);
    void postReply(QIODevice* ioDev, const QByteArray buffer);
    void postClearCanvas(LaserXCanvas* cav);
    void postTemporaryItems(LaserXCanvas* cav, const QList<QGraphicsItem*> items);
    void postInfoItems(LaserXCanvas* cav, const QStringList strInfos);
    void postData(const QVariantList vals);
    void postBindCamera(LaserXCanvas* cav, LaserXCamera* cam);
    void postCanvasSourceName(LaserXCanvas* cav, const QString name);

private slots:
    void logError(const QVariant msg);
    void displayImage(const QVariant cav, const QVariant name, const QVariant mat);
    void writeReply(const QVariant ioDev, const QVariant buffer);
    void clearCanvas(const QVariant cav);
    void appendTemporaryItems(const QVariant cav, const QVariant items);
    void appendInfoItems(const QVariant cav, const QVariant items);
    void logData(const QVariant vals);
    void bindCanvasAndCamera(const QVariant cav, const QVariant cam);
    void setCanvasSourceName(const QVariant cav, const QVariant name);

protected:
    qlonglong mCommandSN = 0;
};

class TriggerProcessorTimer
{
public:
    TriggerProcessorTimer(TriggerProcessor* processor, LaserXCanvas* canvas);
    ~TriggerProcessorTimer();

private:
    LaserXCanvas* const mCanvas;
    TriggerProcessor* const mProcessor;
    QElapsedTimer mTimer;
};

#endif // TRIGGER_PROCESSOR_H
