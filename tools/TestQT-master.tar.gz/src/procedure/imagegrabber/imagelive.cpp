#include "imagelive.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <QtConcurrent>
#include <cmndef.h>
#include <ui/runpage.h>
#include <ui/mainframe.h>
#include <laser_x_camera.h>
#include <laser_x_canvas.h>
#include <laser_x_devicemanager.h>

ImageLive::ImageLive()
    : mLiveType(QStringLiteral("StartLive"))
{
}

QString ImageLive::getTypeName() const
{
    return gTypeImageLive;
}

QString ImageLive::getJson() const
{
    QJsonObject rootObj;
    TriggerProcessor::getJson(rootObj);
    CameraParams::getJson(rootObj);
    OutputParams::getJson(rootObj);
    rootObj[QLatin1String("LiveType")] = mLiveType;
    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void ImageLive::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    TriggerProcessor::setJson(jsonObj);
    CameraParams::setJson(jsonObj);
    OutputParams::setJson(jsonObj);
    mLiveType = fromJson(jsonObj, QLatin1String("LiveType"), QLatin1String("StartLive"));

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (iCav)
    {
        iCav->bindCamera(nullptr);
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (iCam)
    {
        iCam->stopContinuousGrab();
    }
}

bool ImageLive::isValid() const
{
    return true;
}

void ImageLive::copyDataTo(ImageLive* other) const
{
    TriggerProcessor::copyDataTo(other);
    CameraParams::copyDataTo(other);
    OutputParams::copyDataTo(other);
    other->mLiveType = mLiveType;
}

void ImageLive::onButtonCommand()
{
    QAbstractButton* iButton = dynamic_cast<QAbstractButton*>(sender());
    if (iButton)
    {
        iButton->setEnabled(false);
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no camera").arg(name()));
        return;
    }

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (iCav)
    {
        iCav->setImageSourceName(iCam->name());
        iCav->clearAllTemporaryItems();
    }

    ScopedCanvasTimer timer(iCav);
    if (gkAsyncImageProcess)
    {
        QFuture<void> iLiveFuture = QtConcurrent::run(ImageLive::processLiveAsync, this, iCav, iCam, iButton, nullptr);
        Q_UNUSED(iLiveFuture);
    }
    else
    {
        QJsonObject rObj;
        processLive(iCav, rObj);
        iButton->setEnabled(true);
    }
}

void ImageLive::processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj)
{
    Q_UNUSED(cmdObj);
    if (!gMainFrame->mRunning)
    {
        gRunPage->logError(QStringLiteral("Image process stopped").arg(name()));
        sendLiveError(ioDev, kImageProcessError_Stopped);
        return;
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no camera").arg(name()));
        sendLiveError(ioDev, kImageProcessError_NoCamera);
        return;
    }

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (!iCav)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no canvas").arg(name()));
        sendLiveError(ioDev, kImageProcessError_NoCanvas);
        return;
    }

    iCav->setImageSourceName(iCam->name());
    iCav->clearAllTemporaryItems();

    if (gkAsyncImageProcess)
    {
        QFuture<void> iLiveFuture = QtConcurrent::run(ImageLive::processLiveAsync, this, iCav, iCam, nullptr, ioDev);
        Q_UNUSED(iLiveFuture);
    }
    else
    {
        QJsonObject rObj;
        if (processLive(iCav, rObj))
        {
            sendLiveSuccess(ioDev);
        }
        else
        {
            sendLiveError(ioDev, kImageProcessError_General);
        }
    }
}

bool ImageLive::processLive(LaserXCanvas* cav, QJsonObject& rObj)
{
    Q_UNUSED(rObj);

    if (!cav)
    {
        return false;
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        return false;
    }

    if (QStringLiteral("StartLive") == mLiveType)
    {
        iCam->setGrabParams(mCameraGrabParams);
        cav->bindCamera(iCam);
        iCam->startContinuousGrab();
    }
    else if (QStringLiteral("StopLive") == mLiveType)
    {
        iCam->stopContinuousGrab();
        cav->bindCamera(nullptr);
    }
    else
    {
        iCam->setGrabParams(mCameraGrabParams);
        cav->bindCamera(iCam);
        iCam->toggleContinuousGrab();
        if (!iCam->isContinuousGrab())
        {
            cav->bindCamera(nullptr);
        }
    }

    return true;
}

void ImageLive::processLiveAsync(ImageLive* me, LaserXCanvas* cav, LaserXCamera* cam, QAbstractButton* btn, QIODevice* ioDev)
{
    if (QStringLiteral("StartLive") == me->mLiveType)
    {
        cam->setGrabParams(me->mCameraGrabParams);
        me->sendBindCanvasAndCamera(cav, cam);
        cam->startContinuousGrab();
    }
    else if (QStringLiteral("StopLive") == me->mLiveType)
    {
        cam->stopContinuousGrab();
        me->sendBindCanvasAndCamera(cav, nullptr);
    }
    else
    {
        cam->setGrabParams(me->mCameraGrabParams);
        me->sendBindCanvasAndCamera(cav, cam);
        cam->toggleContinuousGrab();
        if (!cam->isContinuousGrab())
        {
            me->sendBindCanvasAndCamera(cav, nullptr);
        }
    }

    me->sendProcessLiveCompleted(kImageProcessError_NoError, btn, ioDev);
}

void ImageLive::sendProcessLiveCompleted(int errorCode, QAbstractButton* btn, QIODevice* ioDev)
{
    QMetaObject::invokeMethod(this, "processLiveCompleted", Qt::QueuedConnection, Q_ARG(int, errorCode), Q_ARG(QAbstractButton*, btn), Q_ARG(QIODevice*, ioDev));
}

void ImageLive::sendBindCanvasAndCamera(LaserXCanvas* cav, LaserXCamera* cam)
{
    QMetaObject::invokeMethod(this, "bindCanvasAndCamera", Qt::QueuedConnection, Q_ARG(LaserXCanvas*, cav), Q_ARG(LaserXCamera*, cam));
}

void ImageLive::processLiveCompleted(int errorCode, QAbstractButton* btn, QIODevice* ioDev)
{
    if (kImageProcessError_NoError == errorCode)
    {
        sendLiveSuccess(ioDev);
    }
    else
    {
        sendLiveError(ioDev, errorCode);
    }

    if (btn)
    {
        btn->setEnabled(true);
    }

    emit processCompleted();
}

void ImageLive::bindCanvasAndCamera(LaserXCanvas* cav, LaserXCamera* cam)
{
    if (cav)
    {
        cav->bindCamera(cam);
    }
}

void ImageLive::sendLiveSuccess(QIODevice* ioDev)
{
    if (!ioDev)
    {
        return;
    }

    QJsonObject rObj;
    rObj[QLatin1String("CommandName")] = mCommandName;
    rObj[QLatin1String("CommandSN")] = mCommandSN;
    rObj[QLatin1String("Success")] = true;
    rObj[QLatin1String("ErrorId")] = kImageProcessError_NoError;
    rObj[QLatin1String("ErrorMsg")] = gGetErrorMsg(kImageProcessError_NoError);
    rObj[QLatin1String("ImageWidth")] = 0;
    rObj[QLatin1String("ImageHeight")] = 0;

    QJsonDocument doc(rObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    buffer.append('\n');
    ioDev->write(buffer);
}

void ImageLive::sendLiveError(QIODevice* ioDev, int errId)
{
    if (!ioDev)
    {
        return;
    }

    QJsonObject rObj;
    rObj[QLatin1String("CommandName")] = mCommandName;
    rObj[QLatin1String("CommandSN")] = mCommandSN;
    rObj[QLatin1String("Success")] = false;
    rObj[QLatin1String("ErrorId")] = errId;
    rObj[QLatin1String("ErrorMsg")] = gGetErrorMsg(errId);
    rObj[QLatin1String("ImageWidth")] = 0;
    rObj[QLatin1String("ImageHeight")] = 0;

    QJsonDocument doc(rObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    buffer.append('\n');
    ioDev->write(buffer);
}
