#include "imagelive.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <QtConcurrent>
#include <cmndef.h>
#include <ui/runpage.h>
#include <ui/mainframe.h>
#include <laser_x_camera.h>
#include <laser_x_canvas.h>
#include <laser_x_devicemanager.h>

ImageLive::ImageLive()
    : mLiveType(QStringLiteral("StartLive"))
{
}

QString ImageLive::getTypeName() const
{
    return gTypeImageLive;
}

QString ImageLive::getJson() const
{
    QJsonObject rootObj;
    TriggerProcessor::getJson(rootObj);
    CameraParams::getJson(rootObj);
    OutputParams::getJson(rootObj);
    rootObj[QLatin1String("LiveType")] = mLiveType;
    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void ImageLive::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    TriggerProcessor::setJson(jsonObj);
    CameraParams::setJson(jsonObj);
    OutputParams::setJson(jsonObj);
    mLiveType = fromJson(jsonObj, QLatin1String("LiveType"), QLatin1String("StartLive"));

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (iCav)
    {
        iCav->bindCamera(nullptr);
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (iCam)
    {
        iCam->stopContinuousGrab();
    }
}

bool ImageLive::isValid() const
{
    return true;
}

void ImageLive::copyDataTo(ImageLive* other) const
{
    TriggerProcessor::copyDataTo(other);
    CameraParams::copyDataTo(other);
    OutputParams::copyDataTo(other);
    other->mLiveType = mLiveType;
}

void ImageLive::onButtonCommand()
{
    QAbstractButton* iButton = dynamic_cast<QAbstractButton*>(sender());
    if (iButton)
    {
        iButton->setEnabled(false);
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no camera").arg(name()));
        return;
    }

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (iCav)
    {
        iCav->setImageSourceName(iCam->name());
        iCav->clearAllTemporaryItems();
    }

    ScopedCanvasTimer timer(iCav);
    QJsonObject rObj;
    processLive(iCav, rObj);
    iButton->setEnabled(true);
}

void ImageLive::processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj)
{
    Q_UNUSED(cmdObj);
    if (gkAsyncImageProcess)
    {
        QFuture<void> iLiveFuture = QtConcurrent::run(ImageLive::processAsyncLive, this, ioDev);
        Q_UNUSED(iLiveFuture);
    }
    else
    {
        processAsyncLive(this, ioDev);
    }
}

void ImageLive::processAsyncLive(ImageLive* me, QIODevice* ioDev)
{
    if (!gMainFrame->mRunning)
    {
        me->postLogError(QStringLiteral("Image process stopped").arg(me->name()));
        me->postLiveError(ioDev, kImageProcessError_Stopped);
        return;
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(me->mCameraUUID);
    if (!iCam)
    {
        me->postLogError(QStringLiteral("Procedure %1 no camera").arg(me->name()));
        me->postLiveError(ioDev, kImageProcessError_NoCamera);
        return;
    }

    LaserXCanvas* iCav = gRunPage->findCanvas(me->mOutputCanvas);
    if (!iCav)
    {
        me->postLogError(QStringLiteral("Procedure %1 no canvas").arg(me->name()));
        me->postLiveError(ioDev, kImageProcessError_NoCanvas);
        return;
    }

    me->postClearCanvas(iCav);
    me->postCanvasSourceName(iCav, iCam->name());

    QJsonObject rObj;
    if (me->processLive(iCav, rObj))
    {
        me->postLiveSuccess(ioDev);
    }
    else
    {
        me->postLiveError(ioDev, kImageProcessError_General);
    }
}

bool ImageLive::processLive(LaserXCanvas* cav, QJsonObject& rObj)
{
    Q_UNUSED(rObj);

    if (!cav)
    {
        return false;
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        return false;
    }

    if (QStringLiteral("StartLive") == mLiveType)
    {
        iCam->setGrabParams(mCameraGrabParams);
        postBindCamera(cav, iCam);
        iCam->startContinuousGrab();
    }
    else if (QStringLiteral("StopLive") == mLiveType)
    {
        iCam->stopContinuousGrab();
        postBindCamera(cav, nullptr);
    }
    else
    {
        iCam->setGrabParams(mCameraGrabParams);
        postBindCamera(cav, iCam);
        iCam->toggleContinuousGrab();
        if (!iCam->isContinuousGrab())
        {
            postBindCamera(cav, nullptr);
        }
    }

    return true;
}

void ImageLive::postLiveSuccess(QIODevice* ioDev)
{
    if (!ioDev)
    {
        return;
    }

    QJsonObject rObj;
    rObj[QLatin1String("CommandName")] = mCommandName;
    rObj[QLatin1String("CommandSN")] = mCommandSN;
    rObj[QLatin1String("Success")] = true;
    rObj[QLatin1String("ErrorId")] = kImageProcessError_NoError;
    rObj[QLatin1String("ErrorMsg")] = gGetErrorMsg(kImageProcessError_NoError);
    rObj[QLatin1String("ImageWidth")] = 0;
    rObj[QLatin1String("ImageHeight")] = 0;

    QJsonDocument doc(rObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    buffer.append('\n');
    postReply(ioDev, buffer);
}

void ImageLive::postLiveError(QIODevice* ioDev, int errId)
{
    if (!ioDev)
    {
        return;
    }

    QJsonObject rObj;
    rObj[QLatin1String("CommandName")] = mCommandName;
    rObj[QLatin1String("CommandSN")] = mCommandSN;
    rObj[QLatin1String("Success")] = false;
    rObj[QLatin1String("ErrorId")] = errId;
    rObj[QLatin1String("ErrorMsg")] = gGetErrorMsg(errId);
    rObj[QLatin1String("ImageWidth")] = 0;
    rObj[QLatin1String("ImageHeight")] = 0;

    QJsonDocument doc(rObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    buffer.append('\n');
    postReply(ioDev, buffer);
}
