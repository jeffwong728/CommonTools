#include "imagegrabber.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <QtConcurrent>
#include <cmndef.h>
#include <ui/runpage.h>
#include <ui/mainframe.h>
#include <laser_x_camera.h>
#include <laser_x_canvas.h>
#include <laser_x_devicemanager.h>

ImageGrabber::ImageGrabber()
{
}

QString ImageGrabber::getTypeName() const
{
    return gTypeImageGrabber;
}

QString ImageGrabber::getJson() const
{
    QJsonObject rootObj;
    TriggerProcessor::getJson(rootObj);
    CameraParams::getJson(rootObj);
    OutputParams::getJson(rootObj);
    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void ImageGrabber::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    TriggerProcessor::setJson(jsonObj);
    CameraParams::setJson(jsonObj);
    OutputParams::setJson(jsonObj);
}

bool ImageGrabber::isValid() const
{
    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    return iCam;
}

void ImageGrabber::copyDataTo(ImageGrabber* other) const
{
    TriggerProcessor::copyDataTo(other);
    CameraParams::copyDataTo(other);
    OutputParams::copyDataTo(other);
}

void ImageGrabber::onButtonCommand()
{
    QAbstractButton* iButton = dynamic_cast<QAbstractButton*>(sender());
    if (iButton)
    {
        iButton->setEnabled(false);
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no camera").arg(name()));
        return;
    }

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (!iCav)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no canvas").arg(name()));
        return;
    }

    iCav->setImageSourceName(iCam->name());
    iCav->clearAllTemporaryItems();

    ScopedCanvasTimer timer(iCav);

    if (gkAsyncImageProcess)
    {
        QFuture<void> iLiveFuture = QtConcurrent::run(ImageGrabber::processGrabAsync, this, iCam, iButton, nullptr);
        Q_UNUSED(iLiveFuture);
    }
    else
    {
        QJsonObject rObj;
        processGrab(rObj);
        iButton->setEnabled(true);
    }
}

void ImageGrabber::processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj)
{
    Q_UNUSED(cmdObj);
    if (!gMainFrame->mRunning)
    {
        gRunPage->logError(QStringLiteral("Image process stopped").arg(name()));
        sendGrabError(ioDev, kImageProcessError_Stopped);
        return;
    }

    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no camera").arg(name()));
        sendGrabError(ioDev, kImageProcessError_NoCamera);
        return;
    }

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (!iCav)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no canvas").arg(name()));
        sendGrabError(ioDev, kImageProcessError_NoCanvas);
        return;
    }

    iCav->setImageSourceName(iCam->name());
    iCav->clearAllTemporaryItems();

    if (gkAsyncImageProcess)
    {
        QFuture<void> iGrabFuture = QtConcurrent::run(ImageGrabber::processGrabAsync, this, iCam, nullptr, ioDev);
        Q_UNUSED(iGrabFuture);
    }
    else
    {
        QJsonObject rObj;
        if (processGrab(rObj))
        {
            sendGrabSuccess(ioDev);
        }
        else
        {
            sendGrabError(ioDev, kImageProcessError_General);
        }
    }
}

bool ImageGrabber::processGrab(QJsonObject& rObj)
{
    Q_UNUSED(rObj);
    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        return false;
    }

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (!iCav)
    {
        return false;
    }

    if (iCam->isContinuousGrab())
    {
        iCam->stopContinuousGrab();
    }
    else
    {
        iCam->setGrabParams(mCameraGrabParams);
        cv::Mat iMat = iCam->snap();
        iCav->setMat(iMat);
        iCav->setImageSourceName(iCam->name());
    }

    return true;
}

void ImageGrabber::processGrabAsync(ImageGrabber* me,
    LaserXCamera* cam,
    QAbstractButton* btn,
    QIODevice* ioDev)
{
    if (cam->isContinuousGrab())
    {
        cam->stopContinuousGrab();
    }
    else
    {
        cam->setGrabParams(me->mCameraGrabParams);
        cv::Mat iMat = cam->snap();
        me->sendDisplayImage(iMat, cam->name());
    }

    me->sendProcessGrabCompleted(kImageProcessError_NoError, btn, ioDev);
}

void ImageGrabber::sendProcessGrabCompleted(int errorCode, QAbstractButton* btn, QIODevice* ioDev)
{
    QMetaObject::invokeMethod(this, "processGrabCompleted", Qt::QueuedConnection, Q_ARG(int, errorCode), Q_ARG(QAbstractButton*, btn), Q_ARG(QIODevice*, ioDev));
}

void ImageGrabber::sendDisplayImage(cv::Mat mat, const QString srcName)
{
    QMetaObject::invokeMethod(this, "displayImage", Qt::QueuedConnection, Q_ARG(cv::Mat, mat), Q_ARG(QString, srcName));
}

void ImageGrabber::processGrabCompleted(int errorCode, QAbstractButton* btn, QIODevice* ioDev)
{
    if (kImageProcessError_NoError == errorCode)
    {
        sendGrabSuccess(ioDev);
    }
    else
    {
        sendGrabError(ioDev, errorCode);
    }

    if (btn)
    {
        btn->setEnabled(true);
    }

    emit processCompleted();
}

void ImageGrabber::displayImage(cv::Mat mat, const QString srcName)
{
    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (iCav)
    {
        iCav->setMat(mat);
        iCav->setImageSourceName(srcName);
    }
}


void ImageGrabber::sendGrabSuccess(QIODevice* ioDev)
{
    if (!ioDev)
    {
        return;
    }

    QJsonObject rObj;
    rObj[QLatin1String("CommandName")] = mCommandName;
    rObj[QLatin1String("CommandSN")] = mCommandSN;
    rObj[QLatin1String("Success")] = true;
    rObj[QLatin1String("ErrorId")] = kImageProcessError_NoError;
    rObj[QLatin1String("ErrorMsg")] = gGetErrorMsg(kImageProcessError_NoError);
    rObj[QLatin1String("ImageWidth")] = 0;
    rObj[QLatin1String("ImageHeight")] = 0;

    QJsonDocument doc(rObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    buffer.append('\n');
    ioDev->write(buffer);
}

void ImageGrabber::sendGrabError(QIODevice* ioDev, int errId)
{
    if (!ioDev)
    {
        return;
    }

    QJsonObject rObj;
    rObj[QLatin1String("CommandName")] = mCommandName;
    rObj[QLatin1String("CommandSN")] = mCommandSN;
    rObj[QLatin1String("Success")] = false;
    rObj[QLatin1String("ErrorId")] = errId;
    rObj[QLatin1String("ErrorMsg")] = gGetErrorMsg(errId);
    rObj[QLatin1String("ImageWidth")] = 0;
    rObj[QLatin1String("ImageHeight")] = 0;

    QJsonDocument doc(rObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    buffer.append('\n');
    ioDev->write(buffer);
}
