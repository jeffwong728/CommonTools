#ifndef IMAGE_LIVE_H
#define IMAGE_LIVE_H

#include <QtCore>
#include <procedure/triggerprocessor.h>
#include <procedure/cameraparams.h>
#include <procedure/outputparams.h>
class LaserXCanvas;
class LaserXCamera;
class QAbstractButton;

class ImageLive : public TriggerProcessor, public CameraParams, public OutputParams
{
    Q_OBJECT
public:
    explicit ImageLive();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;
    void copyDataTo(ImageLive* other) const;

public:
    void onButtonCommand() override;
    void processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj) override;

public:
    bool processLive(LaserXCanvas *cav, QJsonObject& rObj);
    static void processLiveAsync(ImageLive *me, LaserXCanvas* cav, LaserXCamera* cam, QAbstractButton* btn, QIODevice* ioDev);

private:
    void sendProcessLiveCompleted(int errorCode, QAbstractButton* btn, QIODevice* ioDev);
    void sendBindCanvasAndCamera(LaserXCanvas* cav, LaserXCamera* cam);

private slots:
    void processLiveCompleted(int errorCode, QAbstractButton* btn, QIODevice* ioDev);
    void bindCanvasAndCamera(LaserXCanvas* cav, LaserXCamera* cam);

private:
    void sendLiveSuccess(QIODevice* ioDev);
    void sendLiveError(QIODevice* ioDev, int errId);

public:
    QString mLiveType;
};

#endif // IMAGE_LIVE_H
