#ifndef IMAGE_LIVE_H
#define IMAGE_LIVE_H

#include <QtCore>
#include <procedure/triggerprocessor.h>
#include <procedure/cameraparams.h>
#include <procedure/outputparams.h>
class LaserXCanvas;
class LaserXCamera;
class QAbstractButton;

class ImageLive : public TriggerProcessor, public CameraParams, public OutputParams
{
    Q_OBJECT
public:
    explicit ImageLive();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;
    void copyDataTo(ImageLive* other) const;

public:
    void onButtonCommand() override;
    void processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj) override;
    static void processAsyncLive(ImageLive* me, QIODevice* ioDev);
    bool processLive(LaserXCanvas *cav, QJsonObject& rObj);

private:
    void postLiveSuccess(QIODevice* ioDev);
    void postLiveError(QIODevice* ioDev, int errId);

public:
    QString mLiveType;
};

#endif // IMAGE_LIVE_H
