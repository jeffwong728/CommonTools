#ifndef IMAGEGRABBER_H
#define IMAGEGRABBER_H

#include <QtCore>
#include <procedure/triggerprocessor.h>
#include <procedure/cameraparams.h>
#include <procedure/outputparams.h>
#include <laser_x_camera.h>

class LaserXCanvas;
class LaserXCamera;
class QAbstractButton;
class QIODevice;

class ImageGrabber : public TriggerProcessor, public CameraParams, public OutputParams
{
    Q_OBJECT
public:
    explicit ImageGrabber();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;
    void copyDataTo(ImageGrabber* other) const;

public:
    void onButtonCommand() override;
    void processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj) override;
    static void processAsyncGrab(ImageGrabber* me, QIODevice* ioDev);
    bool processGrab(QJsonObject& rObj);

private:
    void postGrabSuccess(QIODevice* ioDev);
    void postGrabError(QIODevice* ioDev, int errId);
};

#endif // IMAGEGRABBER_H
