#include "outputparams.h"
#include <laser_x_util.h>

OutputParams::OutputParams()
{
}

void OutputParams::getJson(QJsonObject& jObj) const
{
    jObj[QLatin1String("OutputCanvas")] = mOutputCanvas;
    jObj[QLatin1String("XResolution")]  = mXResolution;
    jObj[QLatin1String("YResolution")]  = mYResolution;
    jObj[QLatin1String("SaveData")]     = mSaveData;
    jObj[QLatin1String("SaveImage")]    = mSaveImage;
}

void OutputParams::setJson(const QJsonObject &jObj)
{
    mOutputCanvas = fromJson(jObj, QLatin1String("OutputCanvas"), QString());
    mXResolution  = fromJson(jObj, QLatin1String("XResolution"), 1.0);
    mYResolution  = fromJson(jObj, QLatin1String("YResolution"), 1.0);
    mSaveData     = fromJson(jObj, QLatin1String("SaveData"), false);
    mSaveImage    = fromJson(jObj, QLatin1String("SaveImage"), QStringLiteral("None"));
}

void OutputParams::copyDataTo(OutputParams* other) const
{
    other->mOutputCanvas = mOutputCanvas;
    other->mXResolution  = mXResolution;
    other->mYResolution  = mYResolution;
    other->mSaveData     = mSaveData;
    other->mSaveImage    = mSaveImage;
}
