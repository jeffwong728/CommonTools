#ifndef OUTPUT_PARAMS_H
#define OUTPUT_PARAMS_H
#include <QtCore>

class OutputParams
{
public:
    explicit OutputParams();

public:
    void getJson(QJsonObject &jObj) const;
    void setJson(const QJsonObject& jObj);
    void copyDataTo(OutputParams *other) const;

public:
    qreal mXResolution = 1.0;
    qreal mYResolution = 1.0;
    QString mOutputCanvas;
    QString mSaveImage;
    bool mSaveData = false;
};

#endif // OUTPUT_PARAMS_H
