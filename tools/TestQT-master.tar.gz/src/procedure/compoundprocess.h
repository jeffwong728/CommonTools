#ifndef COMPOUND_PROCESS_H
#define COMPOUND_PROCESS_H
#include <QtCore>
#include <laser_x_vision.h>
#include "visionprocessor.h"

class CompoundProcess : public VisionProcessor
{
    Q_OBJECT

public:
    explicit CompoundProcess();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    QByteArray getBlob() const override;
    void setJson(const QString& data) override;
    void setBlob(const QByteArray& data) override;
    bool isValid() const override;
    void copyDataTo(CompoundProcess* other) const;

public:
    bool isValidProcedureFlow(QString& errMsg) const;
    bool isValidPositioningAndMeasureFlow(QString &errMsg) const;

public:
    int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;

public:
    QString mCompoundType;
    QStringList mSubProcedures;
};

#endif // COMPOUND_PROCESS_H
