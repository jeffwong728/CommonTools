#include "ncctemplate.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/runpage.h>
#include <laser_x_canvas.h>
#include <manager/image_resource_manager.h>

NCCTemplate::NCCTemplate()
{
}

QString NCCTemplate::getTypeName() const
{
    return gTypeNCCTemplate;
}

QString NCCTemplate::getJson() const
{
    QJsonObject rootObj;
    ImageSearcher::getJson(rootObj);
    rootObj[QLatin1String("CreateROI")] = mCreateROI;
    rootObj[QLatin1String("NumLevels")] = mNumLevels;
    rootObj[QLatin1String("AngleStart")] = mAngleStart;
    rootObj[QLatin1String("AngleExtent")] = mAngleExtent;
    rootObj[QLatin1String("AngleStep")] = mAngleStep;
    rootObj[QLatin1String("MinScore")] = mMinScore;
    rootObj[QLatin1String("UsePolarity")] = mUsePolarity;
    rootObj[QLatin1String("SubPixel")] = mSubPixel;
    rootObj[QLatin1String("AutoNumLevels")] = mAutoNumLevels;
    rootObj[QLatin1String("ReferencePoint")] = toJson(mReferencePoint);

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

QByteArray NCCTemplate::getBlob() const
{
    if (mTemplate)
    {
        return mTemplate->getBlob();
    }
    else
    {
        return QByteArray();
    }
}

void NCCTemplate::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    ImageSearcher::setJson(jsonObj);
    mNumLevels = fromJson(jsonObj, QLatin1String("NumLevels"), 5ll);
    mAngleStart = fromJson(jsonObj, QLatin1String("AngleStart"), -15.0);
    mAngleExtent = fromJson(jsonObj, QLatin1String("AngleExtent"), 30.0);
    mAngleStep = fromJson(jsonObj, QLatin1String("AngleStep"), 3.0);
    mMinScore = fromJson(jsonObj, QLatin1String("MinScore"), 0.8);
    mUsePolarity = fromJson(jsonObj, QLatin1String("UsePolarity"), true);
    mSubPixel = fromJson(jsonObj, QLatin1String("SubPixel"), true);
    mCreateROI = getJsonObject(jsonObj, QLatin1String("CreateROI"));
    mAutoNumLevels = fromJson(jsonObj, QLatin1String("AutoNumLevels"), true);
    mReferencePoint = fromJson(jsonObj, QLatin1String("ReferencePoint"), QPointF());

    initTemplateCreateInfos();
}

void NCCTemplate::setBlob(const QByteArray& data)
{
    mTemplate = gVision->readNccTemplate(data);
}

bool NCCTemplate::isValid() const
{
    return !mTemplate.isNull();
}

void NCCTemplate::copyDataTo(NCCTemplate* other) const
{
    ImageSearcher::copyDataTo(other);
    other->mTemplate          = mTemplate;
    other->mCreateROI         = mCreateROI;
    other->mNumLevels         = mNumLevels;
    other->mAngleStart        = mAngleStart;
    other->mAngleExtent       = mAngleExtent;
    other->mAngleStep         = mAngleStep;
    other->mMinScore          = mMinScore;
    other->mUsePolarity       = mUsePolarity;
    other->mSubPixel          = mSubPixel;
    other->mAutoNumLevels     = mAutoNumLevels;
    other->mReferencePoint    = mReferencePoint;
}

QVariantMap NCCTemplate::getCreateParams() const
{
    QVariantMap params;
    params[QStringLiteral("NumLevels")] = mAutoNumLevels ? 0 : mNumLevels;
    params[QStringLiteral("AngleStart")] = mAngleStart;
    params[QStringLiteral("AngleExtent")] = mAngleExtent;
    params[QStringLiteral("AngleStep")] = 0.;
    params[QStringLiteral("UsePolarity")] = mUsePolarity;
    return params;
}

QVariantMap NCCTemplate::getSearchParams() const
{
    QVariantMap params;
    params[QStringLiteral("AngleStart")] = mAngleStart;
    params[QStringLiteral("AngleExtent")] = mAngleExtent;
    params[QStringLiteral("MinScore")] = mMinScore;
    params[QStringLiteral("SubPixel")] = mSubPixel;

    return params;
}

void NCCTemplate::initTemplateCreateInfos()
{
    if (mImageWidth && mImageHeight)
    {
        mTemplatePath = LaserXVisionManager::getPath(mCreateROI);
        LXRegion iTemplateRegion = gVision->genRegion(mCreateROI);
        if (iTemplateRegion)
        {
            mTemplateCenter = iTemplateRegion->center();
        }
    }
}

bool NCCTemplate::processImpl(LaserXCanvas* iCav, cv::Mat& iMat)
{
    QVariantMap results;
    QVariantMap params = getSearchParams();
    if (!iMat.empty() && mTemplate && 1 == mTemplate->findTemplate(iMat, mSearchRegion, params, results))
    {
        mCenterX = results[QStringLiteral("X")].toDouble();
        mCenterY = results[QStringLiteral("Y")].toDouble();
        mAngle = qRadiansToDegrees(results[QStringLiteral("Angle")].toDouble());
        mScore = results[QStringLiteral("Score")].toDouble();

        QTransform t;
        t.translate(mCenterX, mCenterY);
        t.rotate(-mAngle);
        t.translate(-mTemplateCenter.x(), -mTemplateCenter.y());

        QPen pen(Qt::green);
        pen.setCosmetic(true);
        pen.setWidth(1);
        QBrush brush(QColor(255, 140, 0, 64));
        QPainterPath iFoundPath = t.map(mTemplatePath);
        QPointF tRefPoint = t.map(mReferencePoint);
        mCenterX = tRefPoint.x();
        mCenterY = tRefPoint.y();

        if (iCav)
        {
            QGraphicsPathItem* iItem = new QGraphicsPathItem(iFoundPath);
            iItem->setPen(pen);
            iItem->setBrush(brush);
            iCav->addTemporaryItem(iItem);

            QPen refPen(Qt::red);
            refPen.setCosmetic(true);
            refPen.setWidth(1);
            QGraphicsEllipseItem* iRefItem = new QGraphicsEllipseItem(QRectF(tRefPoint.x() - 10, tRefPoint.y() - 10, 21, 21), iItem);
            QGraphicsLineItem* iHLineItem = new QGraphicsLineItem(tRefPoint.x() - 15, tRefPoint.y(), tRefPoint.x() + 15, tRefPoint.y(), iItem);
            QGraphicsLineItem* iVLineItem = new QGraphicsLineItem(tRefPoint.x(), tRefPoint.y() - 15, tRefPoint.x(), tRefPoint.y() + 15, iItem);
            iRefItem->setPen(refPen);
            iHLineItem->setPen(pen);
            iVLineItem->setPen(pen);

            QStringList iInfos;
            iInfos.append(QStringLiteral("Score=%1").arg(mScore, 0, 'f', 2));
            iInfos.append(QStringLiteral("X=%1(pix), Y=%2(pix), A=%3").arg(tRefPoint.x(), 0, 'f', 2).arg(tRefPoint.y(), 0, 'f', 2).arg(mAngle, 0, 'f', 2));
            iInfos.append(QStringLiteral("X=%1(um), Y=%2(um), A=%3").arg(tRefPoint.x() * mXResolution, 0, 'f', 2).arg(tRefPoint.y() * mYResolution, 0, 'f', 2).arg(mAngle, 0, 'f', 2));
            iCav->addInfoItems(iInfos);
        }
        return true;
    }
    else
    {
        return false;
    }
}

bool NCCTemplate::process(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    if (processImpl(iCav, iMat))
    {
        rObj[QLatin1String("Success")] = true;
        rObj[QLatin1String("NumMatches")] = 1;

        rObj[QLatin1String("CenterXList")] = QJsonArray() << mCenterX * mXResolution;
        rObj[QLatin1String("CenterYList")] = QJsonArray() << mCenterY * mYResolution;
        rObj[QLatin1String("AngleList")] = QJsonArray() << mAngle;
        rObj[QLatin1String("ScaleList")] = QJsonArray() << 1.;
        rObj[QLatin1String("ScoreList")] = QJsonArray() << mScore;

        rObj[QLatin1String("ErrorId")] = kImageProcessError_NoError;
        rObj[QLatin1String("ErrorMsg")] = QStringLiteral("No error");
    }
    else
    {
        rObj[QLatin1String("Success")] = false;
        rObj[QLatin1String("NumMatches")] = 0ll;

        rObj[QLatin1String("CenterXList")] = QJsonArray();
        rObj[QLatin1String("CenterYList")] = QJsonArray();
        rObj[QLatin1String("AngleList")] = QJsonArray();
        rObj[QLatin1String("ScaleList")] = QJsonArray();
        rObj[QLatin1String("ScoreList")] = QJsonArray();

        rObj[QLatin1String("ErrorId")] = kImageProcessError_General;
        rObj[QLatin1String("ErrorMsg")] = QStringLiteral("Image process error");
    }

    return rObj[QLatin1String("Success")].toBool();
}
