#ifndef BLOB_SEARCHER_H
#define BLOB_SEARCHER_H
#include <QtCore>
#include <procedure/matching/objectsearcher.h>
class LaserXCanvas;

class BlobSearcher : public ObjectSearcher
{
    Q_OBJECT

public:
    explicit BlobSearcher();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;
    void copyDataTo(BlobSearcher *other) const;
    qreal objectHeight() const override;
    qreal objectWidth() const override;
    QMap<QString, std::tuple<QString, QVariantList>> featureMeta() const;
    QMap<QString, std::tuple<QString, QString, QVariant>> parameterMeta() const;

public:
    int processImage(LaserXCanvas* iCav, cv::Mat &iMat, QJsonObject& rObj) override;

private:
    void drawCircles(LaserXCanvas* iCav, const bool iSuccess, const QVector<qreal>& iXList, const QVector<qreal>& iYList, const QVector<qreal>& iRadiusList, const QVector<qreal>& iAngleList, const QVector<qreal>& iScoreList);
    void drawRects(LaserXCanvas* iCav, const bool iSuccess, const QVector<qreal> &iXList, const QVector<qreal> &iYList, const QVector<qreal> &iWidthList, const QVector<qreal>& iHeightList, const QVector<qreal> &iAngleList, const QVector<qreal> &iScoreList);
    void drawMarks(LaserXCanvas* iCav, const QVector<qreal>& iXList, const QVector<qreal>& iYList, const QVector<qreal>& iAngleList, const QVector<qreal>& iScoreList);

public:
    QString mBlobShape;
    QString mScriptName;
    QString mProcedureName;
    QVariantMap mFeatures;
    QVariantMap mParameters;
};

#endif // BLOB_SEARCHER_H
