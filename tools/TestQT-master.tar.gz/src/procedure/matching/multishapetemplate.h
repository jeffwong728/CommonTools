#ifndef MULTI_SHAPE_TEMPLATE_H
#define MULTI_SHAPE_TEMPLATE_H
#include <QtCore>
#include <laser_x_vision.h>
#include "objectsearcher.h"

class MultiShapeTemplate : public ObjectSearcher
{
    Q_OBJECT
public:
    explicit MultiShapeTemplate();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;
    void copyDataTo(MultiShapeTemplate *other) const;
    QVariantMap getSearchParams() const;

public:
    int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;

public:
    QStringList mSubModels;
    qreal mMinScore = 0.8;
    qreal mGreediness = 0.9;
    bool mSubPixel = true;

private:
    qreal mCenterX = 0.;
    qreal mCenterY = 0.;
    qreal mAngle = 0.;
    qreal mScore = 0.;
    qlonglong mModelIndex = 0;
};

#endif // MULTI_SHAPE_TEMPLATE_H
