#include "objectsearcher.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/loggingdb.h>
#include <ui/runpage.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

ObjectSearcher::ObjectSearcher()
{
}

void ObjectSearcher::getJson(QJsonObject& rootObj) const
{
    VisionProcessor::getJson(rootObj);
    rootObj[QLatin1String("SearchROI")] = mSearchROI;
}

void ObjectSearcher::setJson(const QJsonObject &jsonObj)
{
    VisionProcessor::setJson(jsonObj);
    mSearchROI = getJsonObject(jsonObj, QLatin1String("SearchROI"));
    updateSearchRegion();
}

void ObjectSearcher::copyDataTo(ObjectSearcher* other) const
{
    VisionProcessor::copyDataTo(other);
    other->mSearchROI         = mSearchROI;
    other->mSearchRegion      = mSearchRegion;
}

void ObjectSearcher::updateSearchRegion()
{
    mSearchRegion = gVision->genRegion(mSearchROI);
}

void ObjectSearcher::sortResults(std::vector<qreal>& xList,
    std::vector<qreal>& yList,
    std::vector<qreal>& angleList,
    std::vector<qreal>& scaleList,
    std::vector<qreal>& scoreList)
{
    if (xList.size() > 1)
    {
        const qreal iHalfHeight = objectHeight() / 2.;
        std::vector<int> iIndexs(xList.size(), 0);
        std::iota(iIndexs.begin(), iIndexs.end(), 0);
        std::sort(iIndexs.begin(), iIndexs.end(),
            [this, iHalfHeight, &xList, &yList](const int l, const int r)
            {
                const qreal yDist = std::abs(yList[l] - yList[r]);
                if (yDist < iHalfHeight)
                {
                    return xList[l] < xList[r];
                }
                else
                {
                    return yList[l] < yList[r];
                }
            }
        );

        std::vector<qreal> tCenterXList(xList.size());
        std::vector<qreal> tCenterYList(xList.size());
        std::vector<qreal> tAngleList(xList.size());
        std::vector<qreal> tScaleList(xList.size());
        std::vector<qreal> tScoreList(xList.size());

        for (std::size_t nn = 0; nn < iIndexs.size(); ++nn)
        {
            tCenterXList[nn] = xList[iIndexs[nn]];
            tCenterYList[nn] = yList[iIndexs[nn]];
            tAngleList[nn] = angleList[iIndexs[nn]];
            tScaleList[nn] = scaleList[iIndexs[nn]];
            tScoreList[nn] = scoreList[iIndexs[nn]];
        }

        tCenterXList.swap(xList);
        tCenterYList.swap(yList);
        tAngleList.swap(angleList);
        tScaleList.swap(scaleList);
        tScoreList.swap(scoreList);
    }
}

void ObjectSearcher::postProcess(std::vector<qreal>& xList,
    std::vector<qreal>& yList,
    std::vector<qreal>& angleList,
    std::vector<qreal>& scaleList,
    std::vector<qreal>& scoreList)
{
}
