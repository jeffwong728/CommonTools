#include "blobsearcher.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/runpage.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_devicemanager.h>

BlobSearcher::BlobSearcher()
{
    mFeatures[QSL("area")] = QVariantList() << 1 << 999999;
}

QString BlobSearcher::getTypeName() const
{
    return gTypeBlobFinder;
}

QString BlobSearcher::getJson() const
{
    QJsonObject rootObj;

    ObjectSearcher::getJson(rootObj);
    rootObj[QLatin1String("BlobShape")]     = mBlobShape;
    rootObj[QLatin1String("ScriptName")]    = mScriptName;
    rootObj[QLatin1String("ProcedureName")] = mProcedureName;
    rootObj[QLatin1String("Features")]      = QJsonObject::fromVariantMap(mFeatures);
    rootObj[QLatin1String("Parameters")]    = QJsonObject::fromVariantMap(mParameters);

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void BlobSearcher::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    ObjectSearcher::setJson(jsonObj);
    mBlobShape     = fromJson(jsonObj, QLatin1String("BlobShape"), QLatin1String("FreeShape"));
    mScriptName    = fromJson(jsonObj, QLatin1String("ScriptName"), QLatin1String(""));
    mProcedureName = fromJson(jsonObj, QLatin1String("ProcedureName"), QLatin1String(""));
    mFeatures      = getJsonObject(jsonObj, QLatin1String("Features")).toVariantMap();
    mParameters    = getJsonObject(jsonObj, QLatin1String("Parameters")).toVariantMap();
}

bool BlobSearcher::isValid() const
{
    return true;
}

void BlobSearcher::copyDataTo(BlobSearcher* other) const
{
    ObjectSearcher::copyDataTo(other);
    other->mBlobShape       = mBlobShape;
    other->mScriptName      = mScriptName;
    other->mProcedureName   = mProcedureName;
    other->mFeatures        = mFeatures;
    other->mParameters      = mParameters;
}

qreal BlobSearcher::objectHeight() const
{
    return 0;
}

qreal BlobSearcher::objectWidth() const
{
    return 0;
}

QMap<QString, std::tuple<QString, QVariantList>> BlobSearcher::featureMeta() const
{
    QMap<QString, std::tuple<QString, QVariantList>> iMetas;
    iMetas[QSL("area")]              = std::make_tuple(QSL("Int"),  QVariantList() << 1 << 999 << 1 << 99999999 << 100);
    iMetas[QSL("width")]             = std::make_tuple(QSL("Int"),  QVariantList() << 1 << 999 << 1 << 99999999 << 1);
    iMetas[QSL("height")]            = std::make_tuple(QSL("Int"),  QVariantList() << 1 << 999 << 1 << 99999999 << 1);
    iMetas[QSL("max_diameter")]      = std::make_tuple(QSL("Int"),  QVariantList() << 1 << 999 << 1 << 99999999 << 1);
    iMetas[QSL("rectangularity")]    = std::make_tuple(QSL("Real"), QVariantList() << 0.9 << 1.0 << 0.0 << 1.0 << 2 << 0.1);
    iMetas[QSL("circularity")]       = std::make_tuple(QSL("Real"), QVariantList() << 0.9 << 1.0 << 0.0 << 1.0 << 2 << 0.1);
    iMetas[QSL("outer_radius")]      = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("inner_radius")]      = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("anisometry")]        = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("area_holes")]        = std::make_tuple(QSL("Int"),  QVariantList() << 1 << 999 << 1 << 99999999 << 100);
    iMetas[QSL("holes_num")]         = std::make_tuple(QSL("Int"),  QVariantList() << 1 << 999 << 1 << 99999999 << 1);
    iMetas[QSL("row")]               = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("column")]            = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("compactness")]       = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 1.0 << 9999.0 << 2 << 1.0);
    iMetas[QSL("contlength")]        = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("convexity")]         = std::make_tuple(QSL("Real"), QVariantList() << 0.9 << 1.0 << 0.0 << 1.0 << 2 << 0.1);
    iMetas[QSL("ra")]                = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("rb")]                = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("phi")]               = std::make_tuple(QSL("Real"), QVariantList() << -90.0 << 90.0 << -180.0 << 180.0 << 1 << 1.0);
    iMetas[QSL("bulkiness")]         = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 1.0 << 9999.0 << 2 << 1.0);
    iMetas[QSL("orientation")]       = std::make_tuple(QSL("Real"), QVariantList() << -90.0 << 90.0 << -180.0 << 180.0 << 1 << 1.0);
    iMetas[QSL("euler_number")]      = std::make_tuple(QSL("Int"),  QVariantList() << -5 << 5 << -999 << 999 << 1);
    iMetas[QSL("rect2_phi")]         = std::make_tuple(QSL("Real"), QVariantList() << -90.0 << 90.0 << -180.0 << 180.0 << 1 << 1.0);
    iMetas[QSL("rect2_len1")]        = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("rect2_len2")]        = std::make_tuple(QSL("Real"), QVariantList() << 1.5 << 999.9 << 0.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("gray_mean")]         = std::make_tuple(QSL("Real"), QVariantList() << 128.0 << 255.0 << 0.0 << 255.0 << 1 << 1.0);
    iMetas[QSL("moments_m11_invar")] = std::make_tuple(QSL("Real"), QVariantList() << -1.5 << 1.5 << -999.0 << 999.0 << 3 << 0.01);
    iMetas[QSL("struct_factor")]     = std::make_tuple(QSL("Real"), QVariantList() << 0.0 << 1.0 << 0.0 << 9999.0 << 3 << 0.01);
    return iMetas;
}

QMap<QString, std::tuple<QString, QString, QVariant>> BlobSearcher::parameterMeta() const
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iMetas;
    iMetas[QSL("MinGray")]        = std::make_tuple(QSL("Tuple"),  QSL("Int"),    QVariantList() << 0 << 128 << 0 << 255);
    iMetas[QSL("MaxGray")]        = std::make_tuple(QSL("Tuple"),  QSL("Int"),    QVariantList() << 0 << 255 << 0 << 255);
    iMetas[QSL("MaskWidth")]      = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 9 << 3 << 901 << 2);
    iMetas[QSL("MaskHeight")]     = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 9 << 3 << 901 << 2);
    iMetas[QSL("Offset")]         = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 5.0 << -255.0 << 255.0 << 2 << 5.0);
    iMetas[QSL("LightDark")]      = std::make_tuple(QSL("Enum"),   QSL("String"), QStringList()  << QSL("light") << QSL("dark") << QSL("equal") << QSL("not_equal"));
    iMetas[QSL("ClutterRadius")]  = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 3.5 << 1.5 << 999.5 << 1 << 1.0);
    iMetas[QSL("ClutterWidth")]   = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 10 << 1 << 999 << 1);
    iMetas[QSL("ClutterHeight")]  = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 10 << 1 << 999 << 1);
    iMetas[QSL("NoiseRadius")]    = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 1.5 << 1.5 << 999.5 << 1 << 1.0);
    iMetas[QSL("NoiseWidth")]     = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 1 << 1 << 999 << 1);
    iMetas[QSL("NoiseHeight")]    = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 1 << 1 << 999 << 1);
    iMetas[QSL("ObjectRadius")]   = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 3.5 << 1.5 << 999.5 << 1 << 1.0);
    iMetas[QSL("ObjectWidth")]    = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 10.0 << 1.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("ObjectHeight")]   = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 10.0 << 1.0 << 9999.0 << 1 << 1.0);
    iMetas[QSL("MinScore")]       = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 0.85 << 0.5 << 1.0 << 2 << 0.1);
    iMetas[QSL("MaxDeformation")] = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 0 << 0 << 32 << 1);
    iMetas[QSL("GapWidth")]       = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 1 << 1 << 999 << 1);
    iMetas[QSL("GapHeight")]      = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 1 << 1 << 999 << 1);
    return iMetas;
}

int BlobSearcher::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    QVariantMap iParams = mFeatures;
    iParams.insert(mParameters);
    iParams[QStringLiteral("BlobShape")] = mBlobShape;
    iParams[QStringLiteral("ProcName")] = mProcedureName;
    iParams[QStringLiteral("ProgPath")] = QAppHelper::getSetting<QString>(gAppScriptsDir) + QDir::separator() + mScriptName + QStringLiteral(".hdev");

    QVariantMap iResult = gVision->doBlobAnalysis(iMat, mSearchRegion, iParams);
    QVector<qreal> iXList = iResult.value(QStringLiteral("XList")).value<QVector<qreal>>();
    QVector<qreal> iYList = iResult.value(QStringLiteral("YList")).value<QVector<qreal>>();
    QVector<qreal> iRefXList = iResult.value(QStringLiteral("RefXList")).value<QVector<qreal>>();
    QVector<qreal> iRefYList = iResult.value(QStringLiteral("RefYList")).value<QVector<qreal>>();
    QVector<qreal> iAngleList = iResult.value(QStringLiteral("AngleList")).value<QVector<qreal>>();
    QVector<qreal> iScoreList = iResult.value(QStringLiteral("ScoreList")).value<QVector<qreal>>();
    const int iErrorId = iResult.value(QStringLiteral("ErrorId")).toInt();
    const bool iSuccess = iErrorId == kImageProcessError_NoError;

    if (iCav)
    {
        QPen pen(iSuccess ? Qt::green : Qt::red);
        pen.setCosmetic(true);
        pen.setWidth(1);

        if (QLatin1String("Circle") == mBlobShape)
        {
            QVector<qreal> iRadiusList = iResult.value(QStringLiteral("RadiusList")).value<QVector<qreal>>();
            drawCircles(iCav, iSuccess, iXList, iYList, iRadiusList, iAngleList, iScoreList);
        }
        else
        {
            QVector<qreal> iWidthList = iResult.value(QStringLiteral("WidthList")).value<QVector<qreal>>();
            QVector<qreal> iHeightList = iResult.value(QStringLiteral("HeightList")).value<QVector<qreal>>();
            drawRects(iCav, iSuccess, iXList, iYList, iWidthList, iHeightList, iAngleList, iScoreList);
        }

        drawMarks(iCav, iRefXList, iRefYList, iAngleList, iScoreList);
        if (1 < iXList.size())
        {
            QStringList iInfos;
            iInfos.append(QStringLiteral("NumMatches=%1").arg(iXList.size()));
            postInfoItems(iCav, iInfos);
        }
    }

    if (iSuccess)
    {
        QJsonArray jRefXList;
        QJsonArray jRefYList;
        QJsonArray jAngleList;
        const qlonglong iNumInstances = iRefXList.size();
        for (qlonglong rr = 0; rr < iNumInstances; ++rr)
        {
            jRefXList.push_back(toFixed(iRefXList[rr], 3));
            jRefYList.push_back(toFixed(iRefYList[rr], 3));
            jAngleList.push_back(toFixed(iAngleList[rr], 3));
        }

        rObj[QLatin1String("Success")] = true;
        rObj[QLatin1String("NumMatches")] = static_cast<qlonglong>(iRefXList.size());
        rObj[QLatin1String("CenterXList")] = jRefXList;
        rObj[QLatin1String("CenterYList")] = jRefYList;
        rObj[QLatin1String("AngleList")] = jAngleList;
    }
    else
    {
        rObj[QLatin1String("Success")] = false;
        rObj[QLatin1String("NumMatches")] = 0ll;
        rObj[QLatin1String("CenterXList")] = QJsonArray();
        rObj[QLatin1String("CenterYList")] = QJsonArray();
        rObj[QLatin1String("AngleList")] = QJsonArray();
    }

    return iErrorId;
}

void BlobSearcher::drawCircles(LaserXCanvas* iCav,
    const bool iSuccess,
    const QVector<qreal>& iXList,
    const QVector<qreal>& iYList,
    const QVector<qreal>& iRadiusList,
    const QVector<qreal>& iAngleList,
    const QVector<qreal>& iScoreList)
{
    QPen pen(iSuccess ? Qt::green : Qt::red);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QList<QGraphicsItem*> iLists;
    iLists.reserve(iXList.size());
    QFont serifFont(QSL("Times"), 12, QFont::Bold);
    for (qsizetype nn = 0; nn < iXList.size(); ++nn)
    {
        QPainterPath iPath;
        iPath.addEllipse(QRectF(QPointF(iXList[nn] - iRadiusList[nn], iYList[nn] - iRadiusList[nn]), QSizeF(iRadiusList[nn] * 2, iRadiusList[nn] * 2)));

        QGraphicsPathItem* iItem = new QGraphicsPathItem(iPath);
        iItem->setPen(pen);
        QGraphicsSimpleTextItem* iScoreItem = new QGraphicsSimpleTextItem(iItem);
        iScoreItem->setPen(QPen(iSuccess ? Qt::green : Qt::red));
        iScoreItem->setFont(serifFont);
        iScoreItem->setBrush(QBrush(iSuccess ? Qt::green : Qt::red));
        iScoreItem->setPos(iXList[nn], iYList[nn]);
        iScoreItem->setText(QStringLiteral("Score=%1").arg(iScoreList[nn], 0, 'f', 2));
        iLists.push_back(iItem);
    }

    postTemporaryItems(iCav, iLists);
}

void BlobSearcher::drawRects(LaserXCanvas* iCav,
    const bool iSuccess,
    const QVector<qreal>& iXList,
    const QVector<qreal>& iYList,
    const QVector<qreal>& iWidthList,
    const QVector<qreal>& iHeightList,
    const QVector<qreal>& iAngleList,
    const QVector<qreal>& iScoreList)
{
    QPen pen(iSuccess ? Qt::green : Qt::red);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QList<QGraphicsItem*> iLists;
    iLists.reserve(iXList.size());
    QFont serifFont(QSL("Times"), 12, QFont::Bold);
    for (qsizetype nn = 0; nn < iXList.size(); ++nn)
    {
        QTransform t;
        t.translate(iXList[nn], iYList[nn]);
        t.rotate(-iAngleList[nn]);
        t.translate(-iXList[nn], -iYList[nn]);

        QPainterPath iPath;
        iPath.addRect(QRectF(QPointF(iXList[nn] - iWidthList[nn], iYList[nn] - iHeightList[nn]), QSizeF(iWidthList[nn] * 2, iHeightList[nn] * 2)));

        QPainterPath tPath = t.map(iPath);
        QGraphicsPathItem* iItem = new QGraphicsPathItem(tPath);
        iItem->setPen(pen);

        QGraphicsSimpleTextItem* iScoreItem = new QGraphicsSimpleTextItem(iItem);
        iScoreItem->setPen(QPen(iSuccess ? Qt::green : Qt::red));
        iScoreItem->setBrush(QBrush(iSuccess ? Qt::green : Qt::red));
        iScoreItem->setFont(serifFont);
        iScoreItem->setPos(iXList[nn], iYList[nn]);
        iScoreItem->setText(QStringLiteral("Score=%1").arg(iScoreList[nn], 0, 'f', 2));
        iLists.push_back(iItem);
    }

    postTemporaryItems(iCav, iLists);
}

void BlobSearcher::drawMarks(LaserXCanvas* iCav,
    const QVector<qreal>& iXList,
    const QVector<qreal>& iYList,
    const QVector<qreal>& iAngleList,
    const QVector<qreal>& iScoreList)
{
    Q_UNUSED(iAngleList);
    QPen refPen(Qt::red);
    refPen.setCosmetic(true);
    refPen.setWidth(1);

    QPen pen(Qt::green);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QList<QGraphicsItem*> iLists;
    iLists.reserve(iXList.size());
    for (qsizetype nn = 0; nn < iXList.size(); ++nn)
    {
        const qreal x = iXList.constData()[nn];
        const qreal y = iYList.constData()[nn];
        QGraphicsEllipseItem* iRefItem = new QGraphicsEllipseItem(QRectF(x - 10, y - 10, 21, 21));
        QGraphicsLineItem* iHLineItem = new QGraphicsLineItem(x - 15, y, x + 15, y, iRefItem);
        QGraphicsLineItem* iVLineItem = new QGraphicsLineItem(x, y - 15, x, y + 15, iRefItem);
        iRefItem->setPen(refPen);
        iHLineItem->setPen(pen);
        iVLineItem->setPen(pen);
        iLists.push_back(iRefItem);
    }

    postTemporaryItems(iCav, iLists);

    if (1 == iXList.size())
    {
        QStringList iInfos;
        iInfos.append(QStringLiteral("Score=%1").arg(iScoreList[0], 0, 'f', 2));
        iInfos.append(QStringLiteral("X=%1(pix), Y=%2(pix), A=%3").arg(iXList[0], 0, 'f', 2).arg(iYList[0], 0, 'f', 2).arg(iAngleList[0], 0, 'f', 2));
        postInfoItems(iCav, iInfos);
    }
}
