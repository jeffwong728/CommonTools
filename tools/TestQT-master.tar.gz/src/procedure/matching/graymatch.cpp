#include "graymatch.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/runpage.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_devicemanager.h>

GrayMatch::GrayMatch()
{
}

QString GrayMatch::getTypeName() const
{
    return gTypeNCCTemplate;
}

QString GrayMatch::getJson() const
{
    QJsonObject rootObj;
    TemplateMatch::getJson(rootObj);
    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void GrayMatch::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    TemplateMatch::setJson(jsonObj);
}

QByteArray GrayMatch::getBlob() const
{
    if (mTemplate)
    {
        return mTemplate->getBlob();
    }
    else
    {
        return QByteArray();
    }
}

void GrayMatch::setBlob(const QByteArray& data)
{
    mTemplate = gVision->readNccTemplate(data);
}

bool GrayMatch::isValid() const
{
    return !mTemplate.isNull();
}

void GrayMatch::copyDataTo(GrayMatch* other) const
{
    TemplateMatch::copyDataTo(other);
    other->mTemplate = mTemplate;
}

qreal GrayMatch::objectHeight() const
{
    return mTemplatePath.controlPointRect().height();
}

qreal GrayMatch::objectWidth() const
{
    return mTemplatePath.controlPointRect().width();
}

QMap<QString, std::tuple<QString, QString, QVariant>> GrayMatch::createMeta() const
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iMetas;
    iMetas[QSL("NumLevels")]     = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 0 << 0 << 10 << 1);
    iMetas[QSL("AngleStart")]    = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << -3.0 << -180.0 << 180.0 << 2 << 1.0);
    iMetas[QSL("AngleExtent")]   = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 6.0 << 0.0 << 360.0 << 2 << 1.0);
    iMetas[QSL("Metric")]        = std::make_tuple(QSL("Enum"),   QSL("String"), QStringList()  << QSL("use_polarity") << QSL("ignore_global_polarity"));
    return iMetas;
}

QMap<QString, std::tuple<QString, QString, QVariant>> GrayMatch::searchMeta() const
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iMetas;
    iMetas[QSL("AngleStart")]  = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << -3.0 << -180.0 << 180.0 << 2 << 1.0);
    iMetas[QSL("AngleExtent")] = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << 6.0 << 0.0 << 360.0 << 2 << 1.0);
    iMetas[QSL("MinScore")]    = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << 0.8 << 0.1 << 1.0 << 2 << 0.1);
    iMetas[QSL("NumMatches")]  = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 1 << 0 << 99999 << 1);
    iMetas[QSL("MaxOverlap")]  = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << 0.5 << 0.0 << 1.0 << 2 << 0.05);
    iMetas[QSL("SubPixel")]    = std::make_tuple(QSL("Enum"),   QSL("String"), QStringList() << QSL("true") << QSL("false"));
    iMetas[QSL("LevelStart")]  = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 0 << 0 << 10 << 1);
    iMetas[QSL("LevelEnd")]    = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 1 << 1 << 10 << 1);
    iMetas[QSL("ScriptName")] = std::make_tuple(QSL("Scalar"), QSL("String"), QVariantList() << QSL(""));
    iMetas[QSL("ProcedureName")] = std::make_tuple(QSL("Scalar"), QSL("String"), QVariantList() << QSL(""));
    return iMetas;
}

QVariantMap GrayMatch::searchTemplate(cv::Mat& img) const
{
    QVariantMap iResult;
    if (!mTemplate)
    {
        return iResult;
    }

    iResult = mTemplate->findTemplate(img, mSearchRegion, mSearchParameters);
    return iResult;
}
