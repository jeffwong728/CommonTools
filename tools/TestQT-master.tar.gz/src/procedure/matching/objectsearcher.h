#ifndef OBJECT_SEARCHER_H
#define OBJECT_SEARCHER_H
#include <QtCore>
#include <procedure/visionprocessor.h>

class ObjectSearcher : public VisionProcessor
{
    Q_OBJECT

public:
    explicit ObjectSearcher();

public:
    void getJson(QJsonObject &rootObj) const;
    void setJson(const QJsonObject& jsonObj);
    void copyDataTo(ObjectSearcher*other) const;
    void updateSearchRegion();

public:
    virtual qreal objectHeight() const = 0;
    virtual qreal objectWidth() const = 0;

public:
    void sortResults(std::vector<qreal> &xList, std::vector<qreal> &yList, std::vector<qreal> &angleList, std::vector<qreal> &scaleList, std::vector<qreal> &scoreList);
    void postProcess(std::vector<qreal>& xList, std::vector<qreal>& yList, std::vector<qreal>& angleList, std::vector<qreal>& scaleList, std::vector<qreal>& scoreList);

public:
    QJsonObject mSearchROI;
    LXRegion mSearchRegion;
    QString mPostJSScript;
};

#endif // OBJECT_SEARCHER_H
