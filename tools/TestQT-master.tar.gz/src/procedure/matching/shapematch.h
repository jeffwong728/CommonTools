#ifndef SHAPE_MATCH_H
#define SHAPE_MATCH_H
#include <QtCore>
#include "templatematch.h"
#include <laser_x_vision.h>

class ShapeMatch : public TemplateMatch
{
    Q_OBJECT

public:
    explicit ShapeMatch(const QString &shapeType);

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    QByteArray getBlob() const override;
    void setBlob(const QByteArray& data) override;
    bool isValid() const override;
    void copyDataTo(ShapeMatch*other) const;
    qreal objectHeight() const override;
    qreal objectWidth() const override;
    QMap<QString, std::tuple<QString, QString, QVariant>> createMeta() const;
    QMap<QString, std::tuple<QString, QString, QVariant>> searchMeta() const;

public:
    QVariantMap searchTemplate(cv::Mat& img) const override;

public:
    QString mShapeType;
    LXShapeTemplate mTemplate;
};

#endif // SHAPE_MATCH_H
