#include "multishapetemplate.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <ui/runpage.h>
#include <laser_x_canvas.h>

MultiShapeTemplate::MultiShapeTemplate()
{
}

QString MultiShapeTemplate::getTypeName() const
{
    return gTypeMultiShapeTemplate;
}

QString MultiShapeTemplate::getJson() const
{
    QJsonObject rootObj;

    ObjectSearcher::getJson(rootObj);
    rootObj[QLatin1String("MinScore")] = mMinScore;
    rootObj[QLatin1String("SubPixel")] = mSubPixel;
    rootObj[QLatin1String("Greediness")] = mGreediness;

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void MultiShapeTemplate::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    ObjectSearcher::setJson(jsonObj);
    mMinScore = fromJson(jsonObj, QLatin1String("MinScore"), 0.8);
    mSubPixel = fromJson(jsonObj, QLatin1String("SubPixel"), true);
    mGreediness = fromJson(jsonObj, QLatin1String("Greediness"), 0.9);
}

bool MultiShapeTemplate::isValid() const
{
    for (const QString &iModelProcUUID : mSubModels)
    {

    }

    return true;
}

void MultiShapeTemplate::copyDataTo(MultiShapeTemplate* other) const
{
    ObjectSearcher::copyDataTo(other);
    other->mMinScore          = mMinScore;
    other->mSubPixel          = mSubPixel;
    other->mGreediness        = mGreediness;
}

QVariantMap MultiShapeTemplate::getSearchParams() const
{
    QVariantMap params;
    params[QStringLiteral("AngleStart")]  = 0;
    params[QStringLiteral("AngleExtent")] = 0;
    params[QStringLiteral("MinScore")]    = mMinScore;
    params[QStringLiteral("SubPixel")]    = mSubPixel;
    params[QStringLiteral("Greediness")]  = mGreediness;

    return params;
}

int MultiShapeTemplate::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    QVariantMap params = getSearchParams();
    LXShapeTemplate iTemplate;
    QPointF iTemplateCenter;
    QPainterPath iTemplatePath;
    if (iMat.empty() || !iTemplate)
    {
        return kImageProcessError_General;
    }

    QVariantMap results = iTemplate->findTemplate(iMat, mSearchRegion, params);
    mCenterX = results[QStringLiteral("X")].toDouble();
    mCenterY = results[QStringLiteral("Y")].toDouble();
    mAngle = qRadiansToDegrees(results[QStringLiteral("Angle")].toDouble());
    mScore = results[QStringLiteral("Score")].toDouble();
    if (mScore < 0.01)
    {
        return kImageProcessError_General;
    }

    QTransform t;
    t.translate(mCenterX, mCenterY);
    t.rotate(-mAngle);
    t.translate(-iTemplateCenter.x(), -iTemplateCenter.y());

    QPen pen(Qt::green);
    pen.setCosmetic(true);
    pen.setWidth(1);
    QBrush brush(QColor(255, 140, 0, 64));
    QPainterPath iFoundPath = t.map(iTemplatePath);
    if (iCav)
    {
        QGraphicsPathItem* iItem = new QGraphicsPathItem(iFoundPath);
        iItem->setPen(pen);
        iItem->setBrush(brush);
        iCav->addTemporaryItem(iItem);

        QStringList iInfos;
        iInfos.append(QStringLiteral("Score=%1").arg(mScore, 0, 'f', 2));
        iInfos.append(QStringLiteral("X=%1(pix), Y=%2(pix), A=%3").arg(mCenterX, 0, 'f', 2).arg(mCenterY, 0, 'f', 2).arg(mAngle, 0, 'f', 2));
        iCav->addInfoItems(iInfos);
    }

    return kImageProcessError_NoError;
}
