#include "templatematch.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

TemplateMatch::TemplateMatch()
{
}

void TemplateMatch::getJson(QJsonObject& rootObj) const
{
    ObjectSearcher::getJson(rootObj);
    rootObj[QLatin1String("TemplateROI")] = mTemplateROI;
    rootObj[QLatin1String("ReferencePoint")] = toJson(mReferencePoint);
    rootObj[QLatin1String("CreateParameters")] = QJsonObject::fromVariantMap(mCreateParameters);
    rootObj[QLatin1String("SearchParameters")] = QJsonObject::fromVariantMap(mSearchParameters);
}

void TemplateMatch::setJson(const QJsonObject &jsonObj)
{
    ObjectSearcher::setJson(jsonObj);
    mTemplateROI      = getJsonObject(jsonObj, QLatin1String("TemplateROI"));
    mReferencePoint   = fromJson(jsonObj, QLatin1String("ReferencePoint"), QPointF());
    mCreateParameters = getJsonObject(jsonObj, QLatin1String("CreateParameters")).toVariantMap();
    mSearchParameters = getJsonObject(jsonObj, QLatin1String("SearchParameters")).toVariantMap();
    updateTemplateRegion();
}

void TemplateMatch::copyDataTo(TemplateMatch* other) const
{
    ObjectSearcher::copyDataTo(other);
    other->mTemplateCenter      = mTemplateCenter;
    other->mTemplatePath        = mTemplatePath;
    other->mTemplateROI         = mTemplateROI;
    other->mReferencePoint      = mReferencePoint;
    other->mCreateParameters    = mCreateParameters;
    other->mSearchParameters    = mSearchParameters;
}

void TemplateMatch::updateTemplateRegion()
{
    mTemplatePath = LaserXVisionManager::getPath(mTemplateROI);
    LXRegion iTemplateRegion = gVision->genRegion(mTemplateROI);
    if (iTemplateRegion)
    {
        mTemplateCenter = iTemplateRegion->center();
    }
}

int TemplateMatch::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    if (!iCav)
    {
        fillEmptyResult(rObj);
        return kImageProcessError_NoCanvas;
    }

    QVariantMap iResults = searchTemplate(iMat);
    QVector<qreal> iCenterXList = iResults[QStringLiteral("XList")].value<QVector<qreal>>();
    QVector<qreal> iCenterYList = iResults[QStringLiteral("YList")].value<QVector<qreal>>();
    QVector<qreal> iAngleList = iResults[QStringLiteral("AngleList")].value<QVector<qreal>>();
    QVector<qreal> iScaleList = iResults[QStringLiteral("ScaleList")].value<QVector<qreal>>();
    QVector<qreal> iScoreList = iResults[QStringLiteral("ScoreList")].value<QVector<qreal>>();

    std::vector<qreal> rCenterXList;
    std::vector<qreal> rCenterYList;
    std::vector<qreal> rAngleList;
    std::vector<qreal> rScaleList;
    std::vector<qreal> rScoreList;
    const qreal iMinScore = mSearchParameters.value(QSL("MinScore"), 0.9).toReal();
    for (qlonglong rr = 0; rr < iCenterXList.size(); ++rr)
    {
        qreal iCenterX = iCenterXList.constData()[rr];
        qreal iCenterY = iCenterYList.constData()[rr];
        qreal iAngle = iAngleList.constData()[rr];
        qreal iScale = iScaleList.constData()[rr];
        qreal iScore = iScoreList.constData()[rr];
        if (iScore > iMinScore)
        {
            rCenterXList.push_back(iCenterX);
            rCenterYList.push_back(iCenterY);
            rAngleList.push_back(iAngle);
            rScaleList.push_back(iScale);
            rScoreList.push_back(iScore);
        }
    }

    if (rCenterXList.empty())
    {
        fillEmptyResult(rObj);
        return kImageProcessError_General;
    }

    const int iNumMatches = mSearchParameters.value(QSL("NumMatches"), 1).toInt();
    if (iNumMatches && iNumMatches != rCenterXList.size())
    {
        fillEmptyResult(rObj);
        return kImageProcessError_General;
    }

    QPen refPen(Qt::red);
    refPen.setCosmetic(true);
    refPen.setWidth(1);

    QPen pen(Qt::green);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QBrush brush(QColor(255, 140, 0, 64));
    for (qlonglong rr = 0; rr < rCenterXList.size(); ++rr)
    {
        qreal iCenterX = rCenterXList[rr];
        qreal iCenterY = rCenterYList[rr];
        qreal iAngle = rAngleList[rr];
        qreal iScale = rScaleList[rr];
        qreal iScore = rScoreList[rr];

        QTransform t;
        t.translate(iCenterX, iCenterY);
        t.rotate(-iAngle);
        t.scale(iScale, iScale);
        t.translate(-mTemplateCenter.x(), -mTemplateCenter.y());

        QPointF tRefPoint = t.map(mReferencePoint);
        rCenterXList[rr] = tRefPoint.x();
        rCenterYList[rr] = tRefPoint.y();
        iCenterX = tRefPoint.x();
        iCenterY = tRefPoint.y();

        QPainterPath iFoundPath = t.map(mTemplatePath);
        QGraphicsPathItem* iItem = new QGraphicsPathItem(iFoundPath);
        iItem->setPen(pen);
        iItem->setBrush(brush);
        QGraphicsTextItem* iScoreItem = new QGraphicsTextItem(iItem);
        iScoreItem->setDefaultTextColor(iScore > iMinScore ? Qt::green : Qt::red);
        iScoreItem->setPos(iFoundPath.controlPointRect().center());
        iScoreItem->setPlainText(QStringLiteral("Score=%1").arg(iScore, 0, 'f', 2));

        QGraphicsEllipseItem* iRefItem = new QGraphicsEllipseItem(QRectF(tRefPoint.x() - 10, tRefPoint.y() - 10, 21, 21), iItem);
        QGraphicsLineItem* iHLineItem = new QGraphicsLineItem(tRefPoint.x() - 15, tRefPoint.y(), tRefPoint.x() + 15, tRefPoint.y(), iItem);
        QGraphicsLineItem* iVLineItem = new QGraphicsLineItem(tRefPoint.x(), tRefPoint.y() - 15, tRefPoint.x(), tRefPoint.y() + 15, iItem);
        iRefItem->setPen(refPen);
        iHLineItem->setPen(pen);
        iVLineItem->setPen(pen);
        iCav->addTemporaryItem(iItem);

        if (1 == rCenterXList.size())
        {
            QStringList iInfos;
            iInfos.append(QStringLiteral("Score=%1").arg(iScore, 0, 'f', 2));
            iInfos.append(QStringLiteral("X=%1(pix), Y=%2(pix), A=%3").arg(iCenterX, 0, 'f', 2).arg(iCenterY, 0, 'f', 2).arg(iAngle, 0, 'f', 2));
            iCav->addInfoItems(iInfos);
        }
    }

    if (1 < rCenterXList.size())
    {
        QStringList iInfos;
        iInfos.append(QStringLiteral("NumMatches=%1").arg(rCenterXList.size()));
        iCav->addInfoItems(iInfos);
    }

    sortResults(rCenterXList, rCenterYList, rAngleList, rScaleList, rScoreList);
    QJsonArray jCenterXList;
    QJsonArray jCenterYList;
    QJsonArray jAngleList;
    QJsonArray jScaleList;
    QJsonArray jScoreList;
    for (qlonglong rr = 0; rr < rScoreList.size(); ++rr)
    {
        const qreal iCenterX = rCenterXList[rr];
        const qreal iCenterY = rCenterYList[rr];
        const qreal iAngle = rAngleList[rr];
        const qreal iScale = rScaleList[rr];
        const qreal iScore = rScoreList[rr];

        jCenterXList.push_back(iCenterX);
        jCenterYList.push_back(iCenterY);
        jAngleList.push_back(iAngle);
        jScaleList.push_back(iScale);
        jScoreList.push_back(iScore);
    }

    rObj[QLatin1String("NumMatches")] = static_cast<qlonglong>(rCenterXList.size());
    rObj[QLatin1String("CenterXList")] = jCenterXList;
    rObj[QLatin1String("CenterYList")] = jCenterYList;
    rObj[QLatin1String("AngleList")] = jAngleList;
    rObj[QLatin1String("ScaleList")] = jScaleList;
    rObj[QLatin1String("ScoreList")] = jScoreList;

    return kImageProcessError_NoError;
}

bool TemplateMatch::isPositioning() const
{
    return true;
}

QPointF TemplateMatch::getCenter() const
{
    return mTemplateCenter;
}

std::tuple<QPointF, qreal, bool> TemplateMatch::doPositioning(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) const
{
    if (!iCav)
    {
        fillEmptyResult(rObj);
        return std::make_tuple(mTemplateCenter, 0.0, false);
    }

    QVariantMap iResults = searchTemplate(iMat);
    QVector<qreal> iCenterXList = iResults[QStringLiteral("XList")].value<QVector<qreal>>();
    QVector<qreal> iCenterYList = iResults[QStringLiteral("YList")].value<QVector<qreal>>();
    QVector<qreal> iAngleList = iResults[QStringLiteral("AngleList")].value<QVector<qreal>>();
    QVector<qreal> iScaleList = iResults[QStringLiteral("ScaleList")].value<QVector<qreal>>();
    QVector<qreal> iScoreList = iResults[QStringLiteral("ScoreList")].value<QVector<qreal>>();
    if (1 != iCenterXList.size())
    {
        return std::make_tuple(mTemplateCenter, 0., false);
    }

    const qreal iCenterX = iCenterXList.constData()[0];
    const qreal iCenterY = iCenterYList.constData()[0];
    const qreal iAngle = iAngleList.constData()[0];
    const qreal iScale = iScaleList.constData()[0];
    const qreal iScore = iScoreList.constData()[0];

    QTransform t;
    t.translate(iCenterX, iCenterY);
    t.rotate(-iAngle);
    t.scale(iScale, iScale);
    t.translate(-mTemplateCenter.x(), -mTemplateCenter.y());
    QPointF tRefPoint = t.map(mReferencePoint);

    QPen pen(Qt::green);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QPen refPen(Qt::red);
    refPen.setCosmetic(true);
    refPen.setWidth(1);

    QBrush brush(QColor(255, 140, 0, 64));
    QPainterPath iFoundPath = t.map(mTemplatePath);

    QGraphicsPathItem* iItem = new QGraphicsPathItem(iFoundPath);
    iItem->setPen(pen);
    iItem->setBrush(brush);
    QGraphicsTextItem* iScoreItem = new QGraphicsTextItem(iItem);
    iScoreItem->setDefaultTextColor(Qt::green);
    iScoreItem->setPos(iCenterX, iCenterY);
    iScoreItem->setPlainText(QStringLiteral("Score=%1").arg(iScore, 0, 'f', 2));

    QGraphicsEllipseItem* iRefItem = new QGraphicsEllipseItem(QRectF(tRefPoint.x() - 10, tRefPoint.y() - 10, 21, 21), iItem);
    QGraphicsLineItem* iHLineItem = new QGraphicsLineItem(tRefPoint.x() - 15, tRefPoint.y(), tRefPoint.x() + 15, tRefPoint.y(), iItem);
    QGraphicsLineItem* iVLineItem = new QGraphicsLineItem(tRefPoint.x(), tRefPoint.y() - 15, tRefPoint.x(), tRefPoint.y() + 15, iItem);
    iRefItem->setPen(refPen);
    iHLineItem->setPen(pen);
    iVLineItem->setPen(pen);
    iCav->addTemporaryItem(iItem);

    QStringList iInfos;
    iInfos.append(QStringLiteral("Score=%1").arg(iScore, 0, 'f', 2));
    iInfos.append(QStringLiteral("X=%1(pix), Y=%2(pix), A=%3").arg(tRefPoint.x(), 0, 'f', 2).arg(tRefPoint.y(), 0, 'f', 2).arg(iAngle, 0, 'f', 2));
    iCav->addInfoItems(iInfos);

    rObj[QLatin1String("NumMatches")] = 1ll;
    rObj[QLatin1String("CenterXList")] = QJsonArray::fromVariantList(QVariantList() << tRefPoint.x());
    rObj[QLatin1String("CenterYList")] = QJsonArray::fromVariantList(QVariantList() << tRefPoint.y());
    rObj[QLatin1String("AngleList")] = QJsonArray::fromVariantList(QVariantList() << iAngle);
    rObj[QLatin1String("ScaleList")] = QJsonArray::fromVariantList(QVariantList() << iScale);
    rObj[QLatin1String("ScoreList")] = QJsonArray::fromVariantList(QVariantList() << iScore);

    return std::make_tuple(QPointF(iCenterX, iCenterY), iAngle, true);
}

void TemplateMatch::fillEmptyResult(QJsonObject& rObj) const
{
    rObj[QLatin1String("NumMatches")] = 0ll;
    rObj[QLatin1String("CenterXList")] = QJsonArray();
    rObj[QLatin1String("CenterYList")] = QJsonArray();
    rObj[QLatin1String("AngleList")] = QJsonArray();
    rObj[QLatin1String("ScaleList")] = QJsonArray();
    rObj[QLatin1String("ScoreList")] = QJsonArray();
}
