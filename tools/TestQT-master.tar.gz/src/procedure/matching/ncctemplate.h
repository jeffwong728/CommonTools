#ifndef NCCTEMPLATE_H
#define NCCTEMPLATE_H
#include <QtCore>
#include <procedure/lxprocedure.h>
#include <laser_x_vision.h>
#include <procedure/imagesearcher.h>

class NCCTemplate : public ImageSearcher
{
    Q_OBJECT
    friend class NCCTemplateDialog;
public:
    explicit NCCTemplate();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    QByteArray getBlob() const override;
    void setJson(const QString& data) override;
    void setBlob(const QByteArray& data) override;
    bool isValid() const override;
    void copyDataTo(NCCTemplate * other) const;
    QVariantMap getCreateParams() const;
    QVariantMap getSearchParams() const;
    void initTemplateCreateInfos();

public:
    bool processImpl(LaserXCanvas* iCav, cv::Mat& iMat);
    bool process(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;

public:
    LXNCCTemplate mTemplate;
    QPainterPath mTemplatePath;
    QPointF mTemplateCenter;
    QPointF mReferencePoint;
    QJsonObject mCreateROI;
    qlonglong mNumLevels = 5;
    qreal mAngleStart = -15;
    qreal mAngleExtent = 30;
    qreal mAngleStep = 0;
    qreal mMinScore = 0.8;
    bool mUsePolarity = true;
    bool mSubPixel = true;
    bool mAutoNumLevels = true;

private:
    qreal mCenterX = 0.;
    qreal mCenterY = 0.;
    qreal mAngle = 0.;
    qreal mScore = 0.;
};

#endif // NCCTEMPLATE_H
