#ifndef TEMPLATE_MATCH_H
#define TEMPLATE_MATCH_H
#include <QtCore>
#include "objectsearcher.h"

class TemplateMatch : public ObjectSearcher
{
    Q_OBJECT

public:
    explicit TemplateMatch();

public:
    void getJson(QJsonObject &rootObj) const;
    void setJson(const QJsonObject& jsonObj);
    void copyDataTo(TemplateMatch*other) const;
    void updateTemplateRegion();

public:
    int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;
    virtual QVariantMap searchTemplate(cv::Mat& img) const = 0;

public:
    bool isPositioning() const override;
    QPointF getCenter() const override;
    std::tuple<QPointF, qreal, bool> doPositioning(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;

private:
    void fillEmptyResult(QJsonObject& rObj) const;

public:
    QPointF mTemplateCenter;
    QPainterPath mTemplatePath;
    QJsonObject mTemplateROI;
    QPointF mReferencePoint;
    QVariantMap mCreateParameters;
    QVariantMap mSearchParameters;
};

#endif // TEMPLATE_MATCH_H
