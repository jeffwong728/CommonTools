#ifndef TRIGGER_PARAMS_H
#define TRIGGER_PARAMS_H
#include <QtCore>

class TriggerParams
{
public:
    explicit TriggerParams();

public:
    void getJson(QJsonObject &jObj) const;
    void setJson(const QJsonObject& jObj);
    void copyDataTo(TriggerParams*other) const;

public:
    virtual void disconnectExistingTriggerSources() = 0;
    virtual void connectToTriggerSources() = 0;

public:
    QString mCommandName;
    QStringList mTriggerTypes;
    QStringList mTriggerSources;
};

#endif // TRIGGER_PARAMS_H
