#include "nccocr.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/loggingdb.h>
#include <ui/runpage.h>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

NccOCR::NccOCR()
    : mFontName(QStringLiteral("CustomFont"))
    , mClassifierType(QStringLiteral("Ncc"))
{
}

QString NccOCR::getTypeName() const
{
    return gTypeNccOCR;
}

QString NccOCR::getJson() const
{
    QJsonObject rootObj;
    OCRBase::getJson(rootObj);
    rootObj[QLatin1String("FontName")]          = mFontName;
    rootObj[QLatin1String("ClassifierType")]    = mClassifierType;
    rootObj[QLatin1String("SampleParams")]      = mSampleParams;
    rootObj[QLatin1String("ClassifierParams")]  = QJsonObject::fromVariantMap(mClassifierParams);
    rootObj[QLatin1String("TrainParams")]       = QJsonObject::fromVariantMap(mMatchParams);

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

QByteArray NccOCR::getBlob() const
{
    if (mOCR)
    {
        return mOCR->getBlob();
    }
    else
    {
        return QByteArray();
    }
}

void NccOCR::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    OCRBase::setJson(jsonObj);
    mFontName           = fromJson(jsonObj, QLatin1String("FontName"), QStringLiteral("FontNameA"));
    mClassifierType     = fromJson(jsonObj, QLatin1String("ClassifierType"), QStringLiteral("Ncc"));
    mSampleParams       = jsonObj.value(QLatin1String("SampleParams"));
    mClassifierParams   = getJsonObject(jsonObj, QLatin1String("ClassifierParams")).toVariantMap();
    mMatchParams        = getJsonObject(jsonObj, QLatin1String("TrainParams")).toVariantMap();
}

void NccOCR::setBlob(const QByteArray& data)
{
    mOCR = gVision->readOCR(data, mClassifierParams);
}

bool NccOCR::isValid() const
{
    return !mOCR.isNull();
}

void NccOCR::copyDataTo(NccOCR* other) const
{
    OCRBase::copyDataTo(other);
    other->mOCR                 = mOCR;
    other->mFontName            = mFontName;
    other->mClassifierType      = mClassifierType;
    other->mSampleParams        = mSampleParams;
    other->mClassifierParams    = mClassifierParams;
    other->mMatchParams         = mMatchParams;
}

QVariantMap NccOCR::getMatchParams() const
{
    return mMatchParams;
}

int NccOCR::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    if (iMat.empty() || !mOCR || !iCav)
    {
        fillErrorResult(rObj);
        return kImageProcessError_General;
    }

    LXImage iImg;
    QPointF rOrigin;
    qreal rAngle = 0.;
    QPointF aOrigin;
    qreal aAngle = 0.;
    LXProcedure* iPosProc = gFlowView->findLXProcedure(mPositioning);
    if (iPosProc && iPosProc->isPositioning())
    {
        std::tuple<QPointF, qreal, bool> iPos = iPosProc->doPositioning(iCav, iMat, rObj);
        if (!std::get<2>(iPos))
        {
            fillErrorResult(rObj);
            return kImageProcessError_General;
        }
        else
        {
            rOrigin = iPosProc->getCenter();
            rAngle = iPosProc->getAngle();
            aOrigin = std::get<0>(iPos);
            aAngle = std::get<1>(iPos);
            iImg = gVision->alignImage(iMat, rOrigin, rAngle, aOrigin, aAngle);
        }
    }
    else
    {
        iImg = gVision->fromCVMat(iMat, false);
    }

    if (!iImg)
    {
        fillErrorResult(rObj);
        return kImageProcessError_General;
    }

    QJsonArray boxArray;
    int iErrorId = kImageProcessError_NoError;
    std::vector<OCRBoxParam> iBoxParams = parseOCRBoxJson(mOCRBoxParams);
    for (const OCRBoxParam& iBoxParam : iBoxParams)
    {
        QJsonObject boxObj;
        const int iRet = processOCRBox(iCav, iImg, iBoxParam, rOrigin, rAngle, aOrigin, aAngle, boxObj);
        boxArray.push_back(boxObj);
        if (kImageProcessError_NoError != iRet)
        {
            iErrorId = iRet;
        }
    }

    rObj[QLatin1String("OCRBoxs")] = boxArray;
    return iErrorId;
}

int NccOCR::processOCRBox(LaserXCanvas* iCav,
    const LXImage& iMat,
    const OCRBoxParam& boxParam,
    const QPointF& rOrigin,
    const qreal rAngle,
    const QPointF& aOrigin,
    const qreal aAngle,
    QJsonObject& boxObj)
{
    const QRectF boxRect = boxParam.mRect;
    const LXRegion ocrRegion = gVision->genRectangle1(boxRect);
    QVariantMap iResult = mOCR->doOcrMultiClass(iMat, ocrRegion, getMatchParams());
    QStringList iChars = iResult.value(QStringLiteral("CharacterClasses")).toStringList();
    QVector<qreal> iConfidences = iResult.value(QStringLiteral("Confidences")).value<QVector<qreal>>();
    QVector<QRectF> iRects = iResult.value(QStringLiteral("CharacterRects")).value<QVector<QRectF>>();

    if (iChars.isEmpty())
    {
        iChars.push_back(QStringLiteral("?"));
        iConfidences.push_back(0);
        iRects.push_back(boxRect);
    }

    QTransform t;
    t.translate(aOrigin.x(), aOrigin.y());
    t.rotate(rAngle - aAngle);
    t.translate(-rOrigin.x(), -rOrigin.y());

    for (qsizetype cc = 0; cc < iChars.size(); ++cc)
    {
        QGraphicsTextItem* iClassItem = new QGraphicsTextItem();
        iClassItem->setDefaultTextColor(iConfidences[cc] > mMinConfidence ? Qt::green : Qt::red);
        iClassItem->setPos(iRects[cc].center() + QPoint(0, iRects[cc].height() / 2 + 3));
        iClassItem->setHtml(QStringLiteral("<span style='font-size:12pt; font-weight:700;'>%1</span>").arg(iChars[cc]));
        iClassItem->setTransform(t);
        iCav->addTemporaryItem(iClassItem);

        QPen pen(iConfidences[cc] > mMinConfidence ? Qt::green : Qt::red);
        pen.setCosmetic(true);
        pen.setWidth(1);

        QGraphicsRectItem* iRectItem = new QGraphicsRectItem(iRects[cc]);
        iRectItem->setTransform(t);
        iRectItem->setPen(pen);
        iCav->addTemporaryItem(iRectItem);
    }

    std::vector<OCRChar> iOCRChars;
    for (qsizetype cc = 0; cc < iChars.size(); ++cc)
    {
        iOCRChars.emplace_back(iChars[cc], iRects[cc], iConfidences[cc]);
    }

    int iLineIndex = 0;
    QStringList iInfos;
    OCRBox iOCRBox = sortOCR(boxParam.mName, iOCRChars);
    const std::vector<OCRLine>& iLines = std::get<1>(iOCRBox);
    iInfos.append(QStringLiteral("Box: %1").arg(boxParam.mName));
    for (const OCRLine &iLine : iLines)
    {
        QStringList iStrChars;
        QStringList iStrConfidences;
        const std::vector<OCRChar>& iLineChars = std::get<0>(iLine);
        for (const OCRChar &iLineChar : iLineChars)
        {
            iStrChars.push_back(std::get<0>(iLineChar));
            iStrConfidences.push_back(QStringLiteral("%1").arg(std::get<2>(iLineChar), 0, 'f', 2));
        }

        iInfos.append(QStringLiteral("--Line %1: %2 [%3]").arg(iLineIndex++).arg(iStrChars.join(QChar(L'\0'))).arg(iStrConfidences.join(QChar(L', '))));
    }

    iCav->addInfoItems(iInfos);
    return fillBoxResult(boxParam, iOCRBox, boxObj);
}

QMap<QString, std::tuple<QString, QString, QVariant>> NccOCR::getMatchParamMeta()
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iMatchMetas;
    iMatchMetas[QSL("NumLevels")]   = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 2 << 0 << 5 << 1);
    iMatchMetas[QSL("NumChars")]    = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 1 << 0 << 999 << 1);
    iMatchMetas[QSL("MaxOverlap")]  = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 0.1 << 1.0e-8 << 1 << 2 << 0.05);
    iMatchMetas[QSL("MinScore")]    = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 0.9 << 0.5 << 1.0 << 2 << 0.05);

    return iMatchMetas;
}
