#include "ocrbase.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/runpage.h>
#include <ui/flowchart/flowview.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_devicemanager.h>

OCRBase::OCRBase()
    : mSubstitutionChar(QSL("?"))
{
}

void OCRBase::getJson(QJsonObject &rootObj) const
{
    VisionProcessor::getJson(rootObj);
    rootObj[QLatin1String("MinConfidence")]     = mMinConfidence;
    rootObj[QLatin1String("Positioning")]       = mPositioning;
    rootObj[QLatin1String("SubstitutionChar")]  = mSubstitutionChar;
    rootObj[QLatin1String("OCRBoxParams")]      = mOCRBoxParams;
}

void OCRBase::setJson(const QJsonObject& jsonObj)
{
    VisionProcessor::setJson(jsonObj);
    mMinConfidence      = fromJson(jsonObj, QLatin1String("MinConfidence"),     0.8);
    mPositioning        = fromJson(jsonObj, QLatin1String("Positioning"),       QSL("None"));
    mSubstitutionChar   = fromJson(jsonObj, QLatin1String("SubstitutionChar"),  QSL("?"));
    mOCRBoxParams       = jsonObj.value(QLatin1String("OCRBoxParams"));
}

void OCRBase::copyDataTo(OCRBase* other) const
{
    VisionProcessor::copyDataTo(other);
    other->mMinConfidence       = mMinConfidence;
    other->mPositioning         = mPositioning;
    other->mSubstitutionChar    = mSubstitutionChar;
    other->mOCRBoxParams        = mOCRBoxParams;
}

QString OCRBase::getFullOCRClassifierPath(const QString& fontName) const
{
    QString iOCRDir = QAppHelper::getSetting<QString>(gAppOCRDir);
    QString iOCRPath = iOCRDir + QDir::separator() + fontName + QStringLiteral(".omc");
    if (QFileInfo::exists(iOCRPath) && QFileInfo(iOCRPath).isFile())
    {
        return iOCRPath;
    }

    iOCRPath = iOCRDir + QDir::separator() + fontName + QStringLiteral(".occ");
    if (QFileInfo::exists(iOCRPath) && QFileInfo(iOCRPath).isFile())
    {
        return iOCRPath;
    }
    else
    {
        return fontName;
    }
}

OCRBox OCRBase::sortOCR(const QString& boxName, const std::vector<OCRChar>& iChars)
{
    std::vector<OCRLine> iOCRLines;
    for (const auto& iCharInfo : iChars)
    {
        bool iFoundSameLine = false;
        QRectF iRect = std::get<1>(iCharInfo);
        for (auto& iOCRLine : iOCRLines)
        {
            std::vector<OCRChar>& iLineChars = std::get<0>(iOCRLine);
            for (const auto& iLineChar : iLineChars)
            {
                QRectF iCharRect = std::get<1>(iLineChar);
                const qreal iLineTol = std::max(iCharRect.height(), iRect.height()) / 3;
                if (std::abs(iCharRect.center().y() - iRect.center().y()) < iLineTol)
                {
                    iFoundSameLine = true;
                    iLineChars.push_back(iCharInfo);
                    std::get<1>(iOCRLine) = std::get<1>(iOCRLine).united(iRect);
                    break;
                }
            }

            if (iFoundSameLine)
            {
                break;
            }
        }

        if (!iFoundSameLine)
        {
            iOCRLines.push_back(std::make_tuple(std::vector<OCRChar>(1, iCharInfo), std::get<1>(iCharInfo)));
        }
    }

    auto colLess = [](const OCRChar& c1, const OCRChar& c2)
    {
        const QRectF& iRect1 = std::get<1>(c1);
        const QRectF& iRect2 = std::get<1>(c2);
        return iRect1.left() < iRect2.left();
    };

    auto lineLess = [](const OCRLine& l1, const OCRLine& l2)
    {
        const QRectF& iRect1 = std::get<1>(l1);
        const QRectF& iRect2 = std::get<1>(l2);
        return iRect1.top() < iRect2.top();
    };

    for (auto& iOCRLine : iOCRLines)
    {
        std::sort(std::get<0>(iOCRLine).begin(), std::get<0>(iOCRLine).end(), colLess);
    }

    std::sort(iOCRLines.begin(), iOCRLines.end(), lineLess);
    return std::make_tuple(boxName, iOCRLines);
}

void OCRBase::fillErrorResult(QJsonObject& rObj)
{
    QJsonArray boxArray;
    std::vector<OCRBoxParam> iBoxParams = parseOCRBoxJson(mOCRBoxParams);
    for (const OCRBoxParam &iBoxParam: iBoxParams)
    {
        QJsonObject boxObj;
        fillErrorBoxResult(iBoxParam, boxObj);
        boxArray.push_back(boxObj);
    }

    rObj[QLatin1String("OCRBoxs")] = boxArray;
}

void OCRBase::fillErrorBoxResult(const OCRBoxParam& boxParam, QJsonObject& boxObj)
{
    QJsonArray lArray;
    for (const OCRLineParam& iLineParam : boxParam.mLineParams)
    {
        QJsonObject lObj;
        lObj[QLatin1String("Result")] = QString(iLineParam.mNumLineChars, mSubstitutionChar.isEmpty() ? QChar(L'?') : mSubstitutionChar[0]);
        lObj[QLatin1String("Scores")] = QJsonArray::fromVariantList(QVariantList(iLineParam.mNumLineChars, 0.0));
        lArray.push_back(lObj);
    }

    boxObj[QLatin1String("Name")] = boxParam.mName;
    boxObj[QLatin1String("Lines")] = lArray;
}

int OCRBase::fillBoxResult(const OCRBoxParam& boxParam, OCRBox& ocrBox, QJsonObject& boxObj)
{
    QJsonArray lArray;
    int iErrorCode = kImageProcessError_NoError;
    std::vector<OCRLine> &iLines = std::get<1>(ocrBox);
    const int iMinSize = std::min(static_cast<int>(iLines.size()), static_cast<int>(boxParam.mLineParams.size()));
    for (int ll = 0; ll < iMinSize; ++ll)
    {
        QString vChars;
        QVariantList vConfidences;
        OCRLine iVerifiedLine = verifyOCRLine(iLines[ll], boxParam.mLineParams.at(ll));
        const std::vector<OCRChar>& vOCRChars = std::get<0>(iVerifiedLine);
        for (const OCRChar& vChar : vOCRChars)
        {
            vChars.append(std::get<0>(vChar));
            vConfidences.append(std::get<2>(vChar));
            if (std::get<2>(vChar) < mMinConfidence)
            {
                iErrorCode = kImageProcessError_General;
            }
        }

        QJsonObject lObj;
        lObj[QLatin1String("Result")] = vChars;
        lObj[QLatin1String("Scores")] = QJsonArray::fromVariantList(vConfidences);
        lArray.push_back(lObj);
    }

    for (qsizetype ff = iMinSize; ff < static_cast<qsizetype>(boxParam.mLineParams.size()); ++ff)
    {
        QJsonObject lObj;
        iErrorCode = kImageProcessError_General;
        const OCRLineParam iLineParam = boxParam.mLineParams[ff];
        lObj[QLatin1String("Result")] = QString(iLineParam.mNumLineChars, mSubstitutionChar.isEmpty() ? QChar(L'?') : mSubstitutionChar[0]);
        lObj[QLatin1String("Scores")] = QJsonArray::fromVariantList(QVariantList(iLineParam.mNumLineChars, 0.0));
        lArray.push_back(lObj);
    }

    boxObj[QLatin1String("Name")] = boxParam.mName;
    boxObj[QLatin1String("Lines")] = lArray;

    return iErrorCode;
}

std::vector<OCRBoxParam> OCRBase::parseOCRBoxJson(const QJsonValue& ocrBoxParams)
{
    std::vector<OCRBoxParam> iOCRBoxParams;
    QJsonArray jBoxParams = ocrBoxParams.toArray();
    for (const QJsonValueRef& jBoxParam : jBoxParams)
    {
        OCRBoxParam iOCRBoxParam;
        const QJsonObject jBoxParamObj = jBoxParam.toObject();
        iOCRBoxParam.mName = fromJson(jBoxParamObj, QLatin1String("Name"), QSL("*"));
        iOCRBoxParam.mOrder = fromJson(jBoxParamObj, QLatin1String("Order"), 0);
        iOCRBoxParam.mRect = fromJson(jBoxParamObj, QLatin1String("Rect"), QRectF());

        const QJsonArray jLineStructures = fromJson(jBoxParamObj, QLatin1String("LineStructures"), QJsonArray());
        for (const QJsonValueRef& jLineStructure : jLineStructures)
        {
            OCRLineParam iOCRLineParam;
            const QJsonObject jObj = jLineStructure.toObject();
            iOCRLineParam.mLineNumber = fromJson(jObj, QLatin1String("Number"), 0);
            iOCRLineParam.mMinGap = fromJson(jObj, QLatin1String("MinGap"), 0.8);
            const QString iLineStructure = fromJson(jObj, QLatin1String("Structure"), QSL(""));
            const QStringList iNumWordChars = iLineStructure.split(QChar(L' '));
            for (const QString& iNumChars : iNumWordChars)
            {
                const int n = iNumChars.toInt();
                iOCRLineParam.mNumWordChars.push_back(n);
                iOCRLineParam.mNumLineChars += n;
            }
            iOCRBoxParam.mLineParams.push_back(iOCRLineParam);
        }

        std::sort(iOCRBoxParam.mLineParams.begin(), iOCRBoxParam.mLineParams.end(), [](const OCRLineParam& l, const OCRLineParam& r) { return l.mLineNumber < r.mLineNumber; });
        iOCRBoxParams.push_back(iOCRBoxParam);
    }
    std::sort(iOCRBoxParams.begin(), iOCRBoxParams.end(), [](const OCRBoxParam& l, const OCRBoxParam& r) { return l.mOrder < r.mOrder; });
    return iOCRBoxParams;
}

OCRLine OCRBase::verifyOCRLine(OCRLine& ocrLine, const OCRLineParam& lineParam)
{
    std::vector<OCRChar> iOCRChars = std::get<0>(ocrLine);
    QRectF lastRect = iOCRChars.empty() ? QRectF(0, 0, 8, 10) : std::get<1>(iOCRChars.back());
    const int iNumChars = static_cast<int>(iOCRChars.size());

    if (iNumChars < lineParam.mNumLineChars)
    {
        const int iNumFills = lineParam.mNumLineChars - iNumChars;
        for (int cc = 0; cc < iNumFills; ++cc)
        {
            OCRChar iChar = std::make_tuple(mSubstitutionChar, lastRect, 0.0);
            iOCRChars.push_back(iChar);
            lastRect.translate(lastRect.width() + 3, 0);
        }
    }
    else
    {
        iOCRChars.resize(lineParam.mNumLineChars);
    }

    for (OCRChar &iChar : iOCRChars)
    {
        if (std::get<2>(iChar) < mMinConfidence)
        {
            std::get<0>(iChar) = mSubstitutionChar;
            std::get<2>(iChar) = 0.0;
        }
    }

    std::get<0>(ocrLine).swap(iOCRChars);
    return ocrLine;
}

std::vector<std::vector<OCRChar>> OCRBase::groupChars(const std::vector<OCRChar>& lineChars, const qreal rMinGap)
{
    std::vector<OCRChar> iGroup;
    std::vector<std::vector<OCRChar>> iGroups;
    for (const OCRChar &iChar : lineChars)
    {
        if (iGroup.empty())
        {
            iGroup.push_back(iChar);
        }
        else
        {
            const OCRChar &iPreChar = iGroup.back();
            const qreal iPreRight = std::get<1>(iPreChar).right();
            const qreal iPreWidth = std::get<1>(iPreChar).width();
            const qreal iCurLeft  = std::get<1>(iPreChar).left();
            const qreal iCurWidth = std::get<1>(iPreChar).width();
            const qreal iMinWidth = std::min(iPreWidth, iCurWidth);
            const qreal iGapRatio = (iCurLeft - iPreRight) / (iMinWidth + 0.001);
            if (iGapRatio > rMinGap)
            {
                iGroups.push_back(std::move(iGroup));
                iGroup.assign(1, iChar);
            }
            else
            {
                iGroup.push_back(iChar);
            }
        }
    }

    if (!iGroup.empty())
    {
        iGroups.push_back(std::move(iGroup));
    }

    return iGroups;
}
