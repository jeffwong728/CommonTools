#include "customocr.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/loggingdb.h>
#include <ui/runpage.h>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

CustomOCR::CustomOCR()
    : mFontName(QStringLiteral("CustomFont"))
    , mClassifierType(QStringLiteral("SvmMlp"))
    , mSegmentScriptName(QStringLiteral("ocr"))
    , mSegmentProcedureName(QStringLiteral("SegmentChars"))
{
}

QString CustomOCR::getTypeName() const
{
    return gTypeCustomOCR;
}

QString CustomOCR::getJson() const
{
    QJsonObject rootObj;
    OCRBase::getJson(rootObj);
    rootObj[QLatin1String("FontName")] = mFontName;
    rootObj[QLatin1String("ClassifierType")] = mClassifierType;
    rootObj[QLatin1String("SegmentScriptName")] = mSegmentScriptName;
    rootObj[QLatin1String("SegmentProcedureName")] = mSegmentProcedureName;
    rootObj[QLatin1String("SampleParams")] = mSampleParams;
    rootObj[QLatin1String("ClassifierParams")] = QJsonObject::fromVariantMap(mClassifierParams);
    rootObj[QLatin1String("SegmentParams")] = QJsonObject::fromVariantMap(mSegmentParams);
    rootObj[QLatin1String("SelectParams")] = QJsonObject::fromVariantMap(mSelectParams);
    rootObj[QLatin1String("TrainParams")] = QJsonObject::fromVariantMap(mTrainParams);

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

QByteArray CustomOCR::getBlob() const
{
    if (mOCR)
    {
        return mOCR->getBlob();
    }
    else
    {
        return QByteArray();
    }
}

void CustomOCR::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    OCRBase::setJson(jsonObj);
    mFontName = fromJson(jsonObj, QLatin1String("FontName"), QStringLiteral("FontNameA"));
    mClassifierType = fromJson(jsonObj, QLatin1String("ClassifierType"), QStringLiteral("Mlp"));
    mSegmentScriptName = fromJson(jsonObj, QLatin1String("SegmentScriptName"), QLatin1String(""));
    mSegmentProcedureName = fromJson(jsonObj, QLatin1String("SegmentProcedureName"), QLatin1String(""));
    mSampleParams = jsonObj.value(QLatin1String("SampleParams"));
    mClassifierParams = getJsonObject(jsonObj, QLatin1String("ClassifierParams")).toVariantMap();
    mSegmentParams = getJsonObject(jsonObj, QLatin1String("SegmentParams")).toVariantMap();
    mSelectParams = getJsonObject(jsonObj, QLatin1String("SelectParams")).toVariantMap();
    mTrainParams = getJsonObject(jsonObj, QLatin1String("TrainParams")).toVariantMap();
}

void CustomOCR::setBlob(const QByteArray& data)
{
    mOCR = gVision->readOCR(data, mClassifierParams);
}

bool CustomOCR::isValid() const
{
    return !mOCR.isNull();
}

void CustomOCR::copyDataTo(CustomOCR* other) const
{
    OCRBase::copyDataTo(other);
    other->mOCR = mOCR;
    other->mFontName = mFontName;
    other->mClassifierType = mClassifierType;
    other->mSampleParams = mSampleParams;
    other->mSegmentScriptName = mSegmentScriptName;
    other->mSegmentProcedureName = mSegmentProcedureName;
    other->mClassifierParams = mClassifierParams;
    other->mSegmentParams = mSegmentParams;
    other->mSelectParams = mSelectParams;
    other->mTrainParams = mTrainParams;
}

QVariantMap CustomOCR::getSegmentParams() const
{
    QVariantMap params;
    QString iScriptPath = QAppHelper::getSetting<QString>(gAppScriptsDir) + QDir::separator() + mSegmentScriptName + QStringLiteral(".hdev");
    params[QStringLiteral("OCRClassifier")] = getFullOCRClassifierPath(mFontName);
    params[QStringLiteral("SegmentScriptPath")] = iScriptPath;
    params[QStringLiteral("SegmentProcedureName")] = mSegmentProcedureName;
    params[QStringLiteral("SegmentParams")] = mSegmentParams;
    params[QStringLiteral("SelectParams")] = mSelectParams;
    return params;
}

QVariantMap CustomOCR::getTrainParams() const
{
    QVariantMap params;
    QString iScriptPath = QAppHelper::getSetting<QString>(gAppScriptsDir) + QDir::separator() + mSegmentScriptName + QStringLiteral(".hdev");
    params[QStringLiteral("SegmentScriptPath")] = iScriptPath;
    params[QStringLiteral("SegmentProcedureName")] = mSegmentProcedureName;
    params[QStringLiteral("TrainParams")] = mTrainParams;
    return params;
}

QString CustomOCR::getClassifierExtension() const
{
    if (QSL("Mlp") == mClassifierType)
    {
        return QSL(".omc");
    }
    else if (QSL("Svm") == mClassifierType)
    {
        return QSL(".osc");
    }
    else
    {
        return QString();
    }
}

int CustomOCR::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    if (iMat.empty() || !mOCR || !iCav)
    {
        fillErrorResult(rObj);
        return kImageProcessError_General;
    }

    LXImage iImg;
    QPointF rOrigin;
    qreal rAngle = 0.;
    QPointF aOrigin;
    qreal aAngle = 0.;
    LXProcedure* iPosProc = gFlowView->findLXProcedure(mPositioning);
    if (iPosProc && iPosProc->isPositioning())
    {
        std::tuple<QPointF, qreal, bool> iPos = iPosProc->doPositioning(iCav, iMat, rObj);
        if (!std::get<2>(iPos))
        {
            fillErrorResult(rObj);
            return kImageProcessError_General;
        }
        else
        {
            rOrigin = iPosProc->getCenter();
            rAngle = iPosProc->getAngle();
            aOrigin = std::get<0>(iPos);
            aAngle = std::get<1>(iPos);
            iImg = gVision->alignImage(iMat, rOrigin, rAngle, aOrigin, aAngle);
        }
    }
    else
    {
        iImg = gVision->fromCVMat(iMat, false);
    }

    if (!iImg)
    {
        fillErrorResult(rObj);
        return kImageProcessError_General;
    }

    QJsonArray boxArray;
    int iErrorId = kImageProcessError_NoError;
    std::vector<OCRBoxParam> iBoxParams = parseOCRBoxJson(mOCRBoxParams);
    for (const OCRBoxParam& iBoxParam : iBoxParams)
    {
        QJsonObject boxObj;
        const int iRet = processOCRBox(iCav, iImg, iBoxParam, rOrigin, rAngle, aOrigin, aAngle, boxObj);
        boxArray.push_back(boxObj);
        if (kImageProcessError_NoError != iRet)
        {
            iErrorId = iRet;
        }
    }

    rObj[QLatin1String("OCRBoxs")] = boxArray;
    return iErrorId;
}

int CustomOCR::processOCRBox(LaserXCanvas* iCav,
    const LXImage& iMat,
    const OCRBoxParam& boxParam,
    const QPointF& rOrigin,
    const qreal rAngle,
    const QPointF& aOrigin,
    const qreal aAngle,
    QJsonObject& boxObj)
{
    const QRectF boxRect = boxParam.mRect;
    const LXRegion ocrRegion = gVision->genRectangle1(boxRect);
    QVariantMap iResult = mOCR->doOcrMultiClass(iMat, ocrRegion, getSegmentParams());
    QStringList iChars = iResult.value(QStringLiteral("CharacterClasses")).toStringList();
    QVector<qreal> iConfidences = iResult.value(QStringLiteral("Confidences")).value<QVector<qreal>>();
    QVector<QRectF> iRects = iResult.value(QStringLiteral("CharacterRects")).value<QVector<QRectF>>();

    if (iChars.isEmpty())
    {
        iChars.push_back(QStringLiteral("?"));
        iConfidences.push_back(0);
        iRects.push_back(boxRect);
    }

    QTransform t;
    t.translate(aOrigin.x(), aOrigin.y());
    t.rotate(rAngle - aAngle);
    t.translate(-rOrigin.x(), -rOrigin.y());

    QStringList iStrConfidences;
    QList<QGraphicsItem*> iLists;
    QFont serifFont(QSL("Times"), 16, QFont::Bold);
    for (qsizetype cc = 0; cc < iChars.size(); ++cc)
    {
        QGraphicsSimpleTextItem* iClassItem = new QGraphicsSimpleTextItem();
        iClassItem->setPen(QPen(iConfidences[cc] > mMinConfidence ? Qt::green : Qt::red));
        iClassItem->setBrush(QBrush(iConfidences[cc] > mMinConfidence ? Qt::green : Qt::red));
        iClassItem->setFont(serifFont);
        iClassItem->setPos(iRects[cc].center() + QPoint(0, iRects[cc].height() / 2 + 3));
        iClassItem->setText(iChars[cc]);
        iClassItem->setTransform(t);
        iLists.push_back(iClassItem);

        QPen pen(iConfidences[cc] > mMinConfidence ? Qt::magenta : Qt::red);
        pen.setCosmetic(true);
        pen.setWidth(1);

        QGraphicsRectItem* iRectItem = new QGraphicsRectItem(iRects[cc]);
        iRectItem->setTransform(t);
        iRectItem->setPen(pen);
        iLists.push_back(iRectItem);

        iStrConfidences.push_back(QStringLiteral("%1").arg(iConfidences[cc], 0, 'f', 2));
    }

    postTemporaryItems(iCav, iLists);

    QStringList iInfos;
    iInfos.append(QStringLiteral("%1: %2 [%3]").arg(boxParam.mName).arg(iChars.join(QChar(L'\0'))).arg(iStrConfidences.join(QChar(L', '))));
    postInfoItems(iCav, iInfos);

    std::vector<OCRChar> iOCRChars;
    for (qsizetype cc = 0; cc < iChars.size(); ++cc)
    {
        iOCRChars.emplace_back(iChars[cc], iRects[cc], iConfidences[cc]);
    }

    OCRBox iOCRBox = sortOCR(boxParam.mName, iOCRChars);
    return fillBoxResult(boxParam, iOCRBox, boxObj);
}

QMap<QString, std::tuple<QString, QString, QVariant>> CustomOCR::getSegmentParamMeta()
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iSegmentMetas;
    iSegmentMetas[QSL("Polarity")]          = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("dark_on_light") << QSL("light_on_dark") << QSL("both"));
    iSegmentMetas[QSL("Method")]            = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("local_auto_shape") << QSL("local_contrast_best"));
    iSegmentMetas[QSL("EliminateLines")]    = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iSegmentMetas[QSL("DotPrint")]          = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iSegmentMetas[QSL("StrokeWidth")]       = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("medium") << QSL("light") << QSL("bold") << QSL("ultra_light"));
    iSegmentMetas[QSL("CharWidth")]         = std::make_tuple(QSL("Tuple"),     QSL("Int"),     QVariantList() << 3 << 25 << 1 << 9999);
    iSegmentMetas[QSL("CharHeight")]        = std::make_tuple(QSL("Tuple"),     QSL("Int"),     QVariantList() << 3 << 25 << 1 << 9999);
    iSegmentMetas[QSL("ThresholdOffset")]   = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 255 << 1);
    iSegmentMetas[QSL("Contrast")]          = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 10 << 1 << 255 << 1);

    return iSegmentMetas;
}

QMap<QString, std::tuple<QString, QString, QVariant>> CustomOCR::getSelectParamMeta()
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iSelectMetas;
    iSelectMetas[QSL("DotPrint")]           = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iSelectMetas[QSL("StrokeWidth")]        = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("medium") << QSL("light") << QSL("bold") << QSL("ultra_light"));
    iSelectMetas[QSL("CharWidth")]          = std::make_tuple(QSL("Tuple"), QSL("Int"),     QVariantList() << 3 << 25 << 1 << 9999);
    iSelectMetas[QSL("CharHeight")]         = std::make_tuple(QSL("Tuple"), QSL("Int"),     QVariantList() << 3 << 25 << 1 << 9999);
    iSelectMetas[QSL("Punctuation")]        = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iSelectMetas[QSL("DiacriticMarks")]     = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iSelectMetas[QSL("PartitionMethod")]    = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("fixed_width") << QSL("none") << QSL("variable_width"));
    iSelectMetas[QSL("PartitionLines")]     = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iSelectMetas[QSL("FragmentDistance")]   = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("medium") << QSL("narrow") << QSL("wide"));
    iSelectMetas[QSL("ConnectFragments")]   = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iSelectMetas[QSL("ClutterSizeMax")]     = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 0 << 0 << 9999 << 1);
    iSelectMetas[QSL("StopAfter")]          = std::make_tuple(QSL("Enum"),  QSL("String"),  QStringList() << QSL("completion") << QSL("step1_select_candidates") << QSL("step2_partition_characters") << QSL("step3_connect_fragments") << QSL("step4_select_characters"));

    return iSelectMetas;
}

QMap<QString, std::tuple<QString, QString, QVariant>> CustomOCR::getTrainParamMeta()
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iTrainMetas;
    iTrainMetas[QSL("NumHidden")]       = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 80 << 1 << 1000 << 1);
    iTrainMetas[QSL("WidthCharacter")]  = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 8 << 4 << 20 << 1);
    iTrainMetas[QSL("HeightCharacter")] = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 10 << 4 << 20 << 1);
    iTrainMetas[QSL("MaxIterations")]   = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 200 << 20 << 9999 << 10);
    iTrainMetas[QSL("NumComponents")]   = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 10 << 1 << 1000 << 1);
    iTrainMetas[QSL("RandSeed ")]       = std::make_tuple(QSL("Scalar"), QSL("Int"),    QVariantList() << 42 << 1 << 100 << 1);
    iTrainMetas[QSL("WeightTolerance")] = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 1.0 << 1.0e-8 << 10 << 3 << 0.01);
    iTrainMetas[QSL("ErrorTolerance")]  = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 0.01 << 1.0e-8 << 10 << 3 << 0.01);
    iTrainMetas[QSL("Preprocessing")]   = std::make_tuple(QSL("Enum"),   QSL("String"), QStringList() << QSL("none") << QSL("canonical_variates") << QSL("normalization") << QSL("principal_components"));
    iTrainMetas[QSL("Interpolation")]   = std::make_tuple(QSL("Enum"),   QSL("String"), QStringList() << QSL("constant") << QSL("bicubic") << QSL("bilinear") << QSL("nearest_neighbor") << QSL("weighted"));
    iTrainMetas[QSL("KernelType")]      = std::make_tuple(QSL("Enum"),   QSL("String"), QStringList() << QSL("rbf") << QSL("linear") << QSL("polynomial_homogeneous") << QSL("polynomial_inhomogeneous"));
    iTrainMetas[QSL("KernelParam")]     = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 0.02 << 0.005 << 0.99 << 3 << 0.01);
    iTrainMetas[QSL("Nu")]              = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 0.05 << 0.000000001 << 0.999999999 << 3 << 0.01);
    iTrainMetas[QSL("Mode")]            = std::make_tuple(QSL("Enum"),   QSL("String"), QStringList() << QSL("one-versus-one") << QSL("one-versus-all"));
    iTrainMetas[QSL("Epsilon")]         = std::make_tuple(QSL("Scalar"), QSL("Real"),   QVariantList() << 0.001 << 0.0 << 9.9 << 3 << 0.001);
    iTrainMetas[QSL("TrainMode")]       = std::make_tuple(QSL("Enum"),   QSL("String"), QStringList() << QSL("default") << QSL("add_sv_to_train_set"));

    return iTrainMetas;
}

QStringList CustomOCR::getAllFeatures()
{
    QStringList iFeatures;
    iFeatures << QSL("default");
    iFeatures << QSL("pixel");
    iFeatures << QSL("pixel_invar");
    iFeatures << QSL("pixel_binary");
    iFeatures << QSL("gradient_8dir");
    iFeatures << QSL("projection_horizontal");
    iFeatures << QSL("projection_horizontal_invar");
    iFeatures << QSL("projection_vertical");
    iFeatures << QSL("projection_vertical_invar");
    iFeatures << QSL("ratio");
    iFeatures << QSL("anisometry");
    iFeatures << QSL("width");
    iFeatures << QSL("height");
    iFeatures << QSL("zoom_factor");
    iFeatures << QSL("foreground");
    iFeatures << QSL("foreground_grid_9");
    iFeatures << QSL("foreground_grid_16");
    iFeatures << QSL("compactness");
    iFeatures << QSL("convexity");
    iFeatures << QSL("moments_region_2nd_invar");
    iFeatures << QSL("moments_region_2nd_rel_invar");
    iFeatures << QSL("moments_region_3rd_invar");
    iFeatures << QSL("moments_central");
    iFeatures << QSL("moments_gray_plane");
    iFeatures << QSL("phi");
    iFeatures << QSL("num_connect");
    iFeatures << QSL("num_holes");
    iFeatures << QSL("cooc");
    iFeatures << QSL("num_runs");
    iFeatures << QSL("chord_histo");
    return iFeatures;
}
