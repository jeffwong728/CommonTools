#include "pretrainedocr.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/runpage.h>
#include <ui/flowchart/flowview.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_devicemanager.h>

PretrainedOCR::PretrainedOCR()
    : mOCRClassifier(QStringLiteral("Industrial_0-9A-Z_NoRej"))
    , mMode(QSL("auto"))
{
}

QString PretrainedOCR::getTypeName() const
{
    return gTypePretrainedOCR;
}

QString PretrainedOCR::getJson() const
{
    QJsonObject rootObj;
    OCRBase::getJson(rootObj);
    rootObj[QLatin1String("Mode")]              = mMode;
    rootObj[QLatin1String("OCRClassifier")]     = mOCRClassifier;
    rootObj[QLatin1String("AutoParams")]        = QJsonObject::fromVariantMap(mAutoParams);
    rootObj[QLatin1String("ManualParams")]      = QJsonObject::fromVariantMap(mManualParams);

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void PretrainedOCR::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    OCRBase::setJson(jsonObj);
    mMode          = fromJson(jsonObj, QLatin1String("Mode"),              QSL("auto"));
    mOCRClassifier = fromJson(jsonObj, QLatin1String("OCRClassifier"),     QSL("Industrial_0-9A-Z_NoRej"));
    mAutoParams    = getJsonObject(jsonObj, QLatin1String("AutoParams")).toVariantMap();
    mManualParams  = getJsonObject(jsonObj, QLatin1String("ManualParams")).toVariantMap();

    if (QSL("DeepOCR") != mMode)
    {
        mTextModel = gVision->createTextModelReader(getCreateParams());
    }
}

bool PretrainedOCR::isValid() const
{
    return !mTextModel.isNull() || mMode == QSL("DeepOCR");
}

void PretrainedOCR::copyDataTo(PretrainedOCR* other) const
{
    OCRBase::copyDataTo(other);
    other->mMode            = mMode;
    other->mTextModel       = mTextModel;
    other->mOCRClassifier   = mOCRClassifier;
    other->mAutoParams      = mAutoParams;
    other->mManualParams    = mManualParams;
}

QVariantMap PretrainedOCR::getCreateParams() const
{
    QVariantMap params;
    params[QStringLiteral("OCRClassifier")] = getFullOCRClassifierPath();
    params[QStringLiteral("Mode")]          = mMode;
    return params;
}

QVariantMap PretrainedOCR::getSearchParams() const
{
    if (mMode == QSL("auto"))
    {
        return mAutoParams;
    }
    else if (mMode == QSL("manual"))
    {
        return mManualParams;
    }
    else
    {
        return QVariantMap();
    }
}

int PretrainedOCR::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    if (iMat.empty() || !mTextModel)
    {
        fillErrorResult(rObj);
        return kImageProcessError_General;
    }

    LXImage iImg;
    QPointF rOrigin;
    qreal rAngle = 0.;
    QPointF aOrigin;
    qreal aAngle = 0.;
    LXProcedure* iPosProc = gFlowView->findLXProcedure(mPositioning);
    if (iPosProc && iPosProc->isPositioning())
    {
        std::tuple<QPointF, qreal, bool> iPos = iPosProc->doPositioning(iCav, iMat, rObj);
        if (!std::get<2>(iPos))
        {
            fillErrorResult(rObj);
            return kImageProcessError_General;
        }
        else
        {
            rOrigin = iPosProc->getCenter();
            rAngle = iPosProc->getAngle();
            aOrigin = std::get<0>(iPos);
            aAngle = std::get<1>(iPos);
            iImg = gVision->alignImage(iMat, rOrigin, rAngle, aOrigin, aAngle);
        }
    }
    else
    {
        iImg = gVision->fromCVMat(iMat, false);
    }

    if (!iImg)
    {
        fillErrorResult(rObj);
        return kImageProcessError_General;
    }

    QJsonArray boxArray;
    int iErrorId = kImageProcessError_NoError;
    std::vector<OCRBoxParam> iBoxParams = parseOCRBoxJson(mOCRBoxParams);
    for (const OCRBoxParam& iBoxParam : iBoxParams)
    {
        QJsonObject boxObj;
        const int iRet = processOCRBox(iCav, iImg, iBoxParam, rOrigin, rAngle, aOrigin, aAngle, boxObj);
        boxArray.push_back(boxObj);
        if (kImageProcessError_NoError != iRet)
        {
            iErrorId = iRet;
        }
    }

    rObj[QLatin1String("OCRBoxs")] = boxArray;
    return iErrorId;
}

int PretrainedOCR::processOCRBox(LaserXCanvas* iCav,
    LXImage& iMat,
    const OCRBoxParam& boxParam,
    const QPointF& rOrigin,
    const qreal rAngle,
    const QPointF& aOrigin,
    const qreal aAngle,
    QJsonObject& boxObj)
{
    const QRectF boxRect = boxParam.mRect;
    const LXRegion boxRegion = gVision->genRectangle1(boxRect);

    mTextModel->setParams(getSearchParams());
    if (!mTextModel->findText(iMat, boxRegion))
    {
        fillErrorBoxResult(boxParam, boxObj);
        return kImageProcessError_General;
    }

    QVariantMap iTextResult = mTextModel->getTextResult(QVariantMap());
    int iNumLines                            = iTextResult.value(QSL("NumLines"), 0).toInt();
    QStringList iClassLines                  = iTextResult.value(QSL("ClassLines")).toStringList();
    QVector<QVector<QRectF>> iRectLines      = iTextResult.value(QSL("RectLines")).value<QVector<QVector<QRectF>>>();
    QVector<QVector<qreal>> iConfidenceLines = iTextResult.value(QSL("ConfidenceLines")).value<QVector<QVector<qreal>>>();

    QTransform t;
    t.translate(aOrigin.x(), aOrigin.y());
    t.rotate(rAngle - aAngle);
    t.translate(-rOrigin.x(), -rOrigin.y());
    drawResult(iCav, t, iClassLines, iRectLines, iConfidenceLines);

    std::vector<OCRLine> iLines;
    for (int ll = 0; ll < static_cast<int>(iClassLines.size()); ++ll)
    {
        QString iChars = iClassLines[ll];
        QVector<QRectF> iRects = iRectLines[ll];
        QVector<qreal> iConfidences = iConfidenceLines[ll];

        std::vector<OCRChar> iOCRChars;
        for (qsizetype cc = 0; cc < iRects.size(); ++cc)
        {
            iOCRChars.push_back(std::make_tuple(iChars.sliced(cc, 1), iRects.at(cc), iConfidences.at(cc)));
        }

        OCRLine iLine = std::make_tuple(iOCRChars, QRectF());
        iLines.push_back(iLine);
    }

    OCRBox ocrBox = std::make_tuple(boxParam.mName, iLines);
    return fillBoxResult(boxParam, ocrBox, boxObj);
}

void PretrainedOCR::drawResult(LaserXCanvas* iCav,
    const QTransform& t,
    const QStringList& iClassLines,
    const QVector<QVector<QRectF>>& iRectLines,
    const QVector<QVector<qreal>>& iConfidenceLines)
{
    QStringList iInfos;
    const qsizetype iNumLines = iClassLines.size();
    iInfos.append(QStringLiteral("NumLines: %1").arg(iNumLines));

    for (qsizetype ll = 0; ll < iNumLines; ++ll)
    {
        const QString& iClassLine = iClassLines.constData()[ll];
        const QVector<QRectF>& iRectLine = iRectLines.constData()[ll];
        const QVector<qreal>& iConfidenceLine = iConfidenceLines.constData()[ll];
        iInfos.append(QStringLiteral("Line %1: %2").arg(ll).arg(iClassLines.constData()[ll]));

        for (qsizetype cc = 0; cc < iClassLine.size(); ++cc)
        {
            QRectF iRect = iRectLine.constData()[cc];
            iRect.adjust(-3, -3, 3, 3);
            QGraphicsTextItem* iClassItem = new QGraphicsTextItem();
            iClassItem->setDefaultTextColor(iConfidenceLine.constData()[cc] > mMinConfidence ? Qt::magenta : Qt::red);
            iClassItem->setPos(iRect.center() + QPoint(0, iRect.height() / 2 + 3));
            iClassItem->setPlainText(iClassLine.at(cc));
            iClassItem->setTransform(t);
            iCav->addTemporaryItem(iClassItem);

            QPen pen(iConfidenceLine.constData()[cc] > mMinConfidence ? Qt::magenta : Qt::red);
            pen.setCosmetic(true);
            pen.setWidth(1);

            QGraphicsRectItem* iRectItem = new QGraphicsRectItem(iRect);
            iRectItem->setTransform(t);
            iRectItem->setPen(pen);
            iCav->addTemporaryItem(iRectItem);
        }
    }

    iCav->addInfoItems(iInfos);
}

QString PretrainedOCR::getFullOCRClassifierPath() const
{
    QString iOCRDir = QAppHelper::getSetting<QString>(gAppOCRDir);
    QString iOCRPath = iOCRDir + QDir::separator() + mOCRClassifier + QStringLiteral(".omc");
    if (QFileInfo::exists(iOCRPath) && QFileInfo(iOCRPath).isFile())
    {
        return iOCRPath;
    }

    iOCRPath = iOCRDir + QDir::separator() + mOCRClassifier + QStringLiteral(".occ");
    if (QFileInfo::exists(iOCRPath) && QFileInfo(iOCRPath).isFile())
    {
        return iOCRPath;
    }
    else
    {
        return mOCRClassifier;
    }
}

QMap<QString, std::tuple<QString, QString, QVariant>> PretrainedOCR::getAutoParamMeta()
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iMetas;
    iMetas[QSL("min_contrast")]                 = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 15 << 1 << 255 << 1);
    iMetas[QSL("polarity")]                     = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("both") << QSL("dark_on_light") << QSL("light_on_dark"));
    iMetas[QSL("eliminate_border_blobs")]       = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iMetas[QSL("add_fragments")]                = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("true") << QSL("false"));
    iMetas[QSL("separate_touching_chars")]      = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("standard") << QSL("false") << QSL("enhanced"));
    iMetas[QSL("min_char_height")]              = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 999 << 1);
    iMetas[QSL("max_char_height")]              = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 999 << 1);
    iMetas[QSL("min_char_width")]               = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 999 << 1);
    iMetas[QSL("max_char_width")]               = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 999 << 1);
    iMetas[QSL("min_stroke_width")]             = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 999 << 1);
    iMetas[QSL("max_stroke_width")]             = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 999 << 1);
    iMetas[QSL("return_punctuation")]           = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("true") << QSL("false"));
    iMetas[QSL("return_separators")]            = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("true") << QSL("false"));
    iMetas[QSL("dot_print")]                    = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iMetas[QSL("dot_print_tight_char_spacing")] = std::make_tuple(QSL("Enum"),      QSL("String"),  QStringList() << QSL("false") << QSL("true"));
    iMetas[QSL("dot_print_min_char_gap")]       = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 999 << 1);
    iMetas[QSL("dot_print_max_dot_gap")]        = std::make_tuple(QSL("Scalar"),    QSL("Int"),     QVariantList() << 0 << 0 << 999 << 1);
    return iMetas;
}

QMap<QString, std::tuple<QString, QString, QVariant>> PretrainedOCR::getManualParamMeta()
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iMetas;
    iMetas[QSL("manual_char_height")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 30 << 1 << 999 << 1);
    iMetas[QSL("manual_char_width")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 20 << 1 << 999 << 1);
    iMetas[QSL("manual_stroke_width")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 4 << 1 << 999 << 1);
    iMetas[QSL("manual_base_line_tolerance")] = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << 0.15 << 0.0 << 1.0 << 2 << 0.1);
    iMetas[QSL("manual_polarity")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("dark_on_light") << QSL("light_on_dark"));
    iMetas[QSL("manual_uppercase_only")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("false") << QSL("true"));
    iMetas[QSL("manual_is_dotprint")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("false") << QSL("true"));
    iMetas[QSL("manual_is_imprinted")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("false") << QSL("true"));
    iMetas[QSL("manual_eliminate_horizontal_lines")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("false") << QSL("true"));
    iMetas[QSL("manual_eliminate_border_blobs")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("false") << QSL("true"));
    iMetas[QSL("manual_max_line_num")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 0 << 0 << 999 << 1);
    iMetas[QSL("manual_return_punctuation")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("true") << QSL("false"));
    iMetas[QSL("manual_return_separators")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("true") << QSL("false"));
    iMetas[QSL("manual_add_fragments")] = std::make_tuple(QSL("Enum"), QSL("String"), QStringList() << QSL("true") << QSL("false"));
    iMetas[QSL("manual_fragment_size_min")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 1 << 1 << 999 << 1);
    return iMetas;
}
