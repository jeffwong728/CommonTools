#include "matchocr.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/loggingdb.h>
#include <ui/runpage.h>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

MatchOCR::MatchOCR(const QString& matchType)
    : mFontName(QStringLiteral("CustomFont"))
    , mClassifierType(matchType)
{
}

QString MatchOCR::getTypeName() const
{
    if (QSL("Shape") == mClassifierType)
    {
        return gTypeNccOCR;
    }
    else
    {
        return gTypeNccOCR;
    }
}

QString MatchOCR::getJson() const
{
    QJsonObject rootObj;
    OCRBase::getJson(rootObj);
    rootObj[QLatin1String("FontName")]          = mFontName;
    rootObj[QLatin1String("ClassifierType")]    = mClassifierType;
    rootObj[QLatin1String("SampleParams")]      = mSampleParams;
    rootObj[QLatin1String("ClassifierParams")]  = QJsonObject::fromVariantMap(mClassifierParams);
    rootObj[QLatin1String("TrainParams")]       = QJsonObject::fromVariantMap(mMatchParams);

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

QByteArray MatchOCR::getBlob() const
{
    if (mOCR)
    {
        return mOCR->getBlob();
    }
    else
    {
        return QByteArray();
    }
}

void MatchOCR::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    OCRBase::setJson(jsonObj);
    mFontName           = fromJson(jsonObj, QLatin1String("FontName"), QStringLiteral("FontNameA"));
    mClassifierType     = fromJson(jsonObj, QLatin1String("ClassifierType"), QStringLiteral("Ncc"));
    mSampleParams       = jsonObj.value(QLatin1String("SampleParams"));
    mClassifierParams   = getJsonObject(jsonObj, QLatin1String("ClassifierParams")).toVariantMap();
    mMatchParams        = getJsonObject(jsonObj, QLatin1String("TrainParams")).toVariantMap();
}

void MatchOCR::setBlob(const QByteArray& data)
{
    mOCR = gVision->readOCR(data, mClassifierParams);
}

bool MatchOCR::isValid() const
{
    return !mOCR.isNull();
}

void MatchOCR::copyDataTo(MatchOCR* other) const
{
    OCRBase::copyDataTo(other);
    other->mOCR                 = mOCR;
    other->mFontName            = mFontName;
    other->mClassifierType      = mClassifierType;
    other->mSampleParams        = mSampleParams;
    other->mClassifierParams    = mClassifierParams;
    other->mMatchParams         = mMatchParams;
}

QVariantMap MatchOCR::getMatchParams() const
{
    return mMatchParams;
}

int MatchOCR::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    if (iMat.empty() || !mOCR || !iCav)
    {
        fillErrorResult(rObj);
        return kImageProcessError_General;
    }

    LXImage iImg;
    QPointF rOrigin;
    qreal rAngle = 0.;
    QPointF aOrigin;
    qreal aAngle = 0.;
    LXProcedure* iPosProc = gFlowView->findLXProcedure(mPositioning);
    if (iPosProc && iPosProc->isPositioning())
    {
        std::tuple<QPointF, qreal, bool> iPos = iPosProc->doPositioning(iCav, iMat, rObj);
        if (!std::get<2>(iPos))
        {
            fillErrorResult(rObj);
            return kImageProcessError_General;
        }
        else
        {
            rOrigin = iPosProc->getCenter();
            rAngle = iPosProc->getAngle();
            aOrigin = std::get<0>(iPos);
            aAngle = std::get<1>(iPos);
            iImg = gVision->alignImage(iMat, rOrigin, rAngle, aOrigin, aAngle);
        }
    }
    else
    {
        iImg = gVision->fromCVMat(iMat, false);
    }

    if (!iImg)
    {
        fillErrorResult(rObj);
        return kImageProcessError_General;
    }

    QJsonArray boxArray;
    int iErrorId = kImageProcessError_NoError;
    std::vector<OCRBoxParam> iBoxParams = parseOCRBoxJson(mOCRBoxParams);
    for (const OCRBoxParam& iBoxParam : iBoxParams)
    {
        QJsonObject boxObj;
        const int iRet = processOCRBox(iCav, iImg, iBoxParam, rOrigin, rAngle, aOrigin, aAngle, boxObj);
        boxArray.push_back(boxObj);
        if (kImageProcessError_NoError != iRet)
        {
            iErrorId = iRet;
        }
    }

    rObj[QLatin1String("OCRBoxs")] = boxArray;
    return iErrorId;
}

int MatchOCR::processOCRBox(LaserXCanvas* iCav,
    const LXImage& iMat,
    const OCRBoxParam& boxParam,
    const QPointF& rOrigin,
    const qreal rAngle,
    const QPointF& aOrigin,
    const qreal aAngle,
    QJsonObject& boxObj)
{
    const QRectF boxRect = boxParam.mRect;
    const LXRegion ocrRegion = gVision->genRectangle1(boxRect);
    QVariantMap iResult = mOCR->doOcrMultiClass(iMat, ocrRegion, getMatchParams());
    QStringList iChars = iResult.value(QStringLiteral("CharacterClasses")).toStringList();
    QVector<qreal> iConfidences = iResult.value(QStringLiteral("Confidences")).value<QVector<qreal>>();
    QVector<QRectF> iRects = iResult.value(QStringLiteral("CharacterRects")).value<QVector<QRectF>>();

    if (iChars.isEmpty())
    {
        iChars.push_back(QStringLiteral("?"));
        iConfidences.push_back(0);
        iRects.push_back(boxRect);
    }

    QTransform t;
    t.translate(aOrigin.x(), aOrigin.y());
    t.rotate(rAngle - aAngle);
    t.translate(-rOrigin.x(), -rOrigin.y());

    QList<QGraphicsItem*> tempItems;
    tempItems.reserve(iChars.size()*2);
    QFont serifFont(QSL("Times"), 16, QFont::Bold);
    for (qsizetype cc = 0; cc < iChars.size(); ++cc)
    {
        QPen pen(iConfidences[cc] > mMinConfidence ? Qt::green : Qt::red);
        QBrush brush(iConfidences[cc] > mMinConfidence ? Qt::green : Qt::red);
        QGraphicsSimpleTextItem* iClassItem = new QGraphicsSimpleTextItem();
        iClassItem->setPen(pen);
        iClassItem->setBrush(brush);
        iClassItem->setFont(serifFont);
        iClassItem->setPos(iRects[cc].center() + QPoint(0, iRects[cc].height() / 2 + 3));
        iClassItem->setText(iChars[cc]);
        iClassItem->setTransform(t);
        tempItems.push_back(iClassItem);

        pen.setCosmetic(true);
        pen.setWidth(1);

        QGraphicsRectItem* iRectItem = new QGraphicsRectItem(iRects[cc]);
        iRectItem->setTransform(t);
        iRectItem->setPen(pen);
        tempItems.push_back(iRectItem);
    }

    postTemporaryItems(iCav, tempItems);

    std::vector<OCRChar> iOCRChars;
    for (qsizetype cc = 0; cc < iChars.size(); ++cc)
    {
        iOCRChars.emplace_back(iChars[cc], iRects[cc], iConfidences[cc]);
    }

    int iLineIndex = 0;
    QStringList iInfos;
    OCRBox iOCRBox = sortOCR(boxParam.mName, iOCRChars);
    const std::vector<OCRLine>& iLines = std::get<1>(iOCRBox);
    iInfos.append(QStringLiteral("Box: %1").arg(boxParam.mName));
    for (const OCRLine &iLine : iLines)
    {
        QStringList iStrChars;
        QStringList iStrConfidences;
        const std::vector<OCRChar>& iLineChars = std::get<0>(iLine);
        for (const OCRChar &iLineChar : iLineChars)
        {
            iStrChars.push_back(std::get<0>(iLineChar));
            iStrConfidences.push_back(QStringLiteral("%1").arg(std::get<2>(iLineChar), 0, 'f', 2));
        }

        iInfos.append(QStringLiteral("--Line %1: %2 [%3]").arg(iLineIndex++).arg(iStrChars.join(QChar(L'\0'))).arg(iStrConfidences.join(QChar(L', '))));
    }

    postInfoItems(iCav, iInfos);
    return fillBoxResult(boxParam, iOCRBox, boxObj);
}

QMap<QString, std::tuple<QString, QString, QVariant>> MatchOCR::getMatchParamMeta()
{
    QMap<QString, std::tuple<QString, QString, QVariant>> iMetas;
    iMetas[QSL("NumLevels")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 2 << 0 << 5 << 1);
    iMetas[QSL("NumChars")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 1 << 0 << 999 << 1);
    iMetas[QSL("MaxOverlap")] = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << 0.1 << 1.0e-8 << 1 << 2 << 0.05);
    iMetas[QSL("MinScore")] = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << 0.9 << 0.5 << 1.0 << 2 << 0.05);

    if (QSL("Shape") == mClassifierType)
    {
        iMetas[QSL("AngleExtent")]       = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << 0.0 << 0.0 << 3.0 << 2 << 0.5);
        iMetas[QSL("EdgeContrastLower")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 20 << 7 << 255 << 1);
        iMetas[QSL("EdgeContrastUpper")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 30 << 7 << 255 << 1);
        iMetas[QSL("EdgeMinSize")]       = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 5 << 1 << 999 << 1);
        iMetas[QSL("MinContrast")]       = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 15 << 7 << 255 << 1);
        iMetas[QSL("MaxDeformation")]    = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 0 << 0 << 32 << 1);
    }

    if (QSL("Ncc") == mClassifierType)
    {
        iMetas[QSL("WidthCharacter")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 8 << 4 << 20 << 1);
        iMetas[QSL("HeightCharacter")] = std::make_tuple(QSL("Scalar"), QSL("Int"), QVariantList() << 10 << 4 << 20 << 1);
        iMetas[QSL("Nu")] = std::make_tuple(QSL("Scalar"), QSL("Real"), QVariantList() << 0.05 << 0.000000001 << 0.999999999 << 3 << 0.01);
    }

    return iMetas;
}
