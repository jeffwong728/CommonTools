#ifndef PRETRAINED_OCR_H
#define PRETRAINED_OCR_H
#include <QtCore>
#include "ocrbase.h"
class LaserXCanvas;

class PretrainedOCR : public OCRBase
{
    Q_OBJECT
public:
    explicit PretrainedOCR();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;
    void copyDataTo(PretrainedOCR*other) const;
    QVariantMap getCreateParams() const;
    QVariantMap getSearchParams() const;

public:
    int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject &rObj) override;
    int processOCRBox(LaserXCanvas* iCav, LXImage& iMat, const OCRBoxParam& boxParam, const QPointF& rOrigin, const qreal rAngle, const QPointF& aOrigin, const qreal aAngle, QJsonObject &boxObj);

public:
    void drawResult(LaserXCanvas* iCav, const QTransform  &t, const QStringList &iClassLines, const QVector<QVector<QRectF>> &iRectLines, const QVector<QVector<qreal>> &iConfidenceLines);
    QString getFullOCRClassifierPath() const;

public:
    QMap<QString, std::tuple<QString, QString, QVariant>> getAutoParamMeta();
    QMap<QString, std::tuple<QString, QString, QVariant>> getManualParamMeta();

public:
    QString mMode;
    LXTextModel mTextModel;
    QString mOCRClassifier;
    QVariantMap mAutoParams;
    QVariantMap mManualParams;
};

#endif // PRETRAINED_OCR_H
