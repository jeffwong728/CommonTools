#ifndef OCR_BASE_H
#define OCR_BASE_H
#include <QtCore>
#include <procedure/visionprocessor.h>
class LaserXCanvas;

struct OCRLineParam
{
    int mLineNumber = 0;
    int mNumLineChars = 0;
    qreal mMinGap = 0.8;
    std::vector<int> mNumWordChars;
};

struct OCRBoxParam
{
    QString mName;
    QRectF  mRect;
    int     mOrder = 0;
    std::vector<OCRLineParam> mLineParams;
};

using OCRChar = std::tuple<QString, QRectF, qreal>;
using OCRLine = std::tuple<std::vector<OCRChar>, QRectF>;
using OCRBox = std::tuple<QString, std::vector<OCRLine>>;

class OCRBase : public VisionProcessor
{
    Q_OBJECT
public:
    explicit OCRBase();

public:
    void getJson(QJsonObject &rootObj) const;
    void setJson(const QJsonObject& jsonObj);
    void copyDataTo(OCRBase*other) const;

public:
    QString getFullOCRClassifierPath(const QString &fontName) const;
    OCRBox sortOCR(const QString& boxName, const std::vector<OCRChar>& iChars);
    void fillErrorResult(QJsonObject& rObj);
    void fillErrorBoxResult(const OCRBoxParam& boxParam, QJsonObject& boxObj);
    int fillBoxResult(const OCRBoxParam& boxParam, OCRBox &ocrBox, QJsonObject& boxObj);
    std::vector<OCRBoxParam> parseOCRBoxJson(const QJsonValue& ocrBoxParams);
    OCRLine verifyOCRLine(OCRLine &ocrLine, const OCRLineParam &lineParam);
    std::vector<std::vector<OCRChar>> groupChars(const std::vector<OCRChar>& lineChars, const qreal rMinGap);

public:
    QString mPositioning;
    QString mSubstitutionChar;
    qreal mMinConfidence = 0.8;
    QJsonValue mOCRBoxParams;
};

#endif // OCR_BASE_H
