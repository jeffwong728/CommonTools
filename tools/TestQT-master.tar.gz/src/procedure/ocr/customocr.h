#ifndef CUSTOM_OCR_H
#define CUSTOM_OCR_H
#include <QtCore>
#include "ocrbase.h"

class CustomOCR : public OCRBase
{
    Q_OBJECT

public:
    explicit CustomOCR();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    QByteArray getBlob() const override;
    void setJson(const QString& data) override;
    void setBlob(const QByteArray& data) override;
    bool isValid() const override;
    void copyDataTo(CustomOCR* other) const;
    QVariantMap getSegmentParams() const;
    QVariantMap getTrainParams() const;
    QString getClassifierExtension() const;

public:
    int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;

private:
    int processOCRBox(LaserXCanvas* iCav, const LXImage& iMat, const OCRBoxParam& boxParam, const QPointF& rOrigin, const qreal rAngle, const QPointF& aOrigin, const qreal aAngle, QJsonObject& boxObj);

public:
    QMap<QString, std::tuple<QString, QString, QVariant>> getSegmentParamMeta();
    QMap<QString, std::tuple<QString, QString, QVariant>> getSelectParamMeta();
    QMap<QString, std::tuple<QString, QString, QVariant>> getTrainParamMeta();
    QStringList getAllFeatures();

public:
    LXOCR   mOCR;
    QString mFontName;
    QString mClassifierType;
    QString mSegmentScriptName;
    QString mSegmentProcedureName;
    QJsonValue mSampleParams;
    QVariantMap mClassifierParams;
    QVariantMap mSegmentParams;
    QVariantMap mSelectParams;
    QVariantMap mTrainParams;
};

#endif // CUSTOM_OCR_H
