#ifndef NCC_OCR_H
#define NCC_OCR_H
#include <QtCore>
#include "ocrbase.h"

class NccOCR : public OCRBase
{
    Q_OBJECT

public:
    explicit NccOCR();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    QByteArray getBlob() const override;
    void setJson(const QString& data) override;
    void setBlob(const QByteArray& data) override;
    bool isValid() const override;
    void copyDataTo(NccOCR* other) const;
    QVariantMap getMatchParams() const;

public:
    int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;

private:
    int processOCRBox(LaserXCanvas* iCav, const LXImage& iMat, const OCRBoxParam& boxParam, const QPointF& rOrigin, const qreal rAngle, const QPointF& aOrigin, const qreal aAngle, QJsonObject& boxObj);

public:
    QMap<QString, std::tuple<QString, QString, QVariant>> getMatchParamMeta();

public:
    LXOCR   mOCR;
    QString mFontName;
    QString mClassifierType;
    QJsonValue mSampleParams;
    QVariantMap mClassifierParams;
    QVariantMap mMatchParams;
};

#endif // NCC_OCR_H
