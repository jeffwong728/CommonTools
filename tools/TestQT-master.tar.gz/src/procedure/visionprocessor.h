#ifndef VISION_PROCESSOR_H
#define VISION_PROCESSOR_H
#include "cameraparams.h"
#include "outputparams.h"
#include <QtCore>
#include "triggerprocessor.h"
class LaserXCanvas;
class QGraphicsItem;

class VisionProcessor : public TriggerProcessor, public CameraParams, public OutputParams
{
    Q_OBJECT

public:
    explicit VisionProcessor();

public:
    void getJson(QJsonObject &rootObj) const;
    void setJson(const QJsonObject& jsonObj);
    void copyDataTo(VisionProcessor *other) const;

public:
    virtual int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj);

public:
    void onButtonCommand() override;
    void processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj) override;
    static void processAsyncCommand(VisionProcessor* me, QIODevice* ioDev, QJsonObject cmdObj);

public:
    void postSaveData(const QJsonObject &rObj, const cv::Mat& iMat);
    void postVisionProcessSuccess(QIODevice* ioDev, QJsonObject &rObj, const cv::Mat& iMat);
    void postVisionProcessError(QIODevice* ioDev, QJsonObject& rObj, const cv::Mat& iMat, int errId);
    void initResult(QJsonObject& rObj);
    static cv::Mat rotateImage(const cv::Mat& iMat, QJsonObject& cmdObj);
    static bool isValidImage(const cv::Mat& iMat);
};

#endif // VISION_PROCESSOR_H
