#include "netservertrigger.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <ui/runpage.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>
#include <scripting/jsapp.h>
#include <scripting/jsiodevice.h>

NetServerTrigger::NetServerTrigger()
    : LXProcedure()
{
}

QString NetServerTrigger::getTypeName() const
{
    return gTypeNetworkTrigger;
}

QString NetServerTrigger::getJson() const
{
    QJsonObject rootObj;
    rootObj[QLatin1String("NetServer")] = mNetServer;
    rootObj[QLatin1String("CommandName")] = mCommandName;
    rootObj[QLatin1String("JSScript")] = mJSScript;

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void NetServerTrigger::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    disconnectTriggerSource();
    mNetServer = fromJson(jsonObj, QLatin1String("NetServer"), QString());
    mCommandName = fromJson(jsonObj, QLatin1String("CommandName"), QString());
    mJSScript = fromJson(jsonObj, QLatin1String("JSScript"), QString());
    connectToTriggerSource();
}

bool NetServerTrigger::isValid() const
{
    return !mNetServer.isEmpty();
}

void NetServerTrigger::copyDataTo(NetServerTrigger* other) const
{
    other->mNetServer = mNetServer;
    other->mCommandName = mCommandName;
    other->mJSScript = mJSScript;
}

void NetServerTrigger::disconnectTriggerSource()
{
    LaserXNetListener* iNetServer = gDeviceManager->findNetListener(mNetServer);
    if (iNetServer)
    {
        disconnect(iNetServer, &LaserXNetListener::jsonReceived, this, &NetServerTrigger::onJsonReceived);
    }
}

void NetServerTrigger::connectToTriggerSource()
{
    LaserXNetListener* iNetServer = gDeviceManager->findNetListener(mNetServer);
    if (iNetServer)
    {
        connect(iNetServer, &LaserXNetListener::jsonReceived, this, &NetServerTrigger::onJsonReceived);
    }
}

void NetServerTrigger::onJsonReceived(QTcpSocket* connection, const QJsonDocument& cmdDoc)
{
    const QJsonObject jsonObj = cmdDoc.object();
    QString iCommandName = fromJson(jsonObj, QLatin1String("CommandName"), QLatin1String(""));
    QString iProjectName = fromJson(jsonObj, QLatin1String("ProjectName"), QLatin1String(""));
    mCommandSN = fromJson(jsonObj, QLatin1String("CommandSN"), ++mCommandSN);
    if (iCommandName != mCommandName)
    {
        return;
    }

    QJSEngine iEngine;
    iEngine.installExtensions(QJSEngine::ConsoleExtension);
    iEngine.globalObject().setProperty(QStringLiteral("gCommandSN"), mCommandSN);
    iEngine.globalObject().setProperty(QStringLiteral("gCommandName"), mCommandName);
    iEngine.globalObject().setProperty(QStringLiteral("gProjectName"), iProjectName);

    JSApp* iApp = new JSApp(&iEngine, nullptr);
    QJSValue jsApp = iEngine.newQObject(iApp);
    iEngine.setObjectOwnership(iApp, QJSEngine::JavaScriptOwnership);
    iEngine.globalObject().setProperty(QStringLiteral("gApp"), jsApp);

    JSIODevice* iIO = new JSIODevice(connection, nullptr);
    QJSValue jsIO = iEngine.newQObject(iIO);
    iEngine.setObjectOwnership(iIO, QJSEngine::JavaScriptOwnership);
    iEngine.globalObject().setProperty(QStringLiteral("gIO"), jsIO);

    const QString iName = name();
    QJSValue iResult = iEngine.evaluate(mJSScript);
    if (iResult.isError())
    {
        gRunPage->logError(QStringLiteral("Uncaught exception at line %1").arg(iResult.property(QStringLiteral("lineNumber")).toInt()));
        gRunPage->logError(QStringLiteral("With message: %1").arg(iResult.property(QStringLiteral("message")).toString()));
    }
    else
    {
        gRunPage->logInfo(QStringLiteral("Procedure %1 result: %2").arg(iName).arg(iResult.toString()));
    }
}
