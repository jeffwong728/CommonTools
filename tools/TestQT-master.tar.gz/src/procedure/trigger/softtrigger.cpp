#include "softtrigger.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <ui/runpage.h>
#include <laser_x_command_button.h>
#include <scripting/jsapp.h>

SoftTrigger::SoftTrigger()
    : LXProcedure()
{
}

QString SoftTrigger::getTypeName() const
{
    return gTypeSoftTrigger;
}

QString SoftTrigger::getJson() const
{
    QJsonObject rootObj;
    rootObj[QLatin1String("ButtonName")] = mButtonName;
    rootObj[QLatin1String("JSScript")] = mJSScript;

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void SoftTrigger::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    disconnectTriggerSource();
    mButtonName = fromJson(jsonObj, QLatin1String("ButtonName"), QString());
    mJSScript = fromJson(jsonObj, QLatin1String("JSScript"), QString());
    connectToTriggerSource();
}

bool SoftTrigger::isValid() const
{
    return !mButtonName.isEmpty();
}

void SoftTrigger::copyDataTo(SoftTrigger* other) const
{
    other->mButtonName = mButtonName;
    other->mJSScript = mJSScript;
}

void SoftTrigger::disconnectTriggerSource()
{
    if (!mButtonName.isEmpty() && gRunPage)
    {
        QList<LaserXCommandButton*> iButtons = gRunPage->findChildren<LaserXCommandButton*>(mButtonName);
        if (!iButtons.empty())
        {
            disconnect(iButtons[0], &QAbstractButton::clicked, this, &SoftTrigger::onButtonClicked);
        }
    }
}

void SoftTrigger::connectToTriggerSource()
{
    if (!mButtonName.isEmpty() && gRunPage)
    {
        QList<LaserXCommandButton*> iButtons = gRunPage->findChildren<LaserXCommandButton*>(mButtonName);
        if (!iButtons.empty())
        {
            connect(iButtons[0], &QAbstractButton::clicked, this, &SoftTrigger::onButtonClicked);
        }
    }
}

void SoftTrigger::onButtonClicked()
{
    QJSEngine iEngine;
    iEngine.installExtensions(QJSEngine::ConsoleExtension);
    iEngine.globalObject().setProperty(QStringLiteral("gCommandSN"), ++mCommandSN);

    JSApp* iApp = new JSApp(&iEngine, nullptr);
    QJSValue jsApp = iEngine.newQObject(iApp);
    iEngine.setObjectOwnership(iApp, QJSEngine::JavaScriptOwnership);
    iEngine.globalObject().setProperty(QStringLiteral("gApp"), jsApp);

    QJSValue iResult = iEngine.evaluate(mJSScript);
    if (iResult.isError())
    {
        gRunPage->logError(QStringLiteral("Uncaught exception at line %1").arg(iResult.property(QStringLiteral("lineNumber")).toInt()));
        gRunPage->logError(QStringLiteral("With message: %1").arg(iResult.property(QStringLiteral("message")).toString()));
    }
    else
    {
        gRunPage->logInfo(QStringLiteral("Procedure %1 result: %2").arg(name()).arg(iResult.toString()));
    }
}
