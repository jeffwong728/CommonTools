#include "timertrigger.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <ui/runpage.h>
#include <scripting/jsiodevice.h>
#include <scripting/jsapp.h>

TimerTrigger::TimerTrigger()
    : LXProcedure()
{
    mTimer.setInterval(mInterval);
    connect(&mTimer, &QTimer::timeout, this, &TimerTrigger::onTimeout);
}

QString TimerTrigger::getTypeName() const
{
    return gTypeTimerTrigger;
}

QString TimerTrigger::getJson() const
{
    QJsonObject rootObj;
    rootObj[QLatin1String("Interval")] = mInterval;
    rootObj[QLatin1String("JSScript")] = mJSScript;
    rootObj[QLatin1String("Active")] = mTimer.isActive();

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void TimerTrigger::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    mInterval = fromJson(jsonObj, QLatin1String("Interval"), 100);
    mJSScript = fromJson(jsonObj, QLatin1String("JSScript"), QString());
    bool iActive = fromJson(jsonObj, QLatin1String("Active"), false);

    if (mTimer.isActive())
    {
        mTimer.stop();
    }

    if (iActive)
    {
        mTimer.setInterval(mInterval);
        mTimer.start();
    }
}

bool TimerTrigger::isValid() const
{
    return !mJSScript.isEmpty();
}

void TimerTrigger::onTimeout()
{
    if (mJSScript.isEmpty())
    {
        return;
    }

    QJSEngine iEngine;
    iEngine.installExtensions(QJSEngine::ConsoleExtension);
    iEngine.globalObject().setProperty(QStringLiteral("gCommandSN"), ++mCommandSN);

    JSApp* iApp = new JSApp(&iEngine, nullptr);
    QJSValue jsApp = iEngine.newQObject(iApp);
    iEngine.setObjectOwnership(iApp, QJSEngine::JavaScriptOwnership);
    iEngine.globalObject().setProperty(QStringLiteral("gApp"), jsApp);

    QJSValue iResult = iEngine.evaluate(mJSScript);
    if (iResult.isError())
    {
        gRunPage->logError(QStringLiteral("Uncaught exception at line %1").arg(iResult.property(QStringLiteral("lineNumber")).toInt()));
        gRunPage->logError(QStringLiteral("With message: %1").arg(iResult.property(QStringLiteral("message")).toString()));
    }
}
