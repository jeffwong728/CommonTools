#ifndef TIMERTRIGGER_H
#define TIMERTRIGGER_H

#include <procedure/lxprocedure.h>
#include <QTimer>

class TimerTrigger : public LXProcedure
{
    Q_OBJECT
public:
    explicit TimerTrigger();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;

public:
    void onTimeout();

public:
    QTimer mTimer;
    QString mJSScript;
    int mInterval = 30;
    int mCommandSN = 0;
};

#endif // TIMERTRIGGER_H
