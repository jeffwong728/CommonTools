#ifndef NET_SERVER_TRIGGER_H
#define NET_SERVER_TRIGGER_H
#include <procedure/lxprocedure.h>
class QTcpSocket;

class NetServerTrigger : public LXProcedure
{
    Q_OBJECT
public:
    explicit NetServerTrigger();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;

public:
    void copyDataTo(NetServerTrigger* other) const;
    void disconnectTriggerSource();
    void connectToTriggerSource();
    void onJsonReceived(QTcpSocket* connection, const QJsonDocument& cmdDoc);

public:
    QString mCommandName;
    QString mNetServer;
    QString mJSScript;
    int mCommandSN = 0;
};

#endif // NET_SERVER_TRIGGER_H
