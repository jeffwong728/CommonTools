#ifndef SOFTTRIGGER_H
#define SOFTTRIGGER_H

#include <procedure/lxprocedure.h>
class QAbstractButton;
class RunPage;

class SoftTrigger : public LXProcedure
{
    Q_OBJECT
public:
    explicit SoftTrigger();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;

public:
    void copyDataTo(SoftTrigger* other) const;
    void disconnectTriggerSource();
    void connectToTriggerSource();
    void onButtonClicked();

public:
    QString mButtonName;
    QString mJSScript;
    int mCommandSN = 0;
};

#endif // SOFTTRIGGER_H
