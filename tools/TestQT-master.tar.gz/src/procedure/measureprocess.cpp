#include "measureprocess.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/runpage.h>
#include <ui/flowchart/flowview.h>
#include <laser_x_canvas.h>

MeasureProcess::MeasureProcess()
{
}

QString MeasureProcess::getTypeName() const
{
    return gTypeGeomMeasure;
}

QString MeasureProcess::getJson() const
{
    QJsonObject rootObj;
    VisionProcessor::getJson(rootObj);
    rootObj[QLatin1String("MeasureParams")]         = mMeasureParams;
    rootObj[QLatin1String("PostScriptName")]        = mPostScriptName;
    rootObj[QLatin1String("PostProcedureName")]     = mPostProcedureName;
    rootObj[QLatin1String("PositioningProcedure")]  = mPositioningProcedure;

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

QByteArray MeasureProcess::getBlob() const
{
    if (mModel)
    {
        return mModel->getBlob();
    }
    else
    {
        return QByteArray();
    }
}

void MeasureProcess::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    VisionProcessor::setJson(jsonObj);
    mMeasureParams = getJsonObject(jsonObj, QLatin1String("MeasureParams"));
    mPostScriptName = fromJson(jsonObj, QLatin1String("PostScriptName"), QLatin1String(""));
    mPostProcedureName = fromJson(jsonObj, QLatin1String("PostProcedureName"), QLatin1String(""));
    mPositioningProcedure = fromJson(jsonObj, QLatin1String("PositioningProcedure"), QStringLiteral("None"));
    parseGeomNameIndexs();
}

void MeasureProcess::setBlob(const QByteArray& data)
{
    mModel = gVision->readMeasureModel(data);
}

bool MeasureProcess::isValid() const
{
    return !mModel.isNull();
}

void MeasureProcess::copyDataTo(MeasureProcess* other) const
{
    VisionProcessor::copyDataTo(other);
    other->mMeasureParams = mMeasureParams;
    other->mPostScriptName = mPostScriptName;
    other->mPostProcedureName = mPostProcedureName;
    other->mPositioningProcedure = mPositioningProcedure;
}

qlonglong MeasureProcess::numGeoms() const
{
    return mLineNameIndexs.size() + mRectNameIndexs.size() + mCircleNameIndexs.size() + mEllipseNameIndexs.size();
}

int MeasureProcess::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    if (!iCav || !isValidImage(iMat))
    {
        return false;
    }

    if (!mModel || !numGeoms())
    {
        return false;
    }

    LXProcedure* iPosProc = gFlowView->findLXProcedure(mPositioningProcedure);
    if (iPosProc && iPosProc->isPositioning())
    {
        std::tuple<QPointF, qreal, bool> iMatchingResult = iPosProc->doPositioning(iCav, iMat, rObj);
        if (!std::get<2>(iMatchingResult))
        {
            return false;
        }

        QPointF rsOrigin = iPosProc->getCenter();
        qreal rsAngle = iPosProc->getAngle();
        QPointF aOrigin = std::get<0>(iMatchingResult);
        qreal aAngle = std::get<1>(iMatchingResult);
        QVariantMap rMap = gVision->vectorAngleToAffine(rsOrigin, rsAngle, aOrigin, aAngle);
        QPointF tPoint(rMap[QStringLiteral("Column")].toReal(), rMap[QStringLiteral("Row")].toReal());
        alignModel(tPoint, rMap[QStringLiteral("Angle")].toReal());
    }
    else
    {
        QPointF iOrigin;
        alignModel(iOrigin, 0.);
    }

    mModel->applyMeasure(iMat);
    qlonglong iNumLines = parseLineResults(iCav, rObj);
    qlonglong iNumRects = parseRectResults(iCav, rObj);
    qlonglong iNumCircles = parseCircleResults(iCav, rObj);
    qlonglong iNumEllipses = parseEllipseResults(iCav, rObj);
    qlonglong iNumFoundGeoms = iNumLines + iNumRects + iNumCircles + iNumEllipses;

    QStringList iInfos;
    if (iNumFoundGeoms == numGeoms())
    {
        QPen pen(Qt::green);
        pen.setCosmetic(true);
        pen.setWidth(1);

        QString iScriptPath = QAppHelper::getSetting<QString>(gAppScriptsDir) + QDir::separator() + mPostScriptName + QStringLiteral(".hdev");
        QVariantMap iResults = mModel->getPostResult(rObj, iScriptPath, mPostProcedureName);
        for (const QString &iKey : iResults.keys())
        {
            QVariant iVariant = iResults[iKey];
            if (iVariant.canConvert(QVariant::Double))
            {
                const qreal iVal = iVariant.toReal();
                rObj[iKey] = iVal;
                iInfos.append(QStringLiteral("%1=%2").arg(iKey).arg(iVal, 0, 'f', 2));
            }
            else if (iVariant.canConvert(QVariant::PointF))
            {
                const QPointF iPoint = iVariant.toPointF();
                rObj[iKey] = toJson(iPoint);
                QGraphicsLineItem* iVLineItem = new QGraphicsLineItem(iPoint.x() - 8, iPoint.y() - 8, iPoint.x() + 8, iPoint.y() + 8);
                QGraphicsLineItem* iHLineItem = new QGraphicsLineItem(iPoint.x() - 8, iPoint.y() + 8, iPoint.x() + 8, iPoint.y() - 8);
                QGraphicsEllipseItem* iGeomItem = new QGraphicsEllipseItem(iPoint.x()-5, iPoint.y()-5, 11, 11);
                iVLineItem->setPen(pen);
                iHLineItem->setPen(pen);
                iGeomItem->setPen(pen);
                iCav->addTemporaryItem(iGeomItem);
                iCav->addTemporaryItem(iVLineItem);
                iCav->addTemporaryItem(iHLineItem);
            }
            else if (iVariant.canConvert(QVariant::LineF))
            {
                const QLineF iLine = iVariant.toLineF();
                rObj[iKey] = toJson(iLine);
                QGraphicsLineItem* iGeomItem = new QGraphicsLineItem(iLine);
                iGeomItem->setPen(pen);
                iCav->addTemporaryItem(iGeomItem);
            }
            else
            {
                qWarning() << QStringLiteral("Unknown result type");
            }
        }

        iCav->addInfoItems(iInfos);
        return !iResults.empty();
    }
    else
    {
        iInfos.append(QStringLiteral("Failed"));
        iCav->addInfoItems(iInfos);
        return false;
    }
}

void MeasureProcess::setReferenceSystem(QPointF& rsOrigin, qreal rsAngle)
{
    if (mModel)
    {
        mModel->setReferenceSystem(rsOrigin, rsAngle);
    }
}

void MeasureProcess::alignModel(QPointF& aOrigin, qreal aAngle)
{
    if (mModel)
    {
        mModel->alignModel(aOrigin, aAngle);
    }
}

void MeasureProcess::parseGeomNameIndexs()
{
    mLineNameIndexs.clear();
    mRectNameIndexs.clear();
    mCircleNameIndexs.clear();
    mEllipseNameIndexs.clear();

    if (mMeasureParams.contains(QStringLiteral("Lines")))
    {
        QJsonValue val = mMeasureParams.value(QStringLiteral("Lines"));
        if (val.isArray())
        {
            QJsonArray iArray = val.toArray();
            for (const auto& iGeom : iArray)
            {
                QJsonObject iGeomObj = iGeom.toObject();
                QString iName = fromJson(iGeomObj, QLatin1String("Name"), QStringLiteral(""));
                qlonglong iMeasureIndex = fromJson(iGeomObj, QLatin1String("MeasureIndex"), -1ll);
                if (!iName.isEmpty() && iMeasureIndex >= 0)
                {
                    mLineNameIndexs.emplace_back(iName, iMeasureIndex);
                }
            }
        }
    }

    if (mMeasureParams.contains(QStringLiteral("Rects")))
    {
        QJsonValue val = mMeasureParams.value(QStringLiteral("Rects"));
        if (val.isArray())
        {
            QJsonArray iArray = val.toArray();
            for (const auto& iGeom : iArray)
            {
                QJsonObject iGeomObj = iGeom.toObject();
                QString iName = fromJson(iGeomObj, QLatin1String("Name"), QStringLiteral(""));
                qlonglong iMeasureIndex = fromJson(iGeomObj, QLatin1String("MeasureIndex"), -1ll);
                if (!iName.isEmpty() && iMeasureIndex >= 0)
                {
                    mRectNameIndexs.emplace_back(iName, iMeasureIndex);
                }
            }
        }
    }

    if (mMeasureParams.contains(QStringLiteral("Circles")))
    {
        QJsonValue val = mMeasureParams.value(QStringLiteral("Circles"));
        if (val.isArray())
        {
            QJsonArray iArray = val.toArray();
            for (const auto& iGeom : iArray)
            {
                QJsonObject iGeomObj = iGeom.toObject();
                QString iName = fromJson(iGeomObj, QLatin1String("Name"), QStringLiteral(""));
                qlonglong iMeasureIndex = fromJson(iGeomObj, QLatin1String("MeasureIndex"), -1ll);
                if (!iName.isEmpty() && iMeasureIndex >= 0)
                {
                    mCircleNameIndexs.emplace_back(iName, iMeasureIndex);
                }
            }
        }
    }

    if (mMeasureParams.contains(QStringLiteral("Ellipses")))
    {
        QJsonValue val = mMeasureParams.value(QStringLiteral("Ellipses"));
        if (val.isArray())
        {
            QJsonArray iArray = val.toArray();
            for (const auto& iGeom : iArray)
            {
                QJsonObject iGeomObj = iGeom.toObject();
                QString iName = fromJson(iGeomObj, QLatin1String("Name"), QStringLiteral(""));
                qlonglong iMeasureIndex = fromJson(iGeomObj, QLatin1String("MeasureIndex"), -1ll);
                if (!iName.isEmpty() && iMeasureIndex >= 0)
                {
                    mEllipseNameIndexs.emplace_back(iName, iMeasureIndex);
                }
            }
        }
    }
}

qlonglong MeasureProcess::parseLineResults(LaserXCanvas* iCav, QJsonObject& rObj)
{
    QPen pen(Qt::green);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QJsonArray iResultLines;
    for (const auto &iNameIndex : mLineNameIndexs)
    {
        qlonglong iNumInstances = mModel->getNumInstances(iNameIndex.second);
        if (1 != iNumInstances)
        {
            continue;
        }

        QVariant instance = 0;
        QVariantMap iResult = mModel->getMeasureResult(iNameIndex.second, instance);
        if (!iResult.contains(QStringLiteral("Score"))
            || !iResult.contains(QStringLiteral("StartPoint"))
            || !iResult.contains(QStringLiteral("EndPoint")))
        {
            continue;
        }

        qreal iScore = iResult[QStringLiteral("Score")].toDouble();
        QPointF iStartPoint = iResult[QStringLiteral("StartPoint")].toPointF();
        QPointF iEndPoint = iResult[QStringLiteral("EndPoint")].toPointF();
        QLineF iLine(iStartPoint, iEndPoint);

        QJsonObject rGeom;
        rGeom[QStringLiteral("Name")] = iNameIndex.first;
        rGeom[QStringLiteral("Score")] = iScore;
        rGeom[QStringLiteral("StartX")] = iStartPoint.x();
        rGeom[QStringLiteral("StartY")] = iStartPoint.y();
        rGeom[QStringLiteral("EndX")] = iEndPoint.x();
        rGeom[QStringLiteral("EndY")] = iEndPoint.y();
        rGeom[QStringLiteral("Angle")] = iLine.angle();

        iResultLines.push_back(rGeom);

        QGraphicsLineItem* iGeomItem = new QGraphicsLineItem(QLineF(iStartPoint, iEndPoint));
        iGeomItem->setPen(pen);
        iCav->addTemporaryItem(iGeomItem);
    }

    if (!iResultLines.empty())
    {
        rObj[QStringLiteral("Lines")] = iResultLines;
    }

    return iResultLines.size();
}

qlonglong MeasureProcess::parseRectResults(LaserXCanvas* iCav, QJsonObject& rObj)
{
    QPen pen(Qt::green);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QJsonArray iResultRects;
    for (const auto& iNameIndex : mRectNameIndexs)
    {
        qlonglong iNumInstances = mModel->getNumInstances(iNameIndex.second);
        if (1 != iNumInstances)
        {
            continue;
        }

        QVariant instance = 0;
        QVariantMap iResult = mModel->getMeasureResult(iNameIndex.second, instance);
        if (!iResult.contains(QStringLiteral("Score"))
            || !iResult.contains(QStringLiteral("CenterPoint"))
            || !iResult.contains(QStringLiteral("Angle"))
            || !iResult.contains(QStringLiteral("SemiMajorAxis"))
            || !iResult.contains(QStringLiteral("SemiMinorAxis")))
        {
            continue;
        }

        qreal iScore = iResult[QStringLiteral("Score")].toReal();
        QPointF iCenterPoint = iResult[QStringLiteral("CenterPoint")].toPointF();
        qreal iAngle = iResult[QStringLiteral("Angle")].toReal();
        qreal iSemiMajorAxis = iResult[QStringLiteral("SemiMajorAxis")].toReal();
        qreal iSemiMinorAxis = iResult[QStringLiteral("SemiMinorAxis")].toReal();

        QJsonObject rGeom;
        rGeom[QStringLiteral("Name")] = iNameIndex.first;
        rGeom[QStringLiteral("Score")] = iScore;
        rGeom[QStringLiteral("CenterX")] = iCenterPoint.x();
        rGeom[QStringLiteral("CenterY")] = iCenterPoint.y();
        rGeom[QStringLiteral("Angle")] = iAngle;
        rGeom[QStringLiteral("SemiMajorAxis")] = iSemiMajorAxis;
        rGeom[QStringLiteral("SemiMinorAxis")] = iSemiMinorAxis;
        iResultRects.push_back(rGeom);

        QTransform t;
        t.translate(iCenterPoint.x(), iCenterPoint.y());
        t.rotate(-iAngle);
        t.translate(-iCenterPoint.x(), -iCenterPoint.y());

        QPainterPath iPath;
        iPath.addRect(QRectF(iCenterPoint + QPointF(-iSemiMajorAxis, -iSemiMinorAxis), iCenterPoint + QPointF(iSemiMajorAxis, iSemiMinorAxis)));
        QGraphicsPathItem* iGeomItem = new QGraphicsPathItem(t.map(iPath));
        iGeomItem->setPen(pen);
        iGeomItem->setBrush(QBrush(Qt::NoBrush));
        iCav->addTemporaryItem(iGeomItem);
    }

    if (!iResultRects.empty())
    {
        rObj[QStringLiteral("Rects")] = iResultRects;
    }

    return iResultRects.size();
}

qlonglong MeasureProcess::parseCircleResults(LaserXCanvas* iCav, QJsonObject& rObj)
{
    QPen pen(Qt::green);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QJsonArray iResultCircles;
    for (const auto& iNameIndex : mCircleNameIndexs)
    {
        qlonglong iNumInstances = mModel->getNumInstances(iNameIndex.second);
        if (1 != iNumInstances)
        {
            continue;
        }

        QVariant instance = 0;
        QVariantMap iResult = mModel->getMeasureResult(iNameIndex.second, instance);
        if (!iResult.contains(QStringLiteral("Score"))
            || !iResult.contains(QStringLiteral("CenterPoint"))
            || !iResult.contains(QStringLiteral("Radius")))
        {
            continue;
        }

        qreal iScore = iResult[QStringLiteral("Score")].toDouble();
        QPointF iCenterPoint = iResult[QStringLiteral("CenterPoint")].toPointF();
        qreal iRadius = iResult[QStringLiteral("Radius")].toReal();

        QJsonObject rGeom;
        rGeom[QStringLiteral("Name")] = iNameIndex.first;
        rGeom[QStringLiteral("Score")] = iScore;
        rGeom[QStringLiteral("CenterX")] = iCenterPoint.x();
        rGeom[QStringLiteral("CenterY")] = iCenterPoint.y();
        rGeom[QStringLiteral("Radius")] = iRadius;

        iResultCircles.push_back(rGeom);

        QGraphicsEllipseItem* iGeomItem = new QGraphicsEllipseItem(QRectF(iCenterPoint + QPointF(-iRadius, -iRadius), iCenterPoint + QPointF(iRadius, iRadius)));
        iGeomItem->setPen(pen);
        iGeomItem->setBrush(QBrush(Qt::NoBrush));
        iCav->addTemporaryItem(iGeomItem);
    }

    if (!iResultCircles.empty())
    {
        rObj[QStringLiteral("Circles")] = iResultCircles;
    }

    return iResultCircles.size();
}

qlonglong MeasureProcess::parseEllipseResults(LaserXCanvas* iCav, QJsonObject& rObj)
{
    QPen pen(Qt::green);
    pen.setCosmetic(true);
    pen.setWidth(1);

    QJsonArray iResultEllipses;
    for (const auto& iNameIndex : mEllipseNameIndexs)
    {
        qlonglong iNumInstances = mModel->getNumInstances(iNameIndex.second);
        if (1 != iNumInstances)
        {
            continue;
        }

        QVariant instance = 0;
        QVariantMap iResult = mModel->getMeasureResult(iNameIndex.second, instance);
        if (!iResult.contains(QStringLiteral("Score"))
            || !iResult.contains(QStringLiteral("CenterPoint"))
            || !iResult.contains(QStringLiteral("Angle"))
            || !iResult.contains(QStringLiteral("SemiMajorAxis"))
            || !iResult.contains(QStringLiteral("SemiMinorAxis")))
        {
            continue;
        }

        qreal iScore = iResult[QStringLiteral("Score")].toReal();
        QPointF iCenterPoint = iResult[QStringLiteral("CenterPoint")].toPointF();
        qreal iAngle = iResult[QStringLiteral("Angle")].toReal();
        qreal iSemiMajorAxis = iResult[QStringLiteral("SemiMajorAxis")].toReal();
        qreal iSemiMinorAxis = iResult[QStringLiteral("SemiMinorAxis")].toReal();

        QJsonObject rGeom;
        rGeom[QStringLiteral("Name")] = iNameIndex.first;
        rGeom[QStringLiteral("Score")] = iScore;
        rGeom[QStringLiteral("CenterX")] = iCenterPoint.x();
        rGeom[QStringLiteral("CenterY")] = iCenterPoint.y();
        rGeom[QStringLiteral("Angle")] = iAngle;
        rGeom[QStringLiteral("SemiMajorAxis")] = iSemiMajorAxis;
        rGeom[QStringLiteral("SemiMinorAxis")] = iSemiMinorAxis;
        iResultEllipses.push_back(rGeom);

        QTransform t;
        t.translate(iCenterPoint.x(), iCenterPoint.y());
        t.rotate(-iAngle);
        t.translate(-iCenterPoint.x(), -iCenterPoint.y());

        QPainterPath iPath;
        iPath.addEllipse(QRectF(iCenterPoint + QPointF(-iSemiMajorAxis, -iSemiMinorAxis), iCenterPoint + QPointF(iSemiMajorAxis, iSemiMinorAxis)));
        QGraphicsPathItem* iGeomItem = new QGraphicsPathItem(t.map(iPath));
        iGeomItem->setPen(pen);
        iGeomItem->setBrush(QBrush(Qt::NoBrush));
        iCav->addTemporaryItem(iGeomItem);
    }

    if (!iResultEllipses.empty())
    {
        rObj[QStringLiteral("Ellipses")] = iResultEllipses;
    }

    return iResultEllipses.size();
}
