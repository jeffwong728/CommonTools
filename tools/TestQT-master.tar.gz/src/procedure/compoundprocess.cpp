#include "compoundprocess.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <laser_x_canvas.h>

CompoundProcess::CompoundProcess()
    : mCompoundType(QStringLiteral("Any"))
{
}

QString CompoundProcess::getTypeName() const
{
    return gTypeCompoundProcess;
}

QString CompoundProcess::getJson() const
{
    QJsonObject rootObj;

    VisionProcessor::getJson(rootObj);
    rootObj[QLatin1String("CompoundType")]  = mCompoundType;
    rootObj[QLatin1String("SubProcedures")] = QJsonArray::fromStringList(mSubProcedures);

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

QByteArray CompoundProcess::getBlob() const
{
    return QByteArray();
}

void CompoundProcess::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    VisionProcessor::setJson(jsonObj);

    mCompoundType = fromJson(jsonObj, QLatin1String("CompoundType"), QStringLiteral("Any"));
    mSubProcedures = fromJson(jsonObj, QLatin1String("SubProcedures"), QStringList());
}

void CompoundProcess::setBlob(const QByteArray& data)
{
}

bool CompoundProcess::isValid() const
{
    return !mSubProcedures.isEmpty();
}

void CompoundProcess::copyDataTo(CompoundProcess* other) const
{
    VisionProcessor::copyDataTo(other);
    other->mCompoundType = mCompoundType;
    other->mSubProcedures = mSubProcedures;
}

bool CompoundProcess::isValidProcedureFlow(QString& errMsg) const
{
    errMsg = tr("Compound type %1 not supported yet").arg(mCompoundType);
    return false;
}

bool CompoundProcess::isValidPositioningAndMeasureFlow(QString& errMsg) const
{
    int numShapeMatching = 0;
    std::vector<LXProcedure*> iSubProcs;
    int iMatchingIndex = -1;
    std::vector<int> iMeasureIndexs;

    int index = 0;
    for (const QString &iUUID : mSubProcedures)
    {
        LXProcedure* iSubProc = gFlowView->findLXProcedure(iUUID);
        if (iSubProc)
        {
            iSubProcs.push_back(iSubProc);
        }
        else
        {
            errMsg = tr("Invalid procedure found in %1").arg(name());
            return false;
        }

        if (gTypeShapeTemplate == iSubProc->getTypeName())
        {
            if (iMatchingIndex < 0)
            {
                iMatchingIndex = index;
            }
            else
            {
                errMsg = tr("Only need one shape template").arg(name());
                return false;
            }
        }
        else if (gTypeGeomMeasure == iSubProc->getTypeName())
        {
            iMeasureIndexs.push_back(index);
        }
        else
        {
            errMsg = tr("Procedure type %1 not supported yet").arg(iSubProc->getTypeName());
            return false;
        }

        index += 1;
    }

    if (iMatchingIndex < 0)
    {
        errMsg = tr("No template matching procedure found").arg(name());
        return false;
    }

    if (iMeasureIndexs.empty())
    {
        errMsg = tr("No geometry measure procedure found").arg(name());
        return false;
    }

    if (!std::all_of(iMeasureIndexs.begin(), iMeasureIndexs.end(), [iMatchingIndex](const int v) { return v > iMatchingIndex; }))
    {
        errMsg = tr("Matching procedure must precede all measure procedures").arg(name());
        return false;
    }
    else
    {
        return true;
    }
}

int CompoundProcess::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    Q_UNUSED(rObj);
    if (!iCav || !isValidImage(iMat))
    {
        return false;
    }

    bool bOk = true;
    if (QStringLiteral("Any") == mCompoundType)
    {
        for (const QString& iUUID : mSubProcedures)
        {
            LXProcedure* iSubProc = gFlowView->findLXProcedure(iUUID);
            if (!iSubProc)
            {
                continue;
            }

            bOk = bOk && iSubProc->process(rObj);
            if (bOk)
            {
                break;
            }
        }
    }
    else
    {
        for (const QString& iUUID : mSubProcedures)
        {
            LXProcedure* iSubProc = gFlowView->findLXProcedure(iUUID);
            if (!iSubProc)
            {
                continue;
            }

            bOk = bOk && iSubProc->process(rObj);
        }
    }

    return bOk;
}
