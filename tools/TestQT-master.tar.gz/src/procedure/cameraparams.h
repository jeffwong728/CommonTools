#ifndef CAMERA_PARAMS_H
#define CAMERA_PARAMS_H
#include <QtCore>

struct LightSourceParam
{
    QString mLightSourceUUID;
    QString mLightSourceStatus;
    int mLightSourceChannel = 0;
    int mLightSourceBrightness = 0;
    void setLightSource() const;
    QJsonObject toJson() const;
    void setJson(const QJsonObject& jObj);
    static QJsonArray toJsonArray(const std::vector<LightSourceParam>& lightSourceParams);
    static std::vector<LightSourceParam> fromJsonArray(const QJsonObject &jObj, const QLatin1String& name);
};

class CameraParams
{
public:
    explicit CameraParams();

public:
    void getJson(QJsonObject &jObj) const;
    void setJson(const QJsonObject& jObj);
    void copyDataTo(CameraParams *other) const;
    void setLightSources() const;

public:
    QString mCameraUUID;
    QVariantMap mCameraGrabParams;
    qlonglong mImageWidth = 640;
    qlonglong mImageHeight = 480;
    std::vector<LightSourceParam> mLightSourceParams;
};

#endif // CAMERA_PARAMS_H
