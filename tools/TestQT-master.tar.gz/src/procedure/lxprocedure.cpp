#include "lxprocedure.h"
#include <laser_x_canvas.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>

LXProcedure::LXProcedure()
    : QObject{nullptr}
{
}

LXProcedure::~LXProcedure()
{
}

void LXProcedure::setProcedureItem(LXProcedureItem* const procedureItem)
{
    const_cast<LXProcedureItem *&>(mProcedureItem) = procedureItem;
}

QString LXProcedure::name() const
{
    if (mProcedureItem)
    {
        return mProcedureItem->getName();
    }
    else
    {
        return QString();
    }
}

QString LXProcedure::uuid() const
{
    if (mProcedureItem)
    {
        return mProcedureItem->getUUID();
    }
    else
    {
        return QString();
    }
}

QString LXProcedure::getJson() const
{
    return QString();
}

QByteArray LXProcedure::getBlob() const
{
    return QByteArray();
}

QByteArray LXProcedure::getImageData() const
{
    return QByteArray();
}

bool LXProcedure::isPositioning() const
{
    return false;
}

QPointF LXProcedure::getCenter() const
{
    return QPointF();
}

qreal LXProcedure::getAngle() const
{
    return 0.;
}

std::tuple<QPointF, qreal, bool> LXProcedure::doPositioning(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    Q_UNUSED(iCav);
    Q_UNUSED(iMat);
    Q_UNUSED(rObj);
    return std::make_tuple(QPointF(), 0., false);
}

bool LXProcedure::process(QJsonObject& rObj)
{
    Q_UNUSED(rObj);
    return false;
}

void LXProcedure::setJson(const QString& data)
{
}

void LXProcedure::setBlob(const QByteArray& data)
{
}

void LXProcedure::setImageData(const QByteArray& data)
{
}

ScopedCanvasTimer::ScopedCanvasTimer(LaserXCanvas* canvas) : mCanvas(canvas)
{
    mTimer.start();
}

ScopedCanvasTimer::~ScopedCanvasTimer()
{
    if (mCanvas)
    {
        QString iInfo = QStringLiteral("Timing=%1ms").arg(mTimer.elapsed());
        mCanvas->addInfoItem(iInfo);
    }
}
