#ifndef JS_IMAGE_PROCESS_H
#define JS_IMAGE_PROCESS_H
#include "visionprocessor.h"
class LaserXCanvas;

class JSImageProcess : public VisionProcessor
{
    Q_OBJECT

public:
    explicit JSImageProcess();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    void setJson(const QString& data) override;
    bool isValid() const override;
    void copyDataTo(JSImageProcess *other) const;

public:
    int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;

public:
    QString mJSSript;
};

#endif // JS_IMAGE_PROCESS_H
