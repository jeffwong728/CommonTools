#include "jsimageprocess.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/loggingdb.h>
#include <ui/runpage.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

JSImageProcess::JSImageProcess()
{
}

QString JSImageProcess::getTypeName() const
{
    return gTypeJSImageProcess;
}

QString JSImageProcess::getJson() const
{
    QJsonObject rootObj;
    VisionProcessor::getJson(rootObj);
    rootObj[QLatin1String("JSSript")]  = mJSSript;

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void JSImageProcess::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    VisionProcessor::setJson(jsonObj);
    mJSSript = fromJson(jsonObj, QLatin1String("JSSript"), QSL(""));
}

bool JSImageProcess::isValid() const
{
    return !mJSSript.isEmpty();
}

void JSImageProcess::copyDataTo(JSImageProcess *other) const
{
    VisionProcessor::copyDataTo(other);
    other->mJSSript = mJSSript;
}

int JSImageProcess::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    return kImageProcessError_General;
}
