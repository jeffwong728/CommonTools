#include "triggerprocessor.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/loggingdb.h>
#include <ui/runpage.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

TriggerProcessor::TriggerProcessor()
{
}

void TriggerProcessor::getJson(QJsonObject& rootObj) const
{
    TriggerParams::getJson(rootObj);
}

void TriggerProcessor::setJson(const QJsonObject &jsonObj)
{
    TriggerParams::setJson(jsonObj);
}

void TriggerProcessor::copyDataTo(TriggerProcessor* other) const
{
    TriggerParams::copyDataTo(other);
}

void TriggerProcessor::onButtonCommand()
{
    qWarning() << QStringLiteral("%1 not implemented").arg(QStringLiteral(Q_FUNC_INFO));
}

void TriggerProcessor::onSerialPortCommand(const QJsonDocument& cmdDoc)
{
    QJsonObject jsonObj = cmdDoc.object();
    QString iCommandName = fromJson(jsonObj, QLatin1String("CommandName"), QLatin1String(""));
    mCommandSN = fromJson(jsonObj, QLatin1String("CommandSN"), ++mCommandSN);
    if (iCommandName != mCommandName)
    {
        return;
    }

    LaserXSerialPort* iSerialPort = qobject_cast<LaserXSerialPort*>(sender());
    processIODeviceCommand(iSerialPort, jsonObj);
}

void TriggerProcessor::onNetClientCommand()
{
    QTcpSocket* clientConnection = qobject_cast<QTcpSocket*>(sender());
    if (!clientConnection)
    {
        return;
    }

    QByteArray cmdData;
    if (clientConnection->canReadLine())
    {
        cmdData = clientConnection->readLine();
    }
    else
    {
        cmdData = clientConnection->readAll();
    }

    quint16 iPort = clientConnection->peerPort();
    QString iPeerAddress = clientConnection->peerAddress().toString();

    QJsonParseError jsonError;
    QJsonDocument cmdDoc = QJsonDocument::fromJson(cmdData, &jsonError);
    if (QJsonParseError::NoError == jsonError.error)
    {
        gRunPage->logInfo(QStringLiteral("Command received from %1:%2: %3").arg(iPeerAddress).arg(iPort).arg(QString::fromUtf8(cmdData)));
        QJsonObject jsonObj = cmdDoc.object();
        QString iCommandName = fromJson(jsonObj, QLatin1String("CommandName"), QLatin1String(""));
        mCommandSN = fromJson(jsonObj, QLatin1String("CommandSN"), ++mCommandSN);
        if (iCommandName == mCommandName)
        {
            processIODeviceCommand(clientConnection, jsonObj);
        }
    }
    else
    {
        QString iString = QString::fromUtf8(cmdData);
        if (!iString.isEmpty())
        {
            gRunPage->logInfo(QStringLiteral("Command received from %1:%2: %3").arg(iPeerAddress).arg(iPort).arg(iString));
        }
        else
        {
            gRunPage->logInfo(QStringLiteral("Command received from %1:%2: %3").arg(iPeerAddress).arg(iPort).arg(QString::fromUtf8(cmdData.toHex(':'))));
        }
    }
}

void TriggerProcessor::onNetServerCommand(QTcpSocket* connection, const QJsonDocument& cmdDoc)
{
    QJsonObject jsonObj = cmdDoc.object();
    QString iCommandName = fromJson(jsonObj, QLatin1String("CommandName"), QLatin1String(""));
    mCommandSN = fromJson(jsonObj, QLatin1String("CommandSN"), ++mCommandSN);
    if (iCommandName != mCommandName)
    {
        return;
    }
    processIODeviceCommand(connection, jsonObj);
}

void TriggerProcessor::processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj)
{
    Q_UNUSED(ioDev);
    Q_UNUSED(cmdObj);
    qWarning() << QStringLiteral("%1 not implemented").arg(QStringLiteral(Q_FUNC_INFO));
}

void TriggerProcessor::disconnectExistingTriggerSources()
{
    if (mTriggerTypes.size() == mTriggerSources.size())
    {
        for (qsizetype ss = 0; ss < mTriggerTypes.size(); ++ss)
        {
            QString iTriggerType = mTriggerTypes[ss];
            QString iTriggerSource = mTriggerSources[ss];
            if (QStringLiteral("CommandButton") == iTriggerType)
            {
                QAbstractButton *iButton = gRunPage->findChild<QAbstractButton*>(iTriggerSource);
                if (iButton)
                {
                    disconnect(iButton, &QAbstractButton::clicked, this, &TriggerProcessor::onButtonCommand);
                }
            }
            else if (QStringLiteral("SerialPort") == iTriggerType)
            {
                LaserXSerialPort* iSerialPort = gDeviceManager->findSerialPort(iTriggerSource);
                if (iSerialPort)
                {
                    disconnect(iSerialPort, &LaserXSerialPort::jsonReceived, this, &TriggerProcessor::onSerialPortCommand);
                }
            }
            else if (QStringLiteral("NetClient") == iTriggerType)
            {
                LaserXNetSender* iNetClient = gDeviceManager->findNetSender(iTriggerSource);
                if (iNetClient)
                {
                    disconnect(iNetClient, &LaserXNetSender::readyRead, this, &TriggerProcessor::onNetClientCommand);
                }
            }
            else if (QStringLiteral("NetServer") == iTriggerType)
            {
                LaserXNetListener* iNetServer = gDeviceManager->findNetListener(iTriggerSource);
                if (iNetServer)
                {
                    disconnect(iNetServer, &LaserXNetListener::jsonReceived, this, &TriggerProcessor::onNetServerCommand);
                }
            }
            else
            {
                qWarning() << QStringLiteral("Invalid trigger type");
            }
        }
    }
}

void TriggerProcessor::connectToTriggerSources()
{
    if (mTriggerTypes.size() == mTriggerSources.size())
    {
        for (qsizetype ss = 0; ss < mTriggerTypes.size(); ++ss)
        {
            QString iTriggerType = mTriggerTypes[ss];
            QString iTriggerSource = mTriggerSources[ss];
            if (QStringLiteral("CommandButton") == iTriggerType)
            {
                QAbstractButton *iButton = gRunPage->findChild<QAbstractButton*>(iTriggerSource);
                if (iButton)
                {
                    connect(iButton, &QAbstractButton::clicked, this, &TriggerProcessor::onButtonCommand);
                }
            }
            else if (QStringLiteral("SerialPort") == iTriggerType)
            {
                LaserXSerialPort* iSerialPort = gDeviceManager->findSerialPort(iTriggerSource);
                if (iSerialPort)
                {
                    connect(iSerialPort, &LaserXSerialPort::jsonReceived, this, &TriggerProcessor::onSerialPortCommand);
                }
            }
            else if (QStringLiteral("NetClient") == iTriggerType)
            {
                LaserXNetSender* iNetClient = gDeviceManager->findNetSender(iTriggerSource);
                if (iNetClient)
                {
                    connect(iNetClient, &LaserXNetSender::readyRead, this, &TriggerProcessor::onNetClientCommand);
                }
            }
            else if (QStringLiteral("NetServer") == iTriggerType)
            {
                LaserXNetListener* iNetServer = gDeviceManager->findNetListener(iTriggerSource);
                if (iNetServer)
                {
                    connect(iNetServer, &LaserXNetListener::jsonReceived, this, &TriggerProcessor::onNetServerCommand);
                }
            }
            else
            {
                qWarning() << QStringLiteral("Invalid trigger type");
            }
        }
    }
}

void TriggerProcessor::postLogError(const QString& msg)
{
    const QVariant vMsg(msg);
    QMetaObject::invokeMethod(this, "logError", Qt::QueuedConnection, Q_ARG(QVariant, vMsg));
}

void TriggerProcessor::postImage(LaserXCanvas* cav, const QString name, const cv::Mat mat)
{
    const QVariant vName = name;
    const QVariant vCav = QVariant::fromValue(static_cast<void*>(cav));
    const QVariant vMat = QVariant::fromValue(mat);
    QMetaObject::invokeMethod(this, "displayImage", Qt::QueuedConnection, Q_ARG(QVariant, vCav), Q_ARG(QVariant, vName), Q_ARG(QVariant, vMat));
}

void TriggerProcessor::postReply(QIODevice* ioDev, const QByteArray buffer)
{
    if (buffer.isEmpty())
    {
        return;
    }

    const QVariant vIODev = QVariant::fromValue(static_cast<void*>(ioDev));
    const QVariant vBuffer = buffer;
    QMetaObject::invokeMethod(this, "writeReply", Qt::QueuedConnection, Q_ARG(QVariant, vIODev), Q_ARG(QVariant, vBuffer));
}

void TriggerProcessor::postClearCanvas(LaserXCanvas* cav)
{
    const QVariant vCav = QVariant::fromValue(static_cast<void*>(cav));
    QMetaObject::invokeMethod(this, "clearCanvas", Qt::QueuedConnection, Q_ARG(QVariant, vCav));
}

void TriggerProcessor::postTemporaryItems(LaserXCanvas* cav, const QList<QGraphicsItem*> items)
{
    if (items.empty())
    {
        return;
    }

    const QVariant vCav = QVariant::fromValue(static_cast<void*>(cav));
    const QVariant vItems = QVariant::fromValue(items);
    QMetaObject::invokeMethod(this, "appendTemporaryItems", Qt::QueuedConnection, Q_ARG(QVariant, vCav), Q_ARG(QVariant, vItems));
}

void TriggerProcessor::postInfoItems(LaserXCanvas* cav, const QStringList strInfos)
{
    if (strInfos.empty())
    {
        return;
    }

    const QVariant vCav = QVariant::fromValue(static_cast<void*>(cav));
    const QVariant vItems = strInfos;
    QMetaObject::invokeMethod(this, "appendInfoItems", Qt::QueuedConnection, Q_ARG(QVariant, vCav), Q_ARG(QVariant, vItems));
}

void TriggerProcessor::postData(const QVariantList vals)
{
    if (vals.empty())
    {
        return;
    }

    const QVariant vVals = vals;
    QMetaObject::invokeMethod(this, "logData", Qt::QueuedConnection, Q_ARG(QVariant, vVals));
}

void TriggerProcessor::postBindCamera(LaserXCanvas* cav, LaserXCamera* cam)
{
    const QVariant vCav = QVariant::fromValue(static_cast<void*>(cav));
    const QVariant vCam = QVariant::fromValue(static_cast<void*>(cam));
    QMetaObject::invokeMethod(this, "bindCanvasAndCamera", Qt::QueuedConnection, Q_ARG(QVariant, vCav), Q_ARG(QVariant, vCam));
}

void TriggerProcessor::postCanvasSourceName(LaserXCanvas* cav, const QString name)
{
    const QVariant vName = name;
    const QVariant vCav = QVariant::fromValue(static_cast<void*>(cav));
    QMetaObject::invokeMethod(this, "setCanvasSourceName", Qt::QueuedConnection, Q_ARG(QVariant, vCav), Q_ARG(QVariant, vName));
}

void TriggerProcessor::logError(const QVariant msg)
{
    gRunPage->logError(msg.toString());
}

void TriggerProcessor::displayImage(const QVariant cav, const QVariant name, const QVariant mat)
{
    LaserXCanvas* iCav = static_cast<LaserXCanvas*>(cav.value<void*>());
    if (iCav)
    {
        cv::Mat rMat = mat.value<cv::Mat>();
        iCav->setMat(rMat);
        iCav->setImageSourceName(name.toString());
    }
}

void TriggerProcessor::writeReply(const QVariant ioDev, const QVariant buffer)
{
    QIODevice* iIODev = static_cast<QIODevice*>(ioDev.value<void*>());
    if (!iIODev)
    {
        return;
    }

    QByteArray iBuffer = buffer.toByteArray();
    iIODev->write(iBuffer);
}

void TriggerProcessor::clearCanvas(const QVariant cav)
{
    LaserXCanvas* iCav = static_cast<LaserXCanvas*>(cav.value<void*>());
    if (iCav)
    {
        iCav->clearAllTemporaryItems();
    }
}

void TriggerProcessor::appendTemporaryItems(const QVariant cav, const QVariant items)
{
    LaserXCanvas* iCav = static_cast<LaserXCanvas*>(cav.value<void*>());
    if (!iCav)
    {
        return;
    }

    const QList<QGraphicsItem*> iItems = items.value<QList<QGraphicsItem*>>();
    for (QGraphicsItem* iItem : iItems)
    {
        iCav->addTemporaryItem(iItem);
    }
}

void TriggerProcessor::appendInfoItems(const QVariant cav, const QVariant items)
{
    LaserXCanvas* iCav = static_cast<LaserXCanvas*>(cav.value<void*>());
    if (!iCav)
    {
        return;
    }

    const QStringList iItems = items.toStringList();
    if (!iItems.empty())
    {
        iCav->addInfoItems(iItems);
    }
}

void TriggerProcessor::logData(const QVariant vals)
{
    const QVariantList iVals = vals.toList();
    if (!iVals.empty())
    {
        gLogging->addPosition(iVals);
    }
}

void TriggerProcessor::bindCanvasAndCamera(const QVariant cav, const QVariant cam)
{
    LaserXCanvas* iCav = static_cast<LaserXCanvas*>(cav.value<void*>());
    LaserXCamera* iCam = static_cast<LaserXCamera*>(cam.value<void*>());
    if (iCav)
    {
        iCav->bindCamera(iCam);
    }
}

void TriggerProcessor::setCanvasSourceName(const QVariant cav, const QVariant name)
{
    LaserXCanvas* iCav = static_cast<LaserXCanvas*>(cav.value<void*>());
    if (iCav)
    {
        iCav->setImageSourceName(name.toString());
    }
}

TriggerProcessorTimer::TriggerProcessorTimer(TriggerProcessor* processor, LaserXCanvas* canvas)
    : mProcessor(processor)
    , mCanvas(canvas)
{
    mTimer.start();
}

TriggerProcessorTimer::~TriggerProcessorTimer()
{
    if (mProcessor && mCanvas)
    {
        QString iInfo = QStringLiteral("Timing=%1ms").arg(mTimer.elapsed());
        mProcessor->postInfoItems(mCanvas, QStringList() << iInfo);
    }
}

