#include "cameraparams.h"
#include <cmndef.h>
#include <laser_x_util.h>
#include <laser_x_devicemanager.h>

CameraParams::CameraParams()
{
}

void CameraParams::getJson(QJsonObject& jObj) const
{
    jObj[QLatin1String("CameraUUID")]        = mCameraUUID;
    jObj[QLatin1String("ImageWidth")]        = mImageWidth;
    jObj[QLatin1String("ImageHeight")]       = mImageHeight;
    jObj[QLatin1String("CameraGrabParams")]  = QJsonObject::fromVariantMap(mCameraGrabParams);
    jObj[QLatin1String("LightSourceParams")] = LightSourceParam::toJsonArray(mLightSourceParams);
}

void CameraParams::setJson(const QJsonObject &jObj)
{
    mCameraUUID         = fromJson(jObj,        QLatin1String("CameraUUID"),    QString());
    mImageWidth         = fromJson(jObj,        QLatin1String("ImageWidth"),    640ll);
    mImageHeight        = fromJson(jObj,        QLatin1String("ImageHeight"),   480ll);
    mCameraGrabParams   = getJsonObject(jObj,   QLatin1String("CameraGrabParams")).toVariantMap();
    mLightSourceParams  = LightSourceParam::fromJsonArray(jObj, QLatin1String("LightSourceParams"));
}

void CameraParams::copyDataTo(CameraParams* other) const
{
    other->mCameraUUID        = mCameraUUID;
    other->mImageWidth        = mImageWidth;
    other->mImageHeight       = mImageHeight;
    other->mCameraGrabParams  = mCameraGrabParams;
    other->mLightSourceParams = mLightSourceParams;
}

void CameraParams::setLightSources() const
{
    for (const LightSourceParam& lightSourceParam : mLightSourceParams)
    {
        lightSourceParam.setLightSource();
    }
}

void LightSourceParam::setLightSource() const
{
    LaserXLEDController *iLight = gDeviceManager->findLEDController(mLightSourceUUID);
    if (!iLight)
    {
        return;
    }

    const int newState = QSL("On") == mLightSourceStatus ? 1 : 0;
    iLight->setChannelState(mLightSourceChannel, newState);
    if (newState)
    {
        iLight->setChannelBrightness(mLightSourceChannel, mLightSourceBrightness);
    }
}

QJsonObject LightSourceParam::toJson() const
{
    QJsonObject jObj;
    jObj[QLatin1String("LightSourceUUID")]          = mLightSourceUUID;
    jObj[QLatin1String("LightSourceStatus")]        = mLightSourceStatus;
    jObj[QLatin1String("LightSourceChannel")]       = mLightSourceChannel;
    jObj[QLatin1String("LightSourceBrightness")]    = mLightSourceBrightness;
    return jObj;
}

void LightSourceParam::setJson(const QJsonObject& jObj)
{
    mLightSourceUUID        = fromJson(jObj, QLatin1String("LightSourceUUID"),          QString());
    mLightSourceStatus      = fromJson(jObj, QLatin1String("LightSourceStatus"),        QSL("off"));
    mLightSourceChannel     = fromJson(jObj, QLatin1String("LightSourceChannel"),       0);
    mLightSourceBrightness  = fromJson(jObj, QLatin1String("LightSourceBrightness"),    0);
}

QJsonArray LightSourceParam::toJsonArray(const std::vector<LightSourceParam>& lightSourceParams)
{
    QJsonArray jArray;
    for (const LightSourceParam &lightSourceParam : lightSourceParams)
    {
        jArray.push_back(lightSourceParam.toJson());
    }
    return jArray;
}

std::vector<LightSourceParam> LightSourceParam::fromJsonArray(const QJsonObject& jObj, const QLatin1String& name)
{
    std::vector<LightSourceParam> lightSourceParams;
    if (jObj.contains(name) && jObj[name].isArray())
    {
        QJsonArray jArray = jObj[name].toArray();
        for (const auto &jRef : jArray)
        {
            LightSourceParam lightSourceParam;
            lightSourceParam.setJson(jRef.toObject());
            lightSourceParams.push_back(lightSourceParam);
        }
    }
    return lightSourceParams;
}
