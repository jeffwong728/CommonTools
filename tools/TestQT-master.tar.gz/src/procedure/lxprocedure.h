#ifndef LXPROCEDURE_H
#define LXPROCEDURE_H

#include <QObject>
#include <QtCore>
class LXProcedureItem;
class LaserXCanvas;
namespace cv
{
    class Mat;
}

class LXProcedure : public QObject
{
    Q_OBJECT
public:
    explicit LXProcedure();
    ~LXProcedure();

public:
    void setProcedureItem(LXProcedureItem* const procedureItem);
    QString name() const;
    QString uuid() const;

public:
    virtual QString getTypeName() const = 0;
    virtual QString getJson() const;
    virtual QByteArray getBlob() const;
    virtual QByteArray getImageData() const;
    virtual void setJson(const QString &data);
    virtual void setBlob(const QByteArray& data);
    virtual void setImageData(const QByteArray &data);
    virtual bool isValid() const = 0;
    virtual bool isPositioning() const;
    virtual QPointF getCenter() const;
    virtual qreal getAngle() const;
    virtual std::tuple<QPointF, qreal, bool> doPositioning(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) const;
    virtual bool process(QJsonObject& rObj);

protected:
    LXProcedureItem* const mProcedureItem = nullptr;
};

class ScopedCanvasTimer
{
public:
    ScopedCanvasTimer(LaserXCanvas* canvas);
    ~ScopedCanvasTimer();

private:
    LaserXCanvas* const mCanvas;
    QElapsedTimer mTimer;
};

#endif // LXPROCEDURE_H
