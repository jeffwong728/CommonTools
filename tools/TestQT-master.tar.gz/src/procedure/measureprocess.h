#ifndef MEASURE_PROCESS_H
#define MEASURE_PROCESS_H
#include <QtCore>
#include <laser_x_vision.h>
#include "visionprocessor.h"

class MeasureProcess : public VisionProcessor
{
    Q_OBJECT

public:
    explicit MeasureProcess();

public:
    QString getTypeName() const override;
    QString getJson() const override;
    QByteArray getBlob() const override;
    void setJson(const QString& data) override;
    void setBlob(const QByteArray& data) override;
    bool isValid() const override;
    void copyDataTo(MeasureProcess* other) const;
    qlonglong numGeoms() const;

public:
    int processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj) override;
    void setReferenceSystem(QPointF& rsOrigin, qreal rsAngle);
    void alignModel(QPointF& aOrigin, qreal aAngle);

public:
    void parseGeomNameIndexs();
    qlonglong parseLineResults(LaserXCanvas* iCav, QJsonObject& rObj);
    qlonglong parseRectResults(LaserXCanvas* iCav, QJsonObject& rObj);
    qlonglong parseCircleResults(LaserXCanvas* iCav, QJsonObject& rObj);
    qlonglong parseEllipseResults(LaserXCanvas* iCav, QJsonObject& rObj);

private:
    void fillEmptyResult(QJsonObject& rObj) const;

public:
    LXMeasureModel mModel;
    QJsonObject mMeasureParams;
    QString mPostScriptName;
    QString mPostProcedureName;
    QString mPositioningProcedure;

private:
    std::vector<std::pair<QString, qlonglong>> mLineNameIndexs;
    std::vector<std::pair<QString, qlonglong>> mRectNameIndexs;
    std::vector<std::pair<QString, qlonglong>> mCircleNameIndexs;
    std::vector<std::pair<QString, qlonglong>> mEllipseNameIndexs;
};

#endif // MEASURE_PROCESS_H
