#include "triggerparams.h"
#include <laser_x_util.h>

TriggerParams::TriggerParams()
{
}

void TriggerParams::getJson(QJsonObject& jObj) const
{
    jObj[QLatin1String("CommandName")] = mCommandName;
    jObj[QLatin1String("TriggerTypes")] = QJsonArray::fromStringList(mTriggerTypes);
    jObj[QLatin1String("TriggerSources")] = QJsonArray::fromStringList(mTriggerSources);
}

void TriggerParams::setJson(const QJsonObject &jObj)
{
    disconnectExistingTriggerSources();
    mCommandName = fromJson(jObj, QLatin1String("CommandName"), QLatin1String("CMD0"));
    mTriggerTypes = fromJson(jObj, QLatin1String("TriggerTypes"), QStringList());
    mTriggerSources = fromJson(jObj, QLatin1String("TriggerSources"), QStringList());
    connectToTriggerSources();
}

void TriggerParams::copyDataTo(TriggerParams* other) const
{
    other->mCommandName     = mCommandName;
    other->mTriggerTypes    = mTriggerTypes;
    other->mTriggerSources  = mTriggerSources;
}
