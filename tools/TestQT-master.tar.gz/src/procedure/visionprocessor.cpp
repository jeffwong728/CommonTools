#include "visionprocessor.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/loggingdb.h>
#include <ui/runpage.h>
#include <ui/mainframe.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <laser_x_canvas.h>
#include <laser_x_serialport.h>
#include <laser_x_net_sender.h>
#include <laser_x_net_listener.h>
#include <laser_x_devicemanager.h>

VisionProcessor::VisionProcessor()
{
}

void VisionProcessor::getJson(QJsonObject& rootObj) const
{
    TriggerProcessor::getJson(rootObj);
    CameraParams::getJson(rootObj);
    OutputParams::getJson(rootObj);
}

void VisionProcessor::setJson(const QJsonObject &jsonObj)
{
    TriggerProcessor::setJson(jsonObj);
    CameraParams::setJson(jsonObj);
    OutputParams::setJson(jsonObj);
}

void VisionProcessor::copyDataTo(VisionProcessor* other) const
{
    TriggerProcessor::copyDataTo(other);
    CameraParams::copyDataTo(other);
    OutputParams::copyDataTo(other);
}

int VisionProcessor::processImage(LaserXCanvas* iCav, cv::Mat& iMat, QJsonObject& rObj)
{
    Q_UNUSED(iCav);
    Q_UNUSED(iMat);
    Q_UNUSED(rObj);
    qWarning() << QStringLiteral("%1 not implemented").arg(QStringLiteral(Q_FUNC_INFO));
    return kImageProcessError_General;
}

void VisionProcessor::onButtonCommand()
{
    cv::Mat iMat;
    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (!iCav)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no canvas").arg(name()));
        return;
    }

    ScopedCanvasTimer timer(iCav);
    iCav->clearAllTemporaryItems();
    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no camera").arg(name()));
        return;
    }

    if (iCam->isContinuousGrab())
    {
        iCam->stopContinuousGrab();
    }

    if (iCam->isContinuousGrab())
    {
        gRunPage->logError(QStringLiteral("Procedure %1 camera %2 is living").arg(name()).arg(iCam->name()));
        return;
    }

    setLightSources();
    iCam->setGrabParams(mCameraGrabParams);
    iMat = iCam->snap();
    iCav->setMat(iMat);
    iCav->setImageSourceName(iCam->name());

    QJsonObject rObj;
    const int iErrorId = processImage(iCav, iMat, rObj);
    if (kImageProcessError_NoError != iErrorId)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 error: %2").arg(name()).arg(gGetErrorMsg(iErrorId)));
    }

    saveData(rObj, iMat);
}

void VisionProcessor::processIODeviceCommand(QIODevice* ioDev, QJsonObject& cmdObj)
{
    cv::Mat iMat;
    QJsonObject rObj;
    initResult(rObj);

    if (!gMainFrame->mRunning)
    {
        gRunPage->logError(QStringLiteral("Image process stopped").arg(name()));
        sendVisionProcessError(ioDev, rObj, iMat, kImageProcessError_Stopped);
        return;
    }

    LaserXCanvas* iCav = gRunPage->findCanvas(mOutputCanvas);
    if (!iCav)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no canvas").arg(name()));
        sendVisionProcessError(ioDev, rObj, iMat, kImageProcessError_NoCanvas);
        return;
    }

    ScopedCanvasTimer timer(iCav);
    iCav->clearAllTemporaryItems();
    LaserXCamera* iCam = gDeviceManager->findCamera(mCameraUUID);
    if (!iCam)
    {
        gRunPage->logError(QStringLiteral("Procedure %1 no camera").arg(name()));
        sendVisionProcessError(ioDev, rObj, iMat, kImageProcessError_NoCamera);
        return;
    }

    if (iCam->isContinuousGrab())
    {
        iCam->stopContinuousGrab();
    }

    if (iCam->isContinuousGrab())
    {
        gRunPage->logError(QStringLiteral("Procedure %1 camera %2 is living").arg(name()).arg(iCam->name()));
        sendVisionProcessError(ioDev, rObj, iMat, kImageProcessError_GrabConflict);
        return;
    }

    setLightSources();
    iCam->setGrabParams(mCameraGrabParams);
    iMat = iCam->snap();
    cv::Mat rMat = rotateImage(iMat, cmdObj);
    iCav->setMat(rMat);
    iCav->setImageSourceName(iCam->name());

    const int iErrorId = processImage(iCav, rMat, rObj);
    if (kImageProcessError_NoError == iErrorId)
    {
        sendVisionProcessSuccess(ioDev, rObj, rMat);
    }
    else
    {
        sendVisionProcessError(ioDev, rObj, rMat, iErrorId);
    }
}

void VisionProcessor::saveData(const QJsonObject& rObj, const cv::Mat& iMat) const
{
    if (!mSaveData)
    {
        return;
    }

    if (QStringLiteral("All") == mSaveImage)
    {
        gLogging->addPosition(mProcedureItem->getName(), rObj, iMat);
    }
    else if (QStringLiteral("ErrorOnly") == mSaveImage)
    {
        const bool iSuccess = rObj[QLatin1String("Success")].toBool();
        if (iSuccess)
        {
            gLogging->addPosition(mProcedureItem->getName(), rObj);
        }
        else
        {
            gLogging->addPosition(mProcedureItem->getName(), rObj, iMat);
        }
    }
    else
    {
        gLogging->addPosition(mProcedureItem->getName(), rObj);
    }
}

cv::Mat VisionProcessor::rotateImage(const cv::Mat& iMat, QJsonObject& cmdObj)
{
    cv::Mat dst;
    int degrees = -qRound(fromJson(cmdObj, QLatin1String("Rotate"), 0.0)*100);
    switch (degrees)
    {
    case 0:
    case -36000:
    case 36000:
        dst = iMat;
        break;

    case -9000:
    case 27000:
        cv::rotate(iMat, dst, cv::ROTATE_90_COUNTERCLOCKWISE);
        break;

    case -27000:
    case 9000:
        cv::rotate(iMat, dst, cv::ROTATE_90_CLOCKWISE);
        break;

    case 18000:
    case -18000:
        cv::rotate(iMat, dst, cv::ROTATE_180);
        break;

    default:
        cv::Mat r = cv::getRotationMatrix2D({ iMat.cols / 2.0F, iMat.rows / 2.0F }, -degrees/100.0, 1.0);
        cv::warpAffine(iMat, dst, r, cv::Size(iMat.cols, iMat.rows));
        break;
    }

    return dst;
}

bool VisionProcessor::isValidImage(const cv::Mat& iMat)
{
    if (iMat.empty())
    {
        return false;
    }

    if (1 != iMat.channels())
    {
        return false;
    }

    if (CV_8U != iMat.depth())
    {
        return false;
    }
    else
    {
        return true;
    }
}

void VisionProcessor::sendVisionProcessSuccess(QIODevice* ioDev, QJsonObject& rObj, const cv::Mat& iMat)
{
    if (!ioDev)
    {
        return;
    }

    rObj[QLatin1String("CommandName")] = mCommandName;
    rObj[QLatin1String("CommandSN")] = mCommandSN;
    rObj[QLatin1String("Success")] = true;
    rObj[QLatin1String("ErrorId")] = kImageProcessError_NoError;
    rObj[QLatin1String("ErrorMsg")] = gGetErrorMsg(kImageProcessError_NoError);
    rObj[QLatin1String("ImageWidth")] = iMat.cols;
    rObj[QLatin1String("ImageHeight")] = iMat.rows;
    rObj[QLatin1String("XResolution")] = mXResolution;
    rObj[QLatin1String("YResolution")] = mYResolution;

    QJsonDocument doc(rObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    buffer.append('\n');
    ioDev->write(buffer);

    saveData(rObj, iMat);
}

void VisionProcessor::sendVisionProcessError(QIODevice* ioDev, QJsonObject& rObj, const cv::Mat& iMat, int errId)
{
    if (!ioDev)
    {
        return;
    }

    rObj[QLatin1String("CommandName")] = mCommandName;
    rObj[QLatin1String("CommandSN")] = mCommandSN;
    rObj[QLatin1String("Success")] = false;
    rObj[QLatin1String("ErrorId")] = errId;
    rObj[QLatin1String("ErrorMsg")] = gGetErrorMsg(errId);
    rObj[QLatin1String("ImageWidth")] = iMat.cols;
    rObj[QLatin1String("ImageHeight")] = iMat.rows;
    rObj[QLatin1String("XResolution")] = mXResolution;
    rObj[QLatin1String("YResolution")] = mYResolution;

    QJsonDocument doc(rObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    buffer.append('\n');
    ioDev->write(buffer);

    saveData(rObj, iMat);
}

void VisionProcessor::initResult(QJsonObject& rObj)
{
    rObj[QLatin1String("NumMatches")] = 0;
    rObj[QLatin1String("CenterXList")] = QJsonArray();
    rObj[QLatin1String("CenterYList")] = QJsonArray();
    rObj[QLatin1String("AngleList")] = QJsonArray();
    rObj[QLatin1String("ScaleList")] = QJsonArray();
    rObj[QLatin1String("ScoreList")] = QJsonArray();
    rObj[QLatin1String("OCRBoxs")] = QJsonArray();
}
