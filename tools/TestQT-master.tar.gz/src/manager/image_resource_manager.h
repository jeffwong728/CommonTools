#ifndef IMAGE_RESOURCE_MANAGER_H
#define IMAGE_RESOURCE_MANAGER_H
#include <QtCore>
#include <opencv2/opencv.hpp>

class ImageResourceManager : public QObject
{
    Q_OBJECT
public:
    ImageResourceManager();
    ~ImageResourceManager();

public:
    bool addImage(const QString& uuid, const QString &name, const cv::Mat& mat);
    bool deleteImage(const QString &uuid);
    bool updateImage(const QString & uuid, const QString& name, const cv::Mat& mat);
    cv::Mat getImage(const QString& uuid) const;
    QString getImageName(const QString & uuid) const;
    QVector<QString> getImageUUIDs() const;

signals:
    void imageAdded(const QString& uuid);
    void imageAboutToDelete(const QString& uuid);
    void imageUpdated(const QString& uuid);

private:
    Q_DISABLE_COPY_MOVE(ImageResourceManager)

private:
    std::map<QString, std::pair<QString, cv::Mat>> mImages;
};

#endif // IMAGE_RESOURCE_MANAGER_H
