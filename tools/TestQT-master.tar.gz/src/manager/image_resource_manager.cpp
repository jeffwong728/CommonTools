#include "image_resource_manager.h"

ImageResourceManager::ImageResourceManager()
{
}

ImageResourceManager::~ImageResourceManager()
{
}

bool ImageResourceManager::addImage(const QString& uuid, const QString& name, const cv::Mat& mat)
{
    if (name.isEmpty())
    {
        return false;
    }

    mImages[uuid].first = name;
    mImages[uuid].second = mat;
    emit imageAdded(uuid);
    return true;
}

bool ImageResourceManager::deleteImage(const QString& uuid)
{
    auto it = mImages.find(uuid);
    if (it != mImages.end())
    {
        emit imageAboutToDelete(uuid);
        mImages.erase(it);
        return true;
    }
    else
    {
        return false;
    }
}

bool ImageResourceManager::updateImage(const QString& uuid, const QString& name, const cv::Mat& mat)
{
    auto it = mImages.find(uuid);
    if (it != mImages.end())
    {
        it->second.first = name;
        it->second.second = mat;
        emit imageUpdated(uuid);
        return true;
    }
    else
    {
        return false;
    }
}

cv::Mat ImageResourceManager::getImage(const QString& uuid) const
{
    auto it = mImages.find(uuid);
    if (it != mImages.end())
    {
        return it->second.second;
    }
    else
    {
        return cv::Mat();
    }
}

QString ImageResourceManager::getImageName(const QString& uuid) const
{
    auto it = mImages.find(uuid);
    if (it != mImages.end())
    {
        return it->second.first;
    }
    else
    {
        return QString();
    }
}

QVector<QString> ImageResourceManager::getImageUUIDs() const
{
    QVector<QString> names;
    for (const auto &item : mImages)
    {
        names.push_back(item.first);
    }
    return names;
}
