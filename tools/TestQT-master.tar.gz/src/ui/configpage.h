#ifndef UI_CONFIGPAGE_H
#define UI_CONFIGPAGE_H

#include <QtWidgets>
class QVBoxLayout;
class FlowView;
class LaserXCanvas;
class QUndoGroup;
class QSplitter;
class QToolBar;
class QActionGroup;

class ConfigPage : public QDialog
{
    Q_OBJECT

public:
    ConfigPage(QUndoGroup* undoGroup, QWidget* parent = nullptr);
    ~ConfigPage();

public:
    void retranslateUi();
    void loadProject();
    void refreshProject();
    bool start();
    void stop();
    void showFlowChartViewer(QWidget* parent);

public:
    void onOptionChanged(const QString& optionName, const QVariant& optionValue);

protected:
    QSize sizeHint() const override;
    void changeEvent(QEvent* event) override;

private:
    QVBoxLayout* createToolBar();

private:
    QUndoGroup* mUndoGroup = nullptr;
    FlowView* mFlowView = nullptr;

    QToolBar* mToolBar = nullptr;
    QActionGroup* toolGroup = nullptr;
    QAction* triggerTool = nullptr;
    QAction* imageSourceTool = nullptr;
    QAction* positionTool = nullptr;
    QAction* ocrTool = nullptr;
};

#endif // UI_CONFIGPAGE_H
