#include "configpage.h"
#include <cmndef.h>
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <ui/flowchart/flowview.h>
#include <laser_x_canvas.h>

ConfigPage::ConfigPage(QUndoGroup* undoGroup, QWidget* parent)
    : QDialog(parent)
    , mUndoGroup(undoGroup)
{
    mFlowView = new FlowView(undoGroup, this);
    gFlowView = mFlowView;
    setWindowFlag(Qt::WindowMaximizeButtonHint, true);

    QHBoxLayout* layout = new QHBoxLayout();
    layout->setContentsMargins(1, 1, 1, 1);
    layout->addWidget(mFlowView, 1);

    layout->addLayout(createToolBar());

    QWidgetList toolBoxs = mFlowView->getToolboxs();
    QList<QAction*> toolBtns = toolGroup->actions();
    if (toolBoxs.size() == toolBtns.size())
    {
        const qsizetype numToolBoxs = toolBtns.size();
        for (qsizetype tt=0; tt < numToolBoxs; ++tt)
        {
            connect(toolBtns[tt], &QAction::toggled, toolBoxs[tt], &QWidget::setVisible);
            QToolButton* exitBtn = toolBoxs[tt]->findChild<QToolButton*>(QStringLiteral("exitBtn"), Qt::FindDirectChildrenOnly);
            if (exitBtn)
            {
                connect(exitBtn, &QToolButton::clicked, toolBtns[tt], &QAction::toggle);
            }
        }
    }
    retranslateUi();
    setLayout(layout);
}

ConfigPage::~ConfigPage()
{
}

void ConfigPage::retranslateUi()
{
    imageSourceTool->setText(tr("Image Acquisition"));
    positionTool->setText(tr("Positioning"));
    triggerTool->setText(tr("Trigger / Event"));
    ocrTool->setText(tr("OCR"));
}

void ConfigPage::loadProject()
{
    mFlowView->loadProject();
}

void ConfigPage::refreshProject()
{
    mFlowView->refreshProject();
}

bool ConfigPage::start()
{
    const bool bOk = mFlowView->start();
    if (bOk)
    {
        mToolBar->setEnabled(false);
        QWidgetList toolBoxs = mFlowView->getToolboxs();
        for(QWidget *toolBox : toolBoxs)
        {
            if (toolBox->isVisible())
            {
                toolBox->setVisible(false);
            }
        }
    }
    return bOk;
}

void ConfigPage::stop()
{
    mFlowView->stop();
    mToolBar->setEnabled(true);
}

void ConfigPage::showFlowChartViewer(QWidget* parent)
{
    mFlowView->showFlowChartViewer(parent);
}

void ConfigPage::onOptionChanged(const QString &optionName, const QVariant &optionValue)
{
    mFlowView->onOptionChanged(optionName, optionValue);
}

QSize ConfigPage::sizeHint() const
{
    return QSize(800, 600);
}

void ConfigPage::changeEvent(QEvent* event)
{
    if (QEvent::LanguageChange == event->type())
    {
        retranslateUi();
    }
    QWidget::changeEvent(event);
}

QVBoxLayout* ConfigPage::createToolBar()
{
    mToolBar = new QToolBar(this);
    mToolBar->setMovable(false);
    mToolBar->setOrientation(Qt::Vertical);
    triggerTool = new QAction(QIcon(QStringLiteral(":/qss_icons/images/flash-24.png")), QStringLiteral(""), mToolBar);
    imageSourceTool = new QAction(QIcon(QStringLiteral(":/qss_icons/images/camera.png")), QStringLiteral(""), mToolBar);
    positionTool = new QAction(QIcon(QStringLiteral(":/qss_icons/images/gps-24.png")), QStringLiteral(""), mToolBar);
    ocrTool = new QAction(QIcon(QStringLiteral(":/qss_icons/images/ocr-general-24.png")), QStringLiteral(""), mToolBar);
    triggerTool->setCheckable(true);
    imageSourceTool->setCheckable(true);
    positionTool->setCheckable(true);
    ocrTool->setCheckable(true);

    toolGroup = new QActionGroup(mToolBar);
    toolGroup->addAction(triggerTool);
    toolGroup->addAction(imageSourceTool);
    toolGroup->addAction(positionTool);
    toolGroup->addAction(ocrTool);
    toolGroup->setExclusionPolicy(QActionGroup::ExclusionPolicy::ExclusiveOptional);

    mToolBar->addAction(triggerTool);
    mToolBar->addAction(imageSourceTool);
    mToolBar->addAction(positionTool);
    mToolBar->addAction(ocrTool);
    mToolBar->setIconSize(QSize(22, 22));

    QString buttonStyle = QLatin1String("QToolButton { border: 0px; margin: 1px; padding: 3px; border-radius: 5px; background-color: transparent; }");
    buttonStyle.append(QLatin1String("QToolButton:hover { border: 0px; margin: 1px; padding: 3px; background-color: #3daee9C0; }"));
    buttonStyle.append(QLatin1String("QToolButton:checked, QToolButton:pressed, QToolButton::menu-button:pressed { border: 0px; margin: 1px; padding: 3px; background-color: #3daee9; }"));
    mToolBar->setStyleSheet(buttonStyle);

    QVBoxLayout* layout = new QVBoxLayout();
    layout->setContentsMargins(1, 0, 1, 1);
    layout->addWidget(mToolBar);
    layout->addStretch(1);

    return layout;
}
