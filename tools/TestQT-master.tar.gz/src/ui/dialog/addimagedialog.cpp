#include "addimagedialog.h"
#include "ui_addimagedialog.h"
#include <QtWidgets>

AddImageDialog::AddImageDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddImageDialog)
{
    ui->setupUi(this);
}

AddImageDialog::~AddImageDialog()
{
    delete ui;
}

void AddImageDialog::on_pushButtonLoad_clicked()
{
    QString filter(tr("Images(*.png *.jpg *.tiff *.tif *.bmp *.dib)"));
    QString filePath = QFileDialog::getOpenFileName(this, tr("Load Image File"), QStringLiteral(""), filter);

    if (!filePath.isEmpty() && filePath != ui->lineEditSource->text())
    {
        ui->lineEditSource->setText(filePath);
    }
}

QString AddImageDialog::imageName() const
{
    return ui->lineEditName->text();
}

QString AddImageDialog::imagePath() const
{
    return ui->lineEditSource->text();
}

void AddImageDialog::on_pushButtonOk_clicked()
{
    if (ui->lineEditSource->text().isEmpty())
    {
        ui->labelStatus->setText(tr("<font color='red'>Source empty error</font>"));
    }
    else if (ui->lineEditName->text().isEmpty())
    {
        ui->labelStatus->setText(tr("<font color='red'>Name empty error</font>"));
    }
    else if (!QFileInfo::exists(ui->lineEditSource->text()))
    {
        ui->labelStatus->setText(tr("<font color='red'>Not an existing file error</font>"));
    }
    else if (!QFileInfo(ui->lineEditSource->text()).isFile())
    {
        ui->labelStatus->setText(tr("<font color='red'>Not an file error</font>"));
    }
    else
    {
        done(QDialog::Accepted);
    }
}

void AddImageDialog::on_pushButtonCancel_clicked()
{
    done(QDialog::Rejected);
}
