#include "adduserdialog.h"
#include "ui_adduserdialog.h"
#include <database/settingdb.h>

AddUserDialog::AddUserDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddUserDialog)
{
    ui->setupUi(this);
    ui->statusLabel->setStyleSheet(QStringLiteral("QLabel { color : red; }"));
}

AddUserDialog::~AddUserDialog()
{
    delete ui;
}

void AddUserDialog::on_addButton_clicked()
{
    QString userName = ui->nameLineEdit->text();
    QString password = ui->passwordLineEdit->text();
    QString confirm = ui->confirmLineEdit->text();
    ui->statusLabel->setStyleSheet(QStringLiteral("QLabel { color : red; }"));
    if (userName.isEmpty())
    {
        ui->statusLabel->setText(tr("Name empty error"));
    }
    else if (password.isEmpty())
    {
        ui->statusLabel->setText(tr("Password empty error"));
    }
    else if (confirm.isEmpty())
    {
        ui->statusLabel->setText(tr("Confirm password empty error"));
    }
    else if (confirm != password)
    {
        ui->statusLabel->setText(tr("Confirm password error"));
    }
    else
    {
        SettingDB settingDB;
        if (settingDB.isUserExist(userName, ui->groupComboBox->currentText()))
        {
            ui->statusLabel->setText(tr("User exist error"));
        }
        else
        {
            QString src = userName + password + ui->groupComboBox->currentText();
            QByteArray data = QCryptographicHash::hash(src.toUtf8(), QCryptographicHash::Md5);
            if (settingDB.addUser(userName, ui->groupComboBox->currentText(), data))
            {
                ui->statusLabel->setStyleSheet(QStringLiteral("QLabel { color : green; }"));
                ui->statusLabel->setText(tr("Add user success"));
            }
            else
            {
                ui->statusLabel->setText(tr("Add user error"));
            }
        }
    }
}

void AddUserDialog::on_closeButton_clicked()
{
    QDialog::done(Accepted);
}

void AddUserDialog::on_nameLineEdit_textChanged(const QString&)
{
    ui->statusLabel->setStyleSheet(QStringLiteral("QLabel { color : red; }"));
    ui->statusLabel->setText(QString());
}

void AddUserDialog::on_passwordLineEdit_textChanged(const QString&)
{
    ui->statusLabel->setStyleSheet(QStringLiteral("QLabel { color : red; }"));
    ui->statusLabel->setText(QString());
}

void AddUserDialog::on_groupComboBox_currentIndexChanged(int)
{
    ui->statusLabel->setStyleSheet(QStringLiteral("QLabel { color : red; }"));
    ui->statusLabel->setText(QString());
}
