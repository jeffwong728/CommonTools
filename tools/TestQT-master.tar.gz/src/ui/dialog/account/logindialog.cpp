#include "logindialog.h"
#include "ui_logindialog.h"
#include <util/quihelper.h>
#include <util/qapphelper.h>
#include <database/settingdb.h>
#include <QtGui>
#include <QtWidgets>

LoginDialog::LoginDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::LoginDialog)
{
    QUIHelper::setFramelessForm(this, true, false, false);
    ui->setupUi(this);
    ui->loginStatusLabel->setStyleSheet(QStringLiteral("QLabel { color : red; }"));
}

LoginDialog::~LoginDialog()
{
    delete ui;
}

void LoginDialog::reject()
{
}

QString LoginDialog::getUserName() const
{
    return ui->userNameLineEdit->text();
}

QString LoginDialog::getPassword() const
{
    return ui->passwordLineEdit->text();
}

int LoginDialog::getPrivilege() const
{
    return ui->groupComboBox->currentIndex() + 1;
}

void LoginDialog::closeEvent(QCloseEvent* event)
{
    QDialog::closeEvent(event);
}

void LoginDialog::on_shutdownButton_clicked()
{
    done(Shutdown);
}

void LoginDialog::on_loginButton_clicked()
{
    QString userName = ui->userNameLineEdit->text();
    QString password = ui->passwordLineEdit->text();
    if (userName.isEmpty())
    {
        ui->loginStatusLabel->setText(tr("Name empty error"));
    }
    else if (password.isEmpty())
    {
        ui->loginStatusLabel->setText(tr("Password empty error"));
    }
    else
    {
        QString src = userName + password + ui->groupComboBox->currentText();
        QByteArray hashData = QCryptographicHash::hash(src.toUtf8(), QCryptographicHash::Md5);

        SettingDB settingDB;
        QByteArray data = settingDB.getUserData(userName, ui->groupComboBox->currentText());
        if (data.isEmpty())
        {
            ui->loginStatusLabel->setText(tr("User name or group error"));
        }
        else if (hashData == data)
        {
            done(Login);
        }
        else
        {
            ui->loginStatusLabel->setText(tr("Password error"));
        }
    }
}

void LoginDialog::on_userNameLineEdit_textChanged(const QString&)
{
    ui->loginStatusLabel->setText(QString());
}

void LoginDialog::on_passwordLineEdit_textChanged(const QString&)
{
    ui->loginStatusLabel->setText(QString());
}

void LoginDialog::on_groupComboBox_currentIndexChanged(int)
{
    ui->loginStatusLabel->setText(QString());
}
