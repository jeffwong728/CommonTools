#ifndef ADDUSERDIALOG_H
#define ADDUSERDIALOG_H

#include <QDialog>

namespace Ui {
class AddUserDialog;
}

class AddUserDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddUserDialog(QWidget *parent = nullptr);
    ~AddUserDialog();

private slots:
    void on_addButton_clicked();
    void on_closeButton_clicked();
    void on_nameLineEdit_textChanged(const QString&);
    void on_passwordLineEdit_textChanged(const QString&);
    void on_groupComboBox_currentIndexChanged(int);

private:
    Ui::AddUserDialog *ui;
};

#endif // ADDUSERDIALOG_H
