#ifndef LOGINDIALOG_H
#define LOGINDIALOG_H

#include <QDialog>

namespace Ui {
class LoginDialog;
}

class LoginDialog : public QDialog
{
    Q_OBJECT

public:
    explicit LoginDialog(QWidget *parent = nullptr);
    ~LoginDialog();

    enum LoginDialogCode { Shutdown = Accepted + 1, Restart, Login };

public:
    QString getUserName() const;
    QString getPassword() const;
    int getPrivilege() const;

public Q_SLOTS:
    void reject() override;

protected:
    void closeEvent(QCloseEvent* event) override;

private slots:
    void on_shutdownButton_clicked();
    void on_loginButton_clicked();
    void on_userNameLineEdit_textChanged(const QString&);
    void on_passwordLineEdit_textChanged(const QString&);
    void on_groupComboBox_currentIndexChanged(int);

private:
    Ui::LoginDialog *ui;
};

#endif // LOGINDIALOG_H
