#ifndef ADDIMAGEDIALOG_H
#define ADDIMAGEDIALOG_H

#include <QDialog>

namespace Ui {
class AddImageDialog;
}

class AddImageDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddImageDialog(QWidget *parent = nullptr);
    ~AddImageDialog();

public:
    QString imageName() const;
    QString imagePath() const;

private slots:
    void on_pushButtonLoad_clicked();
    void on_pushButtonOk_clicked();
    void on_pushButtonCancel_clicked();

private:
    Ui::AddImageDialog *ui;
};

#endif // ADDIMAGEDIALOG_H
