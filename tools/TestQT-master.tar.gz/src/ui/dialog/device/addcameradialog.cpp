#include "addcameradialog.h"
#include "ui_addcameradialog.h"
#include <laser_x_util.h>

AddCameraDialog::AddCameraDialog(QWidget* parent, const QVector<LaserXCameraManager*>& cameraManagers) :
    QDialog(parent),
    ui(new Ui::AddCameraDialog)
    , mCameraManagers(cameraManagers)
{
    ui->setupUi(this);
    ui->pushButtonAdd->setEnabled(false);

    mCameras.resize(cameraManagers.size(), nullptr);
    for (LaserXCameraManager* camManager : cameraManagers)
    {
        LaserXAddCameraWidget *camWidget = camManager->getAddWidget(ui->stackedWidget);
        mCameraPages.push_back(camWidget);
        ui->comboBoxCameraType->addItem(camManager->getTypeName());
        ui->stackedWidget->addWidget(camWidget);
        connect(camWidget, &LaserXAddCameraWidget::parametersChanged, this, &AddCameraDialog::onCameraParameterChanged);
    }

    connect(ui->laserXCanvasPreview, &LaserXCanvas::snapClicked, this, &AddCameraDialog::onSnapClicked);
    connect(ui->laserXCanvasPreview, &LaserXCanvas::liveClicked, this, &AddCameraDialog::onLiveClicked);
}

AddCameraDialog::~AddCameraDialog()
{
    delete ui;
    for (qsizetype cc = 0; cc < mCameras.size(); ++cc)
    {
        if (mCameras[cc])
        {
            mCameras[cc]->stopContinuousGrab();
            mCameraManagers[cc]->deleteCamera(mCameras[cc]);
        }
    }
}

void AddCameraDialog::onCameraParameterChanged(const QVariantMap& params)
{
    const qsizetype camManagerIndex = ui->comboBoxCameraType->currentIndex();
    if (camManagerIndex >= 0 && camManagerIndex < mCameraManagers.size())
    {
        if (!mCameras[camManagerIndex])
        {
            mCameras[camManagerIndex] = mCameraManagers[camManagerIndex]->createCamera(params);
            connect(mCameras[camManagerIndex], &LaserXCamera::imageReady, this, &AddCameraDialog::onImageReady, Qt::QueuedConnection);
            connect(mCameras[camManagerIndex], &LaserXCamera::errorOccurred, this, &AddCameraDialog::onErrorOccurred, Qt::QueuedConnection);
        }

        if (mCameras[camManagerIndex]->open(params))
        {
            cv::Mat iMat = mCameras[camManagerIndex]->snap();
            ui->laserXCanvasPreview->setMat(iMat);
            ui->labelStatus->setText(tr("<font color='green'>Camera is opened</font>"));
            ui->pushButtonAdd->setEnabled(true);
        }
        else
        {
            mCameraManagers[camManagerIndex]->deleteCamera(mCameras[camManagerIndex]);
            mCameras[camManagerIndex] = nullptr;
            ui->pushButtonAdd->setEnabled(false);
        }
    }
}

void AddCameraDialog::onSnapClicked()
{
    const qsizetype camManagerIndex = ui->comboBoxCameraType->currentIndex();
    if (camManagerIndex >= 0 && camManagerIndex < mCameraManagers.size())
    {
        if (!mCameras[camManagerIndex])
        {
            onCameraParameterChanged(mCameraPages[camManagerIndex]->getParameters());
        }
        else
        {
            mCameras[camManagerIndex]->stopContinuousGrab();
            cv::Mat iMat = mCameras[camManagerIndex]->snap();
            ui->laserXCanvasPreview->setMat(iMat);
        }
    }
}

void AddCameraDialog::onLiveClicked()
{
    const qsizetype camManagerIndex = ui->comboBoxCameraType->currentIndex();
    if (camManagerIndex >= 0 && camManagerIndex < mCameraManagers.size())
    {
        if (!mCameras[camManagerIndex])
        {
            onCameraParameterChanged(mCameraPages[camManagerIndex]->getParameters());
        }

        if (mCameras[camManagerIndex] && mCameras[camManagerIndex]->isLivable())
        {
            mCameras[camManagerIndex]->toggleContinuousGrab();
        }
    }
}

void AddCameraDialog::onImageReady(cv::Mat img, QVariantMap infos)
{
    LaserXCamera* iCam = dynamic_cast<LaserXCamera*>(sender());
    if (iCam)
    {
        iCam->imageConsumed();
    }
    ui->laserXCanvasPreview->setMat(img);
}

void AddCameraDialog::onErrorOccurred(LaserXCamera::CameraError error)
{
    ui->labelStatus->setText(tr("<font color='red'>Camera error %1</font>").arg(QtEnumToString(error)));
}

void AddCameraDialog::on_comboBoxCameraType_currentIndexChanged(int index)
{
    for (qsizetype cc = 0; cc < mCameras.size(); ++cc)
    {
        if (mCameras[cc])
        {
            mCameras[cc]->stopContinuousGrab();
        }
    }

    const qsizetype camManagerIndex = ui->comboBoxCameraType->currentIndex();
    if (camManagerIndex >= 0 && camManagerIndex < mCameraManagers.size())
    {
        if (!mCameras[camManagerIndex])
        {
            onCameraParameterChanged(mCameraPages[camManagerIndex]->getParameters());
        }

        if (mCameras[camManagerIndex])
        {
            if (mCameras[camManagerIndex]->isOpened())
            {
                ui->labelStatus->setText(tr("<font color='green'>Camera is opened</font>"));
                ui->pushButtonAdd->setEnabled(true);
            }
            else
            {
                ui->pushButtonAdd->setEnabled(false);
            }
            cv::Mat iMat = mCameras[camManagerIndex]->snap();
            ui->laserXCanvasPreview->setMat(iMat);
        }
    }
}

void AddCameraDialog::on_pushButtonAdd_clicked()
{
    if (ui->lineEditName->text().isEmpty())
    {
        ui->labelStatus->setText(tr("<font color='red'>Camera name empty error</font>"));
        return;
    }
    else
    {
        const qsizetype camManagerIndex = ui->comboBoxCameraType->currentIndex();
        if (camManagerIndex >= 0 && camManagerIndex < mCameraManagers.size())
        {
            if (mCameras[camManagerIndex])
            {
                mCameras[camManagerIndex]->setName(ui->lineEditName->text());
                if (mCameras[camManagerIndex]->isOpened() &&
                    mCameraManagers[camManagerIndex]->addCamera(mCameras[camManagerIndex]))
                {
                    mCameraAdded = mCameras[camManagerIndex];
                    mCameraAdded->setName(ui->lineEditName->text());
                    mCameras[camManagerIndex]->stopContinuousGrab();
                    mCameras[camManagerIndex] = nullptr;
                    done(Accepted);
                }
                mCameraManagers[camManagerIndex]->deleteCamera(mCameras[camManagerIndex]);
            }
        }

        ui->labelStatus->setText(tr("<font color='red'>Camera is invalid</font>"));
    }
}
