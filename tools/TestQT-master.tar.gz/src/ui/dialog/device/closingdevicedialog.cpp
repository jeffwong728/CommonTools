#include "closingdevicedialog.h"
#include "ui_closingdevicedialog.h"
#include <laser_x_devicemanager.h>
#include <laser_x_camera.h>
#include <laser_x_serialport.h>
#include <laser_x_net_listener.h>
#include <util/quihelper.h>
#include <QTimer>

ClosingDeviceDialog::ClosingDeviceDialog(QWidget *parent, LaserXDeviceManager* deviceManager) :
    QDialog(parent), ui(new Ui::ClosingDeviceDialog), mDeviceManager(deviceManager)
{
    ui->setupUi(this);
    QUIHelper::setFramelessForm(this, true, false, false);
    QTimer::singleShot(1000, this, &ClosingDeviceDialog::closingAllDevices);
}

ClosingDeviceDialog::~ClosingDeviceDialog()
{
    delete ui;
}

void ClosingDeviceDialog::closingAllDevices()
{
    QVector<LaserXLEDController*> iLEDs = mDeviceManager->ledControllers();
    for (LaserXLEDController* iLED : iLEDs)
    {
        iLED->turnOffAllChannels();
    }

    QVector<LaserXSerialPort*> comPorts = mDeviceManager->serialPorts();
    for (LaserXSerialPort* comPort : comPorts)
    {
        ui->labelStatus->setText(tr("Closing serial port %1 ...").arg(comPort->portName()));
        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
        comPort->close();
        ui->labelStatus->setText(tr("Serial port %1 closed").arg(comPort->portName()));
        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
    }

    QVector<LaserXNetListener*> networkListeners = mDeviceManager->netListeners();
    for (LaserXNetListener* networkListener : networkListeners)
    {
        ui->labelStatus->setText(tr("Closing network listener %1 ...").arg(networkListener->name()));
        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
        networkListener->closeAllConnections();
        networkListener->close();
        ui->labelStatus->setText(tr("Network listener %1 closed").arg(networkListener->name()));
        qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
    }

    QVector<LaserXCameraManager*> camManagers = mDeviceManager->getCameraManagers();
    for (LaserXCameraManager* camManager : camManagers)
    {
        QVector<LaserXCamera*> cameras = camManager->getCameras();
        for (LaserXCamera* camera : cameras)
        {
            ui->labelStatus->setText(tr("Closing camera %1 ...").arg(camera->name()));
            qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
            camera->stopContinuousGrab();
            camera->close();
            ui->labelStatus->setText(tr("Camera %1 closed").arg(camera->name()));
            qApp->processEvents(QEventLoop::ExcludeUserInputEvents);
        }
    }

    done(QDialog::Accepted);
}
