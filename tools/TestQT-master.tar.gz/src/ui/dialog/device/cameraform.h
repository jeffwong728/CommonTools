#ifndef CAMERAFORM_H
#define CAMERAFORM_H

#include <QWidget>
#include <QTimer>
#include <laser_x_camera.h>
class QMdiSubWindow;

namespace Ui {
class CameraForm;
}

class CameraForm : public QWidget
{
    Q_OBJECT

public:
    explicit CameraForm(QMdiSubWindow*parent, LaserXCamera* camera);
    ~CameraForm();

public:
    void showHeaderBar(bool bShow);

protected:
    bool eventFilter(QObject* object, QEvent* evt) override;

private slots:
    void on_pushButtonMax_clicked();
    void on_pushButtonClose_clicked();
    void on_pushButtonToggle_clicked();

private:
    void onSnapClicked();
    void onLiveClicked();
    void onImageReady(cv::Mat img, QVariantMap infos);
    void onErrorOccurred(LaserXCamera::CameraError error);
    void onCameraDeleted();
    void onCameraParameterChanged(const QString& paramName, const QVariant& oldValue, const QVariant& newValue);

private:
    Ui::CameraForm *ui;
    QMdiSubWindow* const mSubWindow;
    LaserXCamera* mCamera;
    LaserXConfigCameraWidget* mConfigWidget = nullptr;
    QPoint mMousePoint;
    bool mMovingMe = false;
};

#endif // CAMERAFORM_H
