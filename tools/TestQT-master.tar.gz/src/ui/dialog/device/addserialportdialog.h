#ifndef ADDSERIALPORTDIALOG_H
#define ADDSERIALPORTDIALOG_H

#include <QDialog>
class QTreeWidgetItem;
namespace Ui {
class AddSerialPortDialog;
}

class AddSerialPortDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddSerialPortDialog(QWidget *parent, const QStringList& existingPortNames);
    ~AddSerialPortDialog();

private:
    void initPortList();

public:
    QString mPortNameToAdd;
    QStringList mExistingPortNames;

private slots:
    void on_pushButtonAdd_clicked();
    void on_pushButtonCancel_clicked();
    void on_treeWidgetSerialPort_itemClicked(QTreeWidgetItem* item, int column);

private:
    Ui::AddSerialPortDialog *ui;
};

#endif // ADDSERIALPORTDIALOG_H
