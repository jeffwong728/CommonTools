#ifndef CAMERADIALOG_H
#define CAMERADIALOG_H

#include <QDialog>
#include <laser_x_camera.h>

namespace Ui {
class CameraDialog;
}

class CameraDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CameraDialog(QWidget *parent, const QVector<LaserXCameraManager*>& cameraManagers, const QString uuid = QString());
    ~CameraDialog();

private slots:
    void on_toolButtonTab_clicked();
    void on_toolButtonTile_clicked();
    void on_toolButtonCascade_clicked();
    void on_toolButtonAddCamera_clicked();
    void on_toolButtonDelete_clicked();
    void on_toolButtonHide_clicked();
    void on_toolButtonLight_clicked();
    void on_treeWidget_itemDoubleClicked(QTreeWidgetItem* item, int column);
    void on_treeWidget_itemClicked(QTreeWidgetItem* item, int column);

private:
    void onSubWindowDestroyed(QObject* obj);
    void onCameraParameterChanged(const QString& paramName, const QVariant& oldValue, const QVariant& newValue);

private:
    Ui::CameraDialog *ui;
    QVector<LaserXCameraManager*> mCameraManagers;
};

#endif // CAMERADIALOG_H
