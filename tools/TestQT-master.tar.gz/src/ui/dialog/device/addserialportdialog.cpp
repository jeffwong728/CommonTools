#include "addserialportdialog.h"
#include "ui_addserialportdialog.h"
#include <QtCore>
#include <QtGui>
#include <QtWidgets>
#include <QtSerialPort>

AddSerialPortDialog::AddSerialPortDialog(QWidget *parent, const QStringList& existingPortNames)
    : QDialog(parent)
    , ui(new Ui::AddSerialPortDialog)
    , mExistingPortNames(existingPortNames)
{
    ui->setupUi(this);
    ui->pushButtonAdd->setEnabled(false);
    initPortList();
}

AddSerialPortDialog::~AddSerialPortDialog()
{
    delete ui;
}

void AddSerialPortDialog::initPortList()
{
    QList<QSerialPortInfo> portInfos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo& portInfo : portInfos)
    {
        if (-1 == mExistingPortNames.indexOf(portInfo.portName()))
        {
            QTreeWidget* tree = ui->treeWidgetSerialPort;
            tree->addTopLevelItem(new QTreeWidgetItem(tree, QStringList() << portInfo.portName() << portInfo.systemLocation() << portInfo.description()));
        }
    }
}

void AddSerialPortDialog::on_pushButtonAdd_clicked()
{
    mPortNameToAdd = ui->treeWidgetSerialPort->selectedItems().front()->text(0);
    done(QDialog::Accepted);
}


void AddSerialPortDialog::on_pushButtonCancel_clicked()
{
    done(QDialog::Rejected);
}


void AddSerialPortDialog::on_treeWidgetSerialPort_itemClicked(QTreeWidgetItem* item, int column)
{
    ui->pushButtonAdd->setEnabled(true);
}

