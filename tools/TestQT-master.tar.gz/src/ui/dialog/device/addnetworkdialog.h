#ifndef ADDNETWORKDIALOG_H
#define ADDNETWORKDIALOG_H

#include <QDialog>
#include <QHostAddress>

namespace Ui {
class AddNetworkDialog;
}

class AddNetworkDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddNetworkDialog(QWidget *parent = nullptr);
    ~AddNetworkDialog();

protected:
    void changeEvent(QEvent* event) override;

private slots:
    void on_pushButtonAdd_clicked();
    void on_pushButtonClose_clicked();

private:
    Ui::AddNetworkDialog *ui;

public:
    QString mName;
    QHostAddress mAddr;
    int mPort = 0;
};

#endif // ADDNETWORKDIALOG_H
