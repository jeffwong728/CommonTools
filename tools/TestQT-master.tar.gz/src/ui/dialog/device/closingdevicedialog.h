#ifndef CLOSINGDEVICEDIALOG_H
#define CLOSINGDEVICEDIALOG_H

#include <QDialog>
class LaserXDeviceManager;
namespace Ui {
class ClosingDeviceDialog;
}

class ClosingDeviceDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ClosingDeviceDialog(QWidget *parent, LaserXDeviceManager* deviceManager);
    ~ClosingDeviceDialog();

private:
    void closingAllDevices();

private:
    Ui::ClosingDeviceDialog *ui;
    LaserXDeviceManager* const mDeviceManager;
};

#endif // CLOSINGDEVICEDIALOG_H
