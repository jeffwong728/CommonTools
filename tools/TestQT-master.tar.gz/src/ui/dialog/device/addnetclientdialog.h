#ifndef ADDNETCLIENTDIALOG_H
#define ADDNETCLIENTDIALOG_H

#include <QDialog>
#include <QHostAddress>

namespace Ui {
class AddNetClientDialog;
}

class AddNetClientDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddNetClientDialog(QWidget *parent = nullptr);
    ~AddNetClientDialog();

private slots:
    void on_pushButtonAdd_clicked();
    void on_pushButtonClose_clicked();

private:
    Ui::AddNetClientDialog *ui;

public:
    QString mName;
    QHostAddress mAddr;
    int mPort = 0;
    int mConnectWait = 3000;
};

#endif // ADDNETCLIENTDIALOG_H
