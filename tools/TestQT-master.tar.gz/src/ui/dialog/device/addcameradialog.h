#ifndef ADDCAMERADIALOG_H
#define ADDCAMERADIALOG_H

#include <QDialog>
#include <QTimer>
#include <laser_x_camera.h>
#include <opencv2/opencv.hpp>

namespace Ui {
class AddCameraDialog;
}

class AddCameraDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddCameraDialog(QWidget *parent, const QVector<LaserXCameraManager*> &cameraManagers);
    ~AddCameraDialog();

public:
    LaserXCamera* getCameraAdded() const { return mCameraAdded; }

private:
    void onCameraParameterChanged(const QVariantMap& params);
    void onSnapClicked();
    void onLiveClicked();
    void onImageReady(cv::Mat img, QVariantMap infos);
    void onErrorOccurred(LaserXCamera::CameraError error);

private slots:
    void on_comboBoxCameraType_currentIndexChanged(int index);
    void on_pushButtonAdd_clicked();

private:
    Ui::AddCameraDialog *ui;
    QVector<LaserXCamera*> mCameras;
    QVector<LaserXCameraManager*> mCameraManagers;
    QVector<LaserXAddCameraWidget*> mCameraPages;
    LaserXCamera* mCameraAdded = nullptr;
};

#endif // ADDCAMERADIALOG_H
