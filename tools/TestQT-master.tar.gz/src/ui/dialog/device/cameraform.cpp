#include "cameraform.h"
#include "ui_cameraform.h"
#include <cmndef.h>
#include <laser_x_util.h>
#include <laser_x_vision.h>
#include <QtWidgets>

CameraForm::CameraForm(QMdiSubWindow*parent, LaserXCamera* camera)
    : QWidget(parent)
    , ui(new Ui::CameraForm)
    , mSubWindow(parent)
    , mCamera(camera)
{
    ui->setupUi(this);
    ui->labelIcon->setPixmap(camera->getManager()->getIcon().pixmap(16, 16));
    ui->pushButtonMax->setIcon(QIcon(QStringLiteral(":/qss_icons/images/maximize-button-16.png")));
    ui->pushButtonMax->setIconSize(QSize(16, 16));
    ui->widgetCameraHeader->installEventFilter(this);
    ui->widgetCameraHeader->setContentsMargins(2, 2, 2, 1);
    ui->horizontalLayoutStatus->addWidget(new QSizeGrip(this), 0, Qt::AlignRight | Qt::AlignBottom);
    ui->horizontalLayoutStatus->setContentsMargins(0, 0, 0, 0);
    ui->pushButtonToggle->setContentsMargins(0, 0, 0, 0);
    ui->labelName->setText(camera->name());
    ui->laserXCanvas->setImageSourceName(camera->name());

    mConfigWidget = mCamera->getManager()->getConfigWidget(ui->frame, camera);
    if (mConfigWidget)
    {
        delete ui->horizontalLayoutConfig->replaceWidget(ui->widgetConfig, mConfigWidget);
        ui->widgetConfig->deleteLater();
        ui->widgetConfig = mConfigWidget;
        mConfigWidget->initialize(mCamera->getParameters());
    }

    ui->widgetConfig->setVisible(false);
    ui->labelStatus->setVisible(false);

    connect(ui->laserXCanvas, &LaserXCanvas::snapClicked, this, &CameraForm::onSnapClicked);
    connect(ui->laserXCanvas, &LaserXCanvas::liveClicked, this, &CameraForm::onLiveClicked);
    connect(mCamera, &LaserXCamera::imageReady, this, &CameraForm::onImageReady, Qt::QueuedConnection);
    connect(mCamera, &LaserXCamera::errorOccurred, this, &CameraForm::onErrorOccurred, Qt::QueuedConnection);
    connect(mCamera, &LaserXCamera::parameterChanged, this, &CameraForm::onCameraParameterChanged, Qt::QueuedConnection);
    connect(mCamera, &LaserXCamera::destroyed, this, &CameraForm::onCameraDeleted);

    QTimer::singleShot(0, [this]() { cv::Mat iMat = mCamera->snap(); ui->laserXCanvas->setMat(iMat); });
}

CameraForm::~CameraForm()
{
    if (mCamera)
    {
        mCamera->stopContinuousGrab();
    }
    delete ui;
}

void CameraForm::showHeaderBar(bool bShow)
{
    ui->widgetCameraHeader->setVisible(bShow);
}

bool CameraForm::eventFilter(QObject* obj, QEvent* evt)
{
    if (ui->widgetCameraHeader == obj && evt)
    {
        if (QEvent::MouseButtonPress == evt->type() && !mSubWindow->isMaximized() &&
            static_cast<QMouseEvent*>(evt)->button() == Qt::LeftButton)
        {
            mMovingMe = true;
            mMousePoint = static_cast<QMouseEvent*>(evt)->globalPosition().toPoint() - mSubWindow->pos();
        }

        if (QEvent::MouseButtonRelease == evt->type())
        {
            mMovingMe = false;
        }

        if (mMovingMe && QEvent::MouseMove == evt->type())
        {
            mSubWindow->move(static_cast<QMouseEvent*>(evt)->globalPosition().toPoint() - mMousePoint);
            QPoint iPos = mSubWindow->pos();
            QSize iSize = mSubWindow->mdiArea()->size();
            QSize iHeaderSize = ui->widgetCameraHeader->size();
            bool iAdjust = false;
            if (iPos.x() < 3 - iHeaderSize.width())
            {
                iPos.setX(3 - iHeaderSize.width());
                iAdjust = true;
            }
            if (iPos.y() < 3 - iHeaderSize.height())
            {
                iPos.setY(3 - iHeaderSize.height());
                iAdjust = true;
            }
            if (iPos.x() >= iSize.width() - 5)
            {
                iPos.setX(iSize.width() - 5);
                iAdjust = true;
            }
            if (iPos.y() >= iSize.height() - 5)
            {
                iPos.setY(iSize.height() - 5);
                iAdjust = true;
            }
            if (iAdjust)
            {
                QSize mySize = mSubWindow->size();
                mSubWindow->setGeometry(iPos.x(), iPos.y(), mySize.width(), mySize.height());
            }
        }

        if (QEvent::MouseButtonDblClick == evt->type() && static_cast<QMouseEvent*>(evt)->button() == Qt::LeftButton)
        {
            if (isMaximized())
            {
                showNormal();
                ui->pushButtonMax->setIcon(QIcon(QStringLiteral(":/qss_icons/images/maximize-button-16.png")));
            }
            else
            {
                showMaximized();
                ui->pushButtonMax->setIcon(QIcon(QStringLiteral(":/qss_icons/images/restore-down-16.png")));
            }
        }
    }

    return QWidget::eventFilter(obj, evt);
}

void CameraForm::on_pushButtonMax_clicked()
{
    if (mSubWindow->isMaximized())
    {
        ui->pushButtonMax->setIcon(QIcon(QStringLiteral(":/qss_icons/images/maximize-button-16.png")));
        mSubWindow->showNormal();
    }
    else
    {
        ui->pushButtonMax->setIcon(QIcon(QStringLiteral(":/qss_icons/images/restore-down-16.png")));
        mSubWindow->showMaximized();
    }
}


void CameraForm::on_pushButtonClose_clicked()
{
    mSubWindow->close();
}

void CameraForm::on_pushButtonToggle_clicked()
{
    ui->widgetConfig->setVisible(!ui->widgetConfig->isVisible());
    ui->labelStatus->setVisible(!ui->labelStatus->isVisible());
    ui->horizontalLayoutConfig->setContentsMargins(0, 0, ui->widgetConfig->isVisible() ? 9 : 0, 0);

    if (ui->widgetConfig->isVisible() && !mSubWindow->isMaximized() && QMdiArea::TabbedView != mSubWindow->mdiArea()->viewMode())
    {
        mSubWindow->adjustSize();
    }
}

void CameraForm::onSnapClicked()
{
    if (mCamera)
    {
        mCamera->stopContinuousGrab();
        cv::Mat iMat = mCamera->snap();
        ui->laserXCanvas->setMat(iMat);
    }
}

void CameraForm::onLiveClicked()
{
    if (mCamera && mCamera->isLivable())
    {
        mCamera->toggleContinuousGrab();
    }
}

void CameraForm::onImageReady(cv::Mat img, QVariantMap infos)
{
    LaserXCamera* iCam = dynamic_cast<LaserXCamera*>(sender());
    if (iCam)
    {
        iCam->imageConsumed();
    }

    ui->laserXCanvas->setMat(img);
}

void CameraForm::onErrorOccurred(LaserXCamera::CameraError error)
{
    ui->labelStatus->setText(tr("<font color='red'>Camera error %1</font>").arg(QtEnumToString(error)));
}

void CameraForm::onCameraDeleted()
{
    mCamera = nullptr;
}

void CameraForm::onCameraParameterChanged(const QString& paramName, const QVariant& oldValue, const QVariant& newValue)
{
    setWindowTitle(mCamera->name());
    ui->labelName->setText(mCamera->name());
    ui->labelStatus->setText(tr("<font color='green'>%1 changed to %2</font>").arg(paramName).arg(newValue.toString()));
}
