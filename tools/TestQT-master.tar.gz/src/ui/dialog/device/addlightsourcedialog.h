#ifndef ADDLIGHTSOURCEDIALOG_H
#define ADDLIGHTSOURCEDIALOG_H

#include <QDialog>

namespace Ui {
class AddLightSourceDialog;
}

class AddLightSourceDialog : public QDialog
{
    Q_OBJECT

public:
    explicit AddLightSourceDialog(QWidget *parent = nullptr);
    ~AddLightSourceDialog();

public:
    QString name() const;
    QString vendorType() const;
    QString commType() const;
    QString commSource() const;
    qlonglong numChannels() const;

private slots:
    void on_pushButtonAdd_clicked();
    void on_pushButtonCancel_clicked();

private:
    Ui::AddLightSourceDialog *ui;
};

#endif // ADDLIGHTSOURCEDIALOG_H
