#include "addnetclientdialog.h"
#include "ui_addnetclientdialog.h"

AddNetClientDialog::AddNetClientDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddNetClientDialog)
{
    ui->setupUi(this);
}

AddNetClientDialog::~AddNetClientDialog()
{
    delete ui;
}

void AddNetClientDialog::on_pushButtonAdd_clicked()
{
    if (ui->lineEditName->text().isEmpty())
    {
        ui->labelStatus->setText(tr("<font color='red'>Name empty error</font>"));
        return;
    }

    if (ui->lineEditAddress->text().isEmpty())
    {
        ui->labelStatus->setText(tr("<font color='red'>Address empty error</font>"));
        return;
    }

    if (ui->lineEditPort->text().isEmpty())
    {
        ui->labelStatus->setText(tr("<font color='red'>Port empty error</font>"));
        return;
    }

    if (!mAddr.setAddress(ui->lineEditAddress->text()))
    {
        ui->labelStatus->setText(tr("<font color='red'>Address invalid error</font>"));
        return;
    }

    bool ok = false;
    mPort = ui->lineEditPort->text().toInt(&ok);
    if (!ok)
    {
        ui->labelStatus->setText(tr("<font color='red'>Port invalid error</font>"));
        return;
    }

    if (mPort < 1024 || mPort > 65535)
    {
        ui->labelStatus->setText(tr("<font color='red'>Port out of range error</font>"));
        return;
    }

    mConnectWait = ui->lineEditConnectWait->text().toInt(&ok);
    if (!ok || mConnectWait < 0)
    {
        ui->labelStatus->setText(tr("<font color='red'>Connect wait invalid error</font>"));
        return;
    }

    mName = ui->lineEditName->text();

    done(Accepted);
}

void AddNetClientDialog::on_pushButtonClose_clicked()
{
    done(Rejected);
}
