#include "addlightsourcedialog.h"
#include "ui_addlightsourcedialog.h"
#include <laser_x_serialport.h>
#include <laser_x_devicemanager.h>
#include <cmndef.h>

AddLightSourceDialog::AddLightSourceDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddLightSourceDialog)
{
    ui->setupUi(this);

    QVector<LaserXSerialPort*> iSerialPorts = gDeviceManager->serialPorts();
    for (LaserXSerialPort* iSerialPort : iSerialPorts)
    {
        if (!iSerialPort->portName().isEmpty())
        {
            ui->comboBoxCommSource->addItem(iSerialPort->portName(), iSerialPort->getUUID());
        }
    }
}

AddLightSourceDialog::~AddLightSourceDialog()
{
    delete ui;
}

QString AddLightSourceDialog::name() const
{
    return ui->lineEditName->text();
}

QString AddLightSourceDialog::vendorType() const
{
    QStringList iVendors;
    iVendors << QStringLiteral("Wordop");
    if (ui->comboBoxVendor->currentIndex() < iVendors.size() && ui->comboBoxVendor->currentIndex() >= 0)
    {
        return iVendors[ui->comboBoxVendor->currentIndex()];
    }
    else
    {
        return QString();
    }
}

QString AddLightSourceDialog::commType() const
{
    return QStringLiteral("SerialPort");
}

QString AddLightSourceDialog::commSource() const
{
    return ui->comboBoxCommSource->currentData().toString();
}

qlonglong AddLightSourceDialog::numChannels() const
{
    return ui->spinBoxNumChannels->value();
}

void AddLightSourceDialog::on_pushButtonAdd_clicked()
{
    ui->labelStatus->setStyleSheet(QStringLiteral("QLabel { color : red; }"));

    if (ui->lineEditName->text().isEmpty())
    {
        ui->labelStatus->setText(QStringLiteral("Light source name empty error"));
        return;
    }

    if (ui->comboBoxCommSource->count() < 1)
    {
        ui->labelStatus->setText(QStringLiteral("No communication device error"));
        return;
    }

    done(QDialog::Accepted);
}

void AddLightSourceDialog::on_pushButtonCancel_clicked()
{
    done(QDialog::Rejected);
}
