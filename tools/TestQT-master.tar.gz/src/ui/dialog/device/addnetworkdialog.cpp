#include "addnetworkdialog.h"
#include "ui_addnetworkdialog.h"
#include <QtWidgets>
#include <QtNetwork>
#include <QtCore>

AddNetworkDialog::AddNetworkDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AddNetworkDialog)
{
    ui->setupUi(this);
    QList<QHostAddress> ipAddressesList = QNetworkInterface::allAddresses();
    ui->comboBoxIPAddress->addItem(QHostAddress(QHostAddress::Any).toString());
    ui->comboBoxIPAddress->addItem(QHostAddress(QHostAddress::LocalHost).toString());
    for (const QHostAddress &iIP : ipAddressesList)
    {
        bool ok = false;
        quint32 ip4Addr = iIP.toIPv4Address(&ok);
        if (ok && iIP != QHostAddress(QHostAddress::LocalHost))
        {
            ui->comboBoxIPAddress->addItem(iIP.toString());
        }
    }
}

AddNetworkDialog::~AddNetworkDialog()
{
    delete ui;
}

void AddNetworkDialog::changeEvent(QEvent* event)
{
    QDialog::changeEvent(event);
}

void AddNetworkDialog::on_pushButtonAdd_clicked()
{
    if (ui->lineEditName->text().isEmpty())
    {
        ui->labelStatus->setText(tr("<font color='red'>Name empty error</font>"));
        return;
    }

    bool ok = false;
    mPort = ui->lineEditPort->text().toInt(&ok);
    if (!ui->lineEditPort->text().isEmpty() && !ok)
    {
        ui->labelStatus->setText(tr("<font color='red'>Invalid port error</font>"));
        return;
    }

    mName = ui->lineEditName->text();
    mAddr = QHostAddress(ui->comboBoxIPAddress->currentText());
    done(Accepted);
}

void AddNetworkDialog::on_pushButtonClose_clicked()
{
    done(Rejected);
}
