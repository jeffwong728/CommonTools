#include "cameradialog.h"
#include "lightsourcedialog.h"
#include "ui_cameradialog.h"
#include "cameraform.h"
#include "addcameradialog.h"
#include <cmndef.h>
#include <util/quihelper.h>
#include <util/qapphelper.h>
#include <ui/mainframe.h>
#include <database/settingdb.h>
#include <QtWidgets>

CameraDialog::CameraDialog(QWidget *parent, const QVector<LaserXCameraManager*>& cameraManagers, const QString uuid)
    : QDialog(parent)
    , ui(new Ui::CameraDialog)
    , mCameraManagers(cameraManagers)
{
    ui->setupUi(this);
    ui->mdiArea->setViewMode(QMdiArea::SubWindowView);
    ui->mdiArea->setTabShape(QTabWidget::Rounded);
    ui->mdiArea->setTabsClosable(true);
    ui->mdiArea->setTabsMovable(true);
    ui->mdiArea->tileSubWindows();
    setWindowFlag(Qt::WindowMaximizeButtonHint, true);

    for (LaserXCameraManager* camManager : cameraManagers)
    {
        QVector<LaserXCamera*> cams = camManager->getCameras();
        for (LaserXCamera* cam : cams)
        {
            QTreeWidgetItem* iCamItem = new QTreeWidgetItem(ui->treeWidget, QStringList() << cam->name());
            iCamItem->setData(0, Qt::UserRole, QVariant::fromValue(static_cast<void*>(cam)));
            ui->treeWidget->addTopLevelItem(iCamItem);
            connect(cam, &LaserXCamera::parameterChanged, this, &CameraDialog::onCameraParameterChanged, Qt::QueuedConnection);
        }
    }

    if (!uuid.isEmpty())
    {
        QTimer::singleShot(0, this, [this, uuid]()
        {
            for (int tt = 0; tt < ui->treeWidget->topLevelItemCount(); ++tt)
            {
                QTreeWidgetItem* item = ui->treeWidget->topLevelItem(tt);
                LaserXCamera* iCam = static_cast<LaserXCamera*>(item->data(0, Qt::UserRole).value<void*>());
                if (iCam && iCam->getUUID() == uuid)
                {
                    ui->treeWidget->setCurrentItem(item);
                    on_treeWidget_itemDoubleClicked(item, 0);
                    QMdiSubWindow* iSubWindow = static_cast<QMdiSubWindow*>(item->data(0, Qt::UserRole + 1).value<void*>());
                    if (iSubWindow)
                    {
                        iSubWindow->showMaximized();
                    }
                    break;
                }
            }
        });
    }
}

CameraDialog::~CameraDialog()
{
    for (int tt = 0; tt < ui->treeWidget->topLevelItemCount(); ++tt)
    {
        QTreeWidgetItem* item = ui->treeWidget->topLevelItem(tt);
        QMdiSubWindow* iSubWindow = static_cast<QMdiSubWindow*>(item->data(0, Qt::UserRole + 1).value<void*>());
        if (iSubWindow)
        {
            disconnect(iSubWindow, &QMdiSubWindow::destroyed, this, &CameraDialog::onSubWindowDestroyed);
        }
    }
}

void CameraDialog::on_toolButtonTab_clicked()
{
    ui->mdiArea->setViewMode(QMdiArea::TabbedView);
    for (QMdiSubWindow* iSubWnd : ui->mdiArea->subWindowList())
    {
        static_cast<CameraForm*>(iSubWnd->widget())->showHeaderBar(false);
    }
}

void CameraDialog::on_toolButtonAddCamera_clicked()
{
    AddCameraDialog dlg(this, mCameraManagers);
    if (QDialog::Accepted == dlg.exec())
    {
        LaserXCamera* iCam = dlg.getCameraAdded();
        if (iCam)
        {
            QTreeWidgetItem *iCamItem = new QTreeWidgetItem(ui->treeWidget, QStringList() << iCam->name());
            iCamItem->setData(0, Qt::UserRole, QVariant::fromValue(static_cast<void*>(iCam)));
            ui->treeWidget->addTopLevelItem(iCamItem);
            connect(iCam, &LaserXCamera::parameterChanged, this, &CameraDialog::onCameraParameterChanged, Qt::QueuedConnection);
            SettingDB db;
            db.addCamera(iCam->getUUID(), iCam->getManager()->getTypeName(), iCam->getParameters());
        }
    }
}

void CameraDialog::on_toolButtonDelete_clicked()
{
    QList<QTreeWidgetItem*> items = ui->treeWidget->selectedItems();
    QVector<QTreeWidgetItem*> delItems;
    if (!items.empty())
    {
        for (QTreeWidgetItem* item : items)
        {
            LaserXCamera* iCam = static_cast<LaserXCamera*>(item->data(0, Qt::UserRole).value<void*>());
            if (iCam)
            {
                if (QMessageBox::Yes == QMessageBox::question(this, tr("Confirm Delete Camera"),
                    tr("Are you sure you want to delete camera %1").arg(iCam->name()), QMessageBox::Yes, QMessageBox::No))
                {
                    QMdiSubWindow* iSubWindow = static_cast<QMdiSubWindow*>(item->data(0, Qt::UserRole + 1).value<void*>());
                    if (iSubWindow)
                    {
                        iSubWindow->close();
                    }

                    iCam->startContinuousGrab();
                    iCam->close();
                    iCam->getManager()->deleteCamera(iCam);
                    SettingDB db;
                    db.deleteCamera(iCam->getUUID());
                    delItems.push_back(item);
                }
            }
        }
        qDeleteAll(delItems);
    }
}

void CameraDialog::on_toolButtonHide_clicked()
{
    ui->treeWidget->setVisible(!ui->treeWidget->isVisible());
}

void CameraDialog::on_toolButtonLight_clicked()
{
    LightSourceDialog* iDialog = new LightSourceDialog(this);
    iDialog->setObjectName(QStringLiteral("CameraLightSourceDialog"));
    iDialog->setAttribute(Qt::WA_DeleteOnClose);
    iDialog->show();
    iDialog->raise();
    iDialog->activateWindow();
}

void CameraDialog::on_treeWidget_itemDoubleClicked(QTreeWidgetItem* item, int column)
{
    if (item && 0 == column)
    {
        LaserXCamera* iCam = static_cast<LaserXCamera*>(item->data(column, Qt::UserRole).value<void*>());
        QMdiSubWindow* iSubWindow = static_cast<QMdiSubWindow*>(item->data(column, Qt::UserRole+1).value<void*>());
        if (!iSubWindow)
        {
            iSubWindow = new QMdiSubWindow(ui->mdiArea->viewport());
            CameraForm* camForm = new CameraForm(iSubWindow, iCam);
            camForm->setWindowTitle(iCam->name());
            iSubWindow->setWidget(camForm);
            iSubWindow->setAttribute(Qt::WA_DeleteOnClose);
            iSubWindow->setWindowFlags(Qt::FramelessWindowHint);
            iSubWindow->setWindowIcon(iCam->getManager()->getIcon());
            ui->mdiArea->addSubWindow(iSubWindow);
            item->setData(0, Qt::UserRole+1, QVariant::fromValue(static_cast<void*>(iSubWindow)));
            connect(iSubWindow, &QMdiSubWindow::destroyed, this, &CameraDialog::onSubWindowDestroyed);
        }

        if (QMdiArea::TabbedView == ui->mdiArea->viewMode())
        {
            qobject_cast<CameraForm*>(iSubWindow->widget())->showHeaderBar(false);
        }

        if (!iSubWindow->isVisible())
        {
            iSubWindow->setVisible(true);
        }
    }
}

void CameraDialog::on_treeWidget_itemClicked(QTreeWidgetItem* item, int column)
{
    if (item && 0 == column)
    {
        QMdiSubWindow* iSubWindow = static_cast<QMdiSubWindow*>(item->data(column, Qt::UserRole + 1).value<void*>());
        if (iSubWindow)
        {
            ui->mdiArea->setActiveSubWindow(iSubWindow);
        }
    }
}

void CameraDialog::onSubWindowDestroyed(QObject* obj)
{
    for (int tt = 0; tt < ui->treeWidget->topLevelItemCount(); ++tt)
    {
        QTreeWidgetItem* item = ui->treeWidget->topLevelItem(tt);
        QMdiSubWindow* iSubWindow = static_cast<QMdiSubWindow*>(item->data(0, Qt::UserRole + 1).value<void*>());
        if (obj == iSubWindow)
        {
            item->setData(0, Qt::UserRole + 1, QVariant::fromValue(static_cast<void*>(nullptr)));
            break;
        }
    }
}

void CameraDialog::onCameraParameterChanged(const QString& paramName, const QVariant& oldValue, const QVariant& newValue)
{
    LaserXCamera* camera = dynamic_cast<LaserXCamera*>(sender());
    if (camera && paramName == QStringLiteral("Name"))
    {
        for (int tt = 0; tt < ui->treeWidget->topLevelItemCount(); ++tt)
        {
            QTreeWidgetItem* item = ui->treeWidget->topLevelItem(tt);
            LaserXCamera* iCam = static_cast<LaserXCamera*>(item->data(0, Qt::UserRole).value<void*>());
            if (iCam == camera)
            {
                item->setText(0, iCam->name());
                break;
            }
        }
    }

    if (camera)
    {
        SettingDB db;
        QJsonDocument doc = QJsonDocument::fromVariant(camera->getParameters());
        QByteArray buffer = doc.toJson(QJsonDocument::Compact);
        QString jsonParams = QString::fromUtf8(buffer);
        db.updateCamera(camera->getUUID(), jsonParams);
    }
}

void CameraDialog::on_toolButtonTile_clicked()
{
    ui->mdiArea->setViewMode(QMdiArea::SubWindowView);
    ui->mdiArea->tileSubWindows();
    for (QMdiSubWindow* iSubWnd : ui->mdiArea->subWindowList())
    {
        static_cast<CameraForm*>(iSubWnd->widget())->showHeaderBar(true);
    }
}

void CameraDialog::on_toolButtonCascade_clicked()
{
    ui->mdiArea->setViewMode(QMdiArea::SubWindowView);
    ui->mdiArea->cascadeSubWindows();
    for (QMdiSubWindow* iSubWnd : ui->mdiArea->subWindowList())
    {
        static_cast<CameraForm*>(iSubWnd->widget())->showHeaderBar(true);
    }
}
