#include "addimage.h"
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/projectdb.h>
#include <manager/image_resource_manager.h>

AddImage::AddImage(const QString &name, const cv::Mat& mat)
    : QUndoCommand()
    , mName(name)
    , mMat(mat)
    , mUUID(QUuid::createUuid().toString())
{
}

AddImage::~AddImage()
{
}

void AddImage::undo()
{
    if (gImageManager->deleteImage(mUUID))
    {
        ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    }
}

void AddImage::redo()
{
    if (gImageManager->addImage(mUUID, mName, mMat))
    {
        ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    }
}
