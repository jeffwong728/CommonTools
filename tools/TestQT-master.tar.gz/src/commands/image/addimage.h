#ifndef COMMANDS_IMAGE_ADD_IMAGE_H
#define COMMANDS_IMAGE_ADD_IMAGE_H
#include <QUndoCommand>
#include <opencv2/opencv.hpp>

class AddImage : public QUndoCommand
{
public:
    AddImage(const QString &name, const cv::Mat& mat);
    ~AddImage();
    void undo() override;
    void redo() override;

private:
    const QString mName;
    const cv::Mat mMat;
    const QString mUUID;
};

#endif // COMMANDS_IMAGE_ADD_IMAGE_H
