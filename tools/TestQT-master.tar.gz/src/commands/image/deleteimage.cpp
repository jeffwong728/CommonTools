#include "deleteimage.h"
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/projectdb.h>
#include <manager/image_resource_manager.h>

DeleteImage::DeleteImage(const QString &name, const QString& uuid, const cv::Mat& mat)
    : QUndoCommand()
    , mName(name)
    , mMat(mat)
    , mUUID(uuid)
{
}

DeleteImage::~DeleteImage()
{
}

void DeleteImage::undo()
{
    if (gImageManager->addImage(mUUID, mName, mMat))
    {
        ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
        projDB.addImage(mUUID, mName, mMat);
    }
}

void DeleteImage::redo()
{
    if (gImageManager->deleteImage(mUUID))
    {
        ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
        projDB.deleteImage(mUUID);
    }
}
