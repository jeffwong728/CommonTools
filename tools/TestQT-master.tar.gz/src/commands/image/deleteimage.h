#ifndef COMMANDS_IMAGE_DELETE_IMAGE_H
#define COMMANDS_IMAGE_DELETE_IMAGE_H
#include <QUndoCommand>
#include <opencv2/opencv.hpp>

class DeleteImage : public QUndoCommand
{
public:
    DeleteImage(const QString &name, const QString& uuid, const cv::Mat& mat);
    ~DeleteImage();
    void undo() override;
    void redo() override;

private:
    const QString mName;
    const cv::Mat mMat;
    const QString mUUID;
};

#endif // COMMANDS_IMAGE_DELETE_IMAGE_H
