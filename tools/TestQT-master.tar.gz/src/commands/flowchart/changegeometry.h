#ifndef COMMANDS_FLOW_CHART_CHANGE_GEOMETRY_H
#define COMMANDS_FLOW_CHART_CHANGE_GEOMETRY_H
#include <QUndoCommand>
class FlowView;
class LXProcedureItem;
class LinkerItem;

class ChangeProcedureGeometry : public QUndoCommand
{
public:
    ChangeProcedureGeometry(FlowView *view, std::vector<LXProcedureItem*> &&procs, std::vector<QRectF> &&oldRects, std::vector<QPointF> &&oldPoss);
    ~ChangeProcedureGeometry();
    void undo() override;
    void redo() override;

private:
    void updateLinkers();
    QVector<LinkerItem*> getUniqueLinkers() const;

private:
    FlowView *mView = nullptr;
    std::vector<LXProcedureItem*> mProcs;
    std::vector<QRectF> mOldRects;
    std::vector<QRectF> mNewRects;
    std::vector<QPointF> mOldPoss;
    std::vector<QPointF> mNewPoss;
};

class ChangeLinkerGeometry : public QUndoCommand
{
public:
    ChangeLinkerGeometry(FlowView* view, std::vector<LinkerItem*>&& linkers, std::vector<std::vector<QPointF>>&& oldPoints);
    ~ChangeLinkerGeometry();
    void undo() override;
    void redo() override;

private:
    FlowView* mView = nullptr;
    std::vector<LinkerItem*> mLinkers;
    std::vector<std::vector<QPointF>> mOldPoints;
    std::vector<std::vector<QPointF>> mNewPoints;
};

#endif // COMMANDS_FLOW_CHART_CHANGE_GEOMETRY_H
