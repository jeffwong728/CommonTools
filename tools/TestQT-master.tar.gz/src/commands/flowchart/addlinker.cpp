#include "addlinker.h"
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/projectdb.h>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/flowscene.h>
#include <ui/flowchart/procedure/linkeritem.h>

AddLinker::AddLinker(FlowView *view, LinkerItem* linker)
    : QUndoCommand()
    , mView(view)
    , mLinker(linker)
{
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    const qint64 id = projDB.addLinker(linker);
    linker->setId(id);
    setText(QObject::tr("Link two Procedures"));
}

AddLinker::~AddLinker()
{
    if (mOwnItem)
    {
        delete mLinker;
    }
}

void AddLinker::undo()
{
    mView->scene()->removeItem(mLinker);
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    projDB.deleteLinker(mLinker);
    mOwnItem = true;
}

void AddLinker::redo()
{
    if (mLinker->scene() != mView->scene())
    {
        mView->scene()->addItem(mLinker);
        ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
        const qint64 id = projDB.addLinker(mLinker);
        mLinker->setId(id);
    }
    mOwnItem = false;
}
