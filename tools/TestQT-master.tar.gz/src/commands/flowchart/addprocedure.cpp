#include "addprocedure.h"
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/projectdb.h>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/flowscene.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>

AddProcedure::AddProcedure(FlowView *view, const QPointF& pos, const QString &type)
    : QUndoCommand()
    , mView(view)
{
    mItem = new LXProcedureItem(type);
    mItem->setRect(0, 0, 71, 51);
    mView->scene()->addItem(mItem);
    mItem->populateChildren(false);

    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    qint64 procId = projDB.addProcedure(mItem);
    mItem->setId(procId);
    mItem->setName(mItem->getName().append(QStringLiteral(" %1").arg(procId)), true);
    mItem->setPos(pos.x() - mItem->rect().width() / 2, pos.y() - mItem->rect().height() / 2);
    projDB.updateName(mItem);
    projDB.updateGeomData(mItem);

    setText(QObject::tr("Add %1").arg(mItem->getName()));
}

AddProcedure::~AddProcedure()
{
    if (mOwnItem)
    {
        delete mItem;
    }
}

void AddProcedure::undo()
{
    mView->scene()->removeItem(mItem);
    mOwnItem = true;

    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    projDB.deleteProcedure(mItem);
}

void AddProcedure::redo()
{
    if (mItem->scene() != mView->scene())
    {
        mView->scene()->addItem(mItem);
        ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
        qint64 procId = projDB.addProcedure(mItem);
        mItem->setId(procId);
    }

    mOwnItem = false;
}
