#include "deletelinkers.h"
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/projectdb.h>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/flowscene.h>
#include <ui/flowchart/procedure/linkeritem.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>

DeleteLinkers::DeleteLinkers(FlowView *view, std::vector<LinkerItem*> &&linkers)
    : QUndoCommand()
    , mView(view)
    , mLinkers(std::move(linkers))
{
    setText(QObject::tr("Delete Linkers"));
}

DeleteLinkers::~DeleteLinkers()
{
    if (mOwnItem)
    {
        qDeleteAll(mLinkers);
    }
}

void DeleteLinkers::undo()
{
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    for (auto linker : mLinkers)
    {
        mView->scene()->addItem(linker);
        linker->restoreLinks();
        const qint64 id = projDB.addLinker(linker);
        linker->setId(id);
    }
    mOwnItem = false;
}

void DeleteLinkers::redo()
{
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    for (auto linker : mLinkers)
    {
        linker->breakLinks();
        mView->scene()->removeItem(linker);
        projDB.deleteLinker(linker);
    }
    mOwnItem = true;
}
