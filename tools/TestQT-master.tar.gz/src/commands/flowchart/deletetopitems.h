#ifndef COMMANDS_FLOW_CHART_DELETE_TOP_ITEMS_H
#define COMMANDS_FLOW_CHART_DELETE_TOP_ITEMS_H
#include <QUndoCommand>
class FlowView;
class FlowScene;
class QGraphicsItem;

class DeleteTopItems : public QUndoCommand
{
public:
    DeleteTopItems(FlowView *view, std::vector<QGraphicsItem*> &&topItems);
    ~DeleteTopItems();
    void undo() override;
    void redo() override;

private:
    FlowView *mView = nullptr;
    std::vector<QGraphicsItem*> mTopItems;
    bool mOwnItem = false;
};

#endif // COMMANDS_FLOW_CHART_DELETE_TOP_ITEMS_H
