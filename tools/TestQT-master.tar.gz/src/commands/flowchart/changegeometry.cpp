#include "changegeometry.h"
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/flowscene.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <ui/flowchart/procedure/linkeritem.h>
#include <database/projectdb.h>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>

ChangeProcedureGeometry::ChangeProcedureGeometry(FlowView* view, std::vector<LXProcedureItem*>&& procs, std::vector<QRectF>&& oldRects, std::vector<QPointF>&& oldPoss)
    : QUndoCommand()
    , mView(view)
    , mProcs(std::move(procs))
    , mOldRects(std::move(oldRects))
    , mOldPoss(std::move(oldPoss))
{
    setText(QObject::tr("Change Geometry of %1 items").arg(mProcs.size()));
}

ChangeProcedureGeometry::~ChangeProcedureGeometry()
{
}

void ChangeProcedureGeometry::undo()
{
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    for (std::size_t nn = 0; nn < mProcs.size(); ++nn)
    {
        mProcs[nn]->setRect(mOldRects[nn]);
        mProcs[nn]->setPos(mOldPoss[nn]);
        mProcs[nn]->updateChildrenRects();
        projDB.updateGeomData(mProcs[nn]);
    }
    QVector<LinkerItem*> iLinkers = getUniqueLinkers();
    for (auto iLinker : iLinkers)
    {
        iLinker->reRouting();
    }
}

void ChangeProcedureGeometry::redo()
{
    QVector<LinkerItem*> iLinkers = getUniqueLinkers();
    if (mNewRects.empty())
    {
        mNewRects.reserve(mProcs.size());
        mNewPoss.reserve(mProcs.size());
        for (const LXProcedureItem* proc : mProcs)
        {
            mNewRects.push_back(proc->rect());
            mNewPoss.push_back(proc->pos());
        }
    }
    else
    {
        for (std::size_t nn = 0; nn < mProcs.size(); ++nn)
        {
            mProcs[nn]->setRect(mNewRects[nn]);
            mProcs[nn]->setPos(mNewPoss[nn]);
            mProcs[nn]->updateChildrenRects();
        }
        for (auto iLinker : iLinkers)
        {
            iLinker->reRouting();
        }
    }

    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    for (LXProcedureItem* proc : mProcs)
    {
        projDB.updateGeomData(proc);
    }

    for (auto iLinker : iLinkers)
    {
        projDB.updateData(iLinker);
    }
}

void ChangeProcedureGeometry::updateLinkers()
{
    QVector<LinkerItem*> myLinkers = getUniqueLinkers();
    for (auto myLinker : myLinkers)
    {
        myLinker->reRouting();
    }
}

QVector<LinkerItem*> ChangeProcedureGeometry::getUniqueLinkers() const
{
    QVector<LinkerItem*> myLinkers;
    for (std::size_t nn = 0; nn < mProcs.size(); ++nn)
    {
        const auto& linkers = mProcs[nn]->getLinkers();
        for (auto linker : linkers)
        {
            myLinkers.push_back(linker);
        }
    }

    std::sort(myLinkers.begin(), myLinkers.end());
    auto newEndIt = std::unique(myLinkers.begin(), myLinkers.end());
    myLinkers.erase(newEndIt, myLinkers.end());

    return myLinkers;
}

ChangeLinkerGeometry::ChangeLinkerGeometry(FlowView* view, std::vector<LinkerItem*>&& linkers, std::vector<std::vector<QPointF>>&& oldPoints)
    : QUndoCommand()
    , mView(view)
    , mLinkers(std::move(linkers))
    , mOldPoints(std::move(oldPoints))
{
    setText(QObject::tr("Change Geometry of %1 Linkers").arg(mLinkers.size()));
}

ChangeLinkerGeometry::~ChangeLinkerGeometry()
{
}

void ChangeLinkerGeometry::undo()
{
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    for (std::size_t nn = 0; nn < mLinkers.size(); ++nn)
    {
        mLinkers[nn]->setPoints(mOldPoints[nn]);
        projDB.updateData(mLinkers[nn]);
    }
}

void ChangeLinkerGeometry::redo()
{
    if (mNewPoints.empty())
    {
        mNewPoints.reserve(mLinkers.size());
        for (const LinkerItem* linker : mLinkers)
        {
            mNewPoints.emplace_back(linker->getPoints());
        }
    }
    else
    {
        for (std::size_t nn = 0; nn < mLinkers.size(); ++nn)
        {
            mLinkers[nn]->setPoints(mNewPoints[nn]);
        }
    }

    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    for (LinkerItem* linker : mLinkers)
    {
        projDB.updateData(linker);
    }
}
