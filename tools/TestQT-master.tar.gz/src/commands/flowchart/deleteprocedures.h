#ifndef COMMANDS_FLOW_CHART_DELETE_PROCEDURES_H
#define COMMANDS_FLOW_CHART_DELETE_PROCEDURES_H
#include <QUndoCommand>
class FlowView;
class FlowScene;
class LXProcedureItem;

class DeleteProcedures : public QUndoCommand
{
public:
    DeleteProcedures(FlowView *view, std::vector<LXProcedureItem*> &&procs);
    ~DeleteProcedures();
    void undo() override;
    void redo() override;

private:
    FlowView *mView = nullptr;
    std::vector<LXProcedureItem*> mProcs;
    bool mOwnItem = false;
};

#endif // COMMANDS_FLOW_CHART_DELETE_PROCEDURES_H
