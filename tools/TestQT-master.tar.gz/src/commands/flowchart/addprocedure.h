#ifndef COMMANDS_FLOW_CHART_ADD_PROCEDURE_H
#define COMMANDS_FLOW_CHART_ADD_PROCEDURE_H
#include <QUndoCommand>
class FlowView;
class FlowScene;
class LXProcedureItem;

class AddProcedure : public QUndoCommand
{
public:
    AddProcedure(FlowView *view, const QPointF &pos, const QString& type);
    ~AddProcedure();
    void undo() override;
    void redo() override;

private:
    FlowView *mView = nullptr;
    LXProcedureItem* mItem = nullptr;
    bool mOwnItem = false;
};

#endif // COMMANDS_FLOW_CHART_ADD_PROCEDURE_H
