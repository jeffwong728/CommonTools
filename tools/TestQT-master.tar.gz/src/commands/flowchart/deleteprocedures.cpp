#include "deleteprocedures.h"
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>
#include <database/projectdb.h>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/flowscene.h>
#include <ui/flowchart/procedure/linkeritem.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>

DeleteProcedures::DeleteProcedures(FlowView *view, std::vector<LXProcedureItem*> &&procs)
    : QUndoCommand()
    , mView(view)
    , mProcs(std::move(procs))
{
    setText(QObject::tr("Delete Procedures"));
}

DeleteProcedures::~DeleteProcedures()
{
    if (mOwnItem)
    {
        qDeleteAll(mProcs);
    }
}

void DeleteProcedures::undo()
{
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    for (auto proc : mProcs)
    {
        mView->scene()->addItem(proc);
        qint64 procId = projDB.addProcedure(proc);
        proc->setId(procId);
    }
    mOwnItem = false;
}

void DeleteProcedures::redo()
{
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    for (auto proc : mProcs)
    {
        projDB.deleteProcedure(proc);
        mView->scene()->removeItem(proc);
    }
    mOwnItem = true;
}
