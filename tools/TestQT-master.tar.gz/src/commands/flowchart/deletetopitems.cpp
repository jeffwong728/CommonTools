#include "deletetopitems.h"
#include <QGraphicsItem>
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/flowscene.h>

DeleteTopItems::DeleteTopItems(FlowView *view, std::vector<QGraphicsItem*> &&topItems)
    : QUndoCommand()
    , mView(view)
    , mTopItems(std::move(topItems))
{
    setText(QObject::tr("Delete Items"));
}

DeleteTopItems::~DeleteTopItems()
{
    if (mOwnItem)
    {
        qDeleteAll(mTopItems);
    }
}

void DeleteTopItems::undo()
{
    for (auto topItem : mTopItems)
    {
        mView->scene()->addItem(topItem);
    }
    mOwnItem = false;
}

void DeleteTopItems::redo()
{
    for (auto topItem : mTopItems)
    {
        mView->scene()->removeItem(topItem);
    }
    mOwnItem = true;
}
