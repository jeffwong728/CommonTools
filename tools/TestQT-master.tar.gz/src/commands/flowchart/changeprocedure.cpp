#include "changeprocedure.h"
#include <ui/flowchart/flowview.h>
#include <ui/flowchart/flowscene.h>
#include <ui/flowchart/procedure/lxprocedureitem.h>
#include <ui/flowchart/procedure/linkeritem.h>
#include <procedure/lxprocedure.h>
#include <database/projectdb.h>
#include <cmndef.h>
#include <util/qapphelper.h>
#include <util/quihelper.h>

ChangeProcedureData::ChangeProcedureData(LXProcedureItem* proc, QString& newName, QString& newJsonData, QByteArray& newBlobData, QByteArray& newImageData)
    : QUndoCommand()
    , mProc(proc)
    , mNewName(newName)
    , mNewJsonData(newJsonData)
    , mNewBlobData(newBlobData)
    , mNewImageData(newImageData)
    , mOldName(proc->getName())
    , mOldJsonData(proc->getLXProcedure()->getJson())
    , mOldBlobData(proc->getLXProcedure()->getBlob())
    , mOldImageData(proc->getLXProcedure()->getImageData())
{
    setText(QObject::tr("Change Data of %1").arg(proc->getName()));
}

ChangeProcedureData::~ChangeProcedureData()
{
}

void ChangeProcedureData::undo()
{
    mProc->setName(mOldName, false);
    mProc->getLXProcedure()->setJson(mOldJsonData);
    mProc->getLXProcedure()->setBlob(mOldBlobData);
    mProc->getLXProcedure()->setImageData(mOldImageData);

    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    projDB.updateName(mProc);
    projDB.updateJsonData(mProc);
    projDB.updateBinData(mProc);
    projDB.updateImageData(mProc);
}

void ChangeProcedureData::redo()
{
    mProc->setName(mNewName, false);
    mProc->getLXProcedure()->setJson(mNewJsonData);
    mProc->getLXProcedure()->setBlob(mNewBlobData);
    mProc->getLXProcedure()->setImageData(mNewImageData);

    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    projDB.updateName(mProc);
    projDB.updateJsonData(mProc);
    projDB.updateBinData(mProc);
    projDB.updateImageData(mProc);
}

ChangeProcedureName::ChangeProcedureName(LXProcedureItem* proc, QString& newName)
    : QUndoCommand()
    , mProc(proc)
    , mNewName(newName)
    , mOldName(proc->getName())
{
    setText(QObject::tr("Change Name of %1").arg(proc->getName()));
}

ChangeProcedureName::~ChangeProcedureName()
{
}

void ChangeProcedureName::undo()
{
    mProc->setName(mOldName, false);
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    projDB.updateName(mProc);
}

void ChangeProcedureName::redo()
{
    mProc->setName(mNewName, false);
    ProjectDB projDB(QAppHelper::getSetting<QString>(gAppProjPath));
    projDB.updateName(mProc);
}
