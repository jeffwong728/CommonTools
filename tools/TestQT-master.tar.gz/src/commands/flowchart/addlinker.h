#ifndef COMMANDS_FLOW_CHART_ADD_LINKER_H
#define COMMANDS_FLOW_CHART_ADD_LINKER_H
#include <QUndoCommand>
class FlowView;
class LinkerItem;

class AddLinker : public QUndoCommand
{
public:
    AddLinker(FlowView *view, LinkerItem* linker);
    ~AddLinker();
    void undo() override;
    void redo() override;

private:
    FlowView *mView = nullptr;
    LinkerItem* mLinker = nullptr;
    bool mOwnItem = false;
};

#endif // COMMANDS_FLOW_CHART_ADD_LINKER_H
