#ifndef COMMANDS_FLOW_CHART_DELETE_LINKERS_H
#define COMMANDS_FLOW_CHART_DELETE_LINKERS_H
#include <QUndoCommand>
class FlowView;
class FlowScene;
class LinkerItem;

class DeleteLinkers : public QUndoCommand
{
public:
    DeleteLinkers(FlowView *view, std::vector<LinkerItem*> &&linkers);
    ~DeleteLinkers();
    void undo() override;
    void redo() override;

private:
    FlowView *mView = nullptr;
    std::vector<LinkerItem*> mLinkers;
    bool mOwnItem = false;
};

#endif // COMMANDS_FLOW_CHART_DELETE_LINKERS_H
