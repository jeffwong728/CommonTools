#ifndef COMMANDS_FLOW_CHART_CHANGE_PROCEDURE_DATA_H
#define COMMANDS_FLOW_CHART_CHANGE_PROCEDURE_DATA_H
#include <QUndoCommand>
class FlowView;
class LXProcedureItem;
class LinkerItem;

class ChangeProcedureData : public QUndoCommand
{
public:
    ChangeProcedureData(LXProcedureItem* proc, QString &newName, QString &newJsonData, QByteArray &newBlobData, QByteArray& newImageData);
    ~ChangeProcedureData();
    void undo() override;
    void redo() override;

private:
    LXProcedureItem* const mProc;
    QString mNewName;
    QString mNewJsonData;
    QByteArray mNewBlobData;
    QByteArray mNewImageData;
    QString mOldName;
    QString mOldJsonData;
    QByteArray mOldBlobData;
    QByteArray mOldImageData;
};

class ChangeProcedureName : public QUndoCommand
{
public:
    ChangeProcedureName(LXProcedureItem* proc, QString& newName);
    ~ChangeProcedureName();
    void undo() override;
    void redo() override;

private:
    LXProcedureItem* const mProc;
    QString mNewName;
    QString mOldName;
};

#endif // COMMANDS_FLOW_CHART_CHANGE_PROCEDURE_DATA_H
