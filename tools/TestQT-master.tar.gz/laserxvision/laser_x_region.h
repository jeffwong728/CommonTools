#ifndef LASER_X_REGION_H
#define LASER_X_REGION_H

#include <QtCore>
#include "laser_x_vision_global.h"

class LASERXVISION_LIBRARY_EXPORT LaserXRegion : public QObject
{
    Q_OBJECT

public:
    LaserXRegion(QObject* parent) : QObject(parent) {}
    virtual ~LaserXRegion() = default;

public:
    virtual void writeRegion(const QString &fileName) const = 0;
    virtual qlonglong area() const = 0;
    virtual QPointF center() const = 0;
    virtual QVariantMap ellipticAxis() const = 0;
    virtual QImage toLabel(const QSize& size) const = 0;
    virtual LXRegion connection() const = 0;
    virtual LXRegion fillHoles() const = 0;
    virtual LXRegion dilationCircle(const qreal radius) const = 0;
    virtual LXRegion closingCircle(const qreal radius) const = 0;
    virtual LXRegion closingRectangle1(const QSize& size) const = 0;
    virtual LXRegion openingCircle(const qreal radius) const = 0;
    virtual LXRegion openingRectangle1(const QSize& size) const = 0;
    virtual qlonglong countObj() const = 0;
    virtual QVariantMap smallestRectangle2() const = 0;
    virtual QVariantMap smallestCircle() const = 0;
    virtual LXRegion selectRegion(const qlonglong index) const = 0;
    virtual LXRegion selectArea(const qreal minArea, const qreal maxArea) const = 0;
    virtual LXRegion selectCircularity(const qreal minCircularity, const qreal maxCircularity) const = 0;
    virtual LXRegion selectOuterRadius(const qreal minOuterRadius, const qreal maxOuterRadius) const = 0;
    virtual LXRegion selectRectangularity(const qreal minRectangularity, const qreal maxRectangularity) const = 0;
    virtual LXRegion selectRect2SemiMajorLen(const qreal minSemiMajorLen, const qreal maxSemiMajorLen) const = 0;
    virtual LXRegion selectRect2SemiMinorLen(const qreal minSemiMinorLen, const qreal maxSemiMinorLen) const = 0;
    virtual QVector<QPolygonF> getPolygons(const qreal tolerance) const = 0;
};

#define LaserXRegionInterfaceIID "net.laserx.RegionInterface"
Q_DECLARE_INTERFACE(LaserXRegion, LaserXRegionInterfaceIID)

#endif // LASER_X_REGION_H
