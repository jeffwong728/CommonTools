#include "laser_x_vision.h"
#include <laser_x_util.h>

QPainterPath LaserXVisionManager::getPath(const QJsonObject& object)
{
    QPainterPath iPath;
    iPath.setFillRule(Qt::WindingFill);

    if (object.contains(QStringLiteral("rects")))
    {
        QJsonValue val = object.value(QStringLiteral("rects"));
        if (val.isArray())
        {
            QJsonArray rects = val.toArray();
            for (const auto& rect : rects)
            {
                QJsonObject data = rect.toObject();
                if (!data.contains(QStringLiteral("Reversed")))
                {
                    continue;
                }

                if (!data.contains(QStringLiteral("vertices")))
                {
                    continue;
                }

                QJsonValue val = data.value(QStringLiteral("vertices"));
                if (!val.isArray())
                {
                    continue;
                }

                QJsonArray vertices = val.toArray();
                if (4 != vertices.count())
                {
                    continue;
                }

                const bool iReversed = data.value(QStringLiteral("Reversed")).toBool();
                if (iReversed)
                {
                    iPath.moveTo(fromJson(vertices[0], QPointF()));
                    iPath.lineTo(fromJson(vertices[3], QPointF()));
                    iPath.lineTo(fromJson(vertices[2], QPointF()));
                    iPath.lineTo(fromJson(vertices[1], QPointF()));
                    iPath.closeSubpath();
                }
                else
                {
                    iPath.moveTo(fromJson(vertices[0], QPointF()));
                    iPath.lineTo(fromJson(vertices[1], QPointF()));
                    iPath.lineTo(fromJson(vertices[2], QPointF()));
                    iPath.lineTo(fromJson(vertices[3], QPointF()));
                    iPath.closeSubpath();
                }
            }
        }
    }

    if (object.contains(QStringLiteral("ellipses")))
    {
        QJsonValue val = object.value(QStringLiteral("ellipses"));
        if (val.isArray())
        {
            QJsonArray ellipses = val.toArray();
            for (const auto& ellipse : ellipses)
            {
                QJsonObject data = ellipse.toObject();
                if (!data.contains(QStringLiteral("Reversed")))
                {
                    continue;
                }

                if (!data.contains(QStringLiteral("vertices")))
                {
                    continue;
                }

                QJsonValue val = data.value(QStringLiteral("vertices"));
                if (!val.isArray())
                {
                    continue;
                }

                QJsonArray vertices = val.toArray();
                if (4 != vertices.count())
                {
                    continue;
                }

                const bool iReversed = data.value(QStringLiteral("Reversed")).toBool();
                const QPointF iVertices[4] =
                {
                    fromJson(vertices[0], QPointF()),
                    fromJson(vertices[1], QPointF()),
                    fromJson(vertices[2], QPointF()),
                    fromJson(vertices[3], QPointF())
                };

                QPointF iTopLeft = iVertices[0];
                QPointF iRightCenter = (iVertices[1] + iVertices[2]) / 2;
                const qreal iWidth = distance(iVertices[0], iVertices[1]);
                const qreal iHeight = distance(iVertices[0], iVertices[3]);

                if (iWidth > 0 && iHeight > 0)
                {
                    iPath.moveTo(iRightCenter);
                    if (iReversed)
                    {
                        iPath.arcTo(iTopLeft.x(), iTopLeft.y(), iWidth, iHeight, 0, -360);
                    }
                    else
                    {
                        iPath.arcTo(iTopLeft.x(), iTopLeft.y(), iWidth, iHeight, 0, 360);
                    }
                    iPath.closeSubpath();
                }
            }
        }
    }

    if (object.contains(QStringLiteral("polygons")))
    {
        QJsonValue val = object.value(QStringLiteral("polygons"));
        if (val.isArray())
        {
            QJsonArray polygons = val.toArray();
            for (const auto& polygon : polygons)
            {
                QJsonObject data = polygon.toObject();
                if (!data.contains(QStringLiteral("Reversed")))
                {
                    continue;
                }

                if (!data.contains(QStringLiteral("vertices")))
                {
                    continue;
                }

                QJsonValue val = data.value(QStringLiteral("vertices"));
                if (!val.isArray())
                {
                    continue;
                }

                QJsonArray vertices = val.toArray();
                if (vertices.count() < 2)
                {
                    continue;
                }

                const bool iReversed = data.value(QStringLiteral("Reversed")).toBool();
                if (iReversed)
                {
                    iPath.moveTo(fromJson(vertices[0], QPointF()));
                    for (qsizetype nn = vertices.size() - 1; nn > 0; --nn)
                    {
                        iPath.lineTo(fromJson(vertices[nn], QPointF()));
                    }
                    iPath.closeSubpath();
                }
                else
                {
                    iPath.moveTo(fromJson(vertices[0], QPointF()));
                    for (qsizetype nn = 1; nn < vertices.size(); ++nn)
                    {
                        iPath.lineTo(fromJson(vertices[nn], QPointF()));
                    }
                    iPath.closeSubpath();
                }
            }
        }
    }

    return iPath;
}