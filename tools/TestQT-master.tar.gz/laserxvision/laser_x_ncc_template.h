#ifndef LASER_X_NCC_TEMPLATE_H
#define LASER_X_NCC_TEMPLATE_H

#include <QtCore>
#include <opencv2/opencv.hpp>
#include "laser_x_vision_global.h"

class LASERXVISION_LIBRARY_EXPORT LaserXNCCTemplate : public QObject
{
    Q_OBJECT

public:
    LaserXNCCTemplate(QObject* parent) : QObject(parent) {}
    virtual ~LaserXNCCTemplate() = default;

public:
    virtual qreal getAngleStart() const = 0;
    virtual qreal getAngleExtent() const = 0;
    virtual qreal getAngleStep() const = 0;
    virtual qlonglong getNumLevels() const = 0;
    virtual bool getUsePolarity() const = 0;
    virtual QByteArray getBlob() const = 0;
    virtual void writeNCCTemplate(const QString& fileName) const = 0;
    virtual QVariantMap findTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const = 0;
};

#define LaserXNCCTemplateInterfaceIID "net.laserx.NCCTemplateInterface"
Q_DECLARE_INTERFACE(LaserXNCCTemplate, LaserXNCCTemplateInterfaceIID)

#endif // LASER_X_NCC_TEMPLATE_H
