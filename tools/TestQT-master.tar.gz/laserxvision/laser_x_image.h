#ifndef LASER_X_IMAGE_H
#define LASER_X_IMAGE_H

#include <QtCore>
#include <opencv2/opencv.hpp>
#include "laser_x_vision_global.h"

class LASERXVISION_LIBRARY_EXPORT LaserXImage : public QObject
{
    Q_OBJECT

public:
    LaserXImage(QObject* parent) : QObject(parent) {}
    virtual ~LaserXImage() = default;

public:
    virtual QSize getSize() const = 0;
    virtual void writeImage(const QString& format, const qlonglong fillColor, const QString& fileName) const = 0;
    virtual LXImage reduceDomain(const LXRegion &region) const = 0;
    virtual bool copyCVMat(const cv::Mat& mat) = 0;
    virtual bool refCVMat(const cv::Mat &mat) = 0;
    virtual cv::Mat toCVMat() const = 0;
};

#define LaserXImageInterfaceIID "net.laserx.ImageInterface"
Q_DECLARE_INTERFACE(LaserXImage, LaserXImageInterfaceIID)

#endif // LASER_X_IMAGE_H
