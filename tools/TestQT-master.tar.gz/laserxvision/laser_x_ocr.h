#ifndef LASER_X_OCR_H
#define LASER_X_OCR_H

#include <QtCore>
#include "laser_x_vision_global.h"

class LASERXVISION_LIBRARY_EXPORT LaserXOCR : public QObject
{
    Q_OBJECT

public:
    LaserXOCR(QObject* parent) : QObject(parent) {}
    virtual ~LaserXOCR() = default;

public:
    virtual QByteArray getBlob() const = 0;
    virtual QVariantMap getParams() const = 0;
    virtual bool writeOCR(const QString &fileName) const = 0;
    virtual QVariantMap trainOCR(const QVariantMap& params) = 0;
    virtual QVariantMap doOcrSingleClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const = 0;
    virtual QVariantMap doOcrMultiClass(const LXImage& mat, const LXRegion& cRegion, const QVariantMap& params) const = 0;
};

#define LaserXOCRInterfaceIID "net.laserx.OCRInterface"
Q_DECLARE_INTERFACE(LaserXOCR, LaserXOCRInterfaceIID)

#endif // LASER_X_OCR_H
