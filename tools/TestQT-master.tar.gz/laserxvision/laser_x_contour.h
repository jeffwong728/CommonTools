#ifndef LASER_X_CONTOUR_H
#define LASER_X_CONTOUR_H

#include <QtCore>
#include "laser_x_vision_global.h"

class LASERXVISION_LIBRARY_EXPORT LaserXContour : public QObject
{
    Q_OBJECT

public:
    LaserXContour(QObject* parent) : QObject(parent) {}
    virtual ~LaserXContour() = default;

public:
    virtual void writeContour(const QString &fileName) const = 0;
};

#define LaserXContourInterfaceIID "net.laserx.ContourInterface"
Q_DECLARE_INTERFACE(LaserXContour, LaserXContourInterfaceIID)

#endif // LASER_X_CONTOUR_H
