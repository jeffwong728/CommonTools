#ifndef LASER_X_TEXT_MODEL_H
#define LASER_X_TEXT_MODEL_H

#include <QtCore>
#include "laser_x_vision_global.h"

class LASERXVISION_LIBRARY_EXPORT LaserXTextModel : public QObject
{
    Q_OBJECT

public:
    LaserXTextModel(QObject* parent) : QObject(parent) {}
    virtual ~LaserXTextModel() = default;

public:
    virtual void setParams(const QVariantMap& params) const = 0;
    virtual bool findText(const cv::Mat& mat, const LXRegion& region) = 0;
    virtual bool findText(const LXImage& mat, const LXRegion& region) = 0;
    virtual LXRegion getTextObject(const QVariantMap& params) = 0;
    virtual QVariantMap getTextResult(const QVariantMap& params) = 0;
    virtual void clearTextResult() = 0;
};

#define LaserXTextModelInterfaceIID "net.laserx.TextModelInterface"
Q_DECLARE_INTERFACE(LaserXTextModel, LaserXTextModelInterfaceIID)

#endif // LASER_X_TEXT_MODEL_H
