#ifndef LASER_X_VISION_GLOBAL_H
#define LASER_X_VISION_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(LASERXVISION_LIBRARY)
#define LASERXVISION_LIBRARY_EXPORT Q_DECL_EXPORT
#else
#define LASERXVISION_LIBRARY_EXPORT Q_DECL_IMPORT
#endif

class LaserXImage;
class LaserXRegion;
class LaserXContour;
class LaserXNCCTemplate;
class LaserXShapeTemplate;
class LaserXMeasureModel;
class LaserXOCR;
class LaserXTextModel;
using LXImage = QSharedPointer<LaserXImage>;
using LXRegion = QSharedPointer<LaserXRegion>;
using LXContour = QSharedPointer<LaserXContour>;
using LXNCCTemplate = QSharedPointer<LaserXNCCTemplate>;
using LXShapeTemplate = QSharedPointer<LaserXShapeTemplate>;
using LXMeasureModel = QSharedPointer<LaserXMeasureModel>;
using LXOCR = QSharedPointer<LaserXOCR>;
using LXTextModel = QSharedPointer<LaserXTextModel>;
using LXWMeasureModel = QWeakPointer<LaserXMeasureModel>;
using LXRegionList = QList<LXRegion>;
using LXContourList = QList<LXContour>;

#endif // LASER_X_VISION_GLOBAL_H
