#ifndef LASER_X_MEASURE_MODEL_H
#define LASER_X_MEASURE_MODEL_H

#include <QtCore>
#include <opencv2/opencv.hpp>
#include "laser_x_vision_global.h"

class LASERXVISION_LIBRARY_EXPORT LaserXMeasureModel : public QObject
{
    Q_OBJECT

public:
    LaserXMeasureModel(QObject* parent) : QObject(parent) {}
    virtual ~LaserXMeasureModel() = default;

public:
    virtual QByteArray getBlob() const = 0;
    virtual void writeMeasureModel(const QString &fileName) const = 0;
    virtual void setModelImageSize(const QSize& size) = 0;
    virtual void setReferenceSystem(const QPointF &origin, const qreal angle) = 0;
    virtual void alignModel(const QPointF& origin, const qreal angle) = 0;
    virtual QVariant addLineMeasure(const QVariantMap& params) = 0;
    virtual QVariant addCircleMeasure(const QVariantMap& params) = 0;
    virtual QVariant addRectangle2Measure(const QVariantMap& params) = 0;
    virtual QVariant addEllipseMeasure(const QVariantMap& params) = 0;
    virtual void clearMeasure(const QVariant& index) = 0;
    virtual void applyMeasure(const cv::Mat& mat) const = 0;
    virtual qlonglong getNumInstances(const QVariant& index) const = 0;
    virtual QVariantList getMeasureIndices() const = 0;
    virtual QVariant getMeasureType(const QVariant &index) const = 0;
    virtual QVariantMap getAllBoxEdges(const QVariant& index) const = 0;
    virtual QVariantMap getMeasureResult(const QVariant& index, const QVariant& instance) const = 0;
    virtual QVariantMap getPostResult(const QJsonObject& rawObj, const QString& progPath, const QString& procName) const = 0;
};

#define LaserXMeasureModelInterfaceIID "net.laserx.MeasureModelInterface"
Q_DECLARE_INTERFACE(LaserXMeasureModel, LaserXMeasureModelInterfaceIID)

#endif // LASER_X_MEASURE_MODEL_H
