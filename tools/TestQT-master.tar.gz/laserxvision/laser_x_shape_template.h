#ifndef LASER_X_SHAPE_TEMPLATE_H
#define LASER_X_SHAPE_TEMPLATE_H

#include <QtCore>
#include <opencv2/opencv.hpp>
#include "laser_x_vision_global.h"

class LASERXVISION_LIBRARY_EXPORT LaserXShapeTemplate : public QObject
{
    Q_OBJECT

public:
    LaserXShapeTemplate(QObject* parent) : QObject(parent) {}
    virtual ~LaserXShapeTemplate() = default;

public:
    virtual QByteArray getBlob() const = 0;
    virtual void writeShapeTemplate(const QString& fileName) const = 0;
    virtual QVariantMap findTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const = 0;
    virtual QVariantMap findTemplates(const std::vector<LXShapeTemplate> &templates, const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const = 0;
};

#define LaserXShapeTemplateInterfaceIID "net.laserx.ShapeTemplateInterface"
Q_DECLARE_INTERFACE(LaserXShapeTemplate, LaserXShapeTemplateInterfaceIID)

#endif // LASER_X_SHAPE_TEMPLATE_H
