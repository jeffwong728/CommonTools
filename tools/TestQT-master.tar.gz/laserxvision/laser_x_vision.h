#ifndef LASER_X_VISION_H
#define LASER_X_VISION_H

#include <QtCore>
#include <QtGui>
#include "laser_x_vision_global.h"
#include "laser_x_image.h"
#include "laser_x_region.h"
#include "laser_x_ncc_template.h"
#include "laser_x_shape_template.h"
#include "laser_x_measure_model.h"
#include "laser_x_text_model.h"
#include "laser_x_ocr.h"

class LASERXVISION_LIBRARY_EXPORT LaserXVisionManager : public QObject
{
    Q_OBJECT;
public:
    virtual ~LaserXVisionManager() = default;

public:
    static QPainterPath getPath(const QJsonObject& object);

public:
    virtual LXImage readImage(const QString & fileName) const = 0;
    virtual LXImage fromCVMat(const cv::Mat &mat, const bool deepCopy = true) const = 0;
    virtual LXImage fromQImage(const QImage& image, const bool deepCopy = true) const = 0;
    virtual LXRegion genRegion(const QJsonObject &object) const = 0;
    virtual LXRegion genRectangle1(const QRectF &rect) const = 0;
    virtual LXRegion genRectangle2(const QRectF &rect, const qreal phi) const = 0;
    virtual LXRegion genCircle(const QPointF &center, const qreal radius) const = 0;
    virtual LXRegion genRegionPolygonFilled(const QPolygonF &polygon) const = 0;
    virtual LXRegion threshold(const cv::Mat& mat, const double minGray, const double maxGray) const = 0;
    virtual LXNCCTemplate readNccTemplate(const QByteArray &blob) const = 0;
    virtual LXNCCTemplate createNccTemplate(const cv::Mat& mat, const LXRegion &region, const QVariantMap & params) const = 0;
    virtual LXShapeTemplate readShapeTemplate(const QByteArray& blob) const = 0;
    virtual LXShapeTemplate createShapeTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const  = 0;
    virtual LXRegionList inspectShapeTemplate(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const = 0;
    virtual LXMeasureModel readMeasureModel(const QByteArray& blob) const = 0;
    virtual LXMeasureModel createMeasureModel(const QVariantMap& params) const = 0;
    virtual LXOCR createOCR(const QVariantMap& params) const = 0;
    virtual LXOCR readOCR(const QByteArray& blob, const QVariantMap& params) const = 0;
    virtual LXOCR readOCR(const QString& fileName, const QVariantMap& params) const = 0;
    virtual LXTextModel createTextModelReader(const QVariantMap& params) const = 0;
    virtual QVariantMap applyDeepOcr(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const = 0;
    virtual QVariantMap applyDeepOcr(const LXImage& mat, const LXRegion& region, const QVariantMap& params) const = 0;
    virtual QVariantMap vectorAngleToAffine(const QPointF& rOrigin, const qreal rAngle, const QPointF& aOrigin, const qreal aAngle) const = 0;
    virtual bool saveImagePart(const cv::Mat& mat, const QString& fileName, const QRectF& rectPart) const = 0;
    virtual LXImage rotateImage(const cv::Mat& mat, const qreal phi) const = 0;
    virtual LXImage alignImage(const cv::Mat& mat, const QPointF& rOrigin, const qreal rAngle, const QPointF& aOrigin, const qreal aAngle) const = 0;
    virtual QVariantMap doBlobAnalysis(const cv::Mat& mat, const LXRegion& region, const QVariantMap& params) const = 0;
    virtual QVariantMap segmentOCRSample(const QVariantMap& params) const = 0;
    virtual QVariantMap appendOCRSample(const QVariantMap& params) const = 0;
    virtual QVariantMap replaceOCRSamples(const QVariantMap& params) const = 0;
    virtual QVariantMap readOCRCharacters(const QVariantMap& params) const = 0;
    virtual QVariantMap packOCRSamples(const QVariantMap& params) const = 0;
};

#define LaserXVisionManagerInterfaceIID "net.laserx.VisionManagerInterface"
Q_DECLARE_INTERFACE(LaserXVisionManager, LaserXVisionManagerInterfaceIID)

#endif // LASER_X_VISION_H
