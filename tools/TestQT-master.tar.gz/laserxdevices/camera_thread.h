#ifndef CAMERA_THREAD_H
#define CAMERA_THREAD_H
#include <QtCore>
class LaserXDeviceManager;

class CameraThread : public QThread
{
    Q_OBJECT
public:
    CameraThread(LaserXDeviceManager* parent);

protected:
    void run() override;

private:
    LaserXDeviceManager* const devManager;
    int mLiveIndex = 0;
};

#endif // CAMERA_THREAD_H
