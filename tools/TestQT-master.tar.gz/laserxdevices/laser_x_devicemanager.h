#ifndef LASER_X_DEVICEMANAGER_H
#define LASER_X_DEVICEMANAGER_H
#include "laser_x_devices_global.h"
#include "laser_x_motion.h"
#include "laser_x_camera.h"
#include "laser_x_led_controller.h"
#include "laser_x_lens_controller.h"
#include <QObject>
#include <QTimer>
#include <QSerialPort>
#include <QtNetwork>
class RunPage;
class LaserXSerialPort;
class LaserXNetSender;
class LaserXNetListener;

class LASERXDEVICES_LIBRARY_EXPORT LaserXDeviceManager : public QObject
{
    Q_OBJECT
public:
    explicit LaserXDeviceManager(QObject *parent = nullptr);
    ~LaserXDeviceManager();

public:
    LaserXSerialPort* newSerialPort();
    LaserXSerialPort* newSerialPort(const QString& uuid);

    LaserXNetListener* newNetListener();
    LaserXNetListener* newNetListener(const QString& uuid);

    LaserXNetSender* newNetSender();
    LaserXNetSender* newNetSender(const QString& uuid);

    LaserXLEDController* newLEDController(const QString& type, const qlonglong numChannels);
    LaserXLEDController* newLEDController(const QString& type, const qlonglong numChannels, const QString& uuid);

    LaserXLensController* newLensController(const QString& type);
    LaserXLensController* newLensController(const QString& type, const QString& uuid);

    void closeAllDevices();
    void loadCameraPlugins(const QString& jsonPlugins);
    void loadMotionPlugins(const QString& jsonPlugins);

public:
    QVector<LaserXCamera*> cameras() const;
    QVector<LaserXMotionDevice*> motionDevices() const;
    QVector<LaserXSerialPort*> serialPorts() const { return mSerialPorts; }
    QVector<LaserXNetListener*> netListeners() const { return mNetListeners; }
    QVector<LaserXNetSender*> netSenders() const { return mNetSenders; }
    QVector<LaserXLEDController*> ledControllers() const { return mLEDControllers; }
    QVector<LaserXLensController*> lensControllers() const { return mLensControllers; }

    void addSerialPort(LaserXSerialPort* comPort);
    void addSerialPorts(const QVector<LaserXSerialPort*> &serialPorts);
    void removeSerialPort(LaserXSerialPort* comPort);

    void addNetListener(LaserXNetListener* netListener);
    void removeNetListener(LaserXNetListener* netListener);

    void addNetSender(LaserXNetSender* netSender);
    void removeNetSender(LaserXNetSender* netSender);

    void addLEDController(LaserXLEDController* ledController);
    void removeLEDController(LaserXLEDController* ledController);

    void addLensController(LaserXLensController* lensController);
    void removeLensController(LaserXLensController* lensController);

    QVector<LaserXCameraManager*> getCameraManagers() const { return mCameraManagers; }
    LaserXCameraManager* getCameraManager(const QString &typeName) const;

    QVector<LaserXMotionManager*> motionManagers() const { return mMotionManagers; }
    LaserXMotionManager* findMotionManager(const QString& typeName) const;

    LaserXCamera* findCamera(const QString& uuid) const;
    LaserXMotionDevice* findMotionDevice(const QString& uuid) const;
    LaserXMotionAxis* findMotionAxis(const QString &uuid) const;
    LaserXNetListener* findNetListener(const QString& uuid) const;
    LaserXNetSender* findNetSender(const QString &uuid) const;
    LaserXSerialPort* findSerialPort(const QString& uuid) const;
    LaserXSerialPort* findSerialPortByName(const QString& name) const;
    LaserXLEDController* findLEDController(const QString& uuid) const;
    LaserXLensController* findLensController(const QString& uuid) const;

    void stopLiveAllCameras();

signals:
    void serialPortCreated(LaserXSerialPort* comPort);
    void serialPortAdded(LaserXSerialPort* comPort);
    void serialPortAboutToDelete(LaserXSerialPort* comPort);

    void netListenerCreated(LaserXNetListener* netListener);
    void netListenerAdded(LaserXNetListener* netListener);
    void netListenerAboutToDelete(LaserXNetListener* netListener);

    void netSenderCreated(LaserXNetSender* netSender);
    void netSenderAdded(LaserXNetSender* netSender);
    void netSenderAboutToDelete(LaserXNetSender* netSender);

    void ledControllerCreated(LaserXLEDController *ledController);
    void ledControllerAdded(LaserXLEDController* ledController);
    void ledControllerAboutToDelete(LaserXLEDController* ledController);

    void lensControllerCreated(LaserXLensController* lensController);
    void lensControllerAdded(LaserXLensController* lensController);
    void lensControllerAboutToDelete(LaserXLensController* lensController);

public:
    void onTimeout();
    void onSerialPortError(QSerialPort::SerialPortError error);
    void onImageConsumed();
    void onStartCameraLive();
    void onStopCameraLive();

private:
    Q_DISABLE_COPY_MOVE(LaserXDeviceManager)

public:
    QThread* mCameraThread = nullptr;
    QAtomicInt mLivePending;
    QMutex mCameraMutex;
    QWaitCondition mCameraLiveStarted;
    QVector<LaserXCamera*> mLiveCameras;

private:
    QVector<LaserXSerialPort*> mSerialPorts;
    QVector<LaserXNetSender*> mNetSenders;
    QVector<LaserXNetListener*> mNetListeners;
    QVector<LaserXMotionManager*> mMotionManagers;
    QVector<LaserXCameraManager*> mCameraManagers;
    QVector<LaserXLEDController*> mLEDControllers;
    QVector<LaserXLensController*> mLensControllers;
    QTimer mTimer;
};

#endif // LASER_X_DEVICEMANAGER_H
