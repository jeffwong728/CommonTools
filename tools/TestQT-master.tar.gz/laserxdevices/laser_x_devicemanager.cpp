#include "laser_x_devicemanager.h"
#include "laser_x_serialport.h"
#include "laser_x_net_sender.h"
#include "laser_x_net_listener.h"
#include <ledcontroller/wordop_controller.h>
#include <lenscontroller/maz_controller.h>
#include <laser_x_util.h>
#include <QtCore>

LaserXDeviceManager::LaserXDeviceManager(QObject *parent)
    : QObject{parent}
{
    mTimer.setTimerType(Qt::VeryCoarseTimer);
    connect(&mTimer, &QTimer::timeout, this, &LaserXDeviceManager::onTimeout);
}

LaserXDeviceManager::~LaserXDeviceManager()
{
    closeAllDevices();

    for (LaserXCameraManager* camManager : mCameraManagers)
    {
        if (!camManager->terminate())
        {
            qCritical() << QStringLiteral("Terminate camera manager %1 failed").arg(camManager->getTypeName());
        }
    }
}

LaserXSerialPort* LaserXDeviceManager::newSerialPort()
{
    LaserXSerialPort *comPort = new LaserXSerialPort(this);
    emit serialPortCreated(comPort);
    return comPort;
}

LaserXSerialPort* LaserXDeviceManager::newSerialPort(const QString& uuid)
{
    LaserXSerialPort* comPort = new LaserXSerialPort(this, uuid);
    emit serialPortCreated(comPort);
    return comPort;
}

LaserXNetListener* LaserXDeviceManager::newNetListener()
{
    LaserXNetListener* netListener = new LaserXNetListener(this);
    emit netListenerCreated(netListener);
    return netListener;
}

LaserXNetListener* LaserXDeviceManager::newNetListener(const QString& uuid)
{
    LaserXNetListener* netListener = new LaserXNetListener(this, uuid);
    emit netListenerCreated(netListener);
    return netListener;
}

LaserXNetSender* LaserXDeviceManager::newNetSender()
{
    LaserXNetSender* netSender = new LaserXNetSender(this);
    emit netSenderCreated(netSender);
    return netSender;
}

LaserXNetSender* LaserXDeviceManager::newNetSender(const QString& uuid)
{
    LaserXNetSender* netSender = new LaserXNetSender(this, uuid);
    emit netSenderCreated(netSender);
    return netSender;
}

LaserXLEDController* LaserXDeviceManager::newLEDController(const QString& type, const qlonglong numChannels)
{
    if (QStringLiteral("Wordop") == type ||
        QStringLiteral("WordopController") == type)
    {
        LaserXLEDController* iLED = new WordopController(this, numChannels);
        emit ledControllerCreated(iLED);
        return iLED;
    }
    else
    {
        return nullptr;
    }
}

LaserXLEDController* LaserXDeviceManager::newLEDController(const QString& type, const qlonglong numChannels, const QString& uuid)
{
    if (QStringLiteral("Wordop") == type ||
        QStringLiteral("WordopController") == type)
    {
        LaserXLEDController* iLED = new WordopController(this, numChannels, uuid);
        emit ledControllerCreated(iLED);
        return iLED;
    }
    else
    {
        return nullptr;
    }
}

LaserXLensController* LaserXDeviceManager::newLensController(const QString& type)
{
    if (QStringLiteral("MAZ") == type ||
        QStringLiteral("MAZController") == type)
    {
        LaserXLensController* iLens = new MAZController(this);
        emit lensControllerCreated(iLens);
        return iLens;
    }
    else
    {
        return nullptr;
    }
}

LaserXLensController* LaserXDeviceManager::newLensController(const QString& type, const QString& uuid)
{
    if (QStringLiteral("MAZ") == type ||
        QStringLiteral("MAZController") == type)
    {
        LaserXLensController* iLens = new MAZController(this, uuid);
        emit lensControllerCreated(iLens);
        return iLens;
    }
    else
    {
        return nullptr;
    }
}

void LaserXDeviceManager::loadCameraPlugins(const QString& jsonPlugins)
{
    QStringList pluginList;
    pluginList << QStringLiteral("laserxfilecamera");
    pluginList << QStringLiteral("laserxfoldercamera");
    pluginList << QStringLiteral("laserxvideocamera");

    QJsonParseError jsonError;
    QByteArray jsonData = jsonPlugins.toUtf8();
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError == jsonError.error)
    {
        const QJsonObject jsonObj = loadDoc.object();
        pluginList.append(fromJson(jsonObj, QLatin1String("CameraPlugins"), QStringList()));
    }
    else
    {
        qCritical() << jsonError.errorString();
    }

    QDir pluginsDir = QDir(QCoreApplication::applicationDirPath());
    pluginsDir.cd(QStringLiteral("plugins"));
    pluginsDir.cd(QStringLiteral("cameras"));

    for (const QString& fileName : pluginList)
    {
        QPluginLoader loader(pluginsDir.absoluteFilePath(fileName));
        QObject* plugin = loader.instance();
        LaserXCameraManager* iCamManager = qobject_cast<LaserXCameraManager*>(plugin);
        if (iCamManager)
        {
            if (iCamManager->initialize())
            {
                mCameraManagers << iCamManager;
            }
            else
            {
                qCritical() << QStringLiteral("Initialize camera manager %1 failed").arg(iCamManager->getTypeName());
            }
        }
    }
}

void LaserXDeviceManager::closeAllDevices()
{
    for (LaserXSerialPort* comPort : mSerialPorts)
    {
        comPort->close();
    }

    for (LaserXNetListener* networkListener : mNetListeners)
    {
        networkListener->closeAllConnections();
        networkListener->close();
    }

    for (LaserXCameraManager* camManager : mCameraManagers)
    {
        QVector<LaserXCamera*> cams = camManager->getCameras();
        for (LaserXCamera* cam : cams)
        {
            cam->close();
            cam->deleteLater();
        }
    }
}

QVector<LaserXCamera*> LaserXDeviceManager::cameras() const
{
    QVector<LaserXCamera*> allCams;
    for (LaserXCameraManager* camManager : mCameraManagers)
    {
        QVector<LaserXCamera*> cams = camManager->getCameras();
        allCams.append(cams);
    }

    return allCams;
}

void LaserXDeviceManager::addSerialPort(LaserXSerialPort* comPort)
{
    if (comPort)
    {
        auto it = std::find_if(mSerialPorts.begin(), mSerialPorts.end(), [comPort](LaserXSerialPort* item) { return item->getUUID() == comPort->getUUID(); });
        if (it == mSerialPorts.end())
        {
            mSerialPorts.push_back(comPort);
            emit serialPortAdded(comPort);
            connect(comPort, &QSerialPort::errorOccurred, this, &LaserXDeviceManager::onSerialPortError);
            onSerialPortError(comPort->error());
        }
    }
}

void LaserXDeviceManager::addSerialPorts(const QVector<LaserXSerialPort*>& serialPorts)
{
    for (LaserXSerialPort* comPort : serialPorts)
    {
        addSerialPort(comPort);
    }
}

void LaserXDeviceManager::removeSerialPort(LaserXSerialPort* comPort)
{
    if (comPort)
    {
        auto it = std::find_if(mSerialPorts.begin(), mSerialPorts.end(), [comPort](LaserXSerialPort* item) { return item->getUUID() == comPort->getUUID(); });
        if (it != mSerialPorts.end())
        {
            mSerialPorts.erase(it);
        }
        emit serialPortAboutToDelete(comPort);
    }
}

void LaserXDeviceManager::addNetListener(LaserXNetListener* netListener)
{
    if (netListener)
    {
        auto it = std::find_if(mNetListeners.begin(), mNetListeners.end(), [netListener](LaserXNetListener* item) { return item->uuid() == netListener->uuid(); });
        if (it == mNetListeners.end())
        {
            mNetListeners.push_back(netListener);
            emit netListenerAdded(netListener);
        }
    }
}

void LaserXDeviceManager::removeNetListener(LaserXNetListener* netListener)
{
    if (netListener)
    {
        auto it = std::find_if(mNetListeners.begin(), mNetListeners.end(), [netListener](LaserXNetListener* item) { return item->uuid() == netListener->uuid(); });
        if (it != mNetListeners.end())
        {
            emit netListenerAboutToDelete(netListener);
            mNetListeners.erase(it);
        }
    }
}

void LaserXDeviceManager::addNetSender(LaserXNetSender* netSender)
{
    if (netSender)
    {
        auto it = std::find_if(mNetSenders.begin(), mNetSenders.end(), [netSender](LaserXNetSender* item) { return item->uuid() == netSender->uuid(); });
        if (it == mNetSenders.end())
        {
            mNetSenders.push_back(netSender);
            emit netSenderAdded(netSender);
        }
    }
}

void LaserXDeviceManager::addLEDController(LaserXLEDController* ledController)
{
    if (ledController)
    {
        auto it = std::find_if(mLEDControllers.begin(), mLEDControllers.end(), [ledController](LaserXLEDController* item) { return item->uuid() == ledController->uuid(); });
        if (it == mLEDControllers.end())
        {
            mLEDControllers.push_back(ledController);
            emit ledControllerAdded(ledController);
        }
    }
}

void LaserXDeviceManager::removeLEDController(LaserXLEDController* ledController)
{
    if (ledController)
    {
        auto it = std::find_if(mLEDControllers.begin(), mLEDControllers.end(), [ledController](LaserXLEDController* item) { return item->uuid() == ledController->uuid(); });
        if (it != mLEDControllers.end())
        {
            emit ledControllerAboutToDelete(ledController);
            mLEDControllers.erase(it);
        }
    }
}

void LaserXDeviceManager::addLensController(LaserXLensController* lensController)
{
    if (lensController)
    {
        auto it = std::find_if(mLensControllers.begin(), mLensControllers.end(), [lensController](LaserXLensController* item) { return item->uuid() == lensController->uuid(); });
        if (it == mLensControllers.end())
        {
            mLensControllers.push_back(lensController);
            emit lensControllerAdded(lensController);
        }
    }
}

void LaserXDeviceManager::removeLensController(LaserXLensController* lensController)
{
    if (lensController)
    {
        auto it = std::find_if(mLensControllers.begin(), mLensControllers.end(), [lensController](LaserXLensController* item) { return item->uuid() == lensController->uuid(); });
        if (it != mLensControllers.end())
        {
            emit lensControllerAboutToDelete(lensController);
            mLensControllers.erase(it);
        }
    }
}

void LaserXDeviceManager::removeNetSender(LaserXNetSender* netSender)
{
    if (netSender)
    {
        auto it = std::find_if(mNetSenders.begin(), mNetSenders.end(), [netSender](LaserXNetSender* item) { return item->uuid() == netSender->uuid(); });
        if (it != mNetSenders.end())
        {
            emit netSenderAboutToDelete(netSender);
            mNetSenders.erase(it);
        }
    }
}

LaserXCameraManager* LaserXDeviceManager::getCameraManager(const QString& typeName) const
{
    for (LaserXCameraManager* camManager : mCameraManagers)
    {
        if (camManager->getTypeName() == typeName)
        {
            return camManager;
        }
    }
    return nullptr;
}

LaserXCamera* LaserXDeviceManager::findCamera(const QString &uuid) const
{
    for (LaserXCameraManager* camManager : mCameraManagers)
    {
        QVector<LaserXCamera*> cams  = camManager->getCameras();
        for (LaserXCamera* cam : cams)
        {
            if (cam->getUUID() == uuid)
            {
                return cam;
            }
        }
    }
    return nullptr;
}

LaserXNetListener* LaserXDeviceManager::findNetListener(const QString& uuid) const
{
    auto it = std::find_if(mNetListeners.begin(), mNetListeners.end(), [uuid](LaserXNetListener* item) { return item->uuid() == uuid; });
    if (it != mNetListeners.end())
    {
        return *it;
    }
    else
    {
        return nullptr;
    }
}

LaserXNetSender* LaserXDeviceManager::findNetSender(const QString& uuid) const
{
    auto it = std::find_if(mNetSenders.begin(), mNetSenders.end(), [uuid](LaserXNetSender* item) { return item->uuid() == uuid; });
    if (it != mNetSenders.end())
    {
        return *it;
    }
    else
    {
        return nullptr;
    }
}

LaserXSerialPort* LaserXDeviceManager::findSerialPort(const QString& uuid) const
{
    auto it = std::find_if(mSerialPorts.begin(), mSerialPorts.end(), [uuid](LaserXSerialPort* item) { return item->getUUID() == uuid; });
    if (it != mSerialPorts.end())
    {
        return *it;
    }
    else
    {
        return nullptr;
    }
}

LaserXSerialPort* LaserXDeviceManager::findSerialPortByName(const QString& name) const
{
    auto it = std::find_if(mSerialPorts.begin(), mSerialPorts.end(), [name](LaserXSerialPort* item) { return item->portName() == name; });
    if (it != mSerialPorts.end())
    {
        return *it;
    }
    else
    {
        return nullptr;
    }
}

LaserXLEDController* LaserXDeviceManager::findLEDController(const QString& uuid) const
{
    auto it = std::find_if(mLEDControllers.begin(), mLEDControllers.end(), [uuid](LaserXLEDController* item) { return item->uuid() == uuid; });
    if (it != mLEDControllers.end())
    {
        return *it;
    }
    else
    {
        return nullptr;
    }
}

LaserXLensController* LaserXDeviceManager::findLensController(const QString& uuid) const
{
    auto it = std::find_if(mLensControllers.begin(), mLensControllers.end(), [uuid](LaserXLensController* item) { return item->uuid() == uuid; });
    if (it != mLensControllers.end())
    {
        return *it;
    }
    else
    {
        return nullptr;
    }
}

void LaserXDeviceManager::stopLiveAllCameras()
{
    QVector<LaserXCamera*> iCams = cameras();
    for (LaserXCamera* iCam : iCams)
    {
        iCam->stopContinuousGrab();
    }
}

void LaserXDeviceManager::onTimeout()
{
    bool rSuccess = true;
    for (LaserXSerialPort* comPort : mSerialPorts)
    {
        rSuccess = comPort->recovery() && rSuccess;
    }

    if (rSuccess)
    {
        mTimer.stop();
    }

    qDebug() << Q_FUNC_INFO;
}

void LaserXDeviceManager::onSerialPortError(QSerialPort::SerialPortError error)
{
    if (QSerialPort::PermissionError == error ||
        QSerialPort::ResourceError == error ||
        QSerialPort::DeviceNotFoundError == error ||
        QSerialPort::NotOpenError == error ||
        QSerialPort::OpenError == error)
    {
        if (!mTimer.isActive())
        {
            mTimer.start(3000);
        }
    }
}
