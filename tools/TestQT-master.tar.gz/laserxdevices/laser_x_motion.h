#ifndef LASER_X_MOTION_H
#define LASER_X_MOTION_H

#include "laser_x_devices_global.h"
#include <QtCore>
#include <QtWidgets>
class LaserXMotionAxis;
class LaserXMotionDevice;
class LaserXMotionManager;

enum MotionError
{
    NoMotionError,
    OpenMotionDeviceError,
    MotionDeviceNotFoundError,
    AccessMotionDeviceDeniedError,
    MotionDeviceDisconnectError,
    UnsupportedMotionOperationError,
    MotionTimeoutError,
    MotionDeviceNotOpenError,
    MotionReadParameterError,
    MotionWriteParameterError,
    UnknownMotionError
};

class LASERXDEVICES_LIBRARY_EXPORT LaserXMotionAxis : public QObject
{
    Q_OBJECT
public:
    LaserXMotionAxis(QObject *parent, const int axisNo);
    virtual ~LaserXMotionAxis() = default;

public:
    QString uuid() const;
    int axisNo() const;
    LaserXMotionDevice *device() const;
    QString name() const;
    void setName(const QString& nName);
    QString description() const;
    void setDescription(const QString& nDescription);

public:
    virtual bool enabled() const = 0;
    virtual QVariantMap setEnabled(const bool bEnabled) const = 0;

    virtual QVariantMap motorState() const = 0;
    virtual qreal actualPosition() const = 0;
    virtual qreal commandPosition() const = 0;
    virtual qreal actualVelocity() const = 0;
    virtual qreal positionError() const = 0;
    virtual qreal encoderFactor() const = 0;
    virtual qreal encoderOffset() const = 0;
    virtual qreal velocity() const = 0;
    virtual qreal acceleration() const = 0;
    virtual qreal deceleration() const = 0;
    virtual qreal killDeceleration() const = 0;
    virtual qreal jerk() const = 0;

    virtual void setVelocity(const qreal val) = 0;
    virtual void setAcceleration(const qreal val) = 0;
    virtual void setDeceleration(const qreal val) = 0;
    virtual void setKillDeceleration(const qreal val) = 0;
    virtual void setJerk(const qreal val) = 0;

    virtual void moveTo(const qreal pos) = 0;
    virtual void moveMinus(const qreal distance) = 0;
    virtual void movePlus(const qreal distance) = 0;
    virtual void jogMinus(const qreal velocity) = 0;
    virtual void jogPlus(const qreal velocity) = 0;
    virtual void halt() = 0;

protected:
    const int mAxisNo;
};

class LASERXDEVICES_LIBRARY_EXPORT LaserXMotionDevice : public QObject
{
    Q_OBJECT
    friend class LaserXMotionAxis;
public:
    LaserXMotionDevice(QObject* parent, const int numAxis);
    LaserXMotionDevice(QObject *parent, const QString &uuid);
    virtual ~LaserXMotionDevice() = default;

public:
    QString uuid() const;
    LaserXMotionManager *manager() const;
    QString name() const;
    void setName(const QString& nName);
    QString description() const;
    void setDescription(const QString &nDescription);

public:
    virtual bool open(const QVariantMap& params) = 0;
    virtual bool close() = 0;
    virtual bool isOpened() const = 0;
    virtual int countAxis() const = 0;
    virtual LaserXMotionAxis* axis(const int axisNo) const = 0;
    virtual LaserXMotionAxis* axis(const QString &axisUUID) const = 0;
    virtual QList<bool> enabledAll() const = 0;
    virtual QVariantMap setEnabledAll(const bool bEnabled) const = 0;

    virtual QVariantMap getParameters() const;
    virtual bool setParameters(const QVariantMap& params);

protected:
    QString axisUuid(const int axisNo) const;
    QString axisName(const int axisNo) const;
    QString axisDescription(const int axisNo) const;
    void setAxisName(const int axisNo, const QString& nName);
    void setAxisDescription(const int axisNo, const QString& nDescription);

signals:
    void motionDeviceOpened();
    void motionDeviceClosed();
    void motionDeviceErrorOccurred(const QVariantMap& params) const;
    void motionDeviceParameterChanged(const QVariantMap& params) const;

protected:
    QString mName;
    QString mDescription;
    const QString mUUID;
    QStringList mAxisNames;
    QStringList mAxisDescriptions;
    const QStringList mAxisUUIDs;
};

#define LaserXMotionDeviceInterfaceIID "net.laserx.MotionDeviceInterface"
Q_DECLARE_INTERFACE(LaserXMotionDevice, LaserXMotionDeviceInterfaceIID)

class LASERXDEVICES_LIBRARY_EXPORT LaserXAddMotionDeviceWidget : public QWidget
{
    Q_OBJECT
public:
    LaserXAddMotionDeviceWidget(QWidget* parent);
    virtual ~LaserXAddMotionDeviceWidget() = default;

public:
    virtual void initialize(const QVariantMap& params);
    virtual int countMotionDevices() const;
    virtual void closeAllMotionDevices();
    virtual QVariantMap getParameters() const;
};

class LASERXDEVICES_LIBRARY_EXPORT LaserXConfigMotionAxisWidget : public QWidget
{
    Q_OBJECT
public:
    LaserXConfigMotionAxisWidget(QWidget* parent);
    virtual ~LaserXConfigMotionAxisWidget() = default;

public:
    virtual void initialize(LaserXMotionAxis* axis);
    virtual QVariantMap getParameters() const;
};

class LASERXDEVICES_LIBRARY_EXPORT LaserXConfigMotionDeviceWidget : public QWidget
{
    Q_OBJECT
public:
    LaserXConfigMotionDeviceWidget(QWidget* parent);
    virtual ~LaserXConfigMotionDeviceWidget() = default;

public:
    virtual void initialize(LaserXMotionDevice *device);
    virtual QVariantMap getParameters() const;
};

class LASERXDEVICES_LIBRARY_EXPORT LaserXMotionManager : public QObject
{
    Q_OBJECT;
public:
    virtual ~LaserXMotionManager() = default;

public:
    virtual bool initialize();
    virtual bool terminate();
    virtual QString typeName() = 0;
    virtual int numMotionDevices() = 0;
    virtual QList<LaserXMotionDevice*> motionDevices() = 0;
    virtual LaserXMotionDevice* createMotionDevice(const QVariantMap& params) = 0;
    virtual LaserXMotionDevice* findMotionDevice(const QVariantMap& params) const = 0;
    virtual bool addMotionDevice(LaserXMotionDevice* device) = 0;
    virtual void deleteMotionDevice(LaserXMotionDevice* device) = 0;
    virtual LaserXAddMotionDeviceWidget* getAddMotionDeviceWidget(QWidget* parent) = 0;
    virtual LaserXConfigMotionDeviceWidget* getConfigMotionDeviceWidget(QWidget* parent) = 0;
    virtual LaserXConfigMotionAxisWidget* getConfigMotionAxisWidget(QWidget* parent) = 0;

signals:
    void motionDeviceCreated(LaserXMotionDevice* device);
    void motionDeviceAdded(LaserXMotionDevice* device);
    void motionDeviceAboutToDelete(LaserXMotionDevice* device);
};

#define LaserXMotionManagerInterfaceIID "net.laserx.MotionManagerInterface"
Q_DECLARE_INTERFACE(LaserXMotionManager, LaserXMotionManagerInterfaceIID)

#endif // LASER_X_MOTION_H
