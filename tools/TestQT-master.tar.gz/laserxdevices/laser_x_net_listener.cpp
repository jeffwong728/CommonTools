#include "laser_x_net_listener.h"
#include <QtCore>
#include <laser_x_util.h>

LaserXNetListener::LaserXNetListener(QObject* parent)
    : LaserXNetListener(parent, QUuid::createUuid().toString())
{
}

LaserXNetListener::LaserXNetListener(QObject* parent, const QString& uuid)
    : QTcpServer(parent)
    , mUUID(uuid)
    , mPort(0)
{
}

bool LaserXNetListener::startListen()
{
    if (isListening())
    {
        return true;
    }

    bool ok = listen(mAddress, mPort);
    if (ok)
    {
        connect(this, &QTcpServer::newConnection, this, &LaserXNetListener::onNewConnection);
        emit listeningStarted(true);
        return true;
    }
    else
    {
        close();
        emit listeningStarted(false);
        return false;
    }
}

void LaserXNetListener::stopListen()
{
    if (isListening())
    {
        close();
        emit listeningStoped();
    }
}

void LaserXNetListener::closeAllConnections()
{
    for (auto clientConnection : mConnections)
    {
        clientConnection->abort();
        clientConnection->disconnectFromHost();
    }
}

LaserXNetListener::~LaserXNetListener()
{
}

QString LaserXNetListener::uuid() const
{
    return mUUID;
}

QString LaserXNetListener::name() const
{
    return mName;
}

void LaserXNetListener::setName(const QString& newName)
{
    if (newName != mName)
    {
        QString oldName = mName;
        mName = newName;
        emit nameChanged(oldName, newName);
    }
}

QHostAddress LaserXNetListener::address() const
{
    return mAddress;
}

void LaserXNetListener::setAddress(const QHostAddress &newAddress)
{
    if (newAddress != mAddress)
    {
        QHostAddress oldAddress = mAddress;
        mAddress = newAddress;
        emit addressChanged(oldAddress, newAddress);
    }
}

quint16 LaserXNetListener::port() const
{
    return mPort;
}

void LaserXNetListener::setPort(const quint16 newPort)
{
    if (newPort != mPort)
    {
        quint16 oldPort = mPort;
        mPort = newPort;
        emit portChanged(oldPort, newPort);
    }
}

QString LaserXNetListener::getJson() const
{
    QJsonObject rootObj;
    rootObj[QLatin1String("Name")] = mName;
    rootObj[QLatin1String("Address")] = mAddress.toString();
    rootObj[QLatin1String("Port")] = mPort;

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void LaserXNetListener::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    mName = fromJson(jsonObj, QLatin1String("Name"), QString());
    mAddress = QHostAddress(fromJson(jsonObj, QLatin1String("Address"), QStringLiteral("")));
    mPort = static_cast<quint16>(fromJson(jsonObj, QLatin1String("Port"), 0));
}

void LaserXNetListener::onNewConnection()
{
    QTcpSocket* clientConnection = nextPendingConnection();
    if (clientConnection)
    {
        mConnections.push_back(clientConnection);
        emit connectionAdded(clientConnection);
        connect(clientConnection, &QAbstractSocket::disconnected, clientConnection, &QObject::deleteLater);
        connect(clientConnection, &QAbstractSocket::disconnected, this, &LaserXNetListener::onDisconnected);
        connect(clientConnection, &QIODevice::readyRead, this, &LaserXNetListener::onReadyRead);
        connect(clientConnection, &QAbstractSocket::errorOccurred, this, &LaserXNetListener::onErrorOccurred);
    }
}

void LaserXNetListener::onDisconnected()
{
    QTcpSocket* clientConnection = qobject_cast<QTcpSocket*>(sender());
    if (clientConnection)
    {
        emit connectionAboutToDelete(clientConnection);
        auto it = std::find(mConnections.begin(), mConnections.end(), clientConnection);
        if (it != mConnections.end())
        {
            mConnections.erase(it);
        }
    }
}

void LaserXNetListener::onReadyRead()
{
    QTcpSocket* clientConnection = qobject_cast<QTcpSocket*>(sender());
    if (!clientConnection)
    {
        return;
    }

    QByteArray cmdData;
    if (clientConnection->canReadLine())
    {
        cmdData = clientConnection->readLine();
    }
    else
    {
        cmdData = clientConnection->readAll();
    }

    QJsonParseError jsonError;
    QJsonDocument cmdDoc = QJsonDocument::fromJson(cmdData, &jsonError);
    if (QJsonParseError::NoError == jsonError.error)
    {
        emit jsonReceived(clientConnection, cmdDoc);
    }
    else
    {
        QString iString = QString::fromUtf8(cmdData);
        if (!iString.isEmpty())
        {
            emit stringReceived(clientConnection, iString.trimmed());
        }
        else
        {
            emit bytesReceived(clientConnection, cmdData);
        }
    }
}

void LaserXNetListener::onErrorOccurred(QAbstractSocket::SocketError socketError)
{
    QTcpSocket* clientConnection = qobject_cast<QTcpSocket*>(sender());
    if (clientConnection && clientConnection->bytesAvailable())
    {
        clientConnection->readAll();
    }
    emit connectionErrorOccurred(clientConnection, socketError);
}
