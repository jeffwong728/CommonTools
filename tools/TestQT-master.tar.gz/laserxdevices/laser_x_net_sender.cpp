#include "laser_x_net_sender.h"
#include <QtCore>
#include <laser_x_util.h>

LaserXNetSender::LaserXNetSender(QObject* parent)
    : LaserXNetSender(parent, QUuid::createUuid().toString())
{
}

LaserXNetSender::LaserXNetSender(QObject* parent, const QString& uuid)
    : QTcpSocket(parent)
    , mUUID(uuid)
    , mPort(0)
{
}

LaserXNetSender::~LaserXNetSender()
{
}

bool LaserXNetSender::connectWithWait()
{
    connectToHost(mAddress, mPort);
    return waitForConnected(mConnectWaitMsecs);
}

bool LaserXNetSender::disconnectWithWait()
{
    disconnectFromHost();
    return waitForConnected(mConnectWaitMsecs);
}

QString LaserXNetSender::uuid() const
{
    return mUUID;
}

QString LaserXNetSender::name() const
{
    return mName;
}

void LaserXNetSender::setName(const QString& newName)
{
    if (newName != mName)
    {
        QString oldName = mName;
        mName = newName;
        emit nameChanged(oldName, newName);
    }
}

QHostAddress LaserXNetSender::address() const
{
    return mAddress;
}

void LaserXNetSender::setAddress(const QHostAddress &newAddress)
{
    if (newAddress != mAddress)
    {
        QHostAddress oldAddress = mAddress;
        mAddress = newAddress;
        emit addressChanged(oldAddress, newAddress);
    }
}

quint16 LaserXNetSender::port() const
{
    return mPort;
}

void LaserXNetSender::setPort(const quint16 newPort)
{
    if (newPort != mPort)
    {
        quint16 oldPort = mPort;
        mPort = newPort;
        emit portChanged(oldPort, newPort);
    }
}

int LaserXNetSender::connectWaitMsecs() const
{
    return mConnectWaitMsecs;
}

void LaserXNetSender::setConnectWaitMsecs(const int newConnectWaitMsecs)
{
    if (newConnectWaitMsecs != mConnectWaitMsecs)
    {
        mConnectWaitMsecs = newConnectWaitMsecs;
    }
}

QString LaserXNetSender::getJson() const
{
    QJsonObject rootObj;
    rootObj[QLatin1String("Name")] = mName;
    rootObj[QLatin1String("Address")] = mAddress.toString();
    rootObj[QLatin1String("Port")] = mPort;
    rootObj[QLatin1String("ConnectWaitMsecs")] = mConnectWaitMsecs;

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void LaserXNetSender::setJson(const QString& data)
{
    QByteArray jsonData = data.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    mName = fromJson(jsonObj, QLatin1String("Name"), QString());
    mAddress = QHostAddress(fromJson(jsonObj, QLatin1String("Address"), QStringLiteral("")));
    mPort = static_cast<quint16>(fromJson(jsonObj, QLatin1String("Port"), 0));
    mConnectWaitMsecs = fromJson(jsonObj, QLatin1String("ConnectWaitMsecs"), 3000);
}

void LaserXNetSender::onErrorOccurred(QAbstractSocket::SocketError socketError)
{
    QTcpSocket* clientConnection = qobject_cast<QTcpSocket*>(sender());
    if (clientConnection)
    {
        clientConnection->readAll();
    }
}
