#include "wordop_controller.h"
#include <QtCore>
#include <QSerialPort>
#include <laser_x_util.h>

WordopController::WordopController(QObject* parent, const qlonglong numChannels)
    : LaserXLEDController(parent, QStringLiteral("WordopController"), numChannels)
{
    setDescription(QStringLiteral("Wordop Controller"));
}

WordopController::WordopController(QObject* parent, const qlonglong numChannels, const QString& uuid)
    : LaserXLEDController(parent, QStringLiteral("WordopController"), numChannels, uuid)
{
    setDescription(QStringLiteral("Wordop Controller"));
}

WordopController::~WordopController()
{
}

void WordopController::setChannelState(const int channelId, const int newVal)
{
    if (!channelInRange(channelId))
    {
        return;
    }

    const int oldVal = mChannelStates[channelId].toInt();
    if (oldVal == newVal)
    {
        return;
    }

    const char iCHLNumber = channelId;
    std::array<char, 8> onOffCmd;
    onOffCmd[0] = 0x40;
    onOffCmd[1] = 0x05;
    onOffCmd[2] = mModelId;
    onOffCmd[3] = mDeviceId;
    onOffCmd[4] = 0x2A;
    onOffCmd[5] = iCHLNumber;
    onOffCmd[6] = newVal;
    onOffCmd[7] = checkSum(onOffCmd.data(), onOffCmd.size() - 1);

    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        icommDev->write(onOffCmd.data(), onOffCmd.size());
        QThread::msleep(50);
    }

    mChannelStates[channelId] = newVal;
}

void WordopController::turnOnAllChannels()
{
    std::array<char, 8> onOffCmd;
    onOffCmd[0] = 0x40;
    onOffCmd[1] = 0x05;
    onOffCmd[2] = mModelId;
    onOffCmd[3] = mDeviceId;
    onOffCmd[4] = 0x2A;
    onOffCmd[5] = 0xFF;
    onOffCmd[6] = 0x01;
    onOffCmd[7] = 0x70;

    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        icommDev->write(onOffCmd.data(), onOffCmd.size());
        QThread::msleep(50);
    }

    std::fill(mChannelStates.begin(), mChannelStates.end(), 1);
}

void WordopController::turnOffAllChannels()
{
    std::array<char, 8> onOffCmd;
    onOffCmd[0] = 0x40;
    onOffCmd[1] = 0x05;
    onOffCmd[2] = mModelId;
    onOffCmd[3] = mDeviceId;
    onOffCmd[4] = 0x2A;
    onOffCmd[5] = 0xFF;
    onOffCmd[6] = 0x00;
    onOffCmd[7] = 0x6F;

    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        icommDev->write(onOffCmd.data(), onOffCmd.size());
        QThread::msleep(50);
    }

    std::fill(mChannelStates.begin(), mChannelStates.end(), 0);
}

void WordopController::toggleChannelState(const int channelId)
{
    if (!channelInRange(channelId))
    {
        return;
    }
}

void WordopController::setChannelBrightness(const int channelId, const int newVal)
{
    if (!channelInRange(channelId))
    {
        return;
    }

    const int oldVal = mChannelBrightnesses[channelId].toInt();
    if (oldVal == newVal)
    {
        return;
    }

    const char iCHLNumber = channelId;
    std::array<char, 8> onOffCmd;
    onOffCmd[0] = 0x40;
    onOffCmd[1] = 0x05;
    onOffCmd[2] = mModelId;
    onOffCmd[3] = mDeviceId;
    onOffCmd[4] = 0x1A;
    onOffCmd[5] = iCHLNumber;
    onOffCmd[6] = newVal;
    onOffCmd[7] = checkSum(onOffCmd.data(), onOffCmd.size() - 1);

    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        icommDev->write(onOffCmd.data(), onOffCmd.size());
        QThread::msleep(50);
    }

    mChannelBrightnesses[channelId] = newVal;
}

void WordopController::setAllChannelsBrightness(const int newVal)
{
    std::array<char, 8> onOffCmd;
    onOffCmd[0] = 0x40;
    onOffCmd[1] = 0x05;
    onOffCmd[2] = mModelId;
    onOffCmd[3] = mDeviceId;
    onOffCmd[4] = 0x1A;
    onOffCmd[5] = 0xFF;
    onOffCmd[6] = newVal;
    onOffCmd[7] = checkSum(onOffCmd.data(), onOffCmd.size() - 1);

    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        icommDev->write(onOffCmd.data(), onOffCmd.size());
        QThread::msleep(50);
    }

    std::fill(mChannelBrightnesses.begin(), mChannelBrightnesses.end(), newVal);
}

void WordopController::setAllChannelsMaximumBrightness()
{
    std::array<char, 8> onOffCmd;
    onOffCmd[0] = 0x40;
    onOffCmd[1] = 0x05;
    onOffCmd[2] = mModelId;
    onOffCmd[3] = mDeviceId;
    onOffCmd[4] = 0x1A;
    onOffCmd[5] = 0xFF;
    onOffCmd[6] = 255;
    onOffCmd[7] = checkSum(onOffCmd.data(), onOffCmd.size() - 1);

    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        icommDev->write(onOffCmd.data(), onOffCmd.size());
        QThread::msleep(50);
    }

    std::fill(mChannelBrightnesses.begin(), mChannelBrightnesses.end(), 255);
}

std::pair<int, int> WordopController::brightnessesRange() const
{
    return std::make_pair<int, int>(0, 255);
}

QString WordopController::getJson() const
{
    QJsonObject rootObj;

    LaserXLEDController::getJson(rootObj);
    rootObj[QLatin1String("ModelId")] = mModelId;
    rootObj[QLatin1String("DeviceId")] = mDeviceId;

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void WordopController::setJson(const QString& params)
{
    QByteArray jsonData = params.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    LaserXLEDController::setJson(jsonObj);
    mModelId = fromJson(jsonObj, QLatin1String("ModelId"), 0x01);
    mDeviceId = fromJson(jsonObj, QLatin1String("DeviceId"), 0x00);

    std::vector<int> iChannelStates;
    std::vector<int> iChannelBrightnesses;
    for (int ii = 0; ii < mNumChannels; ++ii)
    {
        iChannelStates.push_back(channelState(ii));
        iChannelBrightnesses.push_back(channelBrightness(ii));

        mChannelStates[ii] = mChannelStates[ii].toInt() ? 0 : 1;
        mChannelBrightnesses[ii] = (mChannelBrightnesses[ii].toInt() + 1) % 255;
    }

    for (int ii = 0; ii < mNumChannels; ++ii)
    {
        setChannelState(ii, iChannelStates[ii]);
        setChannelBrightness(ii, iChannelBrightnesses[ii]);
    }
}

int WordopController::channelState(const int channel) const
{
    if (!channelInRange(channel))
    {
        return 0;
    }

    return mChannelStates[channel].toInt();
}

int WordopController::channelBrightness(const int channel) const
{
    if (!channelInRange(channel))
    {
        return 0;
    }

    return mChannelBrightnesses[channel].toInt();
}

void WordopController::connectDevice()
{
    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        connect(icommDev, &QIODevice::readyRead, this, &WordopController::onReadyRead);
    }
}

void WordopController::disconnectDevice()
{
    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        disconnect(icommDev, &QIODevice::readyRead, this, &WordopController::onReadyRead);
    }
}

void WordopController::onReadyRead()
{
    QIODevice* iPort = qobject_cast<QIODevice*>(sender());
    if (iPort)
    {
        QByteArray allData = iPort->readAll();
        mReadBuffer.append(allData);
        QByteArray responseData = cropValidResponse();
        if (!responseData.isEmpty())
        {
            emit responseReceived(responseData);
        }
    }
}

const char WordopController::checkSum(const char* iData, const int len)
{
    int iSum = 0;
    for (int nn = 0; nn < len; ++nn)
    {
        iSum += iData[nn];
    }

    return iSum % 256;
}

QByteArray WordopController::cropValidResponse()
{
    if (mReadBuffer.size() < 2)
    {
        return QByteArray();
    }

    const char* cDada = mReadBuffer.constData();
    if (0x40 != cDada[0])
    {
        mReadBuffer.resize(0);
        return QByteArray();
    }

    const qsizetype cSize = cDada[1];
    if (mReadBuffer.size() < (cSize + 3))
    {
        return QByteArray();
    }

    QByteArray replyData = mReadBuffer.first(cSize + 3);
    mReadBuffer = mReadBuffer.last(mReadBuffer.size() - cSize - 3);
    return replyData;
}
