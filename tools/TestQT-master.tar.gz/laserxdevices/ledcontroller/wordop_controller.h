#ifndef WORDOP_CONTROLLER_H
#define WORDOP_CONTROLLER_H

#include "laser_x_devices_global.h"
#include <laser_x_led_controller.h>
#include <QtCore>

class WordopController : public LaserXLEDController
{
    Q_OBJECT
public:
    WordopController(QObject* parent, const qlonglong numChannels);
    WordopController(QObject* parent, const qlonglong numChannels, const QString& uuid);

public:
    ~WordopController();

public:
    void turnOnAllChannels() override;
    void turnOffAllChannels() override;
    void setChannelState(const int channelId, const int newVal) override;
    void toggleChannelState(const int channelId) override;
    void setChannelBrightness(const int channelId, const int newVal) override;
    void setAllChannelsBrightness(const int newVal) override;
    void setAllChannelsMaximumBrightness() override;
    std::pair<int, int> brightnessesRange() const override;
    QString getJson() const override;
    void setJson(const QString& params) override;

    int channelState(const int channel) const override;
    int channelBrightness(const int channel) const override;

    void connectDevice() override;
    void disconnectDevice() override;

private:
    void onReadyRead();
    static const char checkSum(const char *iData, const int len);
    QByteArray cropValidResponse();

private:
    Q_DISABLE_COPY_MOVE(WordopController)

private:
    char mModelId = 0x01;
    char mDeviceId = 0x00;

    QByteArray mReadBuffer;
};

#endif // WORDOP_CONTROLLER_H
