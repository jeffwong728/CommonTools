#ifndef LASER_X_NET_SENDER_H
#define LASER_X_NET_SENDER_H

#include "laser_x_devices_global.h"
#include <QtCore>
#include <QtNetwork>

class LASERXDEVICES_LIBRARY_EXPORT LaserXNetSender : public QTcpSocket
{
    Q_OBJECT
    friend class LaserXDeviceManager;
private:
    LaserXNetSender(QObject* parent);
    LaserXNetSender(QObject* parent, const QString &uuid);

public:
    ~LaserXNetSender();

public:
    bool connectWithWait();
    bool disconnectWithWait();

public:
    QString uuid() const;
    QString name() const;
    void setName(const QString &newName);
    QHostAddress address() const;
    void setAddress(const QHostAddress &newAddress);
    quint16 port() const;
    void setPort(const quint16 newPort);
    int connectWaitMsecs() const;
    void setConnectWaitMsecs(const int newConnectWaitMsecs);
    QString getJson() const;
    void setJson(const QString& data);

private:
    void onErrorOccurred(QAbstractSocket::SocketError socketError);

signals:
    void nameChanged(const QString& oldName, const QString& newName);
    void addressChanged(const QHostAddress &oldAddress, const QHostAddress &newAddress);
    void portChanged(const quint16 oldPort, const quint16 newPort);

private:
    Q_DISABLE_COPY_MOVE(LaserXNetSender)

private:
    const QString mUUID;
    QString mName;
    QHostAddress mAddress;
    int mConnectWaitMsecs = 3000;
    quint16 mPort;
};

#endif // LASER_X_NET_SENDER_H
