#include "laser_x_led_controller.h"
#include "laser_x_devicemanager.h"
#include "laser_x_serialport.h"
#include <QtCore>
#include <laser_x_util.h>

LaserXLEDController::LaserXLEDController(QObject* parent, const QString& type, const qlonglong numChannels)
    : LaserXLEDController(parent, type, numChannels, QUuid::createUuid().toString())
{
}

LaserXLEDController::LaserXLEDController(QObject* parent, const QString& type, const qlonglong numChannels, const QString& uuid)
    : QObject(parent)
    , mType(type)
    , mUUID(uuid)
    , mNumChannels(numChannels)
{
    mChannelNames.reserve(mNumChannels);
    mChannelStates.reserve(mNumChannels);
    mChannelBrightnesses.reserve(mNumChannels);
    for (qlonglong cc = 0; cc < mNumChannels; ++cc)
    {
        mChannelNames.push_back(QStringLiteral("Channel %1").arg(cc));
        mChannelStates.push_back(0);
        mChannelBrightnesses.push_back(0);
    }
}

LaserXLEDController::~LaserXLEDController()
{
}

QString LaserXLEDController::uuid() const
{
    return mUUID;
}

qlonglong LaserXLEDController::numChannels() const
{
    return mNumChannels;
}

bool LaserXLEDController::channelInRange(const int channel) const
{
    if (channel >= 0 && channel < mNumChannels)
    {
        return true;
    }
    else
    {
        return false;
    }
}

QString LaserXLEDController::type() const
{
    return mType;
}

QIODevice* LaserXLEDController::commDevice() const
{
    if (QStringLiteral("SerialPort") == mCommType)
    {
        LaserXDeviceManager* iDevs = qobject_cast<LaserXDeviceManager*>(parent());
        if (iDevs)
        {
            LaserXSerialPort* iPort = iDevs->findSerialPort(mCommSource);
            if (iPort)
            {
                iPort->setDataMode(2);
            }
            return iPort;
        }
    }

    return nullptr;
}

void LaserXLEDController::getJson(QJsonObject& rootObj) const
{
    rootObj[QLatin1String("Name")] = mName;
    rootObj[QLatin1String("Description")] = mDescription;
    rootObj[QLatin1String("CommType")] = mCommType;
    rootObj[QLatin1String("CommSource")] = mCommSource;
    rootObj[QLatin1String("ChannelNames")] = QJsonArray::fromStringList(mChannelNames);
    rootObj[QLatin1String("ChannelStates")] = QJsonArray::fromVariantList(mChannelStates);
    rootObj[QLatin1String("ChannelBrightnesses")] = QJsonArray::fromVariantList(mChannelBrightnesses);
}

void LaserXLEDController::setJson(const QJsonObject& jsonObj)
{
    disconnectDevice();
    mName = fromJson(jsonObj, QLatin1String("Name"), QString());
    mDescription = fromJson(jsonObj, QLatin1String("Description"), QString());
    mCommType = fromJson(jsonObj, QLatin1String("CommType"), QString());
    mCommSource = fromJson(jsonObj, QLatin1String("CommSource"), QString());
    mChannelNames = fromJson(jsonObj, QLatin1String("ChannelNames"), QStringList());
    mChannelStates = fromJson(jsonObj, QLatin1String("ChannelStates"), QJsonArray()).toVariantList();
    mChannelBrightnesses = fromJson(jsonObj, QLatin1String("ChannelBrightnesses"), QJsonArray()).toVariantList();

    mChannelNames.resize(mNumChannels);
    mChannelStates.resize(mNumChannels);
    mChannelBrightnesses.resize(mNumChannels);
    connectDevice();
}

QString LaserXLEDController::name() const
{
    return mName;
}

void LaserXLEDController::setName(const QString& newVal)
{
    if (newVal != mName)
    {
        QString oldVal = mName;
        mName = newVal;
        emit nameChanged(oldVal, newVal);
    }
}

QString LaserXLEDController::commType() const
{
    return mCommType;
}

void LaserXLEDController::setCommType(const QString& newVal)
{
    if (newVal != mCommType)
    {
        mCommType = newVal;
    }
}

QString LaserXLEDController::commSource() const
{
    return mCommSource;
}

QString LaserXLEDController::commSourceName() const
{
    if (QStringLiteral("SerialPort") == mCommType)
    {
        LaserXDeviceManager* iDevs = qobject_cast<LaserXDeviceManager*>(parent());
        if (iDevs)
        {
            LaserXSerialPort *iPort = iDevs->findSerialPort(mCommSource);
            if (iPort)
            {
                return iPort->portName();
            }
        }
    }

    return QStringLiteral("UNDEFINED");
}

void LaserXLEDController::setCommSource(const QString& newVal)
{
    if (newVal != mCommSource)
    {
        mCommSource = newVal;
    }
}

QString LaserXLEDController::description() const
{
    return mDescription;
}

void LaserXLEDController::setDescription(const QString& newVal)
{
    if (newVal != mDescription)
    {
        mDescription = newVal;
    }
}

QString LaserXLEDController::getChannelName(const int channel) const
{
    if (channel >= 0 && channel < mChannelNames.size())
    {
        return mChannelNames.constData()[channel];
    }
    else
    {
        return QStringLiteral("UNDEFINED");
    }
}

void LaserXLEDController::setChannelName(const int channel, const QString& newVal)
{
    if (channel >= 0 && channel < mChannelNames.size())
    {
        if (newVal != mChannelNames.constData()[channel])
        {
            QString oldVal = mChannelNames[channel];
            mChannelNames[channel] = newVal;
            emit channelNameChanged(channel, oldVal, newVal);
        }
    }
}

int LaserXLEDController::findChannelNumber(const QString& name) const
{
    auto it = std::find(mChannelNames.cbegin(), mChannelNames.cend(), name);
    if (it != mChannelNames.cend())
    {
        return std::distance(mChannelNames.cbegin(), it);
    }
    else
    {
        return 0;
    }
}
