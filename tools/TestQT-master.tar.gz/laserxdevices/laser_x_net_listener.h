#ifndef LASER_X_NET_LISTENER_H
#define LASER_X_NET_LISTENER_H

#include "laser_x_devices_global.h"
#include <QtCore>
#include <QtNetwork>

class LASERXDEVICES_LIBRARY_EXPORT LaserXNetListener : public QTcpServer
{
    Q_OBJECT
    friend class LaserXDeviceManager;
private:
    LaserXNetListener(QObject* parent);
    LaserXNetListener(QObject* parent, const QString &uuid);

public:
    ~LaserXNetListener();
    bool startListen();
    void stopListen();
    void closeAllConnections();

public:
    QString uuid() const;
    QString name() const;
    void setName(const QString &newName);
    QHostAddress address() const;
    void setAddress(const QHostAddress &newAddress);
    quint16 port() const;
    void setPort(const quint16 newPort);
    QString getJson() const;
    void setJson(const QString& data);

private:
    void onNewConnection();
    void onDisconnected();
    void onReadyRead();
    void onErrorOccurred(QAbstractSocket::SocketError socketError);

signals:
    void nameChanged(const QString& oldName, const QString& newName);
    void addressChanged(const QHostAddress &oldAddress, const QHostAddress &newAddress);
    void portChanged(const quint16 oldPort, const quint16 newPort);
    void listeningStarted(bool success);
    void listeningStoped();
    void connectionAdded(QTcpSocket* connection);
    void connectionAboutToDelete(QTcpSocket* connection);
    void connectionErrorOccurred(QTcpSocket* connection, QAbstractSocket::SocketError socketError);
    void jsonReceived(QTcpSocket* connection, const QJsonDocument& commandDoc);
    void stringReceived(QTcpSocket* connection, const QString& commandStr);
    void bytesReceived(QTcpSocket* connection, const QByteArray& commandBytes);

private:
    Q_DISABLE_COPY_MOVE(LaserXNetListener)

private:
    const QString mUUID;
    QString mName;
    QHostAddress mAddress;
    quint16 mPort;
    QVector<QTcpSocket*> mConnections;
};

#endif // LASER_X_NET_LISTENER_H
