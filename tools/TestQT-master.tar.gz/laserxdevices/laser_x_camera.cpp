#include "laser_x_camera.h"

LaserXCamera::LaserXCamera(QObject* parent)
    : QObject(parent)
    , mUUID(QUuid::createUuid().toString())
{
}

LaserXCamera::LaserXCamera(QObject* parent, const QString& uuid)
    : QObject(parent)
    , mUUID(uuid)
{
}

QString LaserXCamera::getUUID() const
{
    return mUUID;
}

LaserXCameraManager* LaserXCamera::getManager() const
{
    return qobject_cast<LaserXCameraManager*>(parent());
}

QString LaserXCamera::name() const
{
    return mName;
}

QString LaserXCamera::description() const
{
    return mDescription;
}

LaserXCamera::CameraError LaserXCamera::error() const
{
    return mError;
}

void LaserXCamera::clearError()
{
    QWriteLocker iLocker(&mLocker);
    mError = NoError;
}

void LaserXCamera::setName(const QString& nName)
{
    if (mName != nName)
    {
        QVariant oldValue = mName;
        QVariant newValue = nName;
        mName = nName;
        parameterChanged(QStringLiteral("Name"), oldValue, newValue);
    }
}

void LaserXCamera::setDescription(const QString& nDescription)
{
    if (mDescription != nDescription)
    {
        QVariant oldValue = mDescription;
        QVariant newValue = nDescription;
        mDescription = nDescription;
        parameterChanged(QStringLiteral("Description"), oldValue, newValue);
    }
}

bool LaserXCamera::startContinuousGrab()
{
    if (!mContinuousGrabbing)
    {
        mContinuousGrabbing = true;
        emit startCameraLive();
    }

    return true;
}

bool LaserXCamera::stopContinuousGrab()
{
    if (mContinuousGrabbing)
    {
        mContinuousGrabbing = false;
        emit stopCameraLive();
    }

    return true;
}

bool LaserXCamera::toggleContinuousGrab()
{
    if (mContinuousGrabbing)
    {
        return stopContinuousGrab();
    }
    else
    {
        return startContinuousGrab();
    }
}

bool LaserXCamera::isContinuousGrab() const
{
    return mContinuousGrabbing;
}

QVariantMap LaserXCamera::getParameters() const
{//MT N/A
    QVariantMap params;
    params[QStringLiteral("Name")] = mName;
    params[QStringLiteral("UUID")] = mUUID;
    params[QStringLiteral("Description")] = mDescription;
    return params;
}

bool LaserXCamera::setParameters(const QVariantMap& params)
{//MT
    mName = params.value(QStringLiteral("Name"), mName).toString();
    mDescription = params.value(QStringLiteral("Description"), mDescription).toString();

    return true;
}

int LaserXCamera::getFPS() const
{
    return 30;
}

QVariantMap LaserXCamera::getGrabParams() const
{
    return QVariantMap();
}

void LaserXCamera::setGrabParams(const QVariantMap& grabParams)
{
    Q_UNUSED(grabParams);
}

QString LaserXCamera::getPerProjectParams() const
{
    return QString();
}

void LaserXCamera::setPerProjectParams(const QString& perProjParams)
{
    Q_UNUSED(perProjParams);
}

LaserXAddCameraWidget::LaserXAddCameraWidget(QWidget* parent)
    : QWidget(parent)
{
}

void LaserXAddCameraWidget::initialize(const QVariantMap& params)
{
}

QVariantMap LaserXAddCameraWidget::getParameters() const
{
    return QVariantMap();
}

LaserXConfigCameraWidget::LaserXConfigCameraWidget(QWidget* parent)
    : QWidget(parent)
{
}

void LaserXConfigCameraWidget::initialize(const QVariantMap& params)
{
}

QVariantMap LaserXConfigCameraWidget::getParameters() const
{
    return QVariantMap();
}

bool LaserXCameraManager::initialize()
{
    return true;
}

bool LaserXCameraManager::terminate()
{
    return true;
}

LaserXCamera* LaserXCameraManager::findCamera(const QVariantMap& params) const
{
    return nullptr;
}
