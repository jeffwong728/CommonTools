#ifndef LASER_X_CAMERA_H
#define LASER_X_CAMERA_H

#include "laser_x_devices_global.h"
#include <QtCore>
#include <QtWidgets>
#include <opencv2/opencv.hpp>
Q_DECLARE_METATYPE(cv::Mat);
class LaserXCameraManager;

class LASERXDEVICES_LIBRARY_EXPORT LaserXCamera : public QObject
{
    Q_OBJECT
public:
    enum CameraError {
        NoError,
        DeviceNotFoundError,
        AccessDeniedError,
        OpenError,
        WriteError,
        ReadError,
        TriggerError,
        DisconnectError,
        UnsupportedOperationError,
        TimeoutError,
        NotOpenError,
        ReadParameterError,
        WriteParameterError,
        UnknownError
    };
    Q_ENUM(CameraError)

public:
    LaserXCamera(QObject* parent);
    LaserXCamera(QObject *parent, const QString &uuid);
    virtual ~LaserXCamera() = default;

public:
    QString getUUID() const;
    LaserXCameraManager *getManager() const;
    QString name() const;
    QString description() const;
    CameraError error() const;
    void clearError();
    void setName(const QString& nName);
    void setDescription(const QString &nDescription);

public:
    virtual bool open(const QVariantMap& params) = 0;
    virtual bool close() = 0;
    virtual cv::Mat snap(int msec = 0) = 0;
    virtual cv::Mat tryLiveGrab(int msec = 0) = 0;
    virtual bool startContinuousGrab();
    virtual bool stopContinuousGrab();
    virtual bool toggleContinuousGrab();
    virtual bool isContinuousGrab() const;
    virtual bool isOpened() const = 0;
    virtual bool isLivable() const = 0;
    virtual QVariantMap getParameters() const;
    virtual bool setParameters(const QVariantMap& params);
    virtual int getFPS() const;
    virtual QVariantMap getGrabParams() const;
    virtual void setGrabParams(const QVariantMap &grabParams);
    virtual QString getPerProjectParams() const;
    virtual void setPerProjectParams(const QString& perProjParams);

signals:
    void imageConsumed();
    void startCameraLive();
    void stopCameraLive();
    void imageReady(cv::Mat img, QVariantMap infos);
    void errorOccurred(LaserXCamera::CameraError error) const;
    void errorOccurredEx(LaserXCamera::CameraError error, const QString errorMsg) const;
    void parameterChanged(const QString &paramName, const QVariant &oldValue, const QVariant& newValue) const;
    void cameraOpened();
    void cameraClosed();

protected:
    QString mName;
    QString mDescription;
    const QString mUUID;
    QString mErrorMsg;
    CameraError mError = NoError;
    bool mContinuousGrabbing = false;
    QReadWriteLock mLocker;
};

#define LaserXCameraInterfaceIID "net.laserx.CameraInterface"
Q_DECLARE_INTERFACE(LaserXCamera, LaserXCameraInterfaceIID)

class LASERXDEVICES_LIBRARY_EXPORT LaserXAddCameraWidget : public QWidget
{
    Q_OBJECT
public:
    LaserXAddCameraWidget(QWidget* parent);
    virtual ~LaserXAddCameraWidget() = default;

public:
    virtual void initialize(const QVariantMap& params);
    virtual QVariantMap getParameters() const;

signals:
    void parametersChanged(const QVariantMap& params);
};

class LASERXDEVICES_LIBRARY_EXPORT LaserXConfigCameraWidget : public QWidget
{
    Q_OBJECT
public:
    LaserXConfigCameraWidget(QWidget* parent);
    virtual ~LaserXConfigCameraWidget() = default;

public:
    virtual void initialize(const QVariantMap& params);
    virtual QVariantMap getParameters() const;

signals:
    void parametersChanged(const QVariantMap& params);
};

class LASERXDEVICES_LIBRARY_EXPORT LaserXCameraManager : public QObject
{
    Q_OBJECT;
public:
    virtual ~LaserXCameraManager() = default;

public:
    virtual bool initialize();
    virtual bool terminate();
    virtual QIcon getIcon() const = 0;
    virtual QString getTypeName() = 0;
    virtual int getNumCameras() = 0;
    virtual QVector<LaserXCamera*> getCameras() = 0;
    virtual LaserXCamera* createCamera(const QVariantMap& params) = 0;
    virtual LaserXCamera* findCamera(const QVariantMap& params) const;
    virtual bool addCamera(LaserXCamera* camera) = 0;
    virtual void deleteCamera(LaserXCamera* camera) = 0;
    virtual LaserXAddCameraWidget* getAddWidget(QWidget* parent) = 0;
    virtual LaserXConfigCameraWidget* getConfigWidget(QWidget* parent, LaserXCamera* camera) = 0;

signals:
    void cameraCreated(LaserXCamera* cam);
    void cameraAdded(LaserXCamera* cam);
    void cameraAboutToDelete(LaserXCamera* cam);
};

#define LaserXCameraManagerInterfaceIID "net.laserx.CameraManagerInterface"
Q_DECLARE_INTERFACE(LaserXCameraManager, LaserXCameraManagerInterfaceIID)

#endif // LASER_X_CAMERA_H
