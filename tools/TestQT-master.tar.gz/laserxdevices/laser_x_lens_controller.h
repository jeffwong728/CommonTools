#ifndef LASER_X_LENS_CONTROLLER_H
#define LASER_X_LENS_CONTROLLER_H

#include "laser_x_devices_global.h"
#include <QtCore>

class LASERXDEVICES_LIBRARY_EXPORT LaserXLensController : public QObject
{
    Q_OBJECT
    friend class LaserXDeviceManager;
public:
    LaserXLensController(QObject* parent, const QString &type);
    LaserXLensController(QObject* parent, const QString& type, const QString& uuid);

public:
    ~LaserXLensController();

public:
    virtual qreal magnification(const int msecs) const = 0;
    virtual bool setMagnification(const qreal newVal, const int msecs) = 0;
    virtual bool goHome(const int msecs) = 0;
    virtual QString getJson() const = 0;
    virtual void setJson(const QString& params) = 0;
    virtual void connectDevice() = 0;
    virtual void disconnectDevice() = 0;

    virtual bool sendQueryMagnification() const = 0;
    virtual bool sendSetMagnification(const qreal newVal) = 0;
    virtual bool sendGoHome() = 0;
    virtual bool sendQueryErrorNumPulses() const = 0;
    virtual bool sendQueryMotorStatus() const = 0;

public:
    QString uuid() const;
    QString type() const;
    QIODevice* commDevice() const;

    void getJson(QJsonObject& rootObj) const;
    void setJson(const QJsonObject& jsonObj);

    QString name() const;
    void setName(const QString& newVal);

    QString commType() const;
    void setCommType(const QString& newVal);

    QString commSource() const;
    QString commSourceName() const;
    void setCommSource(const QString& newVal);

    QString description() const;
    void setDescription(const QString& newVal);

    qreal magnificationMin() const;
    void setMagnificationMin(const qreal newVal);

    qreal magnificationMax() const;
    void setMagnificationMax(const qreal newVal);

signals:
    void nameChanged(const QString& oldName, const QString& newName) const;
    void responseReceived(const QByteArray& data) const;
    void homeRemainingNumPulsesReceived(const int val) const;
    void zoomRemainingNumPulsesReceived(const int val) const;
    void currentMagnificationReceived(const qreal val) const;
    void errorNumPulsesReceived(const int val) const;
    void motorStatusReceived(const int val) const;

private:
    Q_DISABLE_COPY_MOVE(LaserXLensController)

private:
    const QString mType;
    const QString mUUID;
    QString mName;
    QString mDescription;
    QString mCommType;
    QString mCommSource;
    qreal mMagnificationMin = 1.;
    qreal mMagnificationMax = 1.;
};

#endif // LASER_X_LENS_CONTROLLER_H
