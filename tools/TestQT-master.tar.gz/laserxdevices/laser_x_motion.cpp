#include "laser_x_motion.h"

LaserXMotionAxis::LaserXMotionAxis(QObject* parent, const int axisNo)
    : QObject(parent)
    , mAxisNo(axisNo)
{
}

QString LaserXMotionAxis::uuid() const
{
    return device()->axisUuid(mAxisNo);
}

int LaserXMotionAxis::axisNo() const
{
    return mAxisNo;
}

LaserXMotionDevice* LaserXMotionAxis::device() const
{
    return dynamic_cast<LaserXMotionDevice*>(parent());
}

QString LaserXMotionAxis::name() const
{
    return device()->axisName(mAxisNo);
}

void LaserXMotionAxis::setName(const QString& nName)
{
    device()->setAxisName(mAxisNo, nName);
}

QString LaserXMotionAxis::description() const
{
    return device()->axisDescription(mAxisNo);
}

void LaserXMotionAxis::setDescription(const QString& nDescription)
{
    device()->setAxisDescription(mAxisNo, nDescription);
}

LaserXMotionDevice::LaserXMotionDevice(QObject* parent, const int numAxis)
    : QObject(parent)
    , mUUID(QUuid::createUuid().toString())
{
    QStringList &axisUUIDs = const_cast<QStringList &>(mAxisUUIDs);
    axisUUIDs.reserve(numAxis);
    for (int aa = 0; aa < numAxis; ++aa)
    {
        axisUUIDs.append(QUuid::createUuid().toString());
    }
}

LaserXMotionDevice::LaserXMotionDevice(QObject* parent, const QString& uuid)
    : QObject(parent)
    , mUUID(uuid)
{
}

QString LaserXMotionDevice::uuid() const
{
    return mUUID;
}

LaserXMotionManager* LaserXMotionDevice::manager() const
{
    return dynamic_cast<LaserXMotionManager*>(parent());
}

QString LaserXMotionDevice::name() const
{
    return mName;
}

void LaserXMotionDevice::setName(const QString& nName)
{
    if (mName != nName)
    {
        QVariantMap cParams;
        cParams[QStringLiteral("ParamName")] = QStringLiteral("DeviceName");
        cParams[QStringLiteral("OldValue")]  = mName;
        cParams[QStringLiteral("NewValue")]  = nName;
        cParams[QStringLiteral("InfoMsg")]   = QStringLiteral("Motion device name changed from %1 to %2").arg(mName).arg(nName);
        cParams[QStringLiteral("SaveDB")]    = true;
        mName = nName;
        motionDeviceParameterChanged(cParams);
    }
}

QString LaserXMotionDevice::description() const
{
    return mDescription;
}

void LaserXMotionDevice::setDescription(const QString& nDescription)
{
    if (mDescription != nDescription)
    {
        QVariantMap cParams;
        cParams[QStringLiteral("ParamName")] = QStringLiteral("DeviceDescription");
        cParams[QStringLiteral("OldValue")]  = mDescription;
        cParams[QStringLiteral("NewValue")]  = nDescription;
        cParams[QStringLiteral("InfoMsg")]   = QStringLiteral("Motion device description changed from %1 to %2").arg(mDescription).arg(nDescription);
        cParams[QStringLiteral("SaveDB")] = true;
        mDescription = nDescription;

        motionDeviceParameterChanged(cParams);
    }
}

QVariantMap LaserXMotionDevice::getParameters() const
{
    QVariantMap params;
    params[QStringLiteral("Name")] = mName;
    params[QStringLiteral("UUID")] = mUUID;
    params[QStringLiteral("Description")] = mDescription;
    params[QStringLiteral("AxisNames")] = mAxisNames;
    params[QStringLiteral("AxisDescriptions")] = mAxisDescriptions;
    params[QStringLiteral("AxisUUIDs")] = mAxisUUIDs;
    return params;
}

bool LaserXMotionDevice::setParameters(const QVariantMap& params)
{
    mName = params.value(QStringLiteral("Name"), mName).toString();
    mDescription = params.value(QStringLiteral("Description"), mDescription).toString();
    mAxisNames = params.value(QStringLiteral("AxisNames"), mAxisNames).toStringList();
    mAxisDescriptions = params.value(QStringLiteral("AxisDescriptions"), mAxisDescriptions).toStringList();
    QStringList axisUuids = params.value(QStringLiteral("AxisUUIDs"), mAxisUUIDs).toStringList();
    QStringList& iAxisUUIDs = const_cast<QStringList&>(mAxisUUIDs);
    iAxisUUIDs.swap(axisUuids);

    if (mAxisNames.size() != mAxisDescriptions.size() || mAxisNames.size() != mAxisUUIDs.size())
    {
        mAxisNames.clear();
        mAxisDescriptions.clear();
        const_cast<QStringList&>(mAxisUUIDs).clear();
    }

    return true;
}

QString LaserXMotionDevice::axisUuid(const int axisNo) const
{
    if (axisNo >= 0 && axisNo < mAxisUUIDs.size())
    {
        return mAxisUUIDs.constData()[axisNo];
    }
    else
    {
        qDebug() << QStringLiteral("Invalid axis number %1").arg(axisNo);
        return QString();
    }
}

QString LaserXMotionDevice::axisName(const int axisNo) const
{
    if (axisNo >= 0 && axisNo < mAxisNames.size())
    {
        return mAxisNames.constData()[axisNo];
    }
    else
    {
        qDebug() << QStringLiteral("Invalid axis number %1").arg(axisNo);
        return QString();
    }
}

QString LaserXMotionDevice::axisDescription(const int axisNo) const
{
    if (axisNo >= 0 && axisNo < mAxisDescriptions.size())
    {
        return mAxisDescriptions.constData()[axisNo];
    }
    else
    {
        qDebug() << QStringLiteral("Invalid axis number %1").arg(axisNo);
        return QString();
    }
}

void LaserXMotionDevice::setAxisName(const int axisNo, const QString& nName)
{
    if (axisNo >=0 && axisNo < mAxisNames.size())
    {
        if (mAxisNames[axisNo] != nName)
        {
            QVariantMap cParams;
            cParams[QStringLiteral("ParamName")] = QStringLiteral("AxisName");
            cParams[QStringLiteral("OldValue")]  = mAxisNames[axisNo];
            cParams[QStringLiteral("NewValue")]  = nName;
            cParams[QStringLiteral("AxisNo")]    = axisNo;
            cParams[QStringLiteral("InfoMsg")]   = QStringLiteral("Axis %1 name changed from %2 to %3").arg(axisNo).arg(mAxisNames[axisNo]).arg(nName);
            cParams[QStringLiteral("SaveDB")] = true;

            mAxisNames[axisNo] = nName;
            motionDeviceParameterChanged(cParams);
        }
    }
    else
    {
        qDebug() << QStringLiteral("Invalid axis number %1").arg(axisNo);
    }
}

void LaserXMotionDevice::setAxisDescription(const int axisNo, const QString& nDescription)
{
    if (axisNo >= 0 && axisNo < mAxisDescriptions.size())
    {
        if (mAxisDescriptions[axisNo] != nDescription)
        {
            QVariantMap cParams;
            cParams[QStringLiteral("ParamName")] = QStringLiteral("AxisDescription");
            cParams[QStringLiteral("OldValue")]  = mAxisDescriptions[axisNo];
            cParams[QStringLiteral("NewValue")]  = nDescription;
            cParams[QStringLiteral("AxisNo")]    = axisNo;
            cParams[QStringLiteral("InfoMsg")]   = QStringLiteral("Axis %1 description changed from %2 to %3").arg(axisNo).arg(mAxisDescriptions[axisNo]).arg(nDescription);
            cParams[QStringLiteral("SaveDB")]    = true;

            mAxisDescriptions[axisNo] = nDescription;
            motionDeviceParameterChanged(cParams);
        }
    }
    else
    {
        qDebug() << QStringLiteral("Invalid axis number %1").arg(axisNo);
    }
}

LaserXAddMotionDeviceWidget::LaserXAddMotionDeviceWidget(QWidget* parent)
    : QWidget(parent)
{
}

void LaserXAddMotionDeviceWidget::initialize(const QVariantMap& params)
{
}

int LaserXAddMotionDeviceWidget::countMotionDevices() const
{
    return 0;
}

void LaserXAddMotionDeviceWidget::closeAllMotionDevices()
{
}

QVariantMap LaserXAddMotionDeviceWidget::getParameters() const
{
    return QVariantMap();
}

LaserXConfigMotionDeviceWidget::LaserXConfigMotionDeviceWidget(QWidget* parent)
    : QWidget(parent)
{
}

void LaserXConfigMotionDeviceWidget::initialize(LaserXMotionDevice* device)
{
}

QVariantMap LaserXConfigMotionDeviceWidget::getParameters() const
{
    return QVariantMap();
}

LaserXConfigMotionAxisWidget::LaserXConfigMotionAxisWidget(QWidget* parent)
    : QWidget(parent)
{
}

void LaserXConfigMotionAxisWidget::initialize(LaserXMotionAxis* axis)
{
}

QVariantMap LaserXConfigMotionAxisWidget::getParameters() const
{
    return QVariantMap();
}

bool LaserXMotionManager::initialize()
{
    return true;
}

bool LaserXMotionManager::terminate()
{
    return true;
}
