#ifndef LASER_X_LED_CONTROLLER_H
#define LASER_X_LED_CONTROLLER_H

#include "laser_x_devices_global.h"
#include <QtCore>

class LASERXDEVICES_LIBRARY_EXPORT LaserXLEDController : public QObject
{
    Q_OBJECT
    friend class LaserXDeviceManager;
public:
    LaserXLEDController(QObject* parent, const QString &type, const qlonglong numChannels);
    LaserXLEDController(QObject* parent, const QString& type, const qlonglong numChannels, const QString& uuid);

public:
    ~LaserXLEDController();

public:
    virtual void turnOnAllChannels() = 0;
    virtual void turnOffAllChannels() = 0;
    virtual void setChannelState(const int channel, const int newVal) = 0;
    virtual void toggleChannelState(const int channel) = 0;
    virtual void setChannelBrightness(const int channel, const int newVal) = 0;
    virtual void setAllChannelsBrightness(const int newVal) = 0;
    virtual void setAllChannelsMaximumBrightness() = 0;
    virtual std::pair<int, int> brightnessesRange() const = 0;
    virtual QString getJson() const = 0;
    virtual void setJson(const QString& params) = 0;

    virtual int channelState(const int channel) const = 0;
    virtual int channelBrightness(const int channel) const = 0;

    virtual void connectDevice() = 0;
    virtual void disconnectDevice() = 0;

public:
    QString uuid() const;
    qlonglong numChannels() const;
    bool channelInRange(const int channel) const;
    QString type() const;
    QIODevice* commDevice() const;

    void getJson(QJsonObject& rootObj) const;
    void setJson(const QJsonObject& jsonObj);

    QString name() const;
    void setName(const QString& newVal);

    QString commType() const;
    void setCommType(const QString& newVal);

    QString commSource() const;
    QString commSourceName() const;
    void setCommSource(const QString& newVal);

    QString description() const;
    void setDescription(const QString& newVal);

    QString getChannelName(const int channel) const;
    void setChannelName(const int channel, const QString& newVal);
    int findChannelNumber(const QString& name) const;

signals:
    void nameChanged(const QString& oldName, const QString& newName);
    void channelNameChanged(const int channel, const QString& oldName, const QString& newName);
    void responseReceived(const QByteArray &data);

private:
    Q_DISABLE_COPY_MOVE(LaserXLEDController)

protected:
    const QString mType;
    const QString mUUID;
    const qlonglong mNumChannels;
    QString mName;
    QString mDescription;
    QString mCommType;
    QString mCommSource;
    QStringList mChannelNames;
    QVariantList mChannelStates;
    QVariantList mChannelBrightnesses;
};

#endif // LASER_X_LED_CONTROLLER_H
