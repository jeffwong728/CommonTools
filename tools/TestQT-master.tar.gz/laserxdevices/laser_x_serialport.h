#ifndef LASER_X_SERIALPORT_H
#define LASER_X_SERIALPORT_H

#include "laser_x_devices_global.h"
#include <QUuid>
#include <QSerialPort>
class QWidget;

class LASERXDEVICES_LIBRARY_EXPORT LaserXSerialPort : public QSerialPort
{
    Q_OBJECT
    friend class LaserXDeviceManager;
private:
    LaserXSerialPort(QObject* parent);
    LaserXSerialPort(QObject* parent, const QString &uuid);
public:
    ~LaserXSerialPort();

public:
    bool open(OpenMode mode) override;
    bool recovery();
    QString getParameters() const;
    QString getUUID() const;
    void setParameters(const QString &params);
    Direction direction() const { return mDirection; }
    bool setDirection(Direction direction);
    QString description() const;
    void setDescription(const QString& description) { mDescription = description; }
    void setDataMode(const int dataMode);

private:
    void onReadyRead();

signals:
    void openResultNotify(bool opened);
    void directionChanged(QSerialPort::Direction direction);
    void recovered();
    void parameterParseError(const QString& errorString);
    void jsonReceived(const QJsonDocument& commandDoc);
    void stringReceived(const QString& commandStr);
    void bytesReceived(const QByteArray& commandBytes);

private:
    Q_DISABLE_COPY_MOVE(LaserXSerialPort)

private:
    QString mUUID;
    Direction mDirection = AllDirections;
    mutable QString mDescription;
    int mDataMode = 0; //0-String, 1-Binary, 2-Ignore
};

#endif // LASER_X_SERIALPORT_H
