#include "laser_x_serialport.h"
#include <QtCore>
#include <QtSerialPort>
#include <laser_x_util.h>

LaserXSerialPort::LaserXSerialPort(QObject* parent)
    : LaserXSerialPort(parent, QUuid::createUuid().toString())
{
}

LaserXSerialPort::LaserXSerialPort(QObject* parent, const QString& uuid)
    : QSerialPort(parent)
    , mUUID(uuid)
{
    connect(this, &QIODevice::readyRead, this, &LaserXSerialPort::onReadyRead);
}

LaserXSerialPort::~LaserXSerialPort()
{
}

bool LaserXSerialPort::open(OpenMode mode)
{
    switch (mDirection)
    {
    case Input: mode = ReadOnly; break;
    case Output: mode = WriteOnly; break;
    case AllDirections: mode = ReadWrite; break;
    default: break;
    }

    bool bOk = QSerialPort::open(mode);
    emit openResultNotify(bOk);

    return bOk;
}

bool LaserXSerialPort::recovery()
{
    if (QSerialPort::PermissionError == error() ||
        QSerialPort::ResourceError == error() ||
        QSerialPort::DeviceNotFoundError == error() ||
        QSerialPort::NotOpenError == error() ||
        QSerialPort::OpenError == error())
    {
        OpenMode mode = ReadWrite;
        switch (mDirection)
        {
        case Input: mode = ReadOnly; break;
        case Output: mode = WriteOnly; break;
        case AllDirections: mode = ReadWrite; break;
        default: break;
        }

        bool bOk = false;
        {
            const QSignalBlocker blocker(this);
            QSerialPort::close();
            bOk = QSerialPort::open(mode);
        }

        if (bOk)
        {
            emit recovered();
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return true;
    }
}

QString LaserXSerialPort::getParameters() const
{
    QJsonObject paramsObj;
    paramsObj[QLatin1String("Direction")] = QtEnumToString(mDirection);
    paramsObj[QLatin1String("BaudRate")] = QtEnumToString(static_cast<BaudRate>(baudRate()));
    paramsObj[QLatin1String("DataBits")] = QtEnumToString(dataBits());
    paramsObj[QLatin1String("Parity")] = QtEnumToString(parity());
    paramsObj[QLatin1String("StopBits")] = QtEnumToString(stopBits());
    paramsObj[QLatin1String("FlowControl")] = QtEnumToString(flowControl());

    QJsonDocument doc(paramsObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

QString LaserXSerialPort::getUUID() const
{
    return mUUID;
}

void LaserXSerialPort::setParameters(const QString& params)
{
    QJsonParseError jsonError;
    QByteArray jsonData = params.toUtf8();
    QJsonDocument doc = QJsonDocument::fromJson(jsonData, &jsonError);
    if (QJsonParseError::NoError != jsonError.error)
    {
        emit parameterParseError(jsonError.errorString());
    }
    else
    {
        const QJsonObject paramsObj = doc.object();
        if (paramsObj.contains(QLatin1String("Direction")))
        {
            setDirection(QtStringToEnum(paramsObj[QLatin1String("Direction")].toString(), AllDirections));
        }

        if (paramsObj.contains(QLatin1String("BaudRate")))
        {
            setBaudRate(QtStringToEnum(paramsObj[QLatin1String("BaudRate")].toString(), Baud9600));
        }

        if (paramsObj.contains(QLatin1String("DataBits")))
        {
            setDataBits(QtStringToEnum(paramsObj[QLatin1String("DataBits")].toString(), Data8));
        }

        if (paramsObj.contains(QLatin1String("Parity")))
        {
            setParity(QtStringToEnum(paramsObj[QLatin1String("Parity")].toString(), NoParity));
        }

        if (paramsObj.contains(QLatin1String("StopBits")))
        {
            setStopBits(QtStringToEnum(paramsObj[QLatin1String("StopBits")].toString(), OneStop));
        }

        if (paramsObj.contains(QLatin1String("FlowControl")))
        {
            setFlowControl(QtStringToEnum(paramsObj[QLatin1String("FlowControl")].toString(), NoFlowControl));
        }
    }
}

bool LaserXSerialPort::setDirection(Direction direction)
{
    if (mDirection != direction)
    {
        mDirection = direction;
        if (isOpen() && QSerialPort::NoError == error())
        {
            QSerialPort::close();
            QTimer::singleShot(1000, [this]() { LaserXSerialPort::open(ReadWrite); });
        }

        emit directionChanged(direction);
    }

    return true;
}

void LaserXSerialPort::onReadyRead()
{
    QSerialPort* clientConnection = qobject_cast<QSerialPort*>(sender());
    if (clientConnection)
    {
        if (2 == mDataMode)
        {
            qDebug() << QStringLiteral("SerialPort %1 received %2 bytes").arg(portName()).arg(clientConnection->bytesAvailable());
            return;
        }

        QByteArray cmdData;
        if (clientConnection->canReadLine())
        {
            cmdData = clientConnection->readLine();
        }
        else
        {
            cmdData = clientConnection->readAll();
        }

        if (mDataMode)
        {
            emit bytesReceived(cmdData);
        }
        else
        {
            QJsonParseError jsonError;
            QJsonDocument cmdDoc = QJsonDocument::fromJson(cmdData, &jsonError);
            if (QJsonParseError::NoError == jsonError.error)
            {
                emit jsonReceived(cmdDoc);
            }
            else
            {
                QString iString = QString::fromUtf8(cmdData);
                if (!iString.isEmpty())
                {
                    emit stringReceived(iString.trimmed());
                }
                else
                {
                    emit bytesReceived(cmdData);
                }
            }
        }
    }
}

QString LaserXSerialPort::description() const
{
    if (!mDescription.isEmpty())
    {
        return mDescription;
    }

    QList<QSerialPortInfo> portInfos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo& portInfo : portInfos)
    {
        if (portInfo.portName() == portName())
        {
            mDescription = portInfo.description();
            break;
        }
    }

    return mDescription;
}

void LaserXSerialPort::setDataMode(const int dataMode)
{
    if (dataMode != mDataMode)
    {
        mDataMode = dataMode;
    }
}
