#ifndef MAZ_LENS_CONTROLLER_H
#define MAZ_LENS_CONTROLLER_H

#include "laser_x_devices_global.h"
#include <laser_x_lens_controller.h>
#include <QtCore>

class MAZController : public LaserXLensController
{
    Q_OBJECT
public:
    MAZController(QObject* parent);
    MAZController(QObject* parent, const QString& uuid);

public:
    ~MAZController();

public:
    qreal magnification(const int msecs) const override;
    bool setMagnification(const qreal newVal, const int msecs) override;
    bool goHome(const int msecs) override;
    QString getJson() const override;
    void setJson(const QString& params) override;

    void connectDevice() override;
    void disconnectDevice() override;

    bool sendQueryMagnification() const override;
    bool sendSetMagnification(const qreal newVal) override;
    bool sendGoHome() override;
    bool sendQueryErrorNumPulses() const override;
    bool sendQueryMotorStatus() const override;

private:
    void onReadyRead();
    int parseHomeRemainingNumPulses(const QByteArray& replyBytes);
    int parseZoomRemainingNumPulses(const QByteArray &replyBytes);
    qreal parseCurrentMagnification(const QByteArray& replyBytes);
    int parseErrorNumPulses(const QByteArray& replyBytes);
    int parseMotorStatus(const QByteArray& replyBytes);

private:
    Q_DISABLE_COPY_MOVE(MAZController)
};

#endif // MAZ_LENS_CONTROLLER_H
