#include "maz_controller.h"
#include <QtCore>
#include <laser_x_util.h>

MAZController::MAZController(QObject* parent)
    : LaserXLensController(parent, QStringLiteral("MAZController"))
{
    setDescription(QStringLiteral("MAZ Lens Controller"));
}

MAZController::MAZController(QObject* parent, const QString& uuid)
    : LaserXLensController(parent, QStringLiteral("MAZController"), uuid)
{
    setDescription(QStringLiteral("MAZ Lens Controller"));
}

MAZController::~MAZController()
{
}

qreal MAZController::magnification(const int msecs) const
{
    std::array<char, 5> cmdBytes;
    cmdBytes[0] = 0XAB;
    cmdBytes[1] = 0X21;
    cmdBytes[2] = 0X00;
    cmdBytes[3] = 0X00;
    cmdBytes[4] = 0XCD;

    QIODevice* icommDev = commDevice();
    if (!icommDev)
    {
        qDebug() << QLatin1String("MAZController communication device not available");
        return 0.;
    }

    qint64 numBytesWritten = icommDev->write(cmdBytes.data(), cmdBytes.size());
    if (numBytesWritten != cmdBytes.size())
    {
        qDebug() << QLatin1String("MAZController write communication device failed");
        return 0.;
    }

    QElapsedTimer timer;
    timer.start();
    while (!timer.hasExpired(msecs))
    {
        QThread::msleep(100);
        if (icommDev->bytesAvailable() >= 5)
        {
            break;
        }
    }

    QByteArray replyBytes = icommDev->read(5);
    emit responseReceived(replyBytes);
    if (replyBytes.size() == 5 && replyBytes[0] == 0xAB && replyBytes[1] == 0x53 && replyBytes[4] == 0xCD)
    {
        const qint16* iMag = reinterpret_cast<const qint16*>(replyBytes.constData() + 2);
        return (*iMag) / 100.;
    }
    else
    {
        qDebug() << QLatin1String("MAZController read communication device failed");
        return 0.;
    }
}

bool MAZController::setMagnification(const qreal newVal, const int msecs)
{
    std::array<char, 5> cmdBytes;
    cmdBytes[0] = 0XAB;
    cmdBytes[1] = 0X11;
    cmdBytes[2] = 0X00;
    cmdBytes[3] = 0X00;
    cmdBytes[4] = 0XCD;

    qint16* iMag = reinterpret_cast<qint16*>(cmdBytes.data() + 2);
    *iMag = static_cast<qint16>(qRound(newVal * 100));

    QIODevice* icommDev = commDevice();
    if (!icommDev) 
    {
        qDebug() << QLatin1String("MAZController communication device not available");
        return false;
    }

    qint64 numBytesWritten = icommDev->write(cmdBytes.data(), cmdBytes.size());
    if (numBytesWritten != cmdBytes.size())
    {
        qDebug() << QLatin1String("MAZController write communication device failed");
        return false;
    }

    QElapsedTimer timer;
    while (!timer.hasExpired(msecs))
    {
        QThread::msleep(100);
        if (icommDev->bytesAvailable() >= 5)
        {
            QByteArray replyBytes = icommDev->read(5);
            emit responseReceived(replyBytes);
            if (replyBytes.size() != 5)
            {
                qDebug() << QLatin1String("MAZController read communication device failed");
                return false;
            }

            int iZoomRemaining = 9999;
            int iErrorNumPulses = 9999;

            if (replyBytes[0] == 0xAB && replyBytes[4] == 0xCD)
            {
                switch (replyBytes[1])
                {
                case 0x51:
                    emit homeRemainingNumPulsesReceived(parseHomeRemainingNumPulses(replyBytes));
                    break;

                case 0x52:
                    iZoomRemaining = parseZoomRemainingNumPulses(replyBytes);
                    emit zoomRemainingNumPulsesReceived(iZoomRemaining);
                    break;

                case 0x53:
                    emit currentMagnificationReceived(parseCurrentMagnification(replyBytes));
                    break;

                case 0x54:
                    iErrorNumPulses = parseErrorNumPulses(replyBytes);
                    emit errorNumPulsesReceived(iErrorNumPulses);
                    break;

                case 0x57:
                    emit motorStatusReceived(parseMotorStatus(replyBytes));
                    break;

                default:
                    qDebug() << QLatin1String("MAZController read communication device failed");
                    return false;
                }
            }
            else
            {
                qDebug() << QLatin1String("MAZController read communication device failed");
                return false;
            }

            if (iZoomRemaining < 1)
            {
                return true;
            }
        }
    }

    qDebug() << QLatin1String("MAZController set magnification timed out");
    return false;
}

bool MAZController::goHome(const int msecs)
{
    std::array<char, 5> cmdBytes;
    cmdBytes[0] = 0XAB;
    cmdBytes[1] = 0XE5;
    cmdBytes[2] = 0X00;
    cmdBytes[3] = 0X00;
    cmdBytes[4] = 0XCD;

    QIODevice* icommDev = commDevice();
    if (!icommDev)
    {
        qDebug() << QLatin1String("MAZController communication device not available");
        return false;
    }

    qint64 numBytesWritten = icommDev->write(cmdBytes.data(), cmdBytes.size());
    if (numBytesWritten != cmdBytes.size())
    {
        qDebug() << QLatin1String("MAZController write communication device failed");
        return false;
    }

    QElapsedTimer timer;
    while (!timer.hasExpired(msecs))
    {
        QThread::msleep(100);
        if (icommDev->bytesAvailable() >= 5)
        {
            QByteArray replyBytes = icommDev->read(5);
            emit responseReceived(replyBytes);
            if (replyBytes.size() != 5)
            {
                qDebug() << QLatin1String("MAZController read communication device failed");
                return false;
            }

            int iHomeRemaining = 9999;
            int iErrorNumPulses = 9999;

            if (replyBytes[0] == 0xAB && replyBytes[4] == 0xCD)
            {
                switch (replyBytes[1])
                {
                case 0x51:
                    iHomeRemaining = parseHomeRemainingNumPulses(replyBytes);
                    emit homeRemainingNumPulsesReceived(iHomeRemaining);
                    break;

                case 0x52:
                    emit zoomRemainingNumPulsesReceived(parseZoomRemainingNumPulses(replyBytes));
                    break;

                case 0x53:
                    emit currentMagnificationReceived(parseCurrentMagnification(replyBytes));
                    break;

                case 0x54:
                    iErrorNumPulses = parseErrorNumPulses(replyBytes);
                    emit errorNumPulsesReceived(iErrorNumPulses);
                    break;

                case 0x57:
                    emit motorStatusReceived(parseMotorStatus(replyBytes));
                    break;

                default:
                    qDebug() << QLatin1String("MAZController read communication device failed");
                    return false;
                }
            }
            else
            {
                qDebug() << QLatin1String("MAZController read communication device failed");
                return false;
            }

            if (iHomeRemaining < 1)
            {
                return true;
            }
        }
    }

    qDebug() << QLatin1String("MAZController go home timed out");
    return false;
}

QString MAZController::getJson() const
{
    QJsonObject rootObj;

    LaserXLensController::getJson(rootObj);

    QJsonDocument doc(rootObj);
    QByteArray buffer = doc.toJson(QJsonDocument::Compact);
    return QString::fromUtf8(buffer);
}

void MAZController::setJson(const QString& params)
{
    QByteArray jsonData = params.toUtf8();
    QJsonParseError jsonError;
    QJsonDocument loadDoc(QJsonDocument::fromJson(jsonData, &jsonError));
    if (QJsonParseError::NoError != jsonError.error)
    {
        qCritical() << jsonError.errorString();
        return;
    }

    const QJsonObject jsonObj = loadDoc.object();
    LaserXLensController::setJson(jsonObj);
}

void MAZController::connectDevice()
{
    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        connect(icommDev, &QIODevice::readyRead, this, &MAZController::onReadyRead);
    }
}

void MAZController::disconnectDevice()
{
    QIODevice* icommDev = commDevice();
    if (icommDev)
    {
        disconnect(icommDev, &QIODevice::readyRead, this, &MAZController::onReadyRead);
    }
}

bool MAZController::sendQueryMagnification() const
{
    std::array<char, 5> cmdBytes;
    cmdBytes[0] = 0XAB;
    cmdBytes[1] = 0X21;
    cmdBytes[2] = 0X00;
    cmdBytes[3] = 0X00;
    cmdBytes[4] = 0XCD;

    QIODevice* icommDev = commDevice();
    if (!icommDev)
    {
        qDebug() << QLatin1String("MAZController communication device not available");
        return false;
    }

    qint64 numBytesWritten = icommDev->write(cmdBytes.data(), cmdBytes.size());
    if (numBytesWritten != cmdBytes.size())
    {
        qDebug() << QLatin1String("MAZController write communication device failed");
        return false;
    }
    else
    {
        return true;
    }
}

bool MAZController::sendSetMagnification(const qreal newVal)
{
    std::array<char, 5> cmdBytes;
    cmdBytes[0] = 0XAB;
    cmdBytes[1] = 0X11;
    cmdBytes[2] = 0X00;
    cmdBytes[3] = 0X00;
    cmdBytes[4] = 0XCD;

    qint16* iMag = reinterpret_cast<qint16*>(cmdBytes.data() + 2);
    *iMag = static_cast<qint16>(qRound(newVal * 100));

    QIODevice* icommDev = commDevice();
    if (!icommDev)
    {
        qDebug() << QLatin1String("MAZController communication device not available");
        return false;
    }

    qint64 numBytesWritten = icommDev->write(cmdBytes.data(), cmdBytes.size());
    if (numBytesWritten != cmdBytes.size())
    {
        qDebug() << QLatin1String("MAZController write communication device failed");
        return false;
    }
    else
    {
        return true;
    }
}

bool MAZController::sendGoHome()
{
    std::array<char, 5> cmdBytes;
    cmdBytes[0] = 0XAB;
    cmdBytes[1] = 0XE5;
    cmdBytes[2] = 0X00;
    cmdBytes[3] = 0X00;
    cmdBytes[4] = 0XCD;

    QIODevice* icommDev = commDevice();
    if (!icommDev)
    {
        qDebug() << QLatin1String("MAZController communication device not available");
        return false;
    }

    qint64 numBytesWritten = icommDev->write(cmdBytes.data(), cmdBytes.size());
    if (numBytesWritten != cmdBytes.size())
    {
        qDebug() << QLatin1String("MAZController write communication device failed");
        return false;
    }
    else
    {
        return true;
    }
}

bool MAZController::sendQueryErrorNumPulses() const
{
    std::array<char, 5> cmdBytes;
    cmdBytes[0] = 0XAB;
    cmdBytes[1] = 0X22;
    cmdBytes[2] = 0X00;
    cmdBytes[3] = 0X00;
    cmdBytes[4] = 0XCD;

    QIODevice* icommDev = commDevice();
    if (!icommDev)
    {
        qDebug() << QLatin1String("MAZController communication device not available");
        return false;
    }

    qint64 numBytesWritten = icommDev->write(cmdBytes.data(), cmdBytes.size());
    if (numBytesWritten != cmdBytes.size())
    {
        qDebug() << QLatin1String("MAZController write communication device failed");
        return false;
    }
    else
    {
        return true;
    }
}

bool MAZController::sendQueryMotorStatus() const
{
    std::array<char, 5> cmdBytes;
    cmdBytes[0] = 0XAB;
    cmdBytes[1] = 0X25;
    cmdBytes[2] = 0X00;
    cmdBytes[3] = 0X00;
    cmdBytes[4] = 0XCD;

    QIODevice* icommDev = commDevice();
    if (!icommDev)
    {
        qDebug() << QLatin1String("MAZController communication device not available");
        return false;
    }

    qint64 numBytesWritten = icommDev->write(cmdBytes.data(), cmdBytes.size());
    if (numBytesWritten != cmdBytes.size())
    {
        qDebug() << QLatin1String("MAZController write communication device failed");
        return false;
    }
    else
    {
        return true;
    }
}

void MAZController::onReadyRead()
{
    QIODevice* iPort = qobject_cast<QIODevice*>(sender());
    if (iPort && iPort->bytesAvailable() >= 5)
    {
        QByteArray replyBytes = iPort->read(5);
        if (!replyBytes.isEmpty())
        {
            emit responseReceived(replyBytes);
        }

        if (5 == replyBytes.size() && replyBytes[0] == 0xAB && replyBytes[4] == 0xCD)
        {
            switch (replyBytes[1])
            {
            case 0x51:
                emit homeRemainingNumPulsesReceived(parseHomeRemainingNumPulses(replyBytes));
                break;

            case 0x52:
                emit zoomRemainingNumPulsesReceived(parseZoomRemainingNumPulses(replyBytes));
                break;

            case 0x53:
                emit currentMagnificationReceived(parseCurrentMagnification(replyBytes));
                break;

            case 0x54:
                emit errorNumPulsesReceived(parseErrorNumPulses(replyBytes));
                break;

            case 0x57:
                emit motorStatusReceived(parseMotorStatus(replyBytes));
                break;

            default:
                qDebug() << QLatin1String("MAZController read communication device failed");
            }
        }
    }
}

int MAZController::parseHomeRemainingNumPulses(const QByteArray& replyBytes)
{
    const qint16* iNumPulses = reinterpret_cast<const qint16*>(replyBytes.constData() + 2);
    return *iNumPulses;
}

int MAZController::parseZoomRemainingNumPulses(const QByteArray& replyBytes)
{
    const qint16* iNumPulses = reinterpret_cast<const qint16*>(replyBytes.constData() + 2);
    return *iNumPulses;
}

qreal MAZController::parseCurrentMagnification(const QByteArray& replyBytes)
{
    const qint16* iMag = reinterpret_cast<const qint16*>(replyBytes.constData() + 2);
    return (*iMag) / 100.;
}

int MAZController::parseErrorNumPulses(const QByteArray& replyBytes)
{
    const qint16* iNumPulses = reinterpret_cast<const qint16*>(replyBytes.constData() + 2);
    return *iNumPulses;
}

int MAZController::parseMotorStatus(const QByteArray& replyBytes)
{
    const qint8* iMotorStatus = reinterpret_cast<const qint8*>(replyBytes.constData() + 3);
    return *iMotorStatus;
}
