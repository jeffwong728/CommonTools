#include "camera_thread.h"
#include "laser_x_devicemanager.h"

CameraThread::CameraThread(LaserXDeviceManager* parent)
    : QThread(parent)
    , devManager(parent)
{
}

void CameraThread::run()
{
    for(;;)
    {
        {
            QMutexLocker waitLocker(&devManager->mCameraMutex);
            devManager->mCameraLiveStarted.wait(&devManager->mCameraMutex);
        }

        for (;;)
        {
            QThread::yieldCurrentThread();
            QMutexLocker grabLocker(&devManager->mCameraMutex);
            if (devManager->mLiveCameras.isEmpty())
            {
                break;
            }

            if (mLiveIndex >= devManager->mLiveCameras.size())
            {
                mLiveIndex = 0;
            }

            LaserXCamera* cam = devManager->mLiveCameras.constData()[mLiveIndex++];
            if (!cam)
            {
                return;
            }

            if (!cam->isContinuousGrab())
            {
                continue;
            }

            if (devManager->mLivePending > 0)
            {
                continue;
            }

            int iFPS = cam->getFPS();
            QThread::msleep(iFPS ? 1000 / iFPS : 50);

            cv::Mat iMat = cam->tryLiveGrab(1000);
            if (iMat.empty())
            {
                continue;
            }

            QVariantMap infos;
            devManager->mLivePending += 1;
            emit cam->imageReady(iMat, infos);
        }
    }
}
