#include "laser_x_lens_controller.h"
#include "laser_x_devicemanager.h"
#include "laser_x_serialport.h"
#include <QtCore>
#include <laser_x_util.h>

LaserXLensController::LaserXLensController(QObject* parent, const QString& type)
    : LaserXLensController(parent, type, QUuid::createUuid().toString())
{
}

LaserXLensController::LaserXLensController(QObject* parent, const QString& type, const QString& uuid)
    : QObject(parent)
    , mType(type)
    , mUUID(uuid)
{
}

LaserXLensController::~LaserXLensController()
{
}

QString LaserXLensController::uuid() const
{
    return mUUID;
}

QString LaserXLensController::type() const
{
    return mType;
}

QIODevice* LaserXLensController::commDevice() const
{
    if (QStringLiteral("SerialPort") == mCommType)
    {
        LaserXDeviceManager* iDevs = qobject_cast<LaserXDeviceManager*>(parent());
        if (iDevs)
        {
            LaserXSerialPort* iPort = iDevs->findSerialPort(mCommSource);
            if (iPort)
            {
                iPort->setDataMode(2);
            }
            return iPort;
        }
    }

    return nullptr;
}

void LaserXLensController::getJson(QJsonObject& rootObj) const
{
    rootObj[QLatin1String("Name")] = mName;
    rootObj[QLatin1String("Description")] = mDescription;
    rootObj[QLatin1String("CommType")] = mCommType;
    rootObj[QLatin1String("CommSource")] = mCommSource;
}

void LaserXLensController::setJson(const QJsonObject& jsonObj)
{
    mName = fromJson(jsonObj, QLatin1String("Name"), QString());
    mDescription = fromJson(jsonObj, QLatin1String("Description"), QString());
    mCommType = fromJson(jsonObj, QLatin1String("CommType"), QString());
    mCommSource = fromJson(jsonObj, QLatin1String("CommSource"), QString());
}

QString LaserXLensController::name() const
{
    return mName;
}

void LaserXLensController::setName(const QString& newVal)
{
    if (newVal != mName)
    {
        QString oldVal = mName;
        mName = newVal;
        emit nameChanged(oldVal, newVal);
    }
}

QString LaserXLensController::commType() const
{
    return mCommType;
}

void LaserXLensController::setCommType(const QString& newVal)
{
    if (newVal != mCommType)
    {
        mCommType = newVal;
    }
}

QString LaserXLensController::commSource() const
{
    return mCommSource;
}

QString LaserXLensController::commSourceName() const
{
    if (QStringLiteral("SerialPort") == mCommType)
    {
        LaserXDeviceManager* iDevs = qobject_cast<LaserXDeviceManager*>(parent());
        if (iDevs)
        {
            LaserXSerialPort *iPort = iDevs->findSerialPort(mCommSource);
            if (iPort)
            {
                return iPort->portName();
            }
        }
    }

    return QStringLiteral("UNDEFINED");
}

void LaserXLensController::setCommSource(const QString& newVal)
{
    if (newVal != mCommSource)
    {
        mCommSource = newVal;
    }
}

QString LaserXLensController::description() const
{
    return mDescription;
}

void LaserXLensController::setDescription(const QString& newVal)
{
    if (newVal != mDescription)
    {
        mDescription = newVal;
    }
}

qreal LaserXLensController::magnificationMin() const
{
    return mMagnificationMin;
}

void LaserXLensController::setMagnificationMin(const qreal newVal)
{
    if (newVal != mMagnificationMin)
    {
        mMagnificationMin = newVal;
    }
}

qreal LaserXLensController::magnificationMax() const
{
    return mMagnificationMax;
}

void LaserXLensController::setMagnificationMax(const qreal newVal)
{
    if (newVal != mMagnificationMax)
    {
        mMagnificationMax = newVal;
    }
}
